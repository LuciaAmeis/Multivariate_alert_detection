#'##############################################################################
#                                                                              #
#                  Corresponding R Code to the Manuscript                      #
#                "Estimating effect thresholds and beyond:                     #
#              A flexible framework for multivariate alert detection"          #
#                                                                              #
#                                 Authors                                      #
#                    L. Ameis, N. Hagemann and K. Moellenhoff                  #
#                                                                              #
#                               Master file                                    #
#                                                                              #
#'##############################################################################

#'==============================================================================
# Library ====
#'==============================================================================
library("tibble")
library("plotly")   
library("reticulate")
library("dplyr")
library("tidyr")
library("matrixStats")
library("Biobase")
library("qpcR")
library("parallel")
library("foreach")
library("doParallel")
library("doSNOW")
library("stats4") 
#library("MASS")   
library("gamlss")
library("minpack.lm")
library("grDevices")
#library("readr")
#library("gsubfn")
library("patchwork")
library("magick")
library("pdftools")
library("grid")
#library("xlsx")
library("openxlsx")
library("DoseFinding")
library("purrr")

#' Of note, the package gamlss.nl is loaded from an archived version on CRAN R
#' since no current version is available
#' Please uncomment the following two lines to install

#url <- "https://cran.r-project.org/src/contrib/Archive/gamlss.nl/gamlss.nl_4.1-0.tar.gz"
#install.packages(url, repos = NULL, type = "source")

library("gamlss.nl")

#' Of note, the package ICAOD is loaded from an archived version on CRAN R
#' since no current version is available
#' It is required for the td2pLL package
#' Please uncomment the following two lines to install

#url <- "https://cran.r-project.org/src/contrib/Archive/ICAOD/ICAOD_1.0.1.tar.gz"
#install.packages(url, repos = NULL, type = "source")

#' With this, we can now install the package "td2pLL" from gitHub
#' It contains the parametric function and the dataset used in the Case Study

#devtools::install_github("jcduda/td2pLL", build_vignettes = TRUE)
library("td2pLL")

#'==============================================================================
# Parallelisation ====
#'==============================================================================
#Parallelisation
n.cores<-parallel::detectCores()-1
my.cluster<-parallel::makeCluster(
  n.cores,
  type="PSOCK"
)

#'==============================================================================
# Working Directory (Please change before running) ====
#'==============================================================================

# Please change the following path to the storage location of the master file
setwd("please set")

#'==============================================================================
# Handling tmp plot files (Please consider before running) ====
#'==============================================================================


#' To handle large white endges, when creating plotly plots, the plot
#' is saved as pdf in the folder plots_tables/tmp_plots, read in as png, cleaned 
#' and afterwards saved as pdf in the plots_tables again.
#' The following value decides, if the file in the tmp_plots folder is 
#' deleted (T) automatically, or not (F)

clean_tmp_file <- T

#'==============================================================================
# Preparations ====
#'==============================================================================
#'------------------------------------------------------------------------------
## Functions ----
#'------------------------------------------------------------------------------

# This file includes all functions needed for the analysis and the simulations
# Please always run first
# general functions
source("./base/base_TDR.R")
#first add cytotox specific models 
#also simplifies the bootstrap, critval_boot and conf.bands
#functions fitting to the cytotox data
#Please run before running the case study
#Pleas run base_TDR.R first
#Is used for the following analysis
source("./base/base_cytotox_TDR.R")

#'------------------------------------------------------------------------------
## Data ----
#'------------------------------------------------------------------------------

# Preparation of the data file used for the case study and template for the 
# simulations
# Please run beforehand
source("./data_preparation/data_preparation_TDR.R")

#'==============================================================================
# Simulation Study ====
#'==============================================================================
#'

#'------------------------------------------------------------------------------
## Scenario 0 ----
#'------------------------------------------------------------------------------
#'------------------------------------------------------------------------------
### Data generation ----
#'------------------------------------------------------------------------------

source("./simulation/simulation_scenario0_alt_TDR.R")

#'------------------------------------------------------------------------------
### Run simulation ----
#'------------------------------------------------------------------------------

source("./simulation/scenario0_alt_run_simulation_TDR.R")

#'------------------------------------------------------------------------------
### Simulation Results ----
#'------------------------------------------------------------------------------

# Of note, the simulations are time consuming. Therefore, the code is written such 
# that a prepared .RData file is loaded instead 
source("./simulation/scenario0_alt_analysis_simulation_TDR.R")


#'------------------------------------------------------------------------------
## Scenario 1 ----
#'------------------------------------------------------------------------------
#'------------------------------------------------------------------------------
### Data generation ----
#'------------------------------------------------------------------------------

source("./simulation/simulation_scenario1_TDR.R")

#'------------------------------------------------------------------------------
### Run simulation ----
#'------------------------------------------------------------------------------

source("./simulation/scenario1_run_simulation_TDR.R")

#'------------------------------------------------------------------------------
### Simulation Results ----
#'------------------------------------------------------------------------------

# Of note, the simulations are time consuming. Therefore, the code is written such 
# that a prepared .RData file is loaded instead 
source("./simulation/scenario1_analysis_simulation_TDR.R")


#'------------------------------------------------------------------------------
## Scenario 2 ----
#'------------------------------------------------------------------------------
#'------------------------------------------------------------------------------
### Data generation ----
#'------------------------------------------------------------------------------

source("./simulation/simulation_scenario2_TDR.R")

#'------------------------------------------------------------------------------
### Run simulation ----
#'------------------------------------------------------------------------------

source("./simulation/scenario2_run_simulation_TDR.R")

#'------------------------------------------------------------------------------
### Simulation Results ----
#'------------------------------------------------------------------------------

# Of note, the simulations are time consuming. Therefore, the code is written such 
# that a prepared .RData file is loaded instead 
source("./simulation/scenario2_analysis_simulation_TDR.R")


#'==============================================================================
# Case Study ====
#'==============================================================================

#first add cytotox specific models 
#also simplifies the bootstrap, critval_boot and conf.bands
#functions fitting to the cytotox data
#Please run before running the case study
#Pleas run base_TDR.R first
#Should already be run above, just to be safe
#source("./base/base_cytotox_TDR.R")

#runs case study
source("./case_study/case_study_TDR.R")
#reduced
source("./case_study/case_study_reduced_TDR.R")

#additionally, the analysis was conducted with the more
#complicated hypothesis
#first, we return the functions to their original form
source("./base/base_TDR.R")

#runs centered case study (used for the explanatory picture)
source("./case_study/case_study_centered_TDR.R")
#reduced
source("./case_study/case_study_centered_reduced_TDR.R")

#'==============================================================================
# Plots and Tables ====
#'==============================================================================

source("./plot_generation/plot_generation_function_TDR.R")

#'==============================================================================
# Session Info ====
#'==============================================================================

#sessionInfo()
# R version 4.5.0 (2025-04-11 ucrt)
# Platform: x86_64-w64-mingw32/x64
# Running under: Windows 11 x64 (build 26200)
# 
# Matrix products: default
# LAPACK version 3.12.1
# 
# locale:
#   [1] LC_COLLATE=German_Germany.utf8  LC_CTYPE=German_Germany.utf8    LC_MONETARY=German_Germany.utf8
# [4] LC_NUMERIC=C                    LC_TIME=German_Germany.utf8    
# 
# time zone: Europe/Berlin
# tzcode source: internal
# 
# attached base packages:
#   [1] grid      splines   stats4    parallel  stats     graphics  grDevices utils     datasets  methods   base     
# 
# other attached packages:
#   [1] td2pLL_1.0.0        gamlss.nl_4.1-0     survival_3.8-3      purrr_1.1.0         DoseFinding_1.4-1   openxlsx_4.2.8.1   
# [7] pdftools_3.6.0      magick_2.8.7        patchwork_1.3.0     gamlss_5.4-22       nlme_3.1-168        gamlss.dist_6.1-1  
# [13] gamlss.data_6.0-6   doSNOW_1.0.20       snow_0.4-4          doParallel_1.0.17   iterators_1.0.14    foreach_1.5.2      
# [19] qpcR_1.4-2          Matrix_1.7-3        robustbase_0.99-4-1 rgl_1.3.18          minpack.lm_1.2-4    MASS_7.3-65        
# [25] Biobase_2.69.0      BiocGenerics_0.55.0 generics_0.1.4      matrixStats_1.5.0   tidyr_1.3.1         dplyr_1.1.4        
# [31] reticulate_1.42.0   plotly_4.11.0       ggplot2_3.5.2      
# 
# loaded via a namespace (and not attached):
#   [1] tidyselect_1.2.1    viridisLite_0.4.2   farver_2.1.2        fastmap_1.2.0       lazyeval_0.2.2      TH.data_1.1-3      
# [7] digest_0.6.37       lifecycle_1.0.4     qpdf_1.4.1          statmod_1.5.0       magrittr_2.0.3      compiler_4.5.0     
# [13] rlang_1.1.6         drc_3.0-1           tools_4.5.0         plotrix_3.8-4       data.table_1.17.8   knitr_1.50         
# [19] sn_2.1.1            askpass_1.2.1       htmlwidgets_1.6.4   mnormt_2.1.1        RColorBrewer_1.1-3  multcomp_1.4-28    
# [25] abind_1.4-8         withr_3.0.2         numDeriv_2016.8-1.1 gtools_3.9.5        scales_1.4.0        cli_3.6.5          
# [31] mvtnorm_1.3-3       mvQuad_1.0-8        rstudioapi_0.17.1   httr_1.4.7          base64enc_0.1-3     vctrs_0.6.5        
# [37] sandwich_3.1-1      carData_3.0-5       jsonlite_2.0.0      car_3.1-3           ggrepel_0.9.6       Formula_1.2-5      
# [43] ICAOD_1.0.1         glue_1.8.0          nloptr_2.2.1        DEoptimR_1.1-3-1    codetools_0.2-20    stringi_1.8.7      
# [49] cubature_2.1.4      gtable_0.3.6        tibble_3.3.0        pillar_1.11.0       htmltools_0.5.8.1   R6_2.6.1           
# [55] evaluate_1.0.4      lattice_0.22-7      png_0.1-8           Rcpp_1.1.0          zip_2.3.3           xfun_0.52          
# [61] zoo_1.8-14          pkgconfig_2.0.3   