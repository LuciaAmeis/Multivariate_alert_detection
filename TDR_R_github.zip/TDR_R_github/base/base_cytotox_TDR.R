#'##############################################################################
#                                                                              #
#                  Corresponding R Code to the Manuscript                      #
#                "Estimating effect thresholds and beyond:                     #
#              A flexible framework for multivariate alert detection"          #
#                                                                              #
#                                 Authors                                      #
#                    L. Ameis, N. Hagemann and K. Moellenhoff                  #
#                                                                              #
#                   Base file - Cytotox specific functions                     #
#                                                                              #
#'##############################################################################

#'==============================================================================
# Model function ====
#'==============================================================================

#'------------------------------------------------------------------------------
#'td2pLL ---
#'------------------------------------------------------------------------------

#model 
td2pLL <- function(t, d, theta){
  #t time
  #d dose
  #theta parameters of the function
  
  #extract parameters
  h     <- theta[1]
  Delta <- theta[2]
  gamma <- theta[3]
  C0    <- theta[4]
  
  #calculate response
  z<-100-100*(d^h/(d^h+(Delta*t^(-gamma)+C0)^h))
  
  #return response
  z
}

#Of note, on our server, the td2pLL package could not be installed. Therefore
#the follwing function had to be removed and rewritten, see scenario1_run_simulation
#for details

td2pLL_fast <- function(data){
  fit <- tryCatch({fit_td2pLL(data[,1:3])}, error=function(e){
    NA
  })
  fit
}

td2pLL_formula <- ~100 - 100 * (dose^h / (dose^h + (Delta * time^(-gamma) + C0)^h))


#'------------------------------------------------------------------------------
#' schuettler et al formula ----
#' -----------------------------------------------------------------------------

#model
schuettler <- function(t,d,theta){
  #t time
  #d dose
  #theta parameters of the function
  
  #extract parameters
  log2FC_max <- theta[1]
  slope <- theta[2]
  S_max <- theta[3]
  t_max <- theta[4]
  S_dur <- theta[5]
  
  z <- log2FC_max/(
    1+exp(
      -slope*(
        log(d)-log(
          1/(
            S_max*exp(
              -0.5*(
                (log(t)-log(t_max))/S_dur
              )^2
            )
          )
        )
      )
    )
  )
  
  #return response
  z
  
}


schuettler_formula <- ~ log2FC_max/(
  1+exp(
    -slope*(
      log(dose)-log(
        1/(
          S_max*exp(
            -0.5*(
              (log(time)-log(t_max))/S_dur
            )^2
          )
        )
      )
    )
  )
)


schuettler_fast <- function (data){
  fit <- tryCatch({nlsLM(resp ~ log2FC_max/(
    1+exp(
      -slope*(
        log(dose)-log(
          1/(
            S_max*exp(
              -0.5*(
                (log(time)-log(t_max))/S_dur
              )^2
            )
          )
        )
      )
    )
  ),
          data = data,
          start = mu_start )}, error=function(e){
            NA
          })
  fit
}

  

#'==============================================================================
# Bootstrap ====
#'==============================================================================
#bootstrap
bootstrap <- function(sd, par, B, time, dose, donor=NA, fast=F){
  #sd is standard deviation
  #par is theta
  #B is number of bootstrap runs
  #time is time vector of original data set
  #dose is dose vector of original data set
  #donor is donor vector of original data set (optional if used for sigma_formula)
  
  fits <- list() #store ests 
  boot<-matrix(NA, nrow=B, ncol=nrow(grid_full)) #store results from run
  fail_runs <- numeric(B)   #number of runs, that don't converge
  for(i in 1:B){
    data_boot <- simul(sd=sd, par=par, time=time, dose=dose, donor=donor)
    if(fast==T){
      fit_boot <- modelfit_robust_fast(data_boot)  
    } else{
    fit_boot <- modelfit_robust(data_boot)
    }
    fits[[i]] <- fit_boot
    if(sum(is.na(fit_boot$coef))>0){
      fail_runs[[i]]<-1
    }
    boot[i,] <- model(t=grid_full$time,
                      d=grid_full$dose,
                      theta=fit_boot$coef)
  }
  return(list("fit"=fits, "boot"=boot,"failed_runs"=sum(fail_runs)))
}

#Of note, on our server, the td2pLL package could not be installed. Therefore
#it had to be removed from line 203, see scenario1_run_simulation for details
#on how this problem is handeled

#bootstrap crit value
critval_boot <- function(outerboot, B_in, B_out, sd, par, time, dose,seeds ,donor=NA,fixtime=F,fast_in=F,upper_or_lower="upper"){
  #sd is standard deviation
  #par is theta
  #B_in is number of inner bootstrap runs
  #B_out is number of outer bootstrap runs
  #time is time vector of original data set
  #dose is dose vector of original data set
  #donor is donor vector of original data set (optional if used for sigma_formula)
  #seed vector for inner boostrap
  #upper_or_lower upper or lower confidence band
  
  if(fixtime==F){
    #store
    D <- numeric(nrow(grid_full))
    
  } else{
   grid_fixtime <- grid_full %>%
                    filter(time==fixtime)
    
    indices_fixtime <- which(grid_full$time==fixtime)
    #store
    D <- numeric(nrow(grid_full)+nrow(grid_fixtime))
  }
   
  all_failed_runs <- numeric(1)
  
    #inner boostrap using parallelization
  doParallel::registerDoParallel(cl=my.cluster)
  res <- foreach (m=1:B_out,
                  .combine ="rbind",
                  .export=c("mu_formula","sigma_formula","mu_start","sigma_start","model",
                            "fit_fast","bootstrap","simul","grid_full",
                            "td2pLL","td2pLL_fast","modelfit_robust","modelfit_robust_fast",
                            "schuettler","schuettler_fast",
                            "schuettler_formula","max_dose"),
                  .packages = c("minpack.lm","td2pLL","qpcR","gamlss","gamlss.nl","dplyr","stats4")) %dopar% {
                   set.seed(seeds[m]) 
      
                    if(anyNA(outerboot$fit[[m]]$coef)==T){
                      all_failed_runs <- B_in
                      D <-  rep(NA,length(D))
                    } else{
                      
                    
                   #inner boostrap
                 inner_boot <- bootstrap(par=outerboot$fit[[m]]$coef,
                                               sd=outerboot$fit[[m]]$sd,
                                                B=B_in,
                                                time=time,
                                                dose=dose,
                                                donor=donor,
                                                fast=fast_in) # inner bootstrap for estimating the SE*
                 
                 
                 all_failed_runs <- inner_boot$failed_runs
                 inner_boot <- inner_boot$boot
                 if(fixtime==F){
                 for(l in 1:(nrow(grid_full))){
                      #calculate difference 
                   if(upper_or_lower=="upper"){
                      D[l] <-(model(t=grid_full$time[l],d=grid_full$dose[l],theta=par)-outerboot$boot[m,l])/sd(inner_boot[,l],na.rm=T)
                   } else{
                     if(upper_or_lower=="lower"){
                       D[l] <-(outerboot$boot[m,l]-model(t=grid_full$time[l],d=grid_full$dose[l],theta=par))/sd(inner_boot[,l],na.rm=T)
                     }  
                     
                   } 
                    }
                     } else{
                       for(l in 1:(nrow(grid_full))){
                        #calculate difference 
                         if(upper_or_lower=="upper"){
                         D[l] <-(model(t=grid_full$time[l],d=grid_full$dose[l],theta=par)-outerboot$boot[m,l])/sd(inner_boot[,l],na.rm=T)
                         } else{
                           if(upper_or_lower=="lower"){
                             D[l] <-(outerboot$boot[m,l]-model(t=grid_full$time[l],d=grid_full$dose[l],theta=par))/sd(inner_boot[,l],na.rm=T)
                           }
                           
                         }
                         
                         }
                      for(l in 1:(nrow(grid_fixtime))){
                       #calculate difference
                        indice <- indices_fixtime[l]
                        if(upper_or_lower=="upper"){
                        D[nrow(grid_full)+l] <-(model(t=grid_fixtime$time[l],
                                                       d=grid_fixtime$dose[l],
                                                       theta=par)-outerboot$boot[m,indice])/sd(inner_boot[,indice],na.rm=T)
                        } else{
                          if(upper_or_lower=="lower"){
                       D[nrow(grid_full)+l] <-(outerboot$boot[m,indice]-model(t=grid_fixtime$time[l],
                                                          d=grid_fixtime$dose[l],
                                                          theta=par))/sd(inner_boot[,indice],na.rm=T)
                            
                            
                          }
                          
                        }
                        
                        }
                    }
                    D <- as.numeric(D)
                    }
                    D_add <- c(D,all_failed_runs)
                    D_add
                  }
  stopImplicitCluster()
  #return results
  res_boot <- res[,1:(ncol(res)-1)]
  all_failed_runs <- res[,ncol(res)]
  
  return(list("res"=res_boot,"all_failed_runs"=all_failed_runs))
}

#'==============================================================================
# Evaluation ====
#'==============================================================================

#estimate confidence band
conf.bands <- function(par, c, outerboot, fixtime=F,upper_or_lower="upper"){
  #par theta
  #c result from function crit.val (quantile of dufference)
  #outerboot results outer boostrap
  if(upper_or_lower=="upper"){
  if(fixtime==F){
    #store confidence band
    up.cf_full<-numeric(nrow(grid_full))
    
  } else{
    c_full <- c$full
    c_fixtime <- c$fix
    grid_fixtime <- grid_full %>%
      filter(time==fixtime)
    
    #store confidence band
    up.cf_full<-numeric(nrow(grid_full))
    up.cf_fixtime<-numeric(nrow(grid_fixtime))
    
    indices_fixtime <- which(grid_full$time==fixtime)
    
  }
  
  
  if(fixtime==F){
    #calculate confidence band for grid
    for(l in 1:(nrow(grid_full))){
      tx <- model(t=grid_full$time[l],
                   d=grid_full$dose[l],
                   theta=par) 
      #pointwise estimated variance (each l is one point of the grid)
      var.FC <- var(outerboot$boot[,l],na.rm = T)
      corfac <- c*sqrt(var.FC)
      up.cf_full[l] <- tx + corfac

    }
  return(up.cf=up.cf_full)
  } else{
    #calculate confidence band for grid
    for(l in 1:(nrow(grid_full))){
      tx <- model(t=grid_full$time[l],
                   d=grid_full$dose[l],
                   theta=par) 
      #pointwise estimated variance (each l is one point of the grid)
      var.FC <- var(outerboot$boot[,l],na.rm = T)
      corfac <- c_full*sqrt(var.FC)
      up.cf_full[l] <- tx + corfac
      
    }
    
    for(l in 1:nrow(grid_fixtime)){
      tx <- model(t=grid_fixtime$time[l],
                   d=grid_fixtime$dose[l],
                   theta=par) 
      #pointwise estimated variance (each l is one point of the grid)
      var.FC <- var(outerboot$boot[,indices_fixtime[l]],na.rm = T)
      corfac <- c_fixtime*sqrt(var.FC)
      up.cf_fixtime[l] <- tx + corfac
    }
    up.cf <- list("full"=up.cf_full,"fixtime"=up.cf_fixtime)
  }
    
  } else{
    if(upper_or_lower=="lower"){
      
      if(fixtime==F){
        #store confidence band
        low.cf_full<-numeric(nrow(grid_full))
        
      } else{
        c_full <- c$full
        c_fixtime <- c$fix
        grid_fixtime <- grid_full %>%
          filter(time==fixtime)
        
        #store confidence band
        low.cf_full<-numeric(nrow(grid_full))
        low.cf_fixtime<-numeric(nrow(grid_fixtime))
        
        indices_fixtime <- which(grid_full$time==fixtime)
        
      }
      
      
      if(fixtime==F){
        #calculate confidence band for grid
        for(l in 1:(nrow(grid_full))){
          tx <- model(t=grid_full$time[l],
                      d=grid_full$dose[l],
                      theta=par) 
          #pointwise estimated variance (each l is one point of the grid)
          var.FC <- var(outerboot$boot[,l],na.rm = T)
          corfac <- c*sqrt(var.FC)
          low.cf_full[l] <- tx - corfac
          
        }
        return(low.cf=low.cf_full)
      } else{
        #calculate confidence band for grid
        for(l in 1:(nrow(grid_full))){
          tx <- model(t=grid_full$time[l],
                      d=grid_full$dose[l],
                      theta=par) 
          #pointwise estimated variance (each l is one point of the grid)
          var.FC <- var(outerboot$boot[,l],na.rm = T)
          corfac <- c_full*sqrt(var.FC)
          low.cf_full[l] <- tx - corfac
          
        }
        
        for(l in 1:nrow(grid_fixtime)){
          tx <- model(t=grid_fixtime$time[l],
                      d=grid_fixtime$dose[l],
                      theta=par) 
          #pointwise estimated variance (each l is one point of the grid)
          var.FC <- var(outerboot$boot[,indices_fixtime[l]],na.rm = T)
          corfac <- c_fixtime*sqrt(var.FC)
          low.cf_fixtime[l] <- tx - corfac
        }
        low.cf <- list("full"=low.cf_full,"fixtime"=low.cf_fixtime)
      }   
      
      
    }
    
    
  }
}
