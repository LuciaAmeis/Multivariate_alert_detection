#'##############################################################################
#                                                                              #
#                  Corresponding R Code to the Manuscript                      #
#                "Estimating effect thresholds and beyond:                     #
#              A flexible framework for multivariate alert detection"          #
#                                                                              #
#                                 Authors                                      #
#                    L. Ameis, N. Hagemann and K. Moellenhoff                  #
#                                                                              #
#                               Case study                                     #
#                                                                              #
#'##############################################################################

#'==============================================================================
# Analysis with td2pLL ====
#'==============================================================================

model <- td2pLL

fit_fast <- td2pLL_fast

mu_formula <- td2pLL_formula


#'------------------------------------------------------------------------------
## Basic mean model fit ----
#'------------------------------------------------------------------------------

#Investigate fitting start parameters
fit_jcd <- fit_td2pLL(data = data_subset[,2:4]) #Use modelfit from td2pLL package
summary(fit_jcd)                                #Start parameters for mean

mu_start <- list(h = 3, Delta = 6, gamma = 2, C0 = 5)


#'------------------------------------------------------------------------------
## Basic sd model fit  ----
#'------------------------------------------------------------------------------

#Prepare data set
data_subset_sd <- data_subset          %>%      #combine data via sd
  group_by(time,dose,donor)            %>%
  summarize(resp_sd=sd(resp))


#CASE 1: Constant
sigma_formula_case1 <- ~1
#identify starting values for constant case
error_model <- glm(                             #estimate error model with glm 
  resp_sd ~ 1,
  family = gaussian(link = "log"),              #Log-Link 
  data = data_subset_sd
)
summary(error_model)                            #start parameters for sd 

sigma_start_case1 <- coef(error_model)

#Fit gamlss
td2pLL_fit_gamlss_nl_donor_case1<-nlgamlss( y= resp,
                                      mu.fo = mu_formula, 
                                      sigma.fo = sigma_formula_case1,
                                      mu.start = mu_start,                         
                                      sigma.start = sigma_start_case1,                                                 # Startwerte für sigma
                                      family = NO(),                                                                  # Normalverteilung
                                      data = data_subset
)

td2pLL_fit_gamlss_nl_donor_case1$aic
#2137.09




#CASE 2: From Duda et al
sigma_formula_case2 <- ~ dose+I(dose^2)+time+I(dose^2):time
#identify starting values for constant case
error_model <- glm(                             #estimate error model with glm 
  resp_sd ~ dose+I(dose^2)+time+I(dose^2):time,
  family = gaussian(link = "log"),              #Log-Link 
  data = data_subset_sd
)
summary(error_model)                            #start parameters for sd 

sigma_start_case2 <- coef(error_model)

#Fit gamlss
td2pLL_fit_gamlss_nl_donor_case2<-nlgamlss( y= resp,
                                            mu.fo = mu_formula, 
                                            sigma.fo = sigma_formula_case2,
                                            mu.start = mu_start,                         
                                            sigma.start = sigma_start_case2,                                                 # Startwerte für sigma
                                            family = NO(),                                                                  # Normalverteilung
                                            data = data_subset
)

td2pLL_fit_gamlss_nl_donor_case2$aic
#2127.866

#'------------------------------------------------------------------------------
## Analysis (Fixtime 4) ----
#'------------------------------------------------------------------------------

#CASE 1

sigma_formula <- sigma_formula_case1
sigma_start <- sigma_start_case1
td2pLL_fit_gamlss_nl_donor<-td2pLL_fit_gamlss_nl_donor_case1



#Est conf band
if(file.exists("./case_study/td2pLL_analysis_gamlssnl_donor_CASE1.RData")){
  load("./case_study/td2pLL_analysis_gamlssnl_donor_CASE1.RData")
} else{
  set.seed(52)
  seeds_gamlssnl_donor <- runif(B_out, min = 0, max=1000000)
  outerbootstrap_gamlssnl_donor <- bootstrap(sd=td2pLL_fit_gamlss_nl_donor$sigma.coefficients,
                                             par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                             B=B_out,
                                             time=data_subset$time,
                                             dose=data_subset$dose,
                                             donor=data_subset$donor)
# system.time()
# user     system elapsed 
# 111.51    1.63  113.65 
  crit.val_boot_gamlssnl_donor <- critval_boot(outerboot=outerbootstrap_gamlssnl_donor,
                                               B_in=B_in,
                                               B_out=B_out,
                                               sd=td2pLL_fit_gamlss_nl_donor$sigma.coefficients,
                                               par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                               time=data_subset$time,
                                               dose=data_subset$dose,
                                               donor=data_subset$donor,
                                               seeds=seeds_gamlssnl_donor,
                                               fixtime = 4)
# system.time()
# user  system elapsed 
# 7.29    1.56  297.16 
  crit.val_gamlssnl_donor <- crit.val(crit.val.boot=crit.val_boot_gamlssnl_donor$res,
                                      alpha=0.05,
                                      fixtime=4)
  conf.band_gamlssnl_donor <- conf.bands(par=td2pLL_fit_gamlss_nl_donor$mu.coefficients, 
                                         c=crit.val_gamlssnl_donor, 
                                         outerboot = outerbootstrap_gamlssnl_donor,
                                         fixtime=4)
  
  td2pLL_analysis_gamlssnl_donor_CASE1 <- list("boot"=outerbootstrap_gamlssnl_donor,
                                         "crit_boot"=crit.val_boot_gamlssnl_donor,
                                         "crit_val"=crit.val_gamlssnl_donor,
                                         "conf"=conf.band_gamlssnl_donor)
  save(td2pLL_analysis_gamlssnl_donor_CASE1,
       file="./case_study/td2pLL_analysis_gamlssnl_donor_CASE1.RData")

}

min(which(td2pLL_analysis_gamlssnl_donor_CASE1$conf$fixtime<50))
#64
dose_seq[64]
#6.3


conf_band_mat_gamlssnl_donor <- td2pLL_analysis_gamlssnl_donor_CASE1$conf$full   %>%
  cbind(grid_full, "cf"=. )                %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

min(which(conf_band_mat_gamlssnl_donor[31,]<50))
#69
dose_seq[69]
#6.8

res_td2pLL_CASE1 <- c("td2pLL","Case 1","normal",dose_seq[64],dose_seq[69])


#CASE 2

sigma_formula <- sigma_formula_case2
sigma_start <- sigma_start_case2
td2pLL_fit_gamlss_nl_donor<-td2pLL_fit_gamlss_nl_donor_case2



#Est conf band
if(file.exists("./case_study/td2pLL_analysis_gamlssnl_donor_CASE2.RData")){
  load("./case_study/td2pLL_analysis_gamlssnl_donor_CASE2.RData")
} else{
  set.seed(557)
  seeds_gamlssnl_donor <- runif(B_out, min = 0, max=1000000)
  outerbootstrap_gamlssnl_donor <- bootstrap(sd=td2pLL_fit_gamlss_nl_donor$sigma.coefficients,
                                             par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                             B=B_out,
                                             time=data_subset$time,
                                             dose=data_subset$dose,
                                             donor=data_subset$donor)
  # system.time()
  # user     system elapsed 
  # 111.51    1.63  113.65 
  crit.val_boot_gamlssnl_donor <- critval_boot(outerboot=outerbootstrap_gamlssnl_donor,
                                               B_in=B_in,
                                               B_out=B_out,
                                               sd=td2pLL_fit_gamlss_nl_donor$sigma.coefficients,
                                               par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                               time=data_subset$time,
                                               dose=data_subset$dose,
                                               donor=data_subset$donor,
                                               seeds=seeds_gamlssnl_donor,
                                               fixtime = 4)
  # system.time()
  # user  system elapsed 
  # 7.29    1.56  297.16 
  crit.val_gamlssnl_donor <- crit.val(crit.val.boot=crit.val_boot_gamlssnl_donor$res,
                                      alpha=0.05,
                                      fixtime=4)
  conf.band_gamlssnl_donor <- conf.bands(par=td2pLL_fit_gamlss_nl_donor$mu.coefficients, 
                                         c=crit.val_gamlssnl_donor, 
                                         outerboot = outerbootstrap_gamlssnl_donor,
                                         fixtime=4)
  
  td2pLL_analysis_gamlssnl_donor_CASE2 <- list("boot"=outerbootstrap_gamlssnl_donor,
                                               "crit_boot"=crit.val_boot_gamlssnl_donor,
                                               "crit_val"=crit.val_gamlssnl_donor,
                                               "conf"=conf.band_gamlssnl_donor)
  save(td2pLL_analysis_gamlssnl_donor_CASE2,
       file="./case_study/td2pLL_analysis_gamlssnl_donor_CASE2.RData")
  
}

min(which(td2pLL_analysis_gamlssnl_donor_CASE2$conf$fixtime<50))
#57
dose_seq[57]
#5.6

conf_band_mat_gamlssnl_donor <- td2pLL_analysis_gamlssnl_donor_CASE2$conf$full   %>%
  cbind(grid_full, "cf"=. )                %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

min(which(conf_band_mat_gamlssnl_donor[31,]<50))
#57
dose_seq[57]
#5.6


res_td2pLL_CASE2 <- c("td2pLL","Case 2","normal",dose_seq[57],dose_seq[57])


#'------------------------------------------------------------------------------
## Analysis (Fixtime 4/Fast) ----
#'------------------------------------------------------------------------------

#CASE 1

sigma_formula <- sigma_formula_case1
sigma_start <- sigma_start_case1
td2pLL_fit_gamlss_nl_donor<-td2pLL_fit_gamlss_nl_donor_case1



#Est conf band
if(file.exists("./case_study/tdpLL_analysis_gamlssnl_donor_fast_CASE1.RData")){
  load("./case_study/tdpLL_analysis_gamlssnl_donor_fast_CASE1.RData")
} else{
  set.seed(7)
  seeds_gamlssnl_donor_fast <- runif(B_out, min = 0, max=1000000)
  outerbootstrap_gamlssnl_donor_fast <- bootstrap(sd=td2pLL_fit_gamlss_nl_donor$sigma.coefficients,
                                             par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                             B=B_out,
                                             time=data_subset$time,
                                             dose=data_subset$dose,
                                             donor=data_subset$donor)
# system.time()
# user  system elapsed 
# 115.38    2.39  120.03 
 crit.val_boot_gamlssnl_donor_fast <- critval_boot(outerboot=outerbootstrap_gamlssnl_donor_fast,
                                               B_in=B_in,
                                               B_out=B_out,
                                               sd=td2pLL_fit_gamlss_nl_donor$sigma.coefficients,
                                               par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                               time=data_subset$time,
                                               dose=data_subset$dose,
                                               donor=data_subset$donor,
                                               seeds=seeds_gamlssnl_donor_fast,
                                               fixtime = 4,
                                               fast_in=T)
# system.time()
# user  system elapsed 
# 7.34    1.50   59.45 
  crit.val_gamlssnl_donor_fast <- crit.val(crit.val.boot=crit.val_boot_gamlssnl_donor_fast$res,
                                      alpha=0.05,
                                      fixtime=4)
  conf.band_gamlssnl_donor_fast <- conf.bands(par=td2pLL_fit_gamlss_nl_donor$mu.coefficients, 
                                         c=crit.val_gamlssnl_donor_fast, 
                                         outerboot = outerbootstrap_gamlssnl_donor_fast,
                                         fixtime=4)
  
  td2pLL_analysis_gamlssnl_donor_fast_CASE1 <- list("boot"=outerbootstrap_gamlssnl_donor_fast,
                                              "crit_boot"=crit.val_boot_gamlssnl_donor_fast,
                                              "crit_val"=crit.val_gamlssnl_donor_fast,
                                              "conf"=conf.band_gamlssnl_donor_fast)
  save(td2pLL_analysis_gamlssnl_donor_fast_CASE1,
       file="./case_study/tdpLL_analysis_gamlssnl_donor_fast_CASE1.RData")
  
}


min(which(td2pLL_analysis_gamlssnl_donor_fast_CASE1$conf$fixtime<50))
#65
dose_seq[65]
#6.4

conf_band_mat_gamlssnl_donor_fast <- td2pLL_analysis_gamlssnl_donor_fast_CASE1$conf$full   %>%
  cbind(grid_full, "cf"=. )                %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

min(which(conf_band_mat_gamlssnl_donor_fast[31,]<50))
#69
dose_seq[69]
#6.8

res_td2pLL_CASE1_fast <- c("td2pLL","Case 1","fast",dose_seq[65],dose_seq[69])


#CASE 2

sigma_formula <- sigma_formula_case2
sigma_start <- sigma_start_case2
td2pLL_fit_gamlss_nl_donor<-td2pLL_fit_gamlss_nl_donor_case2



#Est conf band
if(file.exists("./case_study/tdpLL_analysis_gamlssnl_donor_fast_CASE2.RData")){
  load("./case_study/tdpLL_analysis_gamlssnl_donor_fast_CASE2.RData")
} else{
  set.seed(777)
  seeds_gamlssnl_donor_fast <- runif(B_out, min = 0, max=1000000)
  outerbootstrap_gamlssnl_donor_fast <- bootstrap(sd=td2pLL_fit_gamlss_nl_donor$sigma.coefficients,
                                                  par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                                  B=B_out,
                                                  time=data_subset$time,
                                                  dose=data_subset$dose,
                                                  donor=data_subset$donor)
  # system.time()
  # user  system elapsed 
  # 115.38    2.39  120.03 
  crit.val_boot_gamlssnl_donor_fast <- critval_boot(outerboot=outerbootstrap_gamlssnl_donor_fast,
                                                    B_in=B_in,
                                                    B_out=B_out,
                                                    sd=td2pLL_fit_gamlss_nl_donor$sigma.coefficients,
                                                    par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                                    time=data_subset$time,
                                                    dose=data_subset$dose,
                                                    donor=data_subset$donor,
                                                    seeds=seeds_gamlssnl_donor_fast,
                                                    fixtime = 4,
                                                    fast_in=T)
  # system.time()
  # user  system elapsed 
  # 7.34    1.50   59.45 
  crit.val_gamlssnl_donor_fast <- crit.val(crit.val.boot=crit.val_boot_gamlssnl_donor_fast$res,
                                           alpha=0.05,
                                           fixtime=4)
  conf.band_gamlssnl_donor_fast <- conf.bands(par=td2pLL_fit_gamlss_nl_donor$mu.coefficients, 
                                              c=crit.val_gamlssnl_donor_fast, 
                                              outerboot = outerbootstrap_gamlssnl_donor_fast,
                                              fixtime=4)
  
  td2pLL_analysis_gamlssnl_donor_fast_CASE2 <- list("boot"=outerbootstrap_gamlssnl_donor_fast,
                                                    "crit_boot"=crit.val_boot_gamlssnl_donor_fast,
                                                    "crit_val"=crit.val_gamlssnl_donor_fast,
                                                    "conf"=conf.band_gamlssnl_donor_fast)
  save(td2pLL_analysis_gamlssnl_donor_fast_CASE2,
       file="./case_study/tdpLL_analysis_gamlssnl_donor_fast_CASE2.RData")
  
}


min(which(td2pLL_analysis_gamlssnl_donor_fast_CASE2$conf$fixtime<50))
#55
dose_seq[55]
#5.4

conf_band_mat_gamlssnl_donor_fast <- td2pLL_analysis_gamlssnl_donor_fast_CASE2$conf$full   %>%
  cbind(grid_full, "cf"=. )                %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

min(which(conf_band_mat_gamlssnl_donor_fast[31,]<50))
#55
dose_seq[55]
#5.4

res_td2pLL_CASE2_fast <- c("td2pLL","Case 2","fast",dose_seq[55],dose_seq[55])

#'==============================================================================
# Analysis with schuettler formula ====
#'==============================================================================

model <- schuettler

fit_fast <- schuettler_fast

mu_formula <- schuettler_formula

#'------------------------------------------------------------------------------
## Basic model fit ----
#'------------------------------------------------------------------------------

#Investigate fitting start parameters
fit_schuettler <- nlsLM(resp ~ log2FC_max/(                         #Use basic model fit
  1+exp(
    -slope*(
      log(dose)-log(
        1/(
          S_max*exp(
            -0.5*(
              (log(time)-log(t_max))/S_dur
            )^2
          )
        )
      )
    )
  )
),
data = data_subset,
start = list(log2FC_max=100,slope = -3, S_max = 0.2, t_max = 5.5, S_dur = 1.4) )
summary(fit_schuettler)                                       

mu_start <- list(log2FC_max=100,slope = -3, S_max=0.2,t_max=7, S_dur=1.5)


#'------------------------------------------------------------------------------
## Basic sd model fit  ----
#'------------------------------------------------------------------------------

#Prepare data set
data_subset_sd <- data_subset          %>%      #combine data via sd
  group_by(time,dose,donor)            %>%
  summarize(resp_sd=sd(resp))

#CASE 1: Constant
sigma_formula_case1 <- ~1
#identify starting values for constant case
error_model <- glm(                             #estimate error model with glm 
  resp_sd ~ 1,
  family = gaussian(link = "log"),              #Log-Link 
  data = data_subset_sd
)
summary(error_model)                            #start parameters for sd 

sigma_start_case1 <- coef(error_model)

#Fit gamlss
schuettler_fit_gamlss_nl_donor_case1 <-nlgamlss( y= resp,
                                            mu.fo = mu_formula, 
                                            sigma.fo = sigma_formula_case1,
                                            mu.start = mu_start,                         
                                            sigma.start = sigma_start_case1,                                                 # Startwerte für sigma
                                            family = NO(),                                                                  # Normalverteilung
                                            data = data_subset
)

schuettler_fit_gamlss_nl_donor_case1$aic
#2137.68


#CASE 2: From Duda et al
sigma_formula_case2 <- ~ dose+I(dose^2)+time+I(dose^2):time
#identify starting values for constant case
error_model <- glm(                             #estimate error model with glm 
  resp_sd ~ dose+I(dose^2)+time+I(dose^2):time,
  family = gaussian(link = "log"),              #Log-Link 
  data = data_subset_sd
)
summary(error_model)                            #start parameters for sd 

sigma_start_case2 <- coef(error_model)

#Fit gamlss
schuettler_fit_gamlss_nl_donor_case2 <-nlgamlss( y= resp,
                                            mu.fo = mu_formula, 
                                            sigma.fo = sigma_formula_case2,
                                            mu.start = mu_start,                         
                                            sigma.start = sigma_start_case2,                                                 # Startwerte für sigma
                                            family = NO(),                                                                  # Normalverteilung
                                            data = data_subset
)

schuettler_fit_gamlss_nl_donor_case2$aic
#2125.422




#'------------------------------------------------------------------------------
## Analysis (Fixtime 4) ----
#'------------------------------------------------------------------------------

#CASE 1

sigma_formula <- sigma_formula_case1
sigma_start <- sigma_start_case1
schuettler_fit_gamlss_nl_donor<-schuettler_fit_gamlss_nl_donor_case1


#Est conf band
if(file.exists("./case_study/schuettler_analysis_gamlssnl_donor_CASE1.RData")){
  load("./case_study/schuettler_analysis_gamlssnl_donor_CASE1.RData")
} else{
  set.seed(11)
  seeds_gamlssnl_donor <- runif(B_out, min = 0, max=1000000)
  outerbootstrap_gamlssnl_donor <- bootstrap(sd=schuettler_fit_gamlss_nl_donor$sigma.coefficients,
                                             par=schuettler_fit_gamlss_nl_donor$mu.coefficients,
                                             B=B_out,
                                             time=data_subset$time,
                                             dose=data_subset$dose,
                                             donor=data_subset$donor)
  # system.time()
  # user  system elapsed 
  # 102.71    0.59  103.95  
  crit.val_boot_gamlssnl_donor <- critval_boot(outerboot=outerbootstrap_gamlssnl_donor,
                                               B_in=B_in,
                                               B_out=B_out,
                                               sd=schuettler_fit_gamlss_nl_donor$sigma.coefficients,
                                               par=schuettler_fit_gamlss_nl_donor$mu.coefficients,
                                               time=data_subset$time,
                                               dose=data_subset$dose,
                                               donor=data_subset$donor,
                                               seeds=seeds_gamlssnl_donor,
                                               fixtime = 4)
  # system.time()
  # user  system elapsed 
  # 6.73    1.85  313.44 
  crit.val_gamlssnl_donor <- crit.val(crit.val.boot=crit.val_boot_gamlssnl_donor$res,
                                      alpha=0.05,
                                      fixtime=4)
  conf.band_gamlssnl_donor <- conf.bands(par=schuettler_fit_gamlss_nl_donor$mu.coefficients, 
                                         c=crit.val_gamlssnl_donor, 
                                         outerboot = outerbootstrap_gamlssnl_donor,
                                         fixtime=4)
  
  schuettler_analysis_gamlssnl_donor_CASE1 <- list("boot"=outerbootstrap_gamlssnl_donor,
                                         "crit_boot"=crit.val_boot_gamlssnl_donor,
                                         "crit_val"=crit.val_gamlssnl_donor,
                                         "conf"=conf.band_gamlssnl_donor)
  save(schuettler_analysis_gamlssnl_donor_CASE1,
       file="./case_study/schuettler_analysis_gamlssnl_donor_CASE1.RData")
  
}


min(which(schuettler_analysis_gamlssnl_donor_CASE1$conf$fixtime<50))
#68
dose_seq[68]
#6.7

conf_band_mat_gamlssnl_donor <- schuettler_analysis_gamlssnl_donor_CASE1$conf$full   %>%
  cbind(grid_full, "cf"=. )                %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

min(which(conf_band_mat_gamlssnl_donor[31,]<50))
#73
dose_seq[73]
#7.2


res_schuettler_CASE1 <- c("schuettler","Case 1","normal",dose_seq[68],dose_seq[73])


#CASE 2

sigma_formula <- sigma_formula_case2
sigma_start <- sigma_start_case2
schuettler_fit_gamlss_nl_donor<-schuettler_fit_gamlss_nl_donor_case2


#Est conf band
if(file.exists("./case_study/schuettler_analysis_gamlssnl_donor_CASE2.RData")){
  load("./case_study/schuettler_analysis_gamlssnl_donor_CASE2.RData")
} else{
  set.seed(111111)
  seeds_gamlssnl_donor <- runif(B_out, min = 0, max=1000000)
  outerbootstrap_gamlssnl_donor <- bootstrap(sd=schuettler_fit_gamlss_nl_donor$sigma.coefficients,
                                             par=schuettler_fit_gamlss_nl_donor$mu.coefficients,
                                             B=B_out,
                                             time=data_subset$time,
                                             dose=data_subset$dose,
                                             donor=data_subset$donor)
  # system.time()
  # user  system elapsed 
  # 102.71    0.59  103.95  
  crit.val_boot_gamlssnl_donor <- critval_boot(outerboot=outerbootstrap_gamlssnl_donor,
                                               B_in=B_in,
                                               B_out=B_out,
                                               sd=schuettler_fit_gamlss_nl_donor$sigma.coefficients,
                                               par=schuettler_fit_gamlss_nl_donor$mu.coefficients,
                                               time=data_subset$time,
                                               dose=data_subset$dose,
                                               donor=data_subset$donor,
                                               seeds=seeds_gamlssnl_donor,
                                               fixtime = 4)
  # system.time()
  # user  system elapsed 
  # 6.73    1.85  313.44 
  crit.val_gamlssnl_donor <- crit.val(crit.val.boot=crit.val_boot_gamlssnl_donor$res,
                                      alpha=0.05,
                                      fixtime=4)
  conf.band_gamlssnl_donor <- conf.bands(par=schuettler_fit_gamlss_nl_donor$mu.coefficients, 
                                         c=crit.val_gamlssnl_donor, 
                                         outerboot = outerbootstrap_gamlssnl_donor,
                                         fixtime=4)
  
  schuettler_analysis_gamlssnl_donor_CASE2 <- list("boot"=outerbootstrap_gamlssnl_donor,
                                                   "crit_boot"=crit.val_boot_gamlssnl_donor,
                                                   "crit_val"=crit.val_gamlssnl_donor,
                                                   "conf"=conf.band_gamlssnl_donor)
  save(schuettler_analysis_gamlssnl_donor_CASE2,
       file="./case_study/schuettler_analysis_gamlssnl_donor_CASE2.RData")
  
}


min(which(schuettler_analysis_gamlssnl_donor_CASE2$conf$fixtime<50))
#55
dose_seq[55]
#5.4

conf_band_mat_gamlssnl_donor <- schuettler_analysis_gamlssnl_donor_CASE2$conf$full   %>%
  cbind(grid_full, "cf"=. )                %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

min(which(conf_band_mat_gamlssnl_donor[31,]<50))
#57
dose_seq[57]
#5.6

res_schuettler_CASE2 <- c("schuettler","Case 2","normal",dose_seq[55],dose_seq[57])


#'------------------------------------------------------------------------------
## Analysis (Fixtime 4/Fast)  ----
#'------------------------------------------------------------------------------


#CASE 1

sigma_formula <- sigma_formula_case1
sigma_start <- sigma_start_case1
schuettler_fit_gamlss_nl_donor<-schuettler_fit_gamlss_nl_donor_case1


#Est conf band
if(file.exists("./case_study/schuettler_analysis_gamlssnl_donor_fast_CASE1.RData")){
  load("./case_study/schuettler_analysis_gamlssnl_donor_fast_CASE1.RData")
} else{
  set.seed(13)
  seeds_gamlssnl_donor_fast <- runif(B_out, min = 0, max=1000000)
  outerbootstrap_gamlssnl_donor_fast <- bootstrap(sd=schuettler_fit_gamlss_nl_donor$sigma.coefficients,
                                                  par=schuettler_fit_gamlss_nl_donor$mu.coefficients,
                                                  B=B_out,
                                                  time=data_subset$time,
                                                  dose=data_subset$dose,
                                                  donor=data_subset$donor)
  # system.time()
  # user  system elapsed 
  #  102.64    0.42  103.58 
  crit.val_boot_gamlssnl_donor_fast <- critval_boot(outerboot=outerbootstrap_gamlssnl_donor_fast,
                                                    B_in=B_in,
                                                    B_out=B_out,
                                                    sd=schuettler_fit_gamlss_nl_donor$sigma.coefficients,
                                                    par=schuettler_fit_gamlss_nl_donor$mu.coefficients,
                                                    time=data_subset$time,
                                                    dose=data_subset$dose,
                                                    donor=data_subset$donor,
                                                    seeds=seeds_gamlssnl_donor_fast,
                                                    fixtime = 4,
                                                    fast_in=T)
  # system.time()
  # user  system elapsed 
  # 5.84    1.48   43.39 
  crit.val_gamlssnl_donor_fast <- crit.val(crit.val.boot=crit.val_boot_gamlssnl_donor_fast$res,
                                           alpha=0.05,
                                           fixtime=4)
  conf.band_gamlssnl_donor_fast <- conf.bands(par=schuettler_fit_gamlss_nl_donor$mu.coefficients, 
                                              c=crit.val_gamlssnl_donor_fast, 
                                              outerboot = outerbootstrap_gamlssnl_donor_fast,
                                              fixtime=4)
  
  schuettler_analysis_gamlssnl_donor_fast_CASE1 <- list("boot"=outerbootstrap_gamlssnl_donor_fast,
                                                "crit_boot"=crit.val_boot_gamlssnl_donor_fast,
                                                "crit_val"=crit.val_gamlssnl_donor_fast,
                                                "conf"=conf.band_gamlssnl_donor_fast)
  save(schuettler_analysis_gamlssnl_donor_fast_CASE1,
       file="./case_study/schuettler_analysis_gamlssnl_donor_fast_CASE1.RData")
  
}


min(which(schuettler_analysis_gamlssnl_donor_fast_CASE1$conf$fixtime<50))
#67
dose_seq[67]
#6.6

conf_band_mat_gamlssnl_donor_fast <- schuettler_analysis_gamlssnl_donor_fast_CASE1$conf$full   %>%
  cbind(grid_full, "cf"=. )                %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

min(which(conf_band_mat_gamlssnl_donor_fast[31,]<50))
#69
dose_seq[69]
#6.8


res_schuettler_CASE1_fast <- c("schuettler","Case 1","fast",dose_seq[67],dose_seq[69])


#CASE 2

sigma_formula <- sigma_formula_case2
sigma_start <- sigma_start_case2
schuettler_fit_gamlss_nl_donor<-schuettler_fit_gamlss_nl_donor_case2


#Est conf band
if(file.exists("./case_study/schuettler_analysis_gamlssnl_donor_fast_CASE2.RData")){
  load("./case_study/schuettler_analysis_gamlssnl_donor_fast_CASE2.RData")
} else{
  set.seed(131313)
  seeds_gamlssnl_donor_fast <- runif(B_out, min = 0, max=1000000)
  outerbootstrap_gamlssnl_donor_fast <- bootstrap(sd=schuettler_fit_gamlss_nl_donor$sigma.coefficients,
                                                  par=schuettler_fit_gamlss_nl_donor$mu.coefficients,
                                                  B=B_out,
                                                  time=data_subset$time,
                                                  dose=data_subset$dose,
                                                  donor=data_subset$donor)
  # system.time()
  # user  system elapsed 
  #  102.64    0.42  103.58 
  crit.val_boot_gamlssnl_donor_fast <- critval_boot(outerboot=outerbootstrap_gamlssnl_donor_fast,
                                                    B_in=B_in,
                                                    B_out=B_out,
                                                    sd=schuettler_fit_gamlss_nl_donor$sigma.coefficients,
                                                    par=schuettler_fit_gamlss_nl_donor$mu.coefficients,
                                                    time=data_subset$time,
                                                    dose=data_subset$dose,
                                                    donor=data_subset$donor,
                                                    seeds=seeds_gamlssnl_donor_fast,
                                                    fixtime = 4,
                                                    fast_in=T)
  # system.time()
  # user  system elapsed 
  # 5.84    1.48   43.39 
  crit.val_gamlssnl_donor_fast <- crit.val(crit.val.boot=crit.val_boot_gamlssnl_donor_fast$res,
                                           alpha=0.05,
                                           fixtime=4)
  conf.band_gamlssnl_donor_fast <- conf.bands(par=schuettler_fit_gamlss_nl_donor$mu.coefficients, 
                                              c=crit.val_gamlssnl_donor_fast, 
                                              outerboot = outerbootstrap_gamlssnl_donor_fast,
                                              fixtime=4)
  
  schuettler_analysis_gamlssnl_donor_fast_CASE2 <- list("boot"=outerbootstrap_gamlssnl_donor_fast,
                                                        "crit_boot"=crit.val_boot_gamlssnl_donor_fast,
                                                        "crit_val"=crit.val_gamlssnl_donor_fast,
                                                        "conf"=conf.band_gamlssnl_donor_fast)
  save(schuettler_analysis_gamlssnl_donor_fast_CASE2,
       file="./case_study/schuettler_analysis_gamlssnl_donor_fast_CASE2.RData")
  
}


min(which(schuettler_analysis_gamlssnl_donor_fast_CASE2$conf$fixtime<50))
#53
dose_seq[53]
#5.2

conf_band_mat_gamlssnl_donor_fast <- schuettler_analysis_gamlssnl_donor_fast_CASE2$conf$full   %>%
  cbind(grid_full, "cf"=. )                %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

min(which(conf_band_mat_gamlssnl_donor_fast[31,]<50))
#55
dose_seq[55]
#5.4

res_schuettler_CASE2_fast <- c("schuettler","Case 2","fast",dose_seq[53],dose_seq[55])

#'------------------------------------------------------------------------------
#### Simultaneous inference ----
#'------------------------------------------------------------------------------

conf_band_mat_gamlssnl_donor <- schuettler_analysis_gamlssnl_donor_fast_CASE2$conf$full   %>%
  cbind(grid_full, "cf"=. )           %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

alert_gamlssnl_donor_c2_20 <- matrix(NA,nrow=length(time_seq),ncol=2)
for(i in length(time_seq):1){
  alert_gamlssnl_donor_c2_20[i,1] <- i
  alert_gamlssnl_donor_c2_20[i,2] <- min(subset(which(conf_band_mat_gamlssnl_donor<20,arr.ind=T)[,2],
                                                which(conf_band_mat_gamlssnl_donor<20,T)[,1]==i))
}

alert_gamlssnl_donor_c2_30 <- matrix(NA,nrow=length(time_seq),ncol=2)
for(i in length(time_seq):1){
  alert_gamlssnl_donor_c2_30[i,1] <- i
  alert_gamlssnl_donor_c2_30[i,2] <- min(subset(which(conf_band_mat_gamlssnl_donor<30,arr.ind=T)[,2],
                                                which(conf_band_mat_gamlssnl_donor<30,T)[,1]==i))
}

alert_gamlssnl_donor_c2_40 <- matrix(NA,nrow=length(time_seq),ncol=2)
for(i in length(time_seq):1){
  alert_gamlssnl_donor_c2_40[i,1] <- i
  alert_gamlssnl_donor_c2_40[i,2] <- min(subset(which(conf_band_mat_gamlssnl_donor<40,arr.ind=T)[,2],
                                                which(conf_band_mat_gamlssnl_donor<40,T)[,1]==i))
}


alert_gamlssnl_donor_c2_50 <- matrix(NA,nrow=length(time_seq),ncol=2)
for(i in length(time_seq):1){
  alert_gamlssnl_donor_c2_50[i,1] <- i
  alert_gamlssnl_donor_c2_50[i,2] <- min(subset(which(conf_band_mat_gamlssnl_donor<50,arr.ind=T)[,2],
                                                which(conf_band_mat_gamlssnl_donor<50,T)[,1]==i))
}

alert_gamlssnl_donor_c2_60 <- matrix(NA,nrow=length(time_seq),ncol=2)
for(i in length(time_seq):1){
  alert_gamlssnl_donor_c2_60[i,1] <- i
  alert_gamlssnl_donor_c2_60[i,2] <- min(subset(which(conf_band_mat_gamlssnl_donor<60,arr.ind=T)[,2],
                                                which(conf_band_mat_gamlssnl_donor<60,T)[,1]==i))
}

alert_gamlssnl_donor_c2_70 <- matrix(NA,nrow=length(time_seq),ncol=2)
for(i in length(time_seq):1){
  alert_gamlssnl_donor_c2_70[i,1] <- i
  alert_gamlssnl_donor_c2_70[i,2] <- min(subset(which(conf_band_mat_gamlssnl_donor<70,arr.ind=T)[,2],
                                                which(conf_band_mat_gamlssnl_donor<70,T)[,1]==i))
}

alert_gamlssnl_donor_c2_80 <- matrix(NA,nrow=length(time_seq),ncol=2)
for(i in length(time_seq):1){
  alert_gamlssnl_donor_c2_80[i,1] <- i
  alert_gamlssnl_donor_c2_80[i,2] <- min(subset(which(conf_band_mat_gamlssnl_donor<80,arr.ind=T)[,2],
                                                which(conf_band_mat_gamlssnl_donor<80,T)[,1]==i))
}

alert_gamlssnl_donor_c2_90 <- matrix(NA,nrow=length(time_seq),ncol=2)
for(i in length(time_seq):1){
  alert_gamlssnl_donor_c2_90[i,1] <- i
  alert_gamlssnl_donor_c2_90[i,2] <- min(subset(which(conf_band_mat_gamlssnl_donor<90,arr.ind=T)[,2],
                                                which(conf_band_mat_gamlssnl_donor<90,T)[,1]==i))
}

df_simultaneous_inference <- data.frame(
"20perc_diff_30perc"=c(
dose_seq[alert_gamlssnl_donor_c2_20[1,][2]]-dose_seq[alert_gamlssnl_donor_c2_30[1,][2]],
#NA
dose_seq[alert_gamlssnl_donor_c2_20[11,][2]]-dose_seq[alert_gamlssnl_donor_c2_30[11,][2]],
#NA
dose_seq[alert_gamlssnl_donor_c2_20[21,][2]]-dose_seq[alert_gamlssnl_donor_c2_30[21,][2]],
#1.5
dose_seq[alert_gamlssnl_donor_c2_20[31,][2]]-dose_seq[alert_gamlssnl_donor_c2_30[31,][2]],
#1.4
dose_seq[alert_gamlssnl_donor_c2_20[41,][2]]-dose_seq[alert_gamlssnl_donor_c2_30[41,][2]],
#1.4
dose_seq[alert_gamlssnl_donor_c2_20[51,][2]]-dose_seq[alert_gamlssnl_donor_c2_30[51,][2]],
#1.3
dose_seq[alert_gamlssnl_donor_c2_20[61,][2]]-dose_seq[alert_gamlssnl_donor_c2_30[61,][2]]
#1.3
),
"30perc_diff_40perc"=c(
dose_seq[alert_gamlssnl_donor_c2_30[1,][2]]-dose_seq[alert_gamlssnl_donor_c2_40[1,][2]],
#NA
dose_seq[alert_gamlssnl_donor_c2_30[11,][2]]-dose_seq[alert_gamlssnl_donor_c2_40[11,][2]],
#1.3
dose_seq[alert_gamlssnl_donor_c2_30[21,][2]]-dose_seq[alert_gamlssnl_donor_c2_40[21,][2]],
#1.1
dose_seq[alert_gamlssnl_donor_c2_30[31,][2]]-dose_seq[alert_gamlssnl_donor_c2_40[31,][2]],
#0.9
dose_seq[alert_gamlssnl_donor_c2_30[41,][2]]-dose_seq[alert_gamlssnl_donor_c2_40[41,][2]],
#0.9
dose_seq[alert_gamlssnl_donor_c2_30[51,][2]]-dose_seq[alert_gamlssnl_donor_c2_40[51,][2]],
#0.9
dose_seq[alert_gamlssnl_donor_c2_30[61,][2]]-dose_seq[alert_gamlssnl_donor_c2_40[61,][2]]
#0.9
),
"40perc_diff_50perc"=c(
dose_seq[alert_gamlssnl_donor_c2_40[1,][2]]-dose_seq[alert_gamlssnl_donor_c2_50[1,][2]],
#NA  
dose_seq[alert_gamlssnl_donor_c2_40[11,][2]]-dose_seq[alert_gamlssnl_donor_c2_50[11,][2]],
#1
dose_seq[alert_gamlssnl_donor_c2_40[21,][2]]-dose_seq[alert_gamlssnl_donor_c2_50[21,][2]],
#0.8
dose_seq[alert_gamlssnl_donor_c2_40[31,][2]]-dose_seq[alert_gamlssnl_donor_c2_50[31,][2]],
#0.8
dose_seq[alert_gamlssnl_donor_c2_40[41,][2]]-dose_seq[alert_gamlssnl_donor_c2_50[41,][2]],
#0.8
dose_seq[alert_gamlssnl_donor_c2_40[51,][2]]-dose_seq[alert_gamlssnl_donor_c2_50[51,][2]],
#0.7
dose_seq[alert_gamlssnl_donor_c2_40[61,][2]]-dose_seq[alert_gamlssnl_donor_c2_50[61,][2]]
#0.7
),
"50perc_diff_60perc"=c(
dose_seq[alert_gamlssnl_donor_c2_50[1,][2]]-dose_seq[alert_gamlssnl_donor_c2_60[1,][2]],
#NA  
dose_seq[alert_gamlssnl_donor_c2_50[11,][2]]-dose_seq[alert_gamlssnl_donor_c2_60[11,][2]],
#0.9
dose_seq[alert_gamlssnl_donor_c2_50[21,][2]]-dose_seq[alert_gamlssnl_donor_c2_60[21,][2]],
#0.7
dose_seq[alert_gamlssnl_donor_c2_50[31,][2]]-dose_seq[alert_gamlssnl_donor_c2_60[31,][2]],
#0.6
dose_seq[alert_gamlssnl_donor_c2_50[41,][2]]-dose_seq[alert_gamlssnl_donor_c2_60[41,][2]],
#0.6
dose_seq[alert_gamlssnl_donor_c2_50[51,][2]]-dose_seq[alert_gamlssnl_donor_c2_60[51,][2]],
#0.6
dose_seq[alert_gamlssnl_donor_c2_50[61,][2]]-dose_seq[alert_gamlssnl_donor_c2_60[61,][2]]
#0.6
),
"60perc_diff_70perc"=c(
dose_seq[alert_gamlssnl_donor_c2_60[1,][2]]-dose_seq[alert_gamlssnl_donor_c2_70[1,][2]],
#NA  
dose_seq[alert_gamlssnl_donor_c2_60[11,][2]]-dose_seq[alert_gamlssnl_donor_c2_70[11,][2]],
#0.8
dose_seq[alert_gamlssnl_donor_c2_60[21,][2]]-dose_seq[alert_gamlssnl_donor_c2_70[21,][2]],
#0.7
dose_seq[alert_gamlssnl_donor_c2_60[31,][2]]-dose_seq[alert_gamlssnl_donor_c2_70[31,][2]],
#0.6
dose_seq[alert_gamlssnl_donor_c2_60[41,][2]]-dose_seq[alert_gamlssnl_donor_c2_70[41,][2]],
#0.6
dose_seq[alert_gamlssnl_donor_c2_60[51,][2]]-dose_seq[alert_gamlssnl_donor_c2_70[51,][2]],
#0.6
dose_seq[alert_gamlssnl_donor_c2_60[61,][2]]-dose_seq[alert_gamlssnl_donor_c2_70[61,][2]]
#0.6
),
"70perc_diff_80perc"=c(
dose_seq[alert_gamlssnl_donor_c2_70[1,][2]]-dose_seq[alert_gamlssnl_donor_c2_80[1,][2]],
#1.4
dose_seq[alert_gamlssnl_donor_c2_70[11,][2]]-dose_seq[alert_gamlssnl_donor_c2_80[11,][2]],
#0.8
dose_seq[alert_gamlssnl_donor_c2_70[21,][2]]-dose_seq[alert_gamlssnl_donor_c2_80[21,][2]],
#0.7
dose_seq[alert_gamlssnl_donor_c2_70[31,][2]]-dose_seq[alert_gamlssnl_donor_c2_80[31,][2]],
#0.7
dose_seq[alert_gamlssnl_donor_c2_70[41,][2]]-dose_seq[alert_gamlssnl_donor_c2_80[41,][2]],
#0.7
dose_seq[alert_gamlssnl_donor_c2_70[51,][2]]-dose_seq[alert_gamlssnl_donor_c2_80[51,][2]],
#0.6
dose_seq[alert_gamlssnl_donor_c2_70[61,][2]]-dose_seq[alert_gamlssnl_donor_c2_80[61,][2]]
#0.6
),
"80perc_diff_90perc"=c(
dose_seq[alert_gamlssnl_donor_c2_80[1,][2]]-dose_seq[alert_gamlssnl_donor_c2_90[1,][2]],
#1.8
dose_seq[alert_gamlssnl_donor_c2_80[11,][2]]-dose_seq[alert_gamlssnl_donor_c2_90[11,][2]],
#1.1
dose_seq[alert_gamlssnl_donor_c2_80[21,][2]]-dose_seq[alert_gamlssnl_donor_c2_90[21,][2]],
#0.8
dose_seq[alert_gamlssnl_donor_c2_80[31,][2]]-dose_seq[alert_gamlssnl_donor_c2_90[31,][2]],
#0.7
dose_seq[alert_gamlssnl_donor_c2_80[41,][2]]-dose_seq[alert_gamlssnl_donor_c2_90[41,][2]],
#0.7
dose_seq[alert_gamlssnl_donor_c2_80[51,][2]]-dose_seq[alert_gamlssnl_donor_c2_90[51,][2]],
#0.7
dose_seq[alert_gamlssnl_donor_c2_80[61,][2]]-dose_seq[alert_gamlssnl_donor_c2_90[61,][2]]
#0.7
)
)

df_simultaneous_inference <- as.data.frame(t(df_simultaneous_inference))
colnames(df_simultaneous_inference) <- c("t=1","t=2","t=3","t=4","t=5","t=6","t=7")
rownames(df_simultaneous_inference) <- c("20%-30%",
                                         "30%-40%",
                                         "40%-50%",
                                         "50%-60%",
                                         "60%-70%",
                                         "70%-80%",
                                         "80%-90%")



#'==============================================================================
# Combine results in table ====
#'==============================================================================
#Note, that case 1 assumes constant standard deviation and therefore the normal
#and fast assumptions are identical
#Both were run to control the algorithm
#In the paper, only the fast results are presented, as there is a general
#focus on the fast approach

res_case_study <- rbind(#res_td2pLL_CASE1,
                        res_td2pLL_CASE1_fast,
                        res_td2pLL_CASE2,
                        res_td2pLL_CASE2_fast,
                        #res_schuettler_CASE1,
                        res_schuettler_CASE1_fast,
                        res_schuettler_CASE2,
                        res_schuettler_CASE2_fast)

colnames(res_case_study) <- c("Model","Case","Algorithm","2D alert","3D alert")
rownames(res_case_study) <- NULL
write.xlsx(res_case_study,"./plots_tables/001_res_case_study.xlsx", rowNames = FALSE)
