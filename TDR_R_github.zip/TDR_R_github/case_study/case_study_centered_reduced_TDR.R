#'##############################################################################
#                                                                              #
#                  Corresponding R Code to the Manuscript                      #
#                "Estimating effect thresholds and beyond:                     #
#              A flexible framework for multivariate alert detection"          #
#                                                                              #
#                                 Authors                                      #
#                    L. Ameis, N. Hagemann and K. Moellenhoff                  #
#                                                                              #
#                        Case study  - Centered                                #
#                                                                              #
#'##############################################################################

#'==============================================================================
#'Analysis with td2pLL ====
#'==============================================================================

model <- td2pLL

fit_fast <- td2pLL_fast

mu_formula <- td2pLL_formula


#'------------------------------------------------------------------------------
# Basic mean model fit ----
#'------------------------------------------------------------------------------

#Investigate fitting start parameters
fit_jcd <- fit_td2pLL(data = data_subset_reduced[,c(1,2,4)]) #Use modelfit from td2pLL package
summary(fit_jcd)                                #Start parameters for mean

mu_start <- list(h = 3, Delta = 6, gamma = 2, C0 = 5)


#'------------------------------------------------------------------------------
# Basic sd model fit  ----
#'------------------------------------------------------------------------------

#Prepare data set
data_subset_reduced_sd <- data_subset_reduced          %>%      #combine data via sd
  group_by(time,dose)            %>%
  summarize(resp_sd=sd(resp))

#CASE 1: Constant
sigma_formula_case1 <- ~1
#identify starting values for constant case
error_model <- glm(                             #estimate error model with glm 
  resp_sd ~ 1,
  family = gaussian(link = "log"),              #Log-Link 
  data = data_subset_reduced_sd
)
summary(error_model)                            #start parameters for sd 

sigma_start_case1 <- coef(error_model)

#Fit gamlss
td2pLL_fit_gamlss_nl_donor_reduced_case1<-nlgamlss( y= resp,
                                            mu.fo = mu_formula, 
                                            sigma.fo = sigma_formula_case1,
                                            mu.start = mu_start,                         
                                            sigma.start = sigma_start_case1,                                                 # Startwerte für sigma
                                            family = NO(),                                                                  # Normalverteilung
                                            data = data_subset_reduced
)

td2pLL_fit_gamlss_nl_donor_reduced_case1$aic
#440.0188


#CASE 2: From Duda et al
sigma_formula_case2 <- ~ dose+I(dose^2)+time+I(dose^2):time
#identify starting values for constant case
error_model <- glm(                             #estimate error model with glm 
  resp_sd ~ dose+I(dose^2)+time+I(dose^2):time,
  family = gaussian(link = "log"),              #Log-Link 
  data = data_subset_reduced_sd
)
summary(error_model)                            #start parameters for sd 

sigma_start_case2 <- coef(error_model)

#Fit gamlss
td2pLL_fit_gamlss_nl_donor_reduced_case2<-nlgamlss( y= resp,
                                            mu.fo = mu_formula, 
                                            sigma.fo = sigma_formula_case2,
                                            mu.start = mu_start,                         
                                            sigma.start = sigma_start_case2,                                                 # Startwerte für sigma
                                            family = NO(),                                                                  # Normalverteilung
                                            data = data_subset_reduced
)

td2pLL_fit_gamlss_nl_donor_reduced_case2$aic
#447.8604

#'------------------------------------------------------------------------------
# Analysis (Fixtime 4) ----
#'------------------------------------------------------------------------------

#CASE 1

sigma_formula <- sigma_formula_case1
sigma_start <- sigma_start_case1
td2pLL_fit_gamlss_nl_donor<-td2pLL_fit_gamlss_nl_donor_reduced_case1

#Est conf band
if(file.exists("./case_study/centered_td2pLL_analysis_gamlssnl_donor_reduced_CASE1.RData")){
  load("./case_study/centered_td2pLL_analysis_gamlssnl_donor_reduced_CASE1.RData")
} else{
  set.seed(1725)
  seeds_gamlssnl_donor <- runif(B_out, min = 0, max=1000000)
  outerbootstrap_gamlssnl_donor <- bootstrap(sd=td2pLL_fit_gamlss_nl_donor$sigma.coefficients,
                                                          par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                                          B=B_out,
                                                          time=data_subset_reduced$time,
                                                          dose=data_subset_reduced$dose,
                                                          donor=data_subset_reduced$donor,
                                                          fixtime=4)
  # system.time()
  # user     system elapsed 
  # 23.23    0.35   23.61 
  crit.val_boot_gamlssnl_donor <- critval_boot(outerboot=outerbootstrap_gamlssnl_donor,
                                                           B_in=B_in,
                                                           B_out=B_out,
                                                           sd=td2pLL_fit_gamlss_nl_donor$sigma.coefficients,
                                                           par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                                           time=data_subset_reduced$time,
                                                           dose=data_subset_reduced$dose,
                                                           donor=data_subset_reduced$donor,
                                                           seeds=seeds_gamlssnl_donor,
                                                           fixtime = 4)
  # system.time()
  # user  system elapsed 
  # 5.97    1.28  807.51 
  crit.val_gamlssnl_donor <- crit.val(crit.val.boot=crit.val_boot_gamlssnl_donor$res,
                                      alpha=0.05,
                                      fixtime=4)
  conf.band_gamlssnl_donor <- conf.bands(par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                         c=crit.val_gamlssnl_donor, 
                                         outerboot = outerbootstrap_gamlssnl_donor,
                                         fixtime=4)
  
  centered_td2pLL_analysis_gamlssnl_donor_reduced_CASE1 <- list("boot"=outerbootstrap_gamlssnl_donor,
                                                        "crit_boot"=crit.val_boot_gamlssnl_donor,
                                                        "crit_val"=crit.val_gamlssnl_donor,
                                                        "conf"=conf.band_gamlssnl_donor)
  save(centered_td2pLL_analysis_gamlssnl_donor_reduced_CASE1,
       file="./case_study/centered_td2pLL_analysis_gamlssnl_donor_reduced_CASE1.RData")
  
}

min(which(centered_td2pLL_analysis_gamlssnl_donor_reduced_CASE1$conf$fix>50))
#74
dose_seq[74]
#7.3

conf_band_mat_gamlssnl_donor <- centered_td2pLL_analysis_gamlssnl_donor_reduced_CASE1$conf$full   %>%
  cbind(grid_full, "cf"=. )                %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

min(which(conf_band_mat_gamlssnl_donor[31,]>50))
#82
dose_seq[82]
#8.1


res_td2pLL_CASE1_centered_reduced <- c("td2pLL","Case 1","normal",dose_seq[74],dose_seq[82])


#CASE 2

sigma_formula <- sigma_formula_case2
sigma_start <- sigma_start_case2
td2pLL_fit_gamlss_nl_donor<-td2pLL_fit_gamlss_nl_donor_reduced_case2

#Est conf band
if(file.exists("./case_study/centered_td2pLL_analysis_gamlssnl_donor_reduced_CASE2.RData")){
  load("./case_study/centered_td2pLL_analysis_gamlssnl_donor_reduced_CASE2.RData")
} else{
  set.seed(252525)
  seeds_gamlssnl_donor <- runif(B_out, min = 0, max=1000000)
  outerbootstrap_gamlssnl_donor <- bootstrap(sd=td2pLL_fit_gamlss_nl_donor$sigma.coefficients,
                                                          par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                                          B=B_out,
                                                          time=data_subset_reduced$time,
                                                          dose=data_subset_reduced$dose,
                                                          donor=data_subset_reduced$donor,
                                                          fixtime=4)
  # system.time()
  # user     system elapsed 
  # 61.69    1.30   63.99
  crit.val_boot_gamlssnl_donor <- critval_boot(outerboot=outerbootstrap_gamlssnl_donor,
                                                           B_in=B_in,
                                                           B_out=B_out,
                                                           sd=td2pLL_fit_gamlss_nl_donor$sigma.coefficients,
                                                           par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                                           time=data_subset_reduced$time,
                                                           dose=data_subset_reduced$dose,
                                                           donor=data_subset_reduced$donor,
                                                           seeds=seeds_gamlssnl_donor,
                                                           fixtime = 4)
  # system.time()
  # user  system elapsed 
  # 7.61    2.00  912.59 
  crit.val_gamlssnl_donor <- crit.val(crit.val.boot=crit.val_boot_gamlssnl_donor$res,
                                      alpha=0.05,
                                      fixtime=4)
  conf.band_gamlssnl_donor <- conf.bands(par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                         c=crit.val_gamlssnl_donor, 
                                         outerboot = outerbootstrap_gamlssnl_donor,
                                         fixtime=4)
  
  centered_td2pLL_analysis_gamlssnl_donor_reduced_CASE2 <- list("boot"=outerbootstrap_gamlssnl_donor,
                                                        "crit_boot"=crit.val_boot_gamlssnl_donor,
                                                        "crit_val"=crit.val_gamlssnl_donor,
                                                        "conf"=conf.band_gamlssnl_donor)
  save(centered_td2pLL_analysis_gamlssnl_donor_reduced_CASE2,
       file="./case_study/centered_td2pLL_analysis_gamlssnl_donor_reduced_CASE2.RData")
  
}

min(which(centered_td2pLL_analysis_gamlssnl_donor_reduced_CASE2$conf$fix>50))
#66
dose_seq[66]
#6.5

conf_band_mat_gamlssnl_donor <- centered_td2pLL_analysis_gamlssnl_donor_reduced_CASE2$conf$full   %>%
  cbind(grid_full, "cf"=. )                %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

min(which(conf_band_mat_gamlssnl_donor[31,]>50))
#67
dose_seq[67]
#6.6

res_td2pLL_CASE2_centered_reduced <- c("td2pLL","Case 2","normal",dose_seq[66],dose_seq[67])


#'------------------------------------------------------------------------------
# Analysis (Fixtime 4/Fast) ----
#'------------------------------------------------------------------------------


#CASE 1

sigma_formula <- sigma_formula_case1
sigma_start <- sigma_start_case1
td2pLL_fit_gamlss_nl_donor<-td2pLL_fit_gamlss_nl_donor_reduced_case1


#Est conf band
if(file.exists("./case_study/centered_tdpLL_analysis_gamlssnl_donor_fast_reduced_CASE1.RData")){
  load("./case_study/centered_tdpLL_analysis_gamlssnl_donor_fast_reduced_CASE1.RData")
} else{
  set.seed(27)
  seeds_gamlssnl_donor_fast <- runif(B_out, min = 0, max=1000000)
  outerbootstrap_gamlssnl_donor_fast <- bootstrap(sd=td2pLL_fit_gamlss_nl_donor$sigma.coefficients,
                                                              par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                                              B=B_out,
                                                              time=data_subset_reduced$time,
                                                              dose=data_subset_reduced$dose,
                                                              donor=data_subset_reduced$donor,
                                                              fixtime=4)
  # system.time()
  # user  system elapsed 
  #39.28    0.80   40.20
  crit.val_boot_gamlssnl_donor_fast <- critval_boot(outerboot=outerbootstrap_gamlssnl_donor_fast,
                                                                B_in=B_in,
                                                                B_out=B_out,
                                                                sd=td2pLL_fit_gamlss_nl_donor$sigma.coefficients,
                                                                par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                                                time=data_subset_reduced$time,
                                                                dose=data_subset_reduced$dose,
                                                                donor=data_subset_reduced$donor,
                                                                seeds=seeds_gamlssnl_donor_fast,
                                                                fixtime = 4,
                                                                fast_in=T)
  # system.time()
  # user  system elapsed 
  # 6.19    1.75  892.38 
  crit.val_gamlssnl_donor_fast <- crit.val(crit.val.boot=crit.val_boot_gamlssnl_donor_fast$res,
                                           alpha=0.05,
                                           fixtime=4)
  conf.band_gamlssnl_donor_fast <- conf.bands(par=td2pLL_fit_gamlss_nl_donor$mu.coefficients, 
                                              c=crit.val_gamlssnl_donor_fast, 
                                              outerboot = outerbootstrap_gamlssnl_donor_fast,
                                              fixtime=4)
  
  centered_td2pLL_analysis_gamlssnl_donor_fast_reduced_CASE1 <- list("boot"=outerbootstrap_gamlssnl_donor_fast,
                                                             "crit_boot"=crit.val_boot_gamlssnl_donor_fast,
                                                             "crit_val"=crit.val_gamlssnl_donor_fast,
                                                             "conf"=conf.band_gamlssnl_donor_fast)
  save(centered_td2pLL_analysis_gamlssnl_donor_fast_reduced_CASE1,
       file="./case_study/centered_tdpLL_analysis_gamlssnl_donor_fast_reduced_CASE1.RData")
  
}


min(which(centered_td2pLL_analysis_gamlssnl_donor_fast_reduced_CASE1$conf$fix>50))
#73
dose_seq[73]
#7.2

conf_band_mat_gamlssnl_donor <- centered_td2pLL_analysis_gamlssnl_donor_fast_reduced_CASE1$conf$full   %>%
  cbind(grid_full, "cf"=. )                %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

min(which(conf_band_mat_gamlssnl_donor[31,]>50))
#84
dose_seq[84]
#8.3


res_td2pLL_CASE1_fast_centered_reduced <- c("td2pLL","Case 1","fast",dose_seq[73],dose_seq[84])



#CASE 2

sigma_formula <- sigma_formula_case2
sigma_start <- sigma_start_case2
td2pLL_fit_gamlss_nl_donor<-td2pLL_fit_gamlss_nl_donor_reduced_case2


#Est conf band
if(file.exists("./case_study/centered_tdpLL_analysis_gamlssnl_donor_fast_reduced_CASE2.RData")){
  load("./case_study/centered_tdpLL_analysis_gamlssnl_donor_fast_reduced_CASE2.RData")
} else{
  set.seed(272727)
  seeds_gamlssnl_donor_fast <- runif(B_out, min = 0, max=1000000)
  outerbootstrap_gamlssnl_donor_fast <- bootstrap(sd=td2pLL_fit_gamlss_nl_donor$sigma.coefficients,
                                                              par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                                              B=B_out,
                                                              time=data_subset_reduced$time,
                                                              dose=data_subset_reduced$dose,
                                                              donor=data_subset_reduced$donor,
                                                              fixtime=4)
  # system.time()
  # user  system elapsed 
  # 52.01    1.36   55.17
  crit.val_boot_gamlssnl_donor_fast <- critval_boot(outerboot=outerbootstrap_gamlssnl_donor_fast,
                                                                B_in=B_in,
                                                                B_out=B_out,
                                                                sd=td2pLL_fit_gamlss_nl_donor$sigma.coefficients,
                                                                par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                                                time=data_subset_reduced$time,
                                                                dose=data_subset_reduced$dose,
                                                                donor=data_subset_reduced$donor,
                                                                seeds=seeds_gamlssnl_donor_fast,
                                                                fixtime = 4,
                                                                fast_in=T)
  # system.time()
  # user  system elapsed 
  # 5.85    1.83  782.00 
  crit.val_gamlssnl_donor_fast <- crit.val(crit.val.boot=crit.val_boot_gamlssnl_donor_fast$res,
                                           alpha=0.05,
                                           fixtime=4)
  conf.band_gamlssnl_donor_fast <- conf.bands(par=td2pLL_fit_gamlss_nl_donor$mu.coefficients, 
                                              c=crit.val_gamlssnl_donor_fast, 
                                              outerboot = outerbootstrap_gamlssnl_donor_fast,
                                              fixtime=4)
  
  centered_td2pLL_analysis_gamlssnl_donor_fast_reduced_CASE2 <- list("boot"=outerbootstrap_gamlssnl_donor_fast,
                                                             "crit_boot"=crit.val_boot_gamlssnl_donor_fast,
                                                             "crit_val"=crit.val_gamlssnl_donor_fast,
                                                             "conf"=conf.band_gamlssnl_donor_fast)
  save(centered_td2pLL_analysis_gamlssnl_donor_fast_reduced_CASE2,
       file="./case_study/centered_tdpLL_analysis_gamlssnl_donor_fast_reduced_CASE2.RData")
  
}


min(which(centered_td2pLL_analysis_gamlssnl_donor_fast_reduced_CASE2$conf$fix>50))
#64
dose_seq[64]
#6.3

conf_band_mat_gamlssnl_donor <- centered_td2pLL_analysis_gamlssnl_donor_fast_reduced_CASE2$conf$full   %>%
  cbind(grid_full, "cf"=. )                %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

min(which(conf_band_mat_gamlssnl_donor[31,]>50))
#68
dose_seq[68]
#6.7


res_td2pLL_CASE2_fast_centered_reduced <- c("td2pLL","Case 2","fast",dose_seq[64],dose_seq[68])


#'==============================================================================
#'Analysis with schuettler formula ====
#'==============================================================================

model <- schuettler

fit_fast <- schuettler_fast

mu_formula <- schuettler_formula

#'------------------------------------------------------------------------------
# Basic model fit ----
#'------------------------------------------------------------------------------

#Investigate fitting start parameters
fit_schuettler <- nlsLM(resp ~ log2FC_max/(                         #Use basic model fit
  1+exp(
    -slope*(
      log(dose)-log(
        1/(
          S_max*exp(
            -0.5*(
              (log(time)-log(t_max))/S_dur
            )^2
          )
        )
      )
    )
  )
),
data = data_subset_reduced,
start = list(log2FC_max=100,slope = -3, S_max = 0.2, t_max = 5.5, S_dur = 1.4) )
summary(fit_schuettler)                                       

mu_start <- list(log2FC_max=100,slope = -3, S_max=0.2,t_max=7, S_dur=1.5)


#'------------------------------------------------------------------------------
# Basic sd model fit  ----
#'------------------------------------------------------------------------------

#Prepare data set
data_subset_reduced_sd <- data_subset_reduced          %>%      #combine data via sd
  group_by(time,dose)            %>%
  summarize(resp_sd=sd(resp))

#CASE 1: Constant
sigma_formula_case1 <- ~1
#identify starting values for constant case
error_model <- glm(                             #estimate error model with glm 
  resp_sd ~ 1,
  family = gaussian(link = "log"),              #Log-Link 
  data = data_subset_reduced_sd
)
summary(error_model)                            #start parameters for sd 

sigma_start_case1 <- coef(error_model)

#Fit gamlss
schuettler_fit_gamlss_nl_donor_reduced_case1 <-nlgamlss( y= resp,
                                                 mu.fo = mu_formula, 
                                                 sigma.fo = sigma_formula_case1,
                                                 mu.start = mu_start,                         
                                                 sigma.start = sigma_start_case1,                                                 # Startwerte für sigma
                                                 family = NO(),                                                                  # Normalverteilung
                                                 data = data_subset_reduced
)

schuettler_fit_gamlss_nl_donor_reduced_case1$aic
#441.9928


#CASE 2: From Duda et al
sigma_formula_case2 <- ~ dose+I(dose^2)+time+I(dose^2):time
#identify starting values for constant case
error_model <- glm(                             #estimate error model with glm 
  resp_sd ~ dose+I(dose^2)+time+I(dose^2):time,
  family = gaussian(link = "log"),              #Log-Link 
  data = data_subset_reduced_sd
)
summary(error_model)                            #start parameters for sd 

sigma_start_case2 <- coef(error_model)

#Fit gamlss
schuettler_fit_gamlss_nl_donor_reduced_case2 <-nlgamlss( y= resp,
                                                 mu.fo = mu_formula, 
                                                 sigma.fo = sigma_formula_case2,
                                                 mu.start = mu_start,                         
                                                 sigma.start = sigma_start_case2,                                                 # Startwerte für sigma
                                                 family = NO(),                                                                  # Normalverteilung
                                                 data = data_subset_reduced
)

schuettler_fit_gamlss_nl_donor_reduced_case2$aic
#448.8963




#'------------------------------------------------------------------------------
# Analysis (Fixtime 4) ----
#'------------------------------------------------------------------------------

#CASE 1

sigma_formula <- sigma_formula_case1
sigma_start <- sigma_start_case1
schuettler_fit_gamlss_nl_donor<-schuettler_fit_gamlss_nl_donor_reduced_case1


#Est conf band
if(file.exists("./case_study/centered_schuettler_analysis_gamlssnl_donor_reduced_CASE1.RData")){
  load("./case_study/centered_schuettler_analysis_gamlssnl_donor_reduced_CASE1.RData")
} else{
  set.seed(211)
  seeds_gamlssnl_donor <- runif(B_out, min = 0, max=1000000)
  outerbootstrap_gamlssnl_donor <- bootstrap(sd=schuettler_fit_gamlss_nl_donor$sigma.coefficients,
                                                         par=schuettler_fit_gamlss_nl_donor$mu.coefficients,
                                                         B=B_out,
                                                         time=data_subset_reduced$time,
                                                         dose=data_subset_reduced$dose,
                                                         donor=data_subset_reduced$donor,
                                                         fixtime=4)
  # system.time()
  # user  system elapsed 
  # 39.69    1.00   42.26 
  crit.val_boot_gamlssnl_donor <- critval_boot(outerboot=outerbootstrap_gamlssnl_donor,
                                                           B_in=B_in,
                                                           B_out=B_out,
                                                           sd=schuettler_fit_gamlss_nl_donor$sigma.coefficients,
                                                           par=schuettler_fit_gamlss_nl_donor$mu.coefficients,
                                                           time=data_subset_reduced$time,
                                                           dose=data_subset_reduced$dose,
                                                           donor=data_subset_reduced$donor,
                                                           seeds=seeds_gamlssnl_donor,
                                                           fixtime = 4)
  # system.time()
  # user  system elapsed 
  # 6.22    1.28  523.08 
  crit.val_gamlssnl_donor <- crit.val(crit.val.boot=crit.val_boot_gamlssnl_donor$res,
                                      alpha=0.05,
                                      fixtime=4)
  conf.band_gamlssnl_donor <- conf.bands(par=schuettler_fit_gamlss_nl_donor$mu.coefficients, 
                                         c=crit.val_gamlssnl_donor, 
                                         outerboot = outerbootstrap_gamlssnl_donor,
                                         fixtime=4)
  
  centered_schuettler_analysis_gamlssnl_donor_reduced_CASE1 <- list("boot"=outerbootstrap_gamlssnl_donor,
                                                            "crit_boot"=crit.val_boot_gamlssnl_donor,
                                                            "crit_val"=crit.val_gamlssnl_donor,
                                                            "conf"=conf.band_gamlssnl_donor)
  save(centered_schuettler_analysis_gamlssnl_donor_reduced_CASE1,
       file="./case_study/centered_schuettler_analysis_gamlssnl_donor_reduced_CASE1.RData")
  
}


min(which(centered_schuettler_analysis_gamlssnl_donor_reduced_CASE1$conf$fix>50))
#76
dose_seq[76]
#7.5

conf_band_mat_gamlssnl_donor <- centered_schuettler_analysis_gamlssnl_donor_reduced_CASE1$conf$full   %>%
  cbind(grid_full, "cf"=. )                %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

min(which(conf_band_mat_gamlssnl_donor[31,]>50))
#84
dose_seq[84]
#8.3

res_schuettler_CASE1_centered_reduced <- c("schuettler","Case 1","normal",dose_seq[76],dose_seq[84])



#CASE 2

sigma_formula <- sigma_formula_case2
sigma_start <- sigma_start_case2
schuettler_fit_gamlss_nl_donor<-schuettler_fit_gamlss_nl_donor_reduced_case2


#Est conf band
if(file.exists("./case_study/centered_schuettler_analysis_gamlssnl_donor_reduced_CASE2.RData")){
  load("./case_study/centered_schuettler_analysis_gamlssnl_donor_reduced_CASE2.RData")
} else{
  set.seed(211211211)
  seeds_gamlssnl_donor <- runif(B_out, min = 0, max=1000000)
  outerbootstrap_gamlssnl_donor <- bootstrap(sd=schuettler_fit_gamlss_nl_donor$sigma.coefficients,
                                                         par=schuettler_fit_gamlss_nl_donor$mu.coefficients,
                                                         B=B_out,
                                                         time=data_subset_reduced$time,
                                                         dose=data_subset_reduced$dose,
                                                         donor=data_subset_reduced$donor,
                                                         fixtime=4)
  # system.time()
  # user  system elapsed 
  # 59.28    1.31   60.64   
  crit.val_boot_gamlssnl_donor <- critval_boot(outerboot=outerbootstrap_gamlssnl_donor,
                                                           B_in=B_in,
                                                           B_out=B_out,
                                                           sd=schuettler_fit_gamlss_nl_donor$sigma.coefficients,
                                                           par=schuettler_fit_gamlss_nl_donor$mu.coefficients,
                                                           time=data_subset_reduced$time,
                                                           dose=data_subset_reduced$dose,
                                                           donor=data_subset_reduced$donor,
                                                           seeds=seeds_gamlssnl_donor,
                                                           fixtime = 4)
  # system.time()
  # user  system elapsed 
  #  6.06    1.27  608.15 
  crit.val_gamlssnl_donor <- crit.val(crit.val.boot=crit.val_boot_gamlssnl_donor$res,
                                      alpha=0.05,
                                      fixtime=4)
  conf.band_gamlssnl_donor <- conf.bands(par=schuettler_fit_gamlss_nl_donor$mu.coefficients, 
                                         c=crit.val_gamlssnl_donor, 
                                         outerboot = outerbootstrap_gamlssnl_donor,
                                         fixtime=4)
  
  centered_schuettler_analysis_gamlssnl_donor_reduced_CASE2 <- list("boot"=outerbootstrap_gamlssnl_donor,
                                                            "crit_boot"=crit.val_boot_gamlssnl_donor,
                                                            "crit_val"=crit.val_gamlssnl_donor,
                                                            "conf"=conf.band_gamlssnl_donor)
  save(centered_schuettler_analysis_gamlssnl_donor_reduced_CASE2,
       file="./case_study/centered_schuettler_analysis_gamlssnl_donor_reduced_CASE2.RData")
  
}


min(which(centered_schuettler_analysis_gamlssnl_donor_reduced_CASE2$conf$fix>50))
#67
dose_seq[67]
#6.6

conf_band_mat_gamlssnl_donor <- centered_schuettler_analysis_gamlssnl_donor_reduced_CASE2$conf$full   %>%
  cbind(grid_full, "cf"=. )                %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

min(which(conf_band_mat_gamlssnl_donor[31,]>50))
#74
dose_seq[74]
#7.3

res_schuettler_CASE2_centered_reduced <- c("schuettler","Case 2","normal",dose_seq[67],dose_seq[74])

#'------------------------------------------------------------------------------
# Analysis (Fixtime 4/Fast)  ----
#'------------------------------------------------------------------------------


#CASE 1

sigma_formula <- sigma_formula_case1
sigma_start <- sigma_start_case1
schuettler_fit_gamlss_nl_donor<-schuettler_fit_gamlss_nl_donor_reduced_case1


#Est conf band
if(file.exists("./case_study/centered_schuettler_analysis_gamlssnl_donor_fast_reduced_CASE1.RData")){
  load("./case_study/centered_schuettler_analysis_gamlssnl_donor_fast_reduced_CASE1.RData")
} else{
  set.seed(213)
  seeds_gamlssnl_donor_fast <- runif(B_out, min = 0, max=1000000)
  outerbootstrap_gamlssnl_donor_fast <- bootstrap(sd=schuettler_fit_gamlss_nl_donor$sigma.coefficients,
                                                              par=schuettler_fit_gamlss_nl_donor$mu.coefficients,
                                                              B=B_out,
                                                              time=data_subset_reduced$time,
                                                              dose=data_subset_reduced$dose,
                                                              donor=data_subset_reduced$donor,
                                                              fixtime=4)
  # system.time()
  # user  system elapsed 
  # 38.06    0.83   39.05 
  crit.val_boot_gamlssnl_donor_fast <- critval_boot(outerboot=outerbootstrap_gamlssnl_donor_fast,
                                                                B_in=B_in,
                                                                B_out=B_out,
                                                                sd=schuettler_fit_gamlss_nl_donor$sigma.coefficients,
                                                                par=schuettler_fit_gamlss_nl_donor$mu.coefficients,
                                                                time=data_subset_reduced$time,
                                                                dose=data_subset_reduced$dose,
                                                                donor=data_subset_reduced$donor,
                                                                seeds=seeds_gamlssnl_donor_fast,
                                                                fixtime = 4,
                                                                fast_in=T)
  # system.time()
  # user  system elapsed 
  # 5.89    1.19  429.60
  crit.val_gamlssnl_donor_fast <- crit.val(crit.val.boot=crit.val_boot_gamlssnl_donor_fast$res,
                                           alpha=0.05,
                                           fixtime=4)
  conf.band_gamlssnl_donor_fast <- conf.bands(par=schuettler_fit_gamlss_nl_donor$mu.coefficients, 
                                              c=crit.val_gamlssnl_donor_fast, 
                                              outerboot = outerbootstrap_gamlssnl_donor_fast,
                                              fixtime=4)
  
  centered_schuettler_analysis_gamlssnl_donor_fast_reduced_CASE1 <- list("boot"=outerbootstrap_gamlssnl_donor_fast,
                                                                 "crit_boot"=crit.val_boot_gamlssnl_donor_fast,
                                                                 "crit_val"=crit.val_gamlssnl_donor_fast,
                                                                 "conf"=conf.band_gamlssnl_donor_fast)
  save(centered_schuettler_analysis_gamlssnl_donor_fast_reduced_CASE1,
       file="./case_study/centered_schuettler_analysis_gamlssnl_donor_fast_reduced_CASE1.RData")
  
}


min(which(centered_schuettler_analysis_gamlssnl_donor_fast_reduced_CASE1$conf$fix>50))
#81
dose_seq[81]
#8.0

conf_band_mat_gamlssnl_donor <- centered_schuettler_analysis_gamlssnl_donor_fast_reduced_CASE1$conf$full   %>%
  cbind(grid_full, "cf"=. )                %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

min(which(conf_band_mat_gamlssnl_donor[31,]>50))
#87
dose_seq[87]
#8.6

res_schuettler_CASE1_fast_centered_reduced <- c("schuettler","Case 1","fast",dose_seq[81],dose_seq[87])




#CASE 2

sigma_formula <- sigma_formula_case2
sigma_start <- sigma_start_case2
schuettler_fit_gamlss_nl_donor<-schuettler_fit_gamlss_nl_donor_reduced_case2


#Est conf band
if(file.exists("./case_study/centered_schuettler_analysis_gamlssnl_donor_fast_reduced_CASE2.RData")){
  load("./case_study/centered_schuettler_analysis_gamlssnl_donor_fast_reduced_CASE2.RData")
} else{
  set.seed(213213213)
  seeds_gamlssnl_donor_fast <- runif(B_out, min = 0, max=1000000)
  outerbootstrap_gamlssnl_donor_fast <- bootstrap(sd=schuettler_fit_gamlss_nl_donor$sigma.coefficients,
                                                              par=schuettler_fit_gamlss_nl_donor$mu.coefficients,
                                                              B=B_out,
                                                              time=data_subset_reduced$time,
                                                              dose=data_subset_reduced$dose,
                                                              donor=data_subset_reduced$donor,
                                                              fixtime=4)
  # system.time()
  # user  system elapsed 
  # 90.35    2.03   93.54 
  crit.val_boot_gamlssnl_donor_fast <- critval_boot(outerboot=outerbootstrap_gamlssnl_donor_fast,
                                                                B_in=B_in,
                                                                B_out=B_out,
                                                                sd=schuettler_fit_gamlss_nl_donor$sigma.coefficients,
                                                                par=schuettler_fit_gamlss_nl_donor$mu.coefficients,
                                                                time=data_subset_reduced$time,
                                                                dose=data_subset_reduced$dose,
                                                                donor=data_subset_reduced$donor,
                                                                seeds=seeds_gamlssnl_donor_fast,
                                                                fixtime = 4,
                                                                fast_in=T)
  # system.time()
  # user  system elapsed 
  # 5.59    1.56  424.67 
  crit.val_gamlssnl_donor_fast <- crit.val(crit.val.boot=crit.val_boot_gamlssnl_donor_fast$res,
                                           alpha=0.05,
                                           fixtime=4)
  conf.band_gamlssnl_donor_fast <- conf.bands(par=schuettler_fit_gamlss_nl_donor$mu.coefficients, 
                                              c=crit.val_gamlssnl_donor_fast, 
                                              outerboot = outerbootstrap_gamlssnl_donor_fast,
                                              fixtime=4)
  
  centered_schuettler_analysis_gamlssnl_donor_fast_reduced_CASE2 <- list("boot"=outerbootstrap_gamlssnl_donor_fast,
                                                                 "crit_boot"=crit.val_boot_gamlssnl_donor_fast,
                                                                 "crit_val"=crit.val_gamlssnl_donor_fast,
                                                                 "conf"=conf.band_gamlssnl_donor_fast)
  save(centered_schuettler_analysis_gamlssnl_donor_fast_reduced_CASE2,
       file="./case_study/centered_schuettler_analysis_gamlssnl_donor_fast_reduced_CASE2.RData")
  
}


min(which(centered_schuettler_analysis_gamlssnl_donor_fast_reduced_CASE2$conf$fix>50))
#66
dose_seq[66]
#6.5

conf_band_mat_gamlssnl_donor <- centered_schuettler_analysis_gamlssnl_donor_fast_reduced_CASE2$conf$full   %>%
  cbind(grid_full, "cf"=. )                %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

min(which(conf_band_mat_gamlssnl_donor[31,]>50))
#71
dose_seq[71]
#7.0

res_schuettler_CASE2_fast_centered_reduced <- c("schuettler","Case 2","fast",dose_seq[66],dose_seq[71])


#'==============================================================================
# Combine results in table ====
#'==============================================================================

res_case_study_centered_reduced <- rbind(res_td2pLL_CASE1_centered_reduced,
                                         res_td2pLL_CASE1_fast_centered_reduced,
                                         res_td2pLL_CASE2_centered_reduced,
                                         res_td2pLL_CASE2_fast_centered_reduced,
                                         res_schuettler_CASE1_centered_reduced,
                                         res_schuettler_CASE1_fast_centered_reduced,
                                         res_schuettler_CASE2_centered_reduced,
                                         res_schuettler_CASE2_fast_centered_reduced)

colnames(res_case_study_centered_reduced) <- c("Model","Case","Algorithm","2D alert","3D alert")
rownames(res_case_study_centered_reduced) <- NULL
write.xlsx(res_case_study_centered_reduced,"./plots_tables/102_res_case_study_centered_reduced.xlsx", rowNames = FALSE)


