#'##############################################################################
#                                                                              #
#                  Corresponding R Code to the Manuscript                      #
#                "Estimating effect thresholds and beyond:                     #
#              A flexible framework for multivariate alert detection"          #
#                                                                              #
#                                 Authors                                      #
#                    L. Ameis, N. Hagemann and K. Moellenhoff                  #
#                                                                              #
#                         Simulation - Scenario 0: Analysis simulation         #
#                                                                              #
#'##############################################################################


#'==============================================================================
# Two dimensional analysis ====
#'==============================================================================

#'==============================================================================
## Analysis function ====
#'==============================================================================

analysis_2dim <- function(res){
  
  #2dim approach
  res_vec_2dim <- numeric(1000)
  faild_runs_2dim <- numeric(1000)
  no_alert <- numeric(1000)
  for(i in 1:1000){
    if(anyNA(res[[i]])==T){
      faild_runs_2dim[i] <- 1
      alert <- NA  
    } else{
      #identify grid alert
      id<-min(which(res[[i]]$conf$fixtime>50))
      #check if last grid point is selected, then no alert was detected
      if(is.integer(id) && length(id) == 0){
        alert <- NA  
      }
      #save alert
      alert<-dose_seq[id]
    } 
    res_vec_2dim[i] <- alert
  }  
  
  #3dim approach
  res_vec_3dim <- numeric(1000)
  faild_runs_3dim <- numeric(1000)
  for(i in 1:1000){
    if(anyNA(res[[i]])==T){
      faild_runs_3dim[i] <- 1
      alert <- NA  
    } else{
      #identify grid alert
      conf_band_mat <- res[[i]]$conf$full   %>%
        cbind(grid_full, "cf"=. )                %>%
        reshape2::acast(., 
                        time~dose, 
                        value.var="cf")
      
      id <- min(which(conf_band_mat[31,]>50)) 
      #check if there is an alert
      if(is.integer(id) && length(id) == 0){
        alert <- NA  
      }
      #save alert
      alert<-dose_seq[id]
    } 
    res_vec_3dim[i] <- alert
  }  
  

  faild_runs_c <- numeric(1000)
  res_vec_fit <- numeric(1000)
  for(i in 1:1000){
    if(anyNA(res[[i]]$crit_val$fix)==T){
      faild_runs_c[i] <- 1
      alert <- NA  
    } else{
      #identify grid alert
    fit_mat <- model(t=grid_full$time, 
            d=grid_full$dose, 
            theta=res[[i]]$initial_fit$coef)          %>%
        cbind(grid_full, "response"=.)                        %>%
        reshape2::acast(., 
                        time~dose, 
                        value.var="response")
      
      

      
      id <- min(which(fit_mat[31,]>50)) 
      #check if there is an alert
      if(is.integer(id) && length(id) == 0){
        alert <- NA  
      }
      #save alert
      alert<-dose_seq[id]
    } 
    res_vec_fit[i] <- alert
  }  
  
  
  return(list("all_alerts_2dim"=res_vec_2dim,
              "all_alerts_3dim"=res_vec_3dim,
              "all_alerts_fit"=res_vec_fit,
              "median_2dim"=median(res_vec_2dim,na.rm=T),
              "median_3dim"=median(res_vec_3dim,na.rm=T),
              "median_fit"=median(res_vec_fit,na.rm=T),
              "sd_2dim"=round(sd(res_vec_2dim,na.rm=T),3),
              "sd_3dim"=round(sd(res_vec_3dim,na.rm=T),3),
              "sd_fit"=round(sd(res_vec_fit,na.rm=T),3),
              "failed_runs_2dim"=sum(faild_runs_2dim),
              "failed_runs_3dim"=sum(faild_runs_3dim),
              "failed_runs_c"=sum(faild_runs_c),
              "H0_reject_2dim"=sum(!is.na(res_vec_2dim)),
              "H0_reject_3dim"=sum(!is.na(res_vec_3dim)),
              "H0_reject_fit"=sum(!is.na(res_vec_fit))
  ))
}

if(file.exists("./simulation/010_scenario0_alt_analysis_2d_intermediate.RData")){
  load("./simulation/010_scenario0_alt_analysis_2d_intermediate.RData")
}else{
  
  #'==============================================================================
  ## Full data set ====
  #'==============================================================================
  
  #'------------------------------------------------------------------------------
  ### Assume constant value for sd   ----
  #'------------------------------------------------------------------------------
  
  #'------------------------------------------------------------------------------
  #### Assume constant value for sd - Full  ----
  #'------------------------------------------------------------------------------
  
  #'------------------------------------------------------------------------------
  ##### Case: Simple  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_constant <- analysis_2dim(Res_Scenario0_alt_fulldata_assumeconstant_constant)
  
  #'------------------------------------------------------------------------------
  ##### Case: Small  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_small <- analysis_2dim(Res_Scenario0_alt_fulldata_assumeconstant_small)
  
  #'------------------------------------------------------------------------------
  ##### Case: Medium  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_medium <- analysis_2dim(Res_Scenario0_alt_fulldata_assumeconstant_medium)
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Large  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_large <- analysis_2dim(Res_Scenario0_alt_fulldata_assumeconstant_large)
  
  
  #'------------------------------------------------------------------------------
  #### Assume constant value for sd - fast  ----
  #'------------------------------------------------------------------------------
  
  #'------------------------------------------------------------------------------
  ##### Case: Simple  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_constant <- analysis_2dim(Res_Scenario0_alt_fulldata_assumeconstant_fast_constant)
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Small  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_small <- analysis_2dim(Res_Scenario0_alt_fulldata_assumeconstant_fast_small)
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Medium  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_medium <- analysis_2dim(Res_Scenario0_alt_fulldata_assumeconstant_fast_medium)
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Large  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_large <- analysis_2dim(Res_Scenario0_alt_fulldata_assumeconstant_fast_large)
  
  
  
  #'------------------------------------------------------------------------------
  ### Assume complex value for sd   ----
  #'------------------------------------------------------------------------------
  
  #'------------------------------------------------------------------------------
  #### Assume complex value for sd - Full  ----
  #'------------------------------------------------------------------------------
  
  #'------------------------------------------------------------------------------
  ##### Case: Simple  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_constant <- analysis_2dim(Res_Scenario0_alt_fulldata_assumecomplex_constant)
  
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Small  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_small <- analysis_2dim(Res_Scenario0_alt_fulldata_assumecomplex_small)
  
  #'------------------------------------------------------------------------------
  ##### Case: Medium  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_medium <- analysis_2dim(Res_Scenario0_alt_fulldata_assumecomplex_medium)
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Large  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_large <- analysis_2dim(Res_Scenario0_alt_fulldata_assumecomplex_large)
  
  
  
  
  #'------------------------------------------------------------------------------
  #### Assume complex value for sd - fast  ----
  #'------------------------------------------------------------------------------
  
  #'------------------------------------------------------------------------------
  ##### Case: Simple  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_constant <- analysis_2dim(Res_Scenario0_alt_fulldata_assumecomplex_fast_constant)
  
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Small  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_small <- analysis_2dim(Res_Scenario0_alt_fulldata_assumecomplex_fast_small)
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Medium  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_medium <- analysis_2dim(Res_Scenario0_alt_fulldata_assumecomplex_fast_medium)
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Large  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_large <- analysis_2dim(Res_Scenario0_alt_fulldata_assumecomplex_fast_large)
  
  
  
  
  #'==============================================================================
  ## Reduced data set ====
  #'==============================================================================
  
  
  #'------------------------------------------------------------------------------
  ### Assume constant value for sd   ----
  #'------------------------------------------------------------------------------
  
  #'------------------------------------------------------------------------------
  #### Assume constant value for sd - Full  ----
  #'------------------------------------------------------------------------------
  
  #'------------------------------------------------------------------------------
  ##### Case: Simple  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_constant <- analysis_2dim(Res_Scenario0_alt_reduceddata_assumeconstant_constant)
  
  #'------------------------------------------------------------------------------
  ##### Case: Small  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_small <- analysis_2dim(Res_Scenario0_alt_reduceddata_assumeconstant_small)
  
  #'------------------------------------------------------------------------------
  ##### Case: Medium  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_medium <- analysis_2dim(Res_Scenario0_alt_reduceddata_assumeconstant_medium)
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Large  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_large <- analysis_2dim(Res_Scenario0_alt_reduceddata_assumeconstant_large)
  
  
  #'------------------------------------------------------------------------------
  #### Assume constant value for sd - fast  ----
  #'------------------------------------------------------------------------------
  
  #'------------------------------------------------------------------------------
  ##### Case: Simple  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_constant <- analysis_2dim(Res_Scenario0_alt_reduceddata_assumeconstant_fast_constant)
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Small  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_small <- analysis_2dim(Res_Scenario0_alt_reduceddata_assumeconstant_fast_small)
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Medium  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_medium <- analysis_2dim(Res_Scenario0_alt_reduceddata_assumeconstant_fast_medium)
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Large  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_large <- analysis_2dim(Res_Scenario0_alt_reduceddata_assumeconstant_fast_large)
  
  
  
  #'------------------------------------------------------------------------------
  ### Assume complex value for sd   ----
  #'------------------------------------------------------------------------------
  
  #'------------------------------------------------------------------------------
  #### Assume complex value for sd - Full  ----
  #'------------------------------------------------------------------------------
  
  #'------------------------------------------------------------------------------
  ##### Case: Simple  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_constant <- analysis_2dim(Res_Scenario0_alt_reduceddata_assumecomplex_constant)
  
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Small  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_small <- analysis_2dim(Res_Scenario0_alt_reduceddata_assumecomplex_small)
  
  #'------------------------------------------------------------------------------
  ##### Case: Medium  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_medium <- analysis_2dim(Res_Scenario0_alt_reduceddata_assumecomplex_medium)
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Large  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_large <- analysis_2dim(Res_Scenario0_alt_reduceddata_assumecomplex_large)
  
  
  
  
  #'------------------------------------------------------------------------------
  #### Assume complex value for sd - fast  ----
  #'------------------------------------------------------------------------------
  
  #'------------------------------------------------------------------------------
  ##### Case: Simple  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_constant <- analysis_2dim(Res_Scenario0_alt_reduceddata_assumecomplex_fast_constant)
  
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Small  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_small <- analysis_2dim(Res_Scenario0_alt_reduceddata_assumecomplex_fast_small)
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Medium  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_medium <- analysis_2dim(Res_Scenario0_alt_reduceddata_assumecomplex_fast_medium)
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Large  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_large <- analysis_2dim(Res_Scenario0_alt_reduceddata_assumecomplex_fast_large)
  
  #'------------------------------------------------------------------------------
  #### Save intermediate  ----
  #'------------------------------------------------------------------------------
  
  save( Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_constant,
        Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_constant,
        Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_small,
        Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_small,
        Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_medium,
        Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_medium,
        Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_large,
        Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_large,
        Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_constant,
        Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_constant,
        Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_small,
        Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_small,
        Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_medium,
        Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_medium,
        Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_large,
        Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_large,
        Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_constant,
        Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_constant,
        Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_small,
        Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_small,
        Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_medium,
        Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_medium,
        Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_large,
        Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_large,
        Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_constant,
        Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_constant,
        Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_small,
        Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_small,
        Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_medium,
        Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_medium,
        Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_large,
        Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_large,
        file="./simulation/010_scenario0_alt_analysis_2d_intermediate.RData")
}


#'==============================================================================
## Generate Table with resutls ====
#'==============================================================================

table_results_scenario0_alt_2d <- data.frame(
  "_"=c("Approach","Algorithm","Assumption","Scenario 0 - Full - Simple","Scenario 0 - Full -Small","Scenario 0 - Full - Medium","Scenario 0 - Full - Large",
        "Scenario 0 - Reduced - Simple","Scenario 0 - Reduced -Small","Scenario 0 - Reduced - Medium","Scenario 0 - Reduced - Large"),
  "H0_rejected_percent_2D_const"=c("2D","Normal","Constant",c(Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_constant$H0_reject_2dim,
                                                              Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_small$H0_reject_2dim,
                                                              Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_medium$H0_reject_2dim,
                                                              Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_large$H0_reject_2dim,
                                                              Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_constant$H0_reject_2dim,
                                                              Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_small$H0_reject_2dim,
                                                              Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_medium$H0_reject_2dim,
                                                              Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_large$H0_reject_2dim)/10),
  "H0_rejected_percent_3D_const"=c("3D","Normal","Constant",c(Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_constant$H0_reject_3dim,
                                                              Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_small$H0_reject_3dim,
                                                              Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_medium$H0_reject_3dim,
                                                              Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_large$H0_reject_3dim,
                                                              Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_constant$H0_reject_3dim,
                                                              Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_small$H0_reject_3dim,
                                                              Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_medium$H0_reject_3dim,
                                                              Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_large$H0_reject_3dim)/10),
  "H0_rejected_percent_2D_fast_const"=c("2D","Fast","Constant",c(Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_constant$H0_reject_2dim,
                                                                 Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_small$H0_reject_2dim,
                                                                 Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_medium$H0_reject_2dim,
                                                                 Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_large$H0_reject_2dim,
                                                                 Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_constant$H0_reject_2dim,
                                                                 Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_small$H0_reject_2dim,
                                                                 Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_medium$H0_reject_2dim,
                                                                 Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_large$H0_reject_2dim)/10),
  "H0_rejected_percent_3D_fast_const"=c("3D","Fast","Constant",c(Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_constant$H0_reject_3dim,
                                                                 Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_small$H0_reject_3dim,
                                                                 Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_medium$H0_reject_3dim,
                                                                 Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_large$H0_reject_3dim,
                                                                 Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_constant$H0_reject_3dim,
                                                                 Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_small$H0_reject_3dim,
                                                                 Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_medium$H0_reject_3dim,
                                                                 Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_large$H0_reject_3dim)/10),
  "Median_2D_const"=c("2D","Normal","Constant",Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_constant$median_2dim,
                      Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_small$median_2dim,
                      Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_medium$median_2dim,
                      Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_large$median_2dim,
                      Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_constant$median_2dim,
                      Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_small$median_2dim,
                      Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_medium$median_2dim,
                      Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_large$median_2dim),
  "Median_3D_const"=c("3D","Normal","Constant",Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_constant$median_3dim,
                      Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_small$median_3dim,
                      Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_medium$median_3dim,
                      Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_large$median_3dim,
                      Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_constant$median_3dim,
                      Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_small$median_3dim,
                      Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_medium$median_3dim,
                      Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_large$median_3dim),
  "Median_2D_fast_const"=c("2D","Fast","Constant",Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_constant$median_2dim,
                           Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_small$median_2dim,
                           Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_medium$median_2dim,
                           Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_large$median_2dim,
                           Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_constant$median_2dim,
                           Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_small$median_2dim,
                           Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_medium$median_2dim,
                           Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_large$median_2dim),
  "Median_3D_fast_const"=c("3D","Fast","Constant",Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_constant$median_3dim,
                           Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_small$median_3dim,
                           Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_medium$median_3dim,
                           Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_large$median_3dim,
                           Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_constant$median_3dim,
                           Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_small$median_3dim,
                           Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_medium$median_3dim,
                           Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_large$median_3dim),
  "SD_2D_const"=c("2D","Normal","Constant",Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_constant$sd_2dim,
                  Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_small$sd_2dim,
                  Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_medium$sd_2dim,
                  Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_large$sd_2dim,
                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_constant$sd_2dim,
                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_small$sd_2dim,
                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_medium$sd_2dim,
                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_large$sd_2dim),
  "SD_3D_const"=c("3D","Normal","Constant",Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_constant$sd_3dim,
                  Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_small$sd_3dim,
                  Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_medium$sd_3dim,
                  Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_large$sd_3dim,
                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_constant$sd_3dim,
                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_small$sd_3dim,
                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_medium$sd_3dim,
                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_large$sd_3dim),
  "SD_2D_fast_const"=c("2D","Fast","Constant",Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_constant$sd_2dim,
                       Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_small$sd_2dim,
                       Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_medium$sd_2dim,
                       Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_large$sd_2dim,
                       Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_constant$sd_2dim,
                       Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_small$sd_2dim,
                       Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_medium$sd_2dim,
                       Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_large$sd_2dim),
  "SD_3D_fast_const"=c("3D","Fast","Constant",Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_constant$sd_3dim,
                       Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_small$sd_3dim,
                       Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_medium$sd_3dim,
                       Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_large$sd_3dim,
                       Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_constant$sd_3dim,
                       Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_small$sd_3dim,
                       Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_medium$sd_3dim,
                       Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_large$sd_3dim),
  "Failed_runs_2D_const"=c("2D","Normal","Constant",Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_constant$failed_runs_2dim,
                           Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_small$failed_runs_2dim,
                           Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_medium$failed_runs_2dim,
                           Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_large$failed_runs_2dim,
                           Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_constant$failed_runs_2dim,
                           Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_small$failed_runs_2dim,
                           Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_medium$failed_runs_2dim,
                           Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_large$failed_runs_2dim),
  "Failed_runs_3D_const"=c("3D","Normal","Constant",Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_constant$failed_runs_3dim,
                           Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_small$failed_runs_3dim,
                           Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_medium$failed_runs_3dim,
                           Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_large$failed_runs_3dim,
                           Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_constant$failed_runs_3dim,
                           Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_small$failed_runs_3dim,
                           Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_medium$failed_runs_3dim,
                           Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_large$failed_runs_3dim),
  "Failed_runs_2D_fast_const"=c("2D","Fast","Constant",Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_constant$failed_runs_2dim,
                                Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_small$failed_runs_2dim,
                                Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_medium$failed_runs_2dim,
                                Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_large$failed_runs_2dim,
                                Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_constant$failed_runs_2dim,
                                Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_small$failed_runs_2dim,
                                Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_medium$failed_runs_2dim,
                                Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_large$failed_runs_2dim),
  "Failed_runs_3D_fast_const"=c("3D","Fast","Constant",Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_constant$failed_runs_3dim,
                                Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_small$failed_runs_3dim,
                                Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_medium$failed_runs_3dim,
                                Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_large$failed_runs_3dim,
                                Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_constant$failed_runs_3dim,
                                Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_small$failed_runs_3dim,
                                Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_medium$failed_runs_3dim,
                                Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_large$failed_runs_3dim),
  "H0_rejected_percent_2D_complex"=c("2D","Normal","Complex",c(Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_constant$H0_reject_2dim,
                                                               Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_small$H0_reject_2dim,
                                                               Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_medium$H0_reject_2dim,
                                                               Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_large$H0_reject_2dim,
                                                               Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_constant$H0_reject_2dim,
                                                               Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_small$H0_reject_2dim,
                                                               Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_medium$H0_reject_2dim,
                                                               Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_large$H0_reject_2dim)/10),
  "H0_rejected_percent_3D_complex"=c("3D","Normal","Complex",c(Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_constant$H0_reject_3dim,
                                                               Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_small$H0_reject_3dim,
                                                               Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_medium$H0_reject_3dim,
                                                               Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_large$H0_reject_3dim,
                                                               Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_constant$H0_reject_3dim,
                                                               Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_small$H0_reject_3dim,
                                                               Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_medium$H0_reject_3dim,
                                                               Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_large$H0_reject_3dim)/10),
  "H0_rejected_percent_2D_fast_complex"=c("2D","Fast","Complex",c(Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_constant$H0_reject_2dim,
                                                                  Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_small$H0_reject_2dim,
                                                                  Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_medium$H0_reject_2dim,
                                                                  Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_large$H0_reject_2dim,
                                                                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_constant$H0_reject_2dim,
                                                                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_small$H0_reject_2dim,
                                                                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_medium$H0_reject_2dim,
                                                                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_large$H0_reject_2dim)/10),
  "H0_rejected_percent_3D_fast_complex"=c("3D","Fast","Complex",c(Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_constant$H0_reject_3dim,
                                                                  Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_small$H0_reject_3dim,
                                                                  Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_medium$H0_reject_3dim,
                                                                  Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_large$H0_reject_3dim,
                                                                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_constant$H0_reject_3dim,
                                                                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_small$H0_reject_3dim,
                                                                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_medium$H0_reject_3dim,
                                                                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_large$H0_reject_3dim)/10),
  "Median_2D_complex"=c("2D","Normal","Complex",Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_constant$median_2dim,
                        Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_small$median_2dim,
                        Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_medium$median_2dim,
                        Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_large$median_2dim,
                        Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_constant$median_2dim,
                        Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_small$median_2dim,
                        Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_medium$median_2dim,
                        Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_large$median_2dim),
  "Median_3D_complex"=c("3D","Normal","Complex",Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_constant$median_3dim,
                        Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_small$median_3dim,
                        Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_medium$median_3dim,
                        Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_large$median_3dim,
                        Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_constant$median_3dim,
                        Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_small$median_3dim,
                        Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_medium$median_3dim,
                        Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_large$median_3dim),
  "Median_2D_fast_complex"=c("2D","Fast","Complex",Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_constant$median_2dim,
                             Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_small$median_2dim,
                             Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_medium$median_2dim,
                             Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_large$median_2dim,
                             Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_constant$median_2dim,
                             Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_small$median_2dim,
                             Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_medium$median_2dim,
                             Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_large$median_2dim),
  "Median_3D_fast_complex"=c("3D","Fast","Complex",Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_constant$median_3dim,
                             Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_small$median_3dim,
                             Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_medium$median_3dim,
                             Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_large$median_3dim,
                             Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_constant$median_3dim,
                             Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_small$median_3dim,
                             Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_medium$median_3dim,
                             Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_large$median_3dim),
  "SD_2D_complex"=c("2D","Normal","Complex",Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_constant$sd_2dim,
                    Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_small$sd_2dim,
                    Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_medium$sd_2dim,
                    Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_large$sd_2dim,
                    Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_constant$sd_2dim,
                    Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_small$sd_2dim,
                    Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_medium$sd_2dim,
                    Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_large$sd_2dim),
  "SD_3D_complex"=c("3D","Normal","Complex",Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_constant$sd_3dim,
                    Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_small$sd_3dim,
                    Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_medium$sd_3dim,
                    Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_large$sd_3dim,
                    Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_constant$sd_3dim,
                    Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_small$sd_3dim,
                    Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_medium$sd_3dim,
                    Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_large$sd_3dim),
  "SD_2D_fast_complex"=c("2D","Fast","Complex",Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_constant$sd_2dim,
                         Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_small$sd_2dim,
                         Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_medium$sd_2dim,
                         Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_large$sd_2dim,
                         Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_constant$sd_2dim,
                         Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_small$sd_2dim,
                         Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_medium$sd_2dim,
                         Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_large$sd_2dim),
  "SD_3D_fast_complex"=c("3D","Fast","Complex",Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_constant$sd_3dim,
                         Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_small$sd_3dim,
                         Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_medium$sd_3dim,
                         Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_large$sd_3dim,
                         Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_constant$sd_3dim,
                         Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_small$sd_3dim,
                         Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_medium$sd_3dim,
                         Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_large$sd_3dim),
  "Failed_runs_2D_complex"=c("2D","Normal","Complex",Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_constant$failed_runs_2dim,
                             Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_small$failed_runs_2dim,
                             Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_medium$failed_runs_2dim,
                             Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_large$failed_runs_2dim,
                             Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_constant$failed_runs_2dim,
                             Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_small$failed_runs_2dim,
                             Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_medium$failed_runs_2dim,
                             Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_large$failed_runs_2dim),
  "Failed_runs_3D_complex"=c("3D","Normal","Complex",Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_constant$failed_runs_3dim,
                             Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_small$failed_runs_3dim,
                             Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_medium$failed_runs_3dim,
                             Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_large$failed_runs_3dim,
                             Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_constant$failed_runs_3dim,
                             Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_small$failed_runs_3dim,
                             Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_medium$failed_runs_3dim,
                             Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_large$failed_runs_3dim),
  "Failed_runs_2D_fast_complex"=c("2D","Fast","Complex",Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_constant$failed_runs_2dim,
                                  Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_small$failed_runs_2dim,
                                  Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_medium$failed_runs_2dim,
                                  Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_large$failed_runs_2dim,
                                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_constant$failed_runs_2dim,
                                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_small$failed_runs_2dim,
                                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_medium$failed_runs_2dim,
                                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_large$failed_runs_2dim),
  "Failed_runs_3D_fast_complex"=c("3D","Fast","Complex",Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_constant$failed_runs_3dim,
                                  Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_small$failed_runs_3dim,
                                  Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_medium$failed_runs_3dim,
                                  Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_large$failed_runs_3dim,
                                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_constant$failed_runs_3dim,
                                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_small$failed_runs_3dim,
                                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_medium$failed_runs_3dim,
                                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_large$failed_runs_3dim),
  "H0_rejected_percent_2D_complex"=c("2D","Normal","Complex",c(Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_constant$H0_reject_2dim,
                                                               Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_small$H0_reject_2dim,
                                                               Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_medium$H0_reject_2dim,
                                                               Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_large$H0_reject_2dim,
                                                               Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_constant$H0_reject_2dim,
                                                               Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_small$H0_reject_2dim,
                                                               Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_medium$H0_reject_2dim,
                                                               Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_large$H0_reject_2dim)/10),
  "H0_rejected_percent_3D_complex"=c("3D","Normal","Complex",c(Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_constant$H0_reject_3dim,
                                                               Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_small$H0_reject_3dim,
                                                               Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_medium$H0_reject_3dim,
                                                               Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_large$H0_reject_3dim,
                                                               Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_constant$H0_reject_3dim,
                                                               Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_small$H0_reject_3dim,
                                                               Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_medium$H0_reject_3dim,
                                                               Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_large$H0_reject_3dim)/10),
  "H0_rejected_percent_2D_fast_complex"=c("2D","Fast","Complex",c(Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_constant$H0_reject_2dim,
                                                                  Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_small$H0_reject_2dim,
                                                                  Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_medium$H0_reject_2dim,
                                                                  Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_large$H0_reject_2dim,
                                                                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_constant$H0_reject_2dim,
                                                                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_small$H0_reject_2dim,
                                                                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_medium$H0_reject_2dim,
                                                                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_large$H0_reject_2dim)/10),
  "H0_rejected_percent_3D_fast_complex"=c("3D","Fast","Complex",c(Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_constant$H0_reject_3dim,
                                                                  Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_small$H0_reject_3dim,
                                                                  Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_medium$H0_reject_3dim,
                                                                  Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_large$H0_reject_3dim,
                                                                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_constant$H0_reject_3dim,
                                                                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_small$H0_reject_3dim,
                                                                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_medium$H0_reject_3dim,
                                                                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_large$H0_reject_3dim)/10),
  "Median_2D_complex"=c("2D","Normal","Complex",Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_constant$median_2dim,
                        Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_small$median_2dim,
                        Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_medium$median_2dim,
                        Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_large$median_2dim,
                        Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_constant$median_2dim,
                        Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_small$median_2dim,
                        Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_medium$median_2dim,
                        Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_large$median_2dim),
  "Median_3D_complex"=c("3D","Normal","Complex",Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_constant$median_3dim,
                        Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_small$median_3dim,
                        Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_medium$median_3dim,
                        Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_large$median_3dim,
                        Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_constant$median_3dim,
                        Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_small$median_3dim,
                        Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_medium$median_3dim,
                        Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_large$median_3dim),
  "Median_2D_fast_complex"=c("2D","Fast","Complex",Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_constant$median_2dim,
                             Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_small$median_2dim,
                             Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_medium$median_2dim,
                             Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_large$median_2dim,
                             Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_constant$median_2dim,
                             Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_small$median_2dim,
                             Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_medium$median_2dim,
                             Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_large$median_2dim),
  "Median_3D_fast_complex"=c("3D","Fast","Complex",Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_constant$median_3dim,
                             Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_small$median_3dim,
                             Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_medium$median_3dim,
                             Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_large$median_3dim,
                             Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_constant$median_3dim,
                             Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_small$median_3dim,
                             Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_medium$median_3dim,
                             Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_large$median_3dim),
  "SD_2D_complex"=c("2D","Normal","Complex",Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_constant$sd_2dim,
                    Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_small$sd_2dim,
                    Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_medium$sd_2dim,
                    Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_large$sd_2dim,
                    Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_constant$sd_2dim,
                    Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_small$sd_2dim,
                    Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_medium$sd_2dim,
                    Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_large$sd_2dim),
  "SD_3D_complex"=c("3D","Normal","Complex",Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_constant$sd_3dim,
                    Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_small$sd_3dim,
                    Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_medium$sd_3dim,
                    Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_large$sd_3dim,
                    Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_constant$sd_3dim,
                    Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_small$sd_3dim,
                    Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_medium$sd_3dim,
                    Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_large$sd_3dim),
  "SD_2D_fast_complex"=c("2D","Fast","Complex",Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_constant$sd_2dim,
                         Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_small$sd_2dim,
                         Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_medium$sd_2dim,
                         Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_large$sd_2dim,
                         Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_constant$sd_2dim,
                         Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_small$sd_2dim,
                         Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_medium$sd_2dim,
                         Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_large$sd_2dim),
  "SD_3D_fast_complex"=c("3D","Fast","Complex",Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_constant$sd_3dim,
                         Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_small$sd_3dim,
                         Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_medium$sd_3dim,
                         Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_large$sd_3dim,
                         Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_constant$sd_3dim,
                         Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_small$sd_3dim,
                         Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_medium$sd_3dim,
                         Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_large$sd_3dim),
  "Failed_runs_2D_complex"=c("2D","Normal","Complex",Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_constant$failed_runs_2dim,
                             Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_small$failed_runs_2dim,
                             Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_medium$failed_runs_2dim,
                             Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_large$failed_runs_2dim,
                             Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_constant$failed_runs_2dim,
                             Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_small$failed_runs_2dim,
                             Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_medium$failed_runs_2dim,
                             Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_large$failed_runs_2dim),
  "Failed_runs_3D_complex"=c("3D","Normal","Complex",Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_constant$failed_runs_3dim,
                             Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_small$failed_runs_3dim,
                             Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_medium$failed_runs_3dim,
                             Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_large$failed_runs_3dim,
                             Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_constant$failed_runs_3dim,
                             Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_small$failed_runs_3dim,
                             Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_medium$failed_runs_3dim,
                             Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_large$failed_runs_3dim),
  "Failed_runs_2D_fast_complex"=c("2D","Fast","Complex",Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_constant$failed_runs_2dim,
                                  Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_small$failed_runs_2dim,
                                  Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_medium$failed_runs_2dim,
                                  Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_large$failed_runs_2dim,
                                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_constant$failed_runs_2dim,
                                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_small$failed_runs_2dim,
                                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_medium$failed_runs_2dim,
                                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_large$failed_runs_2dim)
)


#Check
#View( as.data.frame(t(table_results_scenario0_alt_2d)))

# write.xlsx(
#   as.data.frame(t(table_results_scenario0_alt_2d)),
#   file = "./plots_tables/203_simulation_scenario0_alt_results_2d_all.xlsx",
#   colNames = F,rowNames=T
# )


#Note, that the combinations constant - normal/fast are identical assumption wise
#They were run to compare the technical performance of both in general
#Since the performance is very similar, only the results of the fast algorithm
#are included in the paper, since there is an overall focus on the fast algorithm


#full data set
write.xlsx(
  (as.data.frame(t(table_results_scenario0_alt_2d))[-c(2,3,6,7,10,11,14,15,16,17,30,31,32,33),1:7])[c(1,2,3,8,9,10,11),],
  file = "./plots_tables/204_simulation_scenario0_alt_results_2d_full.xlsx",
  colNames = F,rowNames=T
)

#reduced data set
write.xlsx(
  as.data.frame(t(table_results_scenario0_alt_2d))[-c(2,3,6,7,10,11,14,15,16,17,30,31,32,33),c(1:3,8:11)][c(1,2,3,8,9,10,11),],
  file = "./plots_tables/205_simulation_scenario0_alt_results_2d_reduced.xlsx",
  colNames = F,rowNames=T
)



#'------------------------------------------------------------------------------
## Table with fit results -----
#'------------------------------------------------------------------------------

# table_results_scenario0_alt_fit_2d_res <- data.frame(
#   "_"=c("Approach","Algorithm","Assumption","Scenario 0 - Full - Simple","Scenario 0 - Full -Small","Scenario 0 - Full - Medium","Scenario 0 - Full - Large",
#         "Scenario 0 - Reduced - Simple","Scenario 0 - Reduced -Small","Scenario 0 - Reduced - Medium","Scenario 0 - Reduced - Large"),
#   "H0_rejected_percent_const"=c("2D","Normal","Constant",c(Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_constant$H0_reject_fit,
#                                                               Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_small$H0_reject_fit,
#                                                               Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_medium$H0_reject_fit,
#                                                               Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_large$H0_reject_fit,
#                                                               Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_constant$H0_reject_fit,
#                                                               Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_small$H0_reject_fit,
#                                                               Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_medium$H0_reject_fit,
#                                                               Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_large$H0_reject_fit)/10),
#   "H0_rejected_percent_fast_const"=c("2D","Fast","Constant",c(Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_constant$H0_reject_fit,
#                                                                  Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_small$H0_reject_fit,
#                                                                  Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_medium$H0_reject_fit,
#                                                                  Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_large$H0_reject_fit,
#                                                                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_constant$H0_reject_fit,
#                                                                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_small$H0_reject_fit,
#                                                                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_medium$H0_reject_fit,
#                                                                  Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_large$H0_reject_fit)/10),
#   "Median_const"=c("2D","Normal","Constant",Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_constant$median_fit,
#                       Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_small$median_fit,
#                       Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_medium$median_fit,
#                       Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_large$median_fit,
#                       Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_constant$median_fit,
#                       Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_small$median_fit,
#                       Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_medium$median_fit,
#                       Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_large$median_fit),
#   "Median_fast_const"=c("2D","Fast","Constant",Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_constant$median_fit,
#                            Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_small$median_fit,
#                            Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_medium$median_fit,
#                            Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_large$median_fit,
#                            Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_constant$median_fit,
#                            Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_small$median_fit,
#                            Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_medium$median_fit,
#                            Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_large$median_fit),
#   "SD_const"=c("2D","Normal","Constant",Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_constant$sd_fit,
#                   Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_small$sd_fit,
#                   Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_medium$sd_fit,
#                   Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_large$sd_fit,
#                   Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_constant$sd_fit,
#                   Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_small$sd_fit,
#                   Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_medium$sd_fit,
#                   Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_large$sd_fit),
#   "SD_fast_const"=c("2D","Fast","Constant",Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_constant$sd_fit,
#                        Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_small$sd_fit,
#                        Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_medium$sd_fit,
#                        Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_large$sd_fit,
#                        Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_constant$sd_fit,
#                        Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_small$sd_fit,
#                        Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_medium$sd_fit,
#                        Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_large$sd_fit),
#   "Failed_runs_const"=c("2D","Normal","Constant",Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_constant$failed_runs_c,
#                            Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_small$failed_runs_c,
#                            Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_medium$failed_runs_c,
#                            Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_large$failed_runs_c,
#                            Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_constant$failed_runs_c,
#                            Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_small$failed_runs_c,
#                            Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_medium$failed_runs_c,
#                            Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_large$failed_runs_c),
#   "Failed_runs_fast_const"=c("2D","Fast","Constant",Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_constant$failed_runs_c,
#                                 Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_small$failed_runs_c,
#                                 Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_medium$failed_runs_c,
#                                 Res_alert_fixtime_Scenario0_alt_fulldata_assumeconstant_fast_large$failed_runs_c,
#                                 Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_constant$failed_runs_c,
#                                 Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_small$failed_runs_c,
#                                 Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_medium$failed_runs_c,
#                                 Res_alert_fixtime_Scenario0_alt_reduceddata_assumeconstant_fast_large$failed_runs_c),
#   "H0_rejected_percent_complex"=c("2D","Normal","Complex",c(Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_constant$H0_reject_fit,
#                                                                Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_small$H0_reject_fit,
#                                                                Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_medium$H0_reject_fit,
#                                                                Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_large$H0_reject_fit,
#                                                                Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_constant$H0_reject_fit,
#                                                                Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_small$H0_reject_fit,
#                                                                Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_medium$H0_reject_fit,
#                                                                Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_large$H0_reject_fit)/10),
#   "H0_rejected_percent_fast_complex"=c("2D","Fast","Complex",c(Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_constant$H0_reject_fit,
#                                                                   Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_small$H0_reject_fit,
#                                                                   Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_medium$H0_reject_fit,
#                                                                   Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_large$H0_reject_fit,
#                                                                   Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_constant$H0_reject_fit,
#                                                                   Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_small$H0_reject_fit,
#                                                                   Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_medium$H0_reject_fit,
#                                                                   Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_large$H0_reject_fit)/10),
#   "Median_complex"=c("2D","Normal","Complex",Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_constant$median_fit,
#                         Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_small$median_fit,
#                         Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_medium$median_fit,
#                         Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_large$median_fit,
#                         Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_constant$median_fit,
#                         Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_small$median_fit,
#                         Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_medium$median_fit,
#                         Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_large$median_fit),
#   "Median_fast_complex"=c("2D","Fast","Complex",Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_constant$median_fit,
#                              Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_small$median_fit,
#                              Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_medium$median_fit,
#                              Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_large$median_fit,
#                              Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_constant$median_fit,
#                              Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_small$median_fit,
#                              Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_medium$median_fit,
#                              Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_large$median_fit),
#   "SD_complex"=c("2D","Normal","Complex",Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_constant$sd_fit,
#                     Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_small$sd_fit,
#                     Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_medium$sd_fit,
#                     Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_large$sd_fit,
#                     Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_constant$sd_fit,
#                     Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_small$sd_fit,
#                     Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_medium$sd_fit,
#                     Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_large$sd_fit),
#   "SD_fast_complex"=c("2D","Fast","Complex",Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_constant$sd_fit,
#                          Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_small$sd_fit,
#                          Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_medium$sd_fit,
#                          Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_large$sd_fit,
#                          Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_constant$sd_fit,
#                          Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_small$sd_fit,
#                          Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_medium$sd_fit,
#                          Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_large$sd_fit),
#   "Failed_runs_complex"=c("2D","Normal","Complex",Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_constant$failed_runs_c,
#                              Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_small$failed_runs_c,
#                              Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_medium$failed_runs_c,
#                              Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_large$failed_runs_c,
#                              Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_constant$failed_runs_c,
#                              Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_small$failed_runs_c,
#                              Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_medium$failed_runs_c,
#                              Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_large$failed_runs_c),
#   "Failed_runs_fast_complex"=c("2D","Fast","Complex",Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_constant$failed_runs_c,
#                                   Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_small$failed_runs_c,
#                                   Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_medium$failed_runs_c,
#                                   Res_alert_fixtime_Scenario0_alt_fulldata_assumecomplex_fast_large$failed_runs_c,
#                                   Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_constant$failed_runs_c,
#                                   Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_small$failed_runs_c,
#                                   Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_medium$failed_runs_c,
#                                   Res_alert_fixtime_Scenario0_alt_reduceddata_assumecomplex_fast_large$failed_runs_c)
# )
# 
# 
# 
# 
# #View(as.data.frame(t(table_results_scenario0_alt_fit_2d_res)))

#'==============================================================================
# Three dimensional analysis ====
#'==============================================================================

#'==============================================================================
## Analysis function ====
#'==============================================================================

#rename for later use
true_alert_relationship_df <- true_alert_relationship_h0 %>%
  rename(d_true = dose)



analysis_3dim <- function(res,scenario_info,
                          design_info,
                          sd_info,
                          sigma_assumed_info,
                          algo_info){
  
  #2dim approach
  res_list <- list()
  no_alert <- numeric(1000) #already somewhat regarded above
  for(i in 1:1000){
    if(anyNA(res[[i]])==T){
      no_alert[i] <- 1
      alert <- F  
    } else{
      #identify grid alert
      conf_band_mat <- res[[i]]$conf$full   %>%
        cbind(grid_full, "cf"=. )                %>%
        reshape2::acast(., 
                        time~dose, 
                        value.var="cf")
      
      alert_id <- matrix(NA,nrow=length(time_seq),ncol=2)
      for(j in length(time_seq):1){
        alert_id[j,1] <- j
        alert_id[j,2] <- min(subset(which(conf_band_mat>50,arr.ind=T)[,2],
                                    which(conf_band_mat>50,arr.ind=T)[,1]==j))
      }
      if(sum(is.infinite(alert_id[,2])) == nrow(alert_id)){
        alert <- F  
        no_alert[i] <-1
      } else{
        alert <- data.frame("time"=time_seq[alert_id[,1]],
                            "dose"=dose_seq[alert_id[,2]])
      }
    }
    res_list[[i]] <- alert
    
  }  
  

  res_list_fit <- list()
  no_alert_fit <- numeric(1000) #already somewhat regarded above
  for(i in 1:1000){
    if(anyNA(res[[i]]$crit_val$full)==T){
      no_alert_fit[i] <- 1
      alert <- F  
    } else{
      #identify grid alert
      fit_mat <- model(t=grid_full$time, 
                             d=grid_full$dose, 
                             theta=res[[i]]$initial_fit$coef)          %>%
        cbind(grid_full, "response"=.)                        %>%
        reshape2::acast(., 
                        time~dose, 
                        value.var="response")
      
      alert_id <- matrix(NA,nrow=length(time_seq),ncol=2)
      for(j in length(time_seq):1){
        alert_id[j,1] <- j
        alert_id[j,2] <- min(subset(which(fit_mat>50,arr.ind=T)[,2],
                                    which(fit_mat>50,arr.ind=T)[,1]==j))
      }
      if(sum(is.infinite(alert_id[,2])) == nrow(alert_id)){
        alert <- F  
        no_alert_fit[i] <-1
      } else{
        alert <- data.frame("time"=time_seq[alert_id[,1]],
                            "dose"=dose_seq[alert_id[,2]])
      }
    }
    res_list_fit[[i]] <- alert
    
  }  
  

  return(list("info"=c(scenario_info,design_info,sd_info,sigma_assumed_info,algo_info),
              "all_alert_relatioships"=res_list,
              "H0_rejected"=1000-sum(no_alert),
              "all_alert_relationships_fit"=res_list_fit,
              "H0_rejected_fit"=1000-sum(no_alert_fit)
  )
  )
}

if(file.exists("./simulation/020_scenario0_alt_analysis_3d_intermediate.RData")){
  load("./simulation/020_scenario0_alt_analysis_3d_intermediate.RData")
}else{
  
  #'==============================================================================
  ## Full data set ====
  #'==============================================================================
  
  #'------------------------------------------------------------------------------
  ### Assume constant value for sd   ----
  #'------------------------------------------------------------------------------
  
  #'------------------------------------------------------------------------------
  #### Assume constant value for sd - Full  ----
  #'------------------------------------------------------------------------------
  
  #'------------------------------------------------------------------------------
  ##### Case: Simple  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_3d_Scenario0_alt_fulldata_assumeconstant_constant <- analysis_3dim(Res_Scenario0_alt_fulldata_assumeconstant_constant,
                                                                           scenario_info = "Scenario 0",
                                                                           design_info = "Full",
                                                                           sd_info="Simple",
                                                                           sigma_assumed_info="Constant",
                                                                           algo_info="Normal")
  
  #'------------------------------------------------------------------------------
  ##### Case: Small  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_3d_Scenario0_alt_fulldata_assumeconstant_small <- analysis_3dim(Res_Scenario0_alt_fulldata_assumeconstant_small,
                                                                        scenario_info = "Scenario 0",
                                                                        design_info = "Full",
                                                                        sd_info="Small",
                                                                        sigma_assumed_info="Constant",
                                                                        algo_info="Normal")
  
  #'------------------------------------------------------------------------------
  ##### Case: Medium  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_3d_Scenario0_alt_fulldata_assumeconstant_medium <- analysis_3dim(Res_Scenario0_alt_fulldata_assumeconstant_medium,
                                                                         scenario_info = "Scenario 0",
                                                                         design_info = "Full",
                                                                         sd_info="Medium",
                                                                         sigma_assumed_info="Constant",
                                                                         algo_info="Normal")
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Large  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_3d_Scenario0_alt_fulldata_assumeconstant_large <- analysis_3dim(Res_Scenario0_alt_fulldata_assumeconstant_large,
                                                                        scenario_info = "Scenario 0",
                                                                        design_info = "Full",
                                                                        sd_info="Large",
                                                                        sigma_assumed_info="Constant",
                                                                        algo_info="Normal")
  
  
  #'------------------------------------------------------------------------------
  #### Assume constant value for sd - fast  ----
  #'------------------------------------------------------------------------------
  
  #'------------------------------------------------------------------------------
  ##### Case: Simple  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_3d_Scenario0_alt_fulldata_assumeconstant_fast_constant <- analysis_3dim(Res_Scenario0_alt_fulldata_assumeconstant_fast_constant,
                                                                                scenario_info = "Scenario 0",
                                                                                design_info = "Full",
                                                                                sd_info="Simple",
                                                                                sigma_assumed_info="Constant",
                                                                                algo_info="Fast")
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Small  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_3d_Scenario0_alt_fulldata_assumeconstant_fast_small <- analysis_3dim(Res_Scenario0_alt_fulldata_assumeconstant_fast_small,
                                                                             scenario_info = "Scenario 0",
                                                                             design_info = "Full",
                                                                             sd_info="Small",
                                                                             sigma_assumed_info="Constant",
                                                                             algo_info="Fast")
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Medium  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_3d_Scenario0_alt_fulldata_assumeconstant_fast_medium <- analysis_3dim(Res_Scenario0_alt_fulldata_assumeconstant_fast_medium,
                                                                              scenario_info = "Scenario 0",
                                                                              design_info = "Full",
                                                                              sd_info="Medium",
                                                                              sigma_assumed_info="Constant",
                                                                              algo_info="Fast")
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Large  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_3d_Scenario0_alt_fulldata_assumeconstant_fast_large <- analysis_3dim(Res_Scenario0_alt_fulldata_assumeconstant_fast_large,
                                                                             scenario_info = "Scenario 0",
                                                                             design_info = "Full",
                                                                             sd_info="Large",
                                                                             sigma_assumed_info="Constant",
                                                                             algo_info="Fast")
  
  
  
  #'------------------------------------------------------------------------------
  ### Assume complex value for sd   ----
  #'------------------------------------------------------------------------------
  
  #'------------------------------------------------------------------------------
  #### Assume complex value for sd - Full  ----
  #'------------------------------------------------------------------------------
  
  #'------------------------------------------------------------------------------
  ##### Case: Simple  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_3d_Scenario0_alt_fulldata_assumecomplex_constant <- analysis_3dim(Res_Scenario0_alt_fulldata_assumecomplex_constant,
                                                                          scenario_info = "Scenario 0",
                                                                          design_info = "Full",
                                                                          sd_info="Simple",
                                                                          sigma_assumed_info="Complex",
                                                                          algo_info="Normal")
  
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Small  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_3d_Scenario0_alt_fulldata_assumecomplex_small <- analysis_3dim(Res_Scenario0_alt_fulldata_assumecomplex_small,
                                                                       scenario_info = "Scenario 0",
                                                                       design_info = "Full",
                                                                       sd_info="Small",
                                                                       sigma_assumed_info="Complex",
                                                                       algo_info="Normal")
  
  #'------------------------------------------------------------------------------
  ##### Case: Medium  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_3d_Scenario0_alt_fulldata_assumecomplex_medium <- analysis_3dim(Res_Scenario0_alt_fulldata_assumecomplex_medium,
                                                                        scenario_info = "Scenario 0",
                                                                        design_info = "Full",
                                                                        sd_info="Medium",
                                                                        sigma_assumed_info="Complex",
                                                                        algo_info="Normal")
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Large  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_3d_Scenario0_alt_fulldata_assumecomplex_large <- analysis_3dim(Res_Scenario0_alt_fulldata_assumecomplex_large,
                                                                       scenario_info = "Scenario 0",
                                                                       design_info = "Full",
                                                                       sd_info="Large",
                                                                       sigma_assumed_info="Complex",
                                                                       algo_info="Normal")
  
  
  
  
  #'------------------------------------------------------------------------------
  #### Assume complex value for sd - fast  ----
  #'------------------------------------------------------------------------------
  
  #'------------------------------------------------------------------------------
  ##### Case: Simple  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_3d_Scenario0_alt_fulldata_assumecomplex_fast_constant <- analysis_3dim(Res_Scenario0_alt_fulldata_assumecomplex_fast_constant,
                                                                               scenario_info = "Scenario 0",
                                                                               design_info = "Full",
                                                                               sd_info="Simple",
                                                                               sigma_assumed_info="Complex",
                                                                               algo_info="Fast")
  
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Small  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_3d_Scenario0_alt_fulldata_assumecomplex_fast_small <- analysis_3dim(Res_Scenario0_alt_fulldata_assumecomplex_fast_small,
                                                                            scenario_info = "Scenario 0",
                                                                            design_info = "Full",
                                                                            sd_info="Small",
                                                                            sigma_assumed_info="Complex",
                                                                            algo_info="Fast")
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Medium  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_3d_Scenario0_alt_fulldata_assumecomplex_fast_medium <- analysis_3dim(Res_Scenario0_alt_fulldata_assumecomplex_fast_medium,
                                                                             scenario_info = "Scenario 0",
                                                                             design_info = "Full",
                                                                             sd_info="Medium",
                                                                             sigma_assumed_info="Complex",
                                                                             algo_info="Fast")
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Large  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_3d_Scenario0_alt_fulldata_assumecomplex_fast_large <- analysis_3dim(Res_Scenario0_alt_fulldata_assumecomplex_fast_large,
                                                                            scenario_info = "Scenario 0",
                                                                            design_info = "Full",
                                                                            sd_info="Large",
                                                                            sigma_assumed_info="Complex",
                                                                            algo_info="Fast")
  
  
  
  
  #'==============================================================================
  ## Reduced data set ====
  #'==============================================================================
  
  
  #'------------------------------------------------------------------------------
  ### Assume constant value for sd   ----
  #'------------------------------------------------------------------------------
  
  #'------------------------------------------------------------------------------
  #### Assume constant value for sd - Full  ----
  #'------------------------------------------------------------------------------
  
  #'------------------------------------------------------------------------------
  ##### Case: Simple  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_3d_Scenario0_alt_reduceddata_assumeconstant_constant <- analysis_3dim(Res_Scenario0_alt_reduceddata_assumeconstant_constant,
                                                                              scenario_info = "Scenario 0",
                                                                              design_info = "Reduced",
                                                                              sd_info="Simple",
                                                                              sigma_assumed_info="Constant",
                                                                              algo_info="Normal")
  
  #'------------------------------------------------------------------------------
  ##### Case: Small  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_3d_Scenario0_alt_reduceddata_assumeconstant_small <- analysis_3dim(Res_Scenario0_alt_reduceddata_assumeconstant_small,
                                                                           scenario_info = "Scenario 0",
                                                                           design_info = "Reduced",
                                                                           sd_info="Small",
                                                                           sigma_assumed_info="Constant",
                                                                           algo_info="Normal")
  
  #'------------------------------------------------------------------------------
  ##### Case: Medium  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_3d_Scenario0_alt_reduceddata_assumeconstant_medium <- analysis_3dim(Res_Scenario0_alt_reduceddata_assumeconstant_medium,
                                                                            scenario_info = "Scenario 0",
                                                                            design_info = "Reduced",
                                                                            sd_info="Medium",
                                                                            sigma_assumed_info="Constant",
                                                                            algo_info="Normal")
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Large  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_3d_Scenario0_alt_reduceddata_assumeconstant_large <- analysis_3dim(Res_Scenario0_alt_reduceddata_assumeconstant_large,
                                                                           scenario_info = "Scenario 0",
                                                                           design_info = "Reduced",
                                                                           sd_info="Large",
                                                                           sigma_assumed_info="Constant",
                                                                           algo_info="Normal")
  
  
  #'------------------------------------------------------------------------------
  #### Assume constant value for sd - fast  ----
  #'------------------------------------------------------------------------------
  
  #'------------------------------------------------------------------------------
  ##### Case: Simple  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_3d_Scenario0_alt_reduceddata_assumeconstant_fast_constant <- analysis_3dim(Res_Scenario0_alt_reduceddata_assumeconstant_fast_constant,
                                                                                   scenario_info = "Scenario 0",
                                                                                   design_info = "Reduced",
                                                                                   sd_info="Simple",
                                                                                   sigma_assumed_info="Constant",
                                                                                   algo_info="Fast")
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Small  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_3d_Scenario0_alt_reduceddata_assumeconstant_fast_small <- analysis_3dim(Res_Scenario0_alt_reduceddata_assumeconstant_fast_small,
                                                                                scenario_info = "Scenario 0",
                                                                                design_info = "Reduced",
                                                                                sd_info="Small",
                                                                                sigma_assumed_info="Constant",
                                                                                algo_info="Fast")
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Medium  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_3d_Scenario0_alt_reduceddata_assumeconstant_fast_medium <- analysis_3dim(Res_Scenario0_alt_reduceddata_assumeconstant_fast_medium,
                                                                                 scenario_info = "Scenario 0",
                                                                                 design_info = "Reduced",
                                                                                 sd_info="Medium",
                                                                                 sigma_assumed_info="Constant",
                                                                                 algo_info="Fast")
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Large  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_3d_Scenario0_alt_reduceddata_assumeconstant_fast_large <- analysis_3dim(Res_Scenario0_alt_reduceddata_assumeconstant_fast_large,
                                                                                scenario_info = "Scenario 0",
                                                                                design_info = "Reduced",
                                                                                sd_info="Large",
                                                                                sigma_assumed_info="Constant",
                                                                                algo_info="Fast")
  
  
  
  #'------------------------------------------------------------------------------
  ### Assume complex value for sd   ----
  #'------------------------------------------------------------------------------
  
  #'------------------------------------------------------------------------------
  #### Assume complex value for sd - Full  ----
  #'------------------------------------------------------------------------------
  
  #'------------------------------------------------------------------------------
  ##### Case: Simple  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_3d_Scenario0_alt_reduceddata_assumecomplex_constant <- analysis_3dim(Res_Scenario0_alt_reduceddata_assumecomplex_constant,
                                                                             scenario_info = "Scenario 0",
                                                                             design_info = "Reduced",
                                                                             sd_info="Simple",
                                                                             sigma_assumed_info="Complex",
                                                                             algo_info="Normal")
  
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Small  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_3d_Scenario0_alt_reduceddata_assumecomplex_small <- analysis_3dim(Res_Scenario0_alt_reduceddata_assumecomplex_small,
                                                                          scenario_info = "Scenario 0",
                                                                          design_info = "Reduced",
                                                                          sd_info="Small",
                                                                          sigma_assumed_info="Complex",
                                                                          algo_info="Normal")
  
  #'------------------------------------------------------------------------------
  ##### Case: Medium  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_3d_Scenario0_alt_reduceddata_assumecomplex_medium <- analysis_3dim(Res_Scenario0_alt_reduceddata_assumecomplex_medium,
                                                                           scenario_info = "Scenario 0",
                                                                           design_info = "Reduced",
                                                                           sd_info="Medium",
                                                                           sigma_assumed_info="Complex",
                                                                           algo_info="Normal")
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Large  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_3d_Scenario0_alt_reduceddata_assumecomplex_large <- analysis_3dim(Res_Scenario0_alt_reduceddata_assumecomplex_large,
                                                                          scenario_info = "Scenario 0",
                                                                          design_info = "Reduced",
                                                                          sd_info="Large",
                                                                          sigma_assumed_info="Complex",
                                                                          algo_info="Normal")
  
  
  
  
  #'------------------------------------------------------------------------------
  #### Assume complex value for sd - fast  ----
  #'------------------------------------------------------------------------------
  
  #'------------------------------------------------------------------------------
  ##### Case: Simple  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_3d_Scenario0_alt_reduceddata_assumecomplex_fast_constant <- analysis_3dim(Res_Scenario0_alt_reduceddata_assumecomplex_fast_constant,
                                                                                  scenario_info = "Scenario 0",
                                                                                  design_info = "Reduced",
                                                                                  sd_info="Simple",
                                                                                  sigma_assumed_info="Complex",
                                                                                  algo_info="Fast")
  
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Small  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_3d_Scenario0_alt_reduceddata_assumecomplex_fast_small <- analysis_3dim(Res_Scenario0_alt_reduceddata_assumecomplex_fast_small,
                                                                               scenario_info = "Scenario 0",
                                                                               design_info = "Reduced",
                                                                               sd_info="Small",
                                                                               sigma_assumed_info="Complex",
                                                                               algo_info="Fast")
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Medium  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_3d_Scenario0_alt_reduceddata_assumecomplex_fast_medium <- analysis_3dim(Res_Scenario0_alt_reduceddata_assumecomplex_fast_medium,
                                                                                scenario_info = "Scenario 0",
                                                                                design_info = "Reduced",
                                                                                sd_info="Medium",
                                                                                sigma_assumed_info="Complex",
                                                                                algo_info="Fast")
  
  
  #'------------------------------------------------------------------------------
  ##### Case: Large  ----
  #'------------------------------------------------------------------------------
  
  Res_alert_3d_Scenario0_alt_reduceddata_assumecomplex_fast_large <- analysis_3dim(Res_Scenario0_alt_reduceddata_assumecomplex_fast_large,
                                                                               scenario_info = "Scenario 0",
                                                                               design_info = "Reduced",
                                                                               sd_info="Large",
                                                                               sigma_assumed_info="Complex",
                                                                               algo_info="Fast")
  
  
  #'------------------------------------------------------------------------------
  #### Save intermediate  ----
  #'------------------------------------------------------------------------------
  
  save( Res_alert_3d_Scenario0_alt_fulldata_assumeconstant_constant,
        Res_alert_3d_Scenario0_alt_fulldata_assumeconstant_fast_constant,
        Res_alert_3d_Scenario0_alt_fulldata_assumeconstant_small,
        Res_alert_3d_Scenario0_alt_fulldata_assumeconstant_fast_small,
        Res_alert_3d_Scenario0_alt_fulldata_assumeconstant_medium,
        Res_alert_3d_Scenario0_alt_fulldata_assumeconstant_fast_medium,
        Res_alert_3d_Scenario0_alt_fulldata_assumeconstant_large,
        Res_alert_3d_Scenario0_alt_fulldata_assumeconstant_fast_large,
        Res_alert_3d_Scenario0_alt_reduceddata_assumeconstant_constant,
        Res_alert_3d_Scenario0_alt_reduceddata_assumeconstant_fast_constant,
        Res_alert_3d_Scenario0_alt_reduceddata_assumeconstant_small,
        Res_alert_3d_Scenario0_alt_reduceddata_assumeconstant_fast_small,
        Res_alert_3d_Scenario0_alt_reduceddata_assumeconstant_medium,
        Res_alert_3d_Scenario0_alt_reduceddata_assumeconstant_fast_medium,
        Res_alert_3d_Scenario0_alt_reduceddata_assumeconstant_large,
        Res_alert_3d_Scenario0_alt_reduceddata_assumeconstant_fast_large,
        Res_alert_3d_Scenario0_alt_fulldata_assumecomplex_constant,
        Res_alert_3d_Scenario0_alt_fulldata_assumecomplex_fast_constant,
        Res_alert_3d_Scenario0_alt_fulldata_assumecomplex_small,
        Res_alert_3d_Scenario0_alt_fulldata_assumecomplex_fast_small,
        Res_alert_3d_Scenario0_alt_fulldata_assumecomplex_medium,
        Res_alert_3d_Scenario0_alt_fulldata_assumecomplex_fast_medium,
        Res_alert_3d_Scenario0_alt_fulldata_assumecomplex_large,
        Res_alert_3d_Scenario0_alt_fulldata_assumecomplex_fast_large,
        Res_alert_3d_Scenario0_alt_reduceddata_assumecomplex_constant,
        Res_alert_3d_Scenario0_alt_reduceddata_assumecomplex_fast_constant,
        Res_alert_3d_Scenario0_alt_reduceddata_assumecomplex_small,
        Res_alert_3d_Scenario0_alt_reduceddata_assumecomplex_fast_small,
        Res_alert_3d_Scenario0_alt_reduceddata_assumecomplex_medium,
        Res_alert_3d_Scenario0_alt_reduceddata_assumecomplex_fast_medium,
        Res_alert_3d_Scenario0_alt_reduceddata_assumecomplex_large,
        Res_alert_3d_Scenario0_alt_reduceddata_assumecomplex_fast_large,
        file="./simulation/020_scenario0_alt_analysis_3d_intermediate.RData")
}

#'==============================================================================
## Generate Table with resutls ====
#'==============================================================================

table_results_scenario0_alt_3d <- data.frame(
  "_"=c("Algorithm","Assumption","Scenario 0 - Full - Simple","Scenario 0 - Full -Small","Scenario 0 - Full - Medium","Scenario 0 - Full - Large",
        "Scenario 0 - Reduced - Simple","Scenario 0 - Reduced -Small","Scenario 0 - Reduced - Medium","Scenario 0 - Reduced - Large"),
  "H0_rejected_precent_const"=c("Normal","Constant",c(Res_alert_3d_Scenario0_alt_fulldata_assumeconstant_constant$H0_rejected,
                                                      Res_alert_3d_Scenario0_alt_fulldata_assumeconstant_small$H0_rejected,
                                                      Res_alert_3d_Scenario0_alt_fulldata_assumeconstant_medium$H0_rejected,
                                                      Res_alert_3d_Scenario0_alt_fulldata_assumeconstant_large$H0_rejected,
                                                      Res_alert_3d_Scenario0_alt_reduceddata_assumeconstant_constant$H0_rejected,
                                                      Res_alert_3d_Scenario0_alt_reduceddata_assumeconstant_small$H0_rejected,
                                                      Res_alert_3d_Scenario0_alt_reduceddata_assumeconstant_medium$H0_rejected,
                                                      Res_alert_3d_Scenario0_alt_reduceddata_assumeconstant_large$H0_rejected)/10),
  "H0_rejected_percent_const_fast"=c("Fast","Constant",c(Res_alert_3d_Scenario0_alt_fulldata_assumeconstant_fast_constant$H0_rejected,
                                                         Res_alert_3d_Scenario0_alt_fulldata_assumeconstant_fast_small$H0_rejected,
                                                         Res_alert_3d_Scenario0_alt_fulldata_assumeconstant_fast_medium$H0_rejected,
                                                         Res_alert_3d_Scenario0_alt_fulldata_assumeconstant_fast_large$H0_rejected,
                                                         Res_alert_3d_Scenario0_alt_reduceddata_assumeconstant_fast_constant$H0_rejected,
                                                         Res_alert_3d_Scenario0_alt_reduceddata_assumeconstant_fast_small$H0_rejected,
                                                         Res_alert_3d_Scenario0_alt_reduceddata_assumeconstant_fast_medium$H0_rejected,
                                                         Res_alert_3d_Scenario0_alt_reduceddata_assumeconstant_fast_large$H0_rejected)/10),
  "H0_rejected_percent_complex"=c("Normal","Complex",c(Res_alert_3d_Scenario0_alt_fulldata_assumecomplex_constant$H0_rejected,
                                                       Res_alert_3d_Scenario0_alt_fulldata_assumecomplex_small$H0_rejected,
                                                       Res_alert_3d_Scenario0_alt_fulldata_assumecomplex_medium$H0_rejected,
                                                       Res_alert_3d_Scenario0_alt_fulldata_assumecomplex_large$H0_rejected,
                                                       Res_alert_3d_Scenario0_alt_reduceddata_assumecomplex_constant$H0_rejected,
                                                       Res_alert_3d_Scenario0_alt_reduceddata_assumecomplex_small$H0_rejected,
                                                       Res_alert_3d_Scenario0_alt_reduceddata_assumecomplex_medium$H0_rejected,
                                                       Res_alert_3d_Scenario0_alt_reduceddata_assumecomplex_large$H0_rejected)/10),
  "H0_rejected_percent_complex_fast"=c("Fast","Complex",c(Res_alert_3d_Scenario0_alt_fulldata_assumecomplex_fast_constant$H0_rejected,
                                                          Res_alert_3d_Scenario0_alt_fulldata_assumecomplex_fast_small$H0_rejected,
                                                          Res_alert_3d_Scenario0_alt_fulldata_assumecomplex_fast_medium$H0_rejected,
                                                          Res_alert_3d_Scenario0_alt_fulldata_assumecomplex_fast_large$H0_rejected,
                                                          Res_alert_3d_Scenario0_alt_reduceddata_assumecomplex_fast_constant$H0_rejected,
                                                          Res_alert_3d_Scenario0_alt_reduceddata_assumecomplex_fast_small$H0_rejected,
                                                          Res_alert_3d_Scenario0_alt_reduceddata_assumecomplex_fast_medium$H0_rejected,
                                                          Res_alert_3d_Scenario0_alt_reduceddata_assumecomplex_fast_large$H0_rejected)/10)
)


#Check
#View(as.data.frame(t(table_results_scenario0_alt_3d)))


# write.xlsx(
#   as.data.frame(t(table_results_scenario0_alt_3d)),
#   file = "./plots_tables/206_simulation_scenario0_alt_results_3d_all.xlsx",
#   colNames = F,rowNames=T
# )

#Note, that the combinations constant - normal/fast are identical assumption wise
#They were run to compare the technical performance of both in general
#Since the performance is very similar, only the results of the fast algorithm
#are included in the paper, since there is an overall focus on the fast algorithm


#full data set
write.xlsx(
  as.data.frame(t(table_results_scenario0_alt_3d))[-2,1:6],
  file = "./plots_tables/207_simulation_scenario0_alt_results_3d_full.xlsx",
  colNames = F,rowNames=T
)

#reduced data set
write.xlsx(
  as.data.frame(t(table_results_scenario0_alt_3d))[-2,c(1:2,7:10)],
  file = "./plots_tables/208_simulation_scenario0_alt_results_3d_reduced.xlsx",
  colNames = F,rowNames=T
)



#'------------------------------------------------------------------------------
## Table with fit results -----
#'------------------------------------------------------------------------------

# 
# table_results_scenario0_alt_3d_fit <- data.frame(
#   "_"=c("Algorithm","Assumption","Scenario 0 - Full - Simple","Scenario 0 - Full -Small","Scenario 0 - Full - Medium","Scenario 0 - Full - Large",
#         "Scenario 0 - Reduced - Simple","Scenario 0 - Reduced -Small","Scenario 0 - Reduced - Medium","Scenario 0 - Reduced - Large"),
#   "H0_rejected_precent_const"=c("Normal","Constant",c(Res_alert_3d_Scenario0_alt_fulldata_assumeconstant_constant$H0_rejected_fit,
#                                                       Res_alert_3d_Scenario0_alt_fulldata_assumeconstant_small$H0_rejected_fit,
#                                                       Res_alert_3d_Scenario0_alt_fulldata_assumeconstant_medium$H0_rejected_fit,
#                                                       Res_alert_3d_Scenario0_alt_fulldata_assumeconstant_large$H0_rejected_fit,
#                                                       Res_alert_3d_Scenario0_alt_reduceddata_assumeconstant_constant$H0_rejected_fit,
#                                                       Res_alert_3d_Scenario0_alt_reduceddata_assumeconstant_small$H0_rejected_fit,
#                                                       Res_alert_3d_Scenario0_alt_reduceddata_assumeconstant_medium$H0_rejected_fit,
#                                                       Res_alert_3d_Scenario0_alt_reduceddata_assumeconstant_large$H0_rejected_fit)/10),
#   "H0_rejected_percent_const_fast"=c("Fast","Constant",c(Res_alert_3d_Scenario0_alt_fulldata_assumeconstant_fast_constant$H0_rejected_fit,
#                                                          Res_alert_3d_Scenario0_alt_fulldata_assumeconstant_fast_small$H0_rejected_fit,
#                                                          Res_alert_3d_Scenario0_alt_fulldata_assumeconstant_fast_medium$H0_rejected_fit,
#                                                          Res_alert_3d_Scenario0_alt_fulldata_assumeconstant_fast_large$H0_rejected_fit,
#                                                          Res_alert_3d_Scenario0_alt_reduceddata_assumeconstant_fast_constant$H0_rejected_fit,
#                                                          Res_alert_3d_Scenario0_alt_reduceddata_assumeconstant_fast_small$H0_rejected_fit,
#                                                          Res_alert_3d_Scenario0_alt_reduceddata_assumeconstant_fast_medium$H0_rejected_fit,
#                                                          Res_alert_3d_Scenario0_alt_reduceddata_assumeconstant_fast_large$H0_rejected_fit)/10),
#   "H0_rejected_percent_complex"=c("Normal","Complex",c(Res_alert_3d_Scenario0_alt_fulldata_assumecomplex_constant$H0_rejected_fit,
#                                                        Res_alert_3d_Scenario0_alt_fulldata_assumecomplex_small$H0_rejected_fit,
#                                                        Res_alert_3d_Scenario0_alt_fulldata_assumecomplex_medium$H0_rejected_fit,
#                                                        Res_alert_3d_Scenario0_alt_fulldata_assumecomplex_large$H0_rejected_fit,
#                                                        Res_alert_3d_Scenario0_alt_reduceddata_assumecomplex_constant$H0_rejected_fit,
#                                                        Res_alert_3d_Scenario0_alt_reduceddata_assumecomplex_small$H0_rejected_fit,
#                                                        Res_alert_3d_Scenario0_alt_reduceddata_assumecomplex_medium$H0_rejected_fit,
#                                                        Res_alert_3d_Scenario0_alt_reduceddata_assumecomplex_large$H0_rejected_fit)/10),
#   "H0_rejected_percent_complex_fast"=c("Fast","Complex",c(Res_alert_3d_Scenario0_alt_fulldata_assumecomplex_fast_constant$H0_rejected_fit,
#                                                           Res_alert_3d_Scenario0_alt_fulldata_assumecomplex_fast_small$H0_rejected_fit,
#                                                           Res_alert_3d_Scenario0_alt_fulldata_assumecomplex_fast_medium$H0_rejected_fit,
#                                                           Res_alert_3d_Scenario0_alt_fulldata_assumecomplex_fast_large$H0_rejected_fit,
#                                                           Res_alert_3d_Scenario0_alt_reduceddata_assumecomplex_fast_constant$H0_rejected_fit,
#                                                           Res_alert_3d_Scenario0_alt_reduceddata_assumecomplex_fast_small$H0_rejected_fit,
#                                                           Res_alert_3d_Scenario0_alt_reduceddata_assumecomplex_fast_medium$H0_rejected_fit,
#                                                           Res_alert_3d_Scenario0_alt_reduceddata_assumecomplex_fast_large$H0_rejected_fit)/10)
# )
# 
# #View(table_results_scenario0_alt_3d_fit)
# 
# #full data set
# write.xlsx(
#   as.data.frame(t(table_results_scenario0_alt_3d_fit[1:6,])),
#   file = "./plots_tables/301_simulation_scenario0_alt_results_fit_full.xlsx",
#   colNames = F,rowNames=T
# )
# 
# #reduced data set
# write.xlsx(
#   as.data.frame(t(table_results_scenario0_alt_3d_fit[c(1:2,7:10),])),
#   file = "./plots_tables/302_simulation_scenario0_alt_results_fit_reduced.xlsx",
#   colNames = F,rowNames=T
# )
