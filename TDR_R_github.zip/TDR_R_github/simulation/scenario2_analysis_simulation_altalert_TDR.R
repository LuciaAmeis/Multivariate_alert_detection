#'##############################################################################
#                                                                              #
#                  Corresponding R Code to the Manuscript                      #
#                "Estimating effect thresholds and beyond:                     #
#              A flexible framework for multivariate alert detection"          #
#                                                                              #
#                                 Authors                                      #
#                    L. Ameis, N. Hagemann and K. Moellenhoff                  #
#                                                                              #
#                         Simulation - Scenario 2: Analysis simulation         #
#                                                                              #
#'##############################################################################


#'==============================================================================
# Two dimensional analysis ====
#'==============================================================================



#'==============================================================================
## Analysis function ====
#'==============================================================================

analysis_2dim <- function(res){
  
  #2dim approach
  res_vec_2dim <- numeric(1000)
  faild_runs_2dim <- numeric(1000)
  for(i in 1:1000){
    if(anyNA(res[[i]])==T){
      faild_runs_2dim[i] <- 1
      alert <- NA  
    } else{
      #identify grid alert
      id<-min(which(res[[i]]$conf$fixtime>threshold50))
      #check if last grid point is selected, then no alert was detected
      if(is.integer(id) && length(id) == 0){
        alert <- NA  
      }
      #save alert
      alert<-dose_seq[id]
    } 
    res_vec_2dim[i] <- alert
  }  
  
  #3dim approach
  res_vec_3dim <- numeric(1000)
  faild_runs_3dim <- numeric(1000)
  for(i in 1:1000){
    if(anyNA(res[[i]])==T){
      faild_runs_3dim[i] <- 1
      alert <- NA  
    } else{
      #identify grid alert
      conf_band_mat <- res[[i]]$conf$full   %>%
        cbind(grid_full, "cf"=. )                %>%
        reshape2::acast(., 
                        time~dose, 
                        value.var="cf")
      
      which(rownames(conf_band_mat)==7)
      #71 
      
      id <- min(which(conf_band_mat[71,]>threshold50)) 
      #check if there is an alert
      if(is.integer(id) && length(id) == 0){
        alert <- NA  
      }
      #save alert
      alert<-dose_seq[id]
    } 
    res_vec_3dim[i] <- alert
  }  
  
  
  return(list("all_alerts_2dim"=res_vec_2dim,
              "all_alerts_3dim"=res_vec_3dim,
              "median_2dim"=median(res_vec_2dim,na.rm=T),
              "median_3dim"=median(res_vec_3dim,na.rm=T),
              "sd_2dim"=round(sd(res_vec_2dim,na.rm=T),3),
              "sd_3dim"=round(sd(res_vec_3dim,na.rm=T),3),
              "failed_runs_2dim"=sum(faild_runs_2dim),
              "failed_runs_3dim"=sum(faild_runs_3dim),
              "H0_reject_2dim"=sum(!is.na(res_vec_2dim)),
              "H0_reject_3dim"=sum(!is.na(res_vec_3dim))
  ))
}


if(file.exists("./simulation/030_scenario2_altalert_analysis_2d_intermediate.RData")){
  load("./simulation/030_scenario2_altalert_analysis_2d_intermediate.RData")
}else{
  #'==============================================================================
  ## Des9 ====
  #'==============================================================================
  
  #N152
  Res_altalert_fixtime_Scenario2_des9_152 <- analysis_2dim(Res_Scenario2_des9_152)
  
  
  #N90
  Res_altalert_fixtime_Scenario2_des9_90 <- analysis_2dim(Res_Scenario2_des9_90)
  
  
  #N45
  Res_altalert_fixtime_Scenario2_des9_45 <- analysis_2dim(Res_Scenario2_des9_45)
  
  
  
  #'==============================================================================
  ## Dopt ====
  #'==============================================================================
  
  #N152
  Res_altalert_fixtime_Scenario2_dopt_152 <- analysis_2dim(Res_Scenario2_dopt_152)
  
  
  #N90
  Res_altalert_fixtime_Scenario2_dopt_90 <- analysis_2dim(Res_Scenario2_dopt_90)
  
  
  #N45
  Res_altalert_fixtime_Scenario2_dopt_45 <- analysis_2dim(Res_Scenario2_dopt_45)
  
  save(Res_altalert_fixtime_Scenario2_des9_152,
       Res_altalert_fixtime_Scenario2_des9_90,
       Res_altalert_fixtime_Scenario2_des9_45,
       Res_altalert_fixtime_Scenario2_dopt_152,
       Res_altalert_fixtime_Scenario2_dopt_90,
       Res_altalert_fixtime_Scenario2_dopt_45,
       file="./simulation/030_scenario2_altalert_analysis_2d_intermediate.RData")
}

#'==============================================================================
## Generate Table with resutls ====
#'==============================================================================

table_results_scenario2_2d <- data.frame(
  "_"=c("Approach","Scenario 2 - Factorial 3x3 - N152","Scenario 2 - Factorial 3x3 - N90","Scenario 2 - Factorial 3x3 - N45","Scenario 2 - D-optimal - N152",
        "Scenario 2 - D-optimal - N90","Scenario 2 - D-optimal - N45"),
  "H0_rejected_percent_2D"=c("2D",c(Res_altalert_fixtime_Scenario2_des9_152$H0_reject_2dim,
                                    Res_altalert_fixtime_Scenario2_des9_90$H0_reject_2dim,
                                    Res_altalert_fixtime_Scenario2_des9_45$H0_reject_2dim,
                                    Res_altalert_fixtime_Scenario2_dopt_152$H0_reject_2dim,
                                    Res_altalert_fixtime_Scenario2_dopt_90$H0_reject_2dim,
                                    Res_altalert_fixtime_Scenario2_dopt_45$H0_reject_2dim)/10),
  "H0_rejected_percent_3D"=c("3D",c(Res_altalert_fixtime_Scenario2_des9_152$H0_reject_3dim,
                                    Res_altalert_fixtime_Scenario2_des9_90$H0_reject_3dim,
                                    Res_altalert_fixtime_Scenario2_des9_45$H0_reject_3dim,
                                    Res_altalert_fixtime_Scenario2_dopt_152$H0_reject_3dim,
                                    Res_altalert_fixtime_Scenario2_dopt_90$H0_reject_3dim,
                                    Res_altalert_fixtime_Scenario2_dopt_45$H0_reject_3dim)/10),
  "Median_2D"=c("2D",Res_altalert_fixtime_Scenario2_des9_152$median_2dim,
                Res_altalert_fixtime_Scenario2_des9_90$median_2dim,
                Res_altalert_fixtime_Scenario2_des9_45$median_2dim,
                Res_altalert_fixtime_Scenario2_dopt_152$median_2dim,
                Res_altalert_fixtime_Scenario2_dopt_90$median_2dim,
                Res_altalert_fixtime_Scenario2_dopt_45$median_2dim),
  "Median_3D"=c("3D",Res_altalert_fixtime_Scenario2_des9_152$median_3dim,
                Res_altalert_fixtime_Scenario2_des9_90$median_3dim,
                Res_altalert_fixtime_Scenario2_des9_45$median_3dim,
                Res_altalert_fixtime_Scenario2_dopt_152$median_3dim,
                Res_altalert_fixtime_Scenario2_dopt_90$median_3dim,
                Res_altalert_fixtime_Scenario2_dopt_45$median_3dim),
  "SD_2D"=c("2D",Res_altalert_fixtime_Scenario2_des9_152$sd_2dim,
            Res_altalert_fixtime_Scenario2_des9_90$sd_2dim,
            Res_altalert_fixtime_Scenario2_des9_45$sd_2dim,
            Res_altalert_fixtime_Scenario2_dopt_152$sd_2dim,
            Res_altalert_fixtime_Scenario2_dopt_90$sd_2dim,
            Res_altalert_fixtime_Scenario2_dopt_45$sd_2dim),
  "SD_3D"=c("3D",Res_altalert_fixtime_Scenario2_des9_152$sd_3dim,
            Res_altalert_fixtime_Scenario2_des9_90$sd_3dim,
            Res_altalert_fixtime_Scenario2_des9_45$sd_3dim,
            Res_altalert_fixtime_Scenario2_dopt_152$sd_3dim,
            Res_altalert_fixtime_Scenario2_dopt_90$sd_3dim,
            Res_altalert_fixtime_Scenario2_dopt_45$sd_3dim),
  "Failed_runs_2D"=c("2D",Res_altalert_fixtime_Scenario2_des9_152$failed_runs_2dim,
                     Res_altalert_fixtime_Scenario2_des9_90$failed_runs_2dim,
                     Res_altalert_fixtime_Scenario2_des9_45$failed_runs_2dim,
                     Res_altalert_fixtime_Scenario2_dopt_152$failed_runs_2dim,
                     Res_altalert_fixtime_Scenario2_dopt_90$failed_runs_2dim,
                     Res_altalert_fixtime_Scenario2_dopt_45$failed_runs_2dim),
  "Failed_runs_3D"=c("3D",Res_altalert_fixtime_Scenario2_des9_152$failed_runs_3dim,
                     Res_altalert_fixtime_Scenario2_des9_90$failed_runs_3dim,
                     Res_altalert_fixtime_Scenario2_des9_45$failed_runs_3dim,
                     Res_altalert_fixtime_Scenario2_dopt_152$failed_runs_3dim,
                     Res_altalert_fixtime_Scenario2_dopt_90$failed_runs_3dim,
                     Res_altalert_fixtime_Scenario2_dopt_45$failed_runs_3dim)
)



write.xlsx(
  as.data.frame(t(table_results_scenario2_2d)),
  file = "./plots_tables/209_simulation_scenario2_altalert_results_2d_all.xlsx",
  colNames = F,rowNames=T
)


#full data set
write.xlsx(
  as.data.frame(t(table_results_scenario2_2d))[c(-8,-9),1:4],
  file = "./plots_tables/210_simulation_scenario2_altalert_results_2d_des9.xlsx",
  colNames = F,rowNames=T
)

#reduced data set
write.xlsx(
  as.data.frame(t(table_results_scenario2_2d))[c(-8,-9),c(1,5:7)],
  file = "./plots_tables/211_simulation_scenario2_altalert_results_2d_dopt.xlsx",
  colNames = F,rowNames=T
)


#'==============================================================================
# Three dimensional analysis ====
#'==============================================================================

#'==============================================================================
## Analysis function ====
#'==============================================================================

#rename for later use
true_alert_relationship_df <- true_alert_relationship50 %>%
  rename(d_true = dose)

#Help function to identify errors per time point
compute_errors_one_sim <- function(sim_df) {
  
  sim_df %>%
    rename(d_hat = dose) %>%
    inner_join(true_alert_relationship_df, by = "time") %>%   # regard overlap
    filter(!is.na(d_hat)&!is.na(d_true)) %>%                # identified doses
    mutate(error = d_hat - d_true) %>%
    dplyr::select(time, error)
}


analysis_3dim <- function(res,scenario_info,
                          design_info,
                          nobsv_info){
  
  #2dim approach
  res_list <- list()
  no_alert <- numeric(1000) #already somewhat regarded above
  for(i in 1:1000){
    if(anyNA(res[[i]])==T){
      no_alert[i] <- 1
      alert <- F  
    } else{
      #identify grid alert
      conf_band_mat <- res[[i]]$conf$full   %>%
        cbind(grid_full, "cf"=. )                %>%
        reshape2::acast(., 
                        time~dose, 
                        value.var="cf")
      
      alert_id <- matrix(NA,nrow=length(time_seq),ncol=2)
      for(j in length(time_seq):1){
        alert_id[j,1] <- j
        alert_id[j,2] <- min(subset(which(conf_band_mat>threshold50,arr.ind=T)[,2],
                                    which(conf_band_mat>threshold50,arr.ind=T)[,1]==j))
      }
      if(sum(is.infinite(alert_id[,2])) == nrow(alert_id)){
        alert <- F  
        no_alert[i] <-1
      } else{
        alert <- data.frame("time"=time_seq[alert_id[,1]],
                            "dose"=dose_seq[alert_id[,2]])
      }
    }
    res_list[[i]] <- alert
    
  }  
  
  
  true_alert_tf <- true_alert_relationship50$time[which(!is.na(true_alert_relationship50$dose))]
  
  recall_vec <- numeric(1000)
  for(i in 1:1000){
    if(no_alert[i]!=1){
      alert_tf <- res_list[[i]]$time[which(!is.na(res_list[[i]]$dose))]
      recall_vec[i] <- length(intersect(true_alert_tf,alert_tf))/length(true_alert_tf)
    } else{
      recall_vec[i] <- NA
    }
  }
  
  precision_vec <- numeric(1000)
  for(i in 1:1000){
    if(no_alert[i]!=1){
      alert_tf <- res_list[[i]]$time[which(!is.na(res_list[[i]]$dose))]
      precision_vec[i] <- length(intersect(true_alert_tf,alert_tf))/length(alert_tf)
    } else{
      precision_vec[i] <- NA
    }
  }
  
  
  onset_err_vec <- numeric(1000)
  for(i in 1:1000){
    if(no_alert[i]!=1){
      alert_tf <- res_list[[i]]$time[which(!is.na(res_list[[i]]$dose))]
      onset_err_vec[i]<-min(alert_tf)-min(true_alert_tf)
    } else{
      onset_err_vec[i] <- NA
    }
  }
  
  offset_err_vec <- numeric(1000)
  for(i in 1:1000){
    if(no_alert[i]!=1){
      alert_tf <- res_list[[i]]$time[which(!is.na(res_list[[i]]$dose))]
      offset_err_vec[i]<-max(alert_tf)-max(true_alert_tf)
    } else{
      offset_err_vec[i] <- NA
    }
  }
  
  rmse_overlap <- numeric(1000)
  for(i in 1:1000){
    if(no_alert[i]!=1){
      alert_tf <- res_list[[i]]$time[which(!is.na(res_list[[i]]$dose))]
      
      alert <- res_list[[i]]
      truth_ol <- true_alert_relationship50[true_alert_relationship50$time %in% intersect(true_alert_tf,alert_tf), ]
      alert_ol   <- alert[alert$time %in% intersect(true_alert_tf,alert_tf), ]
      
      rmse_overlap[i] <- sqrt(mean((alert_ol$dose-truth_ol$dose)^2))
    } else{
      rmse_overlap[i] <- NA
    }
  }
  
  
  res_list_red <- Filter(
    function(x) is.data.frame(x),
    res_list
  )
  
  errors_case <- purrr::imap_dfr(
    res_list_red,
    ~ compute_errors_one_sim(.x) %>%
      mutate(sim = .y)
  )
  
  
  case_info <- data.frame(
    scenario = scenario_info,
    design = design_info,
    nobsv=nobsv_info
  )
  
  errors_case <- errors_case %>%
    mutate(
      scenario = case_info$scenario,
      design = case_info$design,
      nobsv=case_info$nobsv
    )
  
  df_errors  <- errors_case %>%
    group_by(design, nobsv, time) %>%
    summarise(
      med_error = median(error),
      q10 = quantile(error, 0.1),
      q90 = quantile(error, 0.9),
      .groups = "drop"
    )
  
  
  return(list("info"=c(scenario_info,design_info,nobsv_info),
              "all_alert_relatioships"=res_list,
              "errors"=df_errors,
              "recall"=recall_vec,
              "precision"=precision_vec,
              "onset_err"=onset_err_vec,
              "offset_err"=offset_err_vec,
              "rmse_overlap"=rmse_overlap,
              "H0_rejected"=1000-sum(no_alert)
  )
  )
}

if(file.exists("./simulation/040_scenario2_altalert_analysis_3d_intermediate.RData")){
  load("./simulation/040_scenario2_altalert_analysis_3d_intermediate.RData")
}else{
  #'==============================================================================
  ## Des9 ====
  #'==============================================================================
  
  #N152
  Res_altalert_3d_Scenario2_des9_152 <- analysis_3dim(Res_Scenario2_des9_152,
                                                   scenario_info = "Scenario 2",
                                                   design_info = "Factorial 3x3",
                                                   nobsv_info = "N152")
  
  
  #N90
  Res_altalert_3d_Scenario2_des9_90 <- analysis_3dim(Res_Scenario2_des9_90,
                                                  scenario_info = "Scenario 2",
                                                  design_info = "Factorial 3x3",
                                                  nobsv_info = "N90")
  
  
  #N45
  Res_altalert_3d_Scenario2_des9_45 <- analysis_3dim(Res_Scenario2_des9_45,
                                                  scenario_info = "Scenario 2",
                                                  design_info = "Factorial 3x3",
                                                  nobsv_info = "N45")
  
  
  
  #'==============================================================================
  ## Dopt ====
  #'==============================================================================
  
  #N152
  Res_altalert_3d_Scenario2_dopt_152 <- analysis_3dim(Res_Scenario2_dopt_152,
                                                   scenario_info = "Scenario 2",
                                                   design_info = "D - optimal",
                                                   nobsv_info = "N152")
  
  
  #N90
  Res_altalert_3d_Scenario2_dopt_90 <- analysis_3dim(Res_Scenario2_dopt_90,
                                                  scenario_info = "Scenario 2",
                                                  design_info = "D - optimal",
                                                  nobsv_info = "N90")
  
  
  #N45
  Res_altalert_3d_Scenario2_dopt_45 <- analysis_3dim(Res_Scenario2_dopt_45,
                                                  scenario_info = "Scenario 2",
                                                  design_info = "D - optimal",
                                                  nobsv_info = "N45")
  
  save(Res_altalert_3d_Scenario2_des9_152,
       Res_altalert_3d_Scenario2_des9_90,
       Res_altalert_3d_Scenario2_des9_45,
       Res_altalert_3d_Scenario2_dopt_152,
       Res_altalert_3d_Scenario2_dopt_90,
       Res_altalert_3d_Scenario2_dopt_45,
       file="./simulation/040_scenario2_altalert_analysis_3d_intermediate.RData")
  
}

#'==============================================================================
## Generate Table with resutls ====
#'==============================================================================


table_results_scenario2_3d <- data.frame(
  "_"=c("Scenario 2 - Factorial 3x3 - N152","Scenario 2 - Factorial 3x3 - N90","Scenario 2 - Factorial 3x3 - N45","Scenario 2 - D-optimal - N152",
        "Scenario 2 - D-optimal - N90","Scenario 2 - D-optimal - N45"),
  "H0_reject_percent"=c(Res_altalert_3d_Scenario2_des9_152$H0_rejected,
                        Res_altalert_3d_Scenario2_des9_90$H0_rejected,
                        Res_altalert_3d_Scenario2_des9_45$H0_rejected,
                        Res_altalert_3d_Scenario2_dopt_152$H0_rejected,
                        Res_altalert_3d_Scenario2_dopt_90$H0_rejected,
                        Res_altalert_3d_Scenario2_dopt_45$H0_rejected)/10,
  "Mean_recall_percent"=c(round(c(mean(Res_altalert_3d_Scenario2_des9_152$recall,na.rm=T),
                                  mean(Res_altalert_3d_Scenario2_des9_90$recall,na.rm=T),
                                  mean(Res_altalert_3d_Scenario2_des9_45$recall,na.rm=T),
                                  mean(Res_altalert_3d_Scenario2_dopt_152$recall,na.rm=T),
                                  mean(Res_altalert_3d_Scenario2_dopt_90$recall,na.rm=T),
                                  mean(Res_altalert_3d_Scenario2_dopt_45$recall,na.rm=T)
  ),3)*100),
  "SD_recall_percent"=c(round(c(sd(Res_altalert_3d_Scenario2_des9_152$recall,na.rm=T),
                                sd(Res_altalert_3d_Scenario2_des9_90$recall,na.rm=T),
                                sd(Res_altalert_3d_Scenario2_des9_45$recall,na.rm=T),
                                sd(Res_altalert_3d_Scenario2_dopt_152$recall,na.rm=T),
                                sd(Res_altalert_3d_Scenario2_dopt_90$recall,na.rm=T),
                                sd(Res_altalert_3d_Scenario2_dopt_45$recall,na.rm=T)
  ),3)*100),
  "Mean_precision_percent"=c(round(c(mean(Res_altalert_3d_Scenario2_des9_152$precision,na.rm=T),
                                     mean(Res_altalert_3d_Scenario2_des9_90$precision,na.rm=T),
                                     mean(Res_altalert_3d_Scenario2_des9_45$precision,na.rm=T),
                                     mean(Res_altalert_3d_Scenario2_dopt_152$precision,na.rm=T),
                                     mean(Res_altalert_3d_Scenario2_dopt_90$precision,na.rm=T),
                                     mean(Res_altalert_3d_Scenario2_dopt_45$precision,na.rm=T)
  ),3)*100),
  "SD_precision_percent"=c(round(c(sd(Res_altalert_3d_Scenario2_des9_152$precision,na.rm=T),
                                   sd(Res_altalert_3d_Scenario2_des9_90$precision,na.rm=T),
                                   sd(Res_altalert_3d_Scenario2_des9_45$precision,na.rm=T),
                                   sd(Res_altalert_3d_Scenario2_dopt_152$precision,na.rm=T),
                                   sd(Res_altalert_3d_Scenario2_dopt_90$precision,na.rm=T),
                                   sd(Res_altalert_3d_Scenario2_dopt_45$precision,na.rm=T)
  ),3)*100),
  "Mean_onset_err" =c(round(c(mean(Res_altalert_3d_Scenario2_des9_152$onset_err,na.rm=T),
                              mean(Res_altalert_3d_Scenario2_des9_90$onset_err,na.rm=T),
                              mean(Res_altalert_3d_Scenario2_des9_45$onset_err,na.rm=T),
                              mean(Res_altalert_3d_Scenario2_dopt_152$onset_err,na.rm=T),
                              mean(Res_altalert_3d_Scenario2_dopt_90$onset_err,na.rm=T),
                              mean(Res_altalert_3d_Scenario2_dopt_45$onset_err,na.rm=T)
  ),3)),
  "SD_onset_err" =c(round(c(sd(Res_altalert_3d_Scenario2_des9_152$onset_err,na.rm=T),
                            sd(Res_altalert_3d_Scenario2_des9_90$onset_err,na.rm=T),
                            sd(Res_altalert_3d_Scenario2_des9_45$onset_err,na.rm=T),
                            sd(Res_altalert_3d_Scenario2_dopt_152$onset_err,na.rm=T),
                            sd(Res_altalert_3d_Scenario2_dopt_90$onset_err,na.rm=T),
                            sd(Res_altalert_3d_Scenario2_dopt_45$onset_err,na.rm=T)
  ),3)),
  "Mean_offset_err"=c(round(c(mean(Res_altalert_3d_Scenario2_des9_152$offset_err,na.rm=T),
                              mean(Res_altalert_3d_Scenario2_des9_90$offset_err,na.rm=T),
                              mean(Res_altalert_3d_Scenario2_des9_45$offset_err,na.rm=T),
                              mean(Res_altalert_3d_Scenario2_dopt_152$offset_err,na.rm=T),
                              mean(Res_altalert_3d_Scenario2_dopt_90$offset_err,na.rm=T),
                              mean(Res_altalert_3d_Scenario2_dopt_45$offset_err,na.rm=T)
  ),3)),
  "SD_offset_err"=c(round(c(sd(Res_altalert_3d_Scenario2_des9_152$offset_err,na.rm=T),
                            sd(Res_altalert_3d_Scenario2_des9_90$offset_err,na.rm=T),
                            sd(Res_altalert_3d_Scenario2_des9_45$offset_err,na.rm=T),
                            sd(Res_altalert_3d_Scenario2_dopt_152$offset_err,na.rm=T),
                            sd(Res_altalert_3d_Scenario2_dopt_90$offset_err,na.rm=T),
                            sd(Res_altalert_3d_Scenario2_dopt_45$offset_err,na.rm=T)
  ),3))
)



write.xlsx(
  as.data.frame(t(table_results_scenario2_3d)),
  file = "./plots_tables/212_simulation_scenario2_altalert_results_3d_all.xlsx",
  colNames = F,rowNames=T
)


#full data set
write.xlsx(
  as.data.frame(t(table_results_scenario2_3d))[,1:3],
  file = "./plots_tables/213_simulation_scenario2_altalert_results_3d_des9.xlsx",
  colNames = F,rowNames=T
)

#reduced data set
write.xlsx(
  as.data.frame(t(table_results_scenario2_3d))[,4:6],
  file = "./plots_tables/214_simulation_scenario2_altalert_results_3d_dopt.xlsx",
  colNames = F,rowNames=T
)

