#'##############################################################################
#                                                                              #
#                  Corresponding R Code to the Manuscript                      #
#                "Estimating effect thresholds and beyond:                     #
#              A flexible framework for multivariate alert detection"          #
#                                                                              #
#                                 Authors                                      #
#                    L. Ameis, N. Hagemann and K. Moellenhoff                  #
#                                                                              #
#                         Simulation - Dose-Dose                               #
#                                                                              #
#'##############################################################################

#Here we create a simulation scenario based on the second scenario regarded
#in https://doi.org/10.48550/arXiv.2506.05913

#This is a Dose-Dose-Response scenario with two compoounds that show 
# positive interaction effect

#The three dimensional scenario is modeled combinint two Emax models


#'==============================================================================
## Model formula ====
#'==============================================================================

#model function
emax_emax <- function(t, d, theta) {
  #t time
  #d dose
  #theta parameters of the function
  
  E0 <- theta[1]
  Emax_A  <- theta[2]
  ED_A   <- theta[3]
  Emax_B   <- theta[4]
  ED_B   <- theta[5]
  
  gamma <- theta[6]
  
  z <-E0 + (Emax_A*t)/(ED_A+t) + (Emax_B*d)/(ED_B+d) +
    gamma*((Emax_A*t)/(ED_A+t))*((Emax_B*d)/(ED_B+d))
  
  z
}



emax_emax_formula <- ~ E0 + (Emax_A*time)/(ED_A+time) + (Emax_B*dose)/(ED_B+dose) +
  gamma*((Emax_A*time)/(ED_A+time))*((Emax_B*dose)/(ED_B+dose))

emax_emax_fast <- function (data){
  fit <- tryCatch({nlsLM(resp ~ E0 + (Emax_A*time)/(ED_A+time) + (Emax_B*dose)/(ED_B+dose) +
                           gamma*((Emax_A*time)/(ED_A+time))*((Emax_B*dose)/(ED_B+dose)),
  data = data,
  lower = c(E0= 0, Emax_A=-800, ED_A=0, Emax_B= -800, ED_B=0, gamma=-2),
  upper = c(E0=200, Emax_A= 800, ED_A=100, Emax_B = 800, ED_B=100, gamma=2),
  start = mu_start )}, error=function(e){
    NA
  })
  fit
}

#'==============================================================================
# Store analysis specific information ====
#'==============================================================================
#Bootstrap runs
B_out<-500
B_in<-25

#Number of simulations
N <- 1000


#'==============================================================================
## Basics grid ====
#'==============================================================================


#Grid
# Define design region
min_time <- 0
max_time <- 10
min_dose <- 0
max_dose <- 12

#fineness of the grid
epsilon <- 0.1

time_seq <- seq(min_time, max_time, by=epsilon)   #time
dose_seq <- seq(min_dose, max_dose, by=epsilon)   #dose

grid_full      <- data.frame("time"=rep(time_seq, times=length(dose_seq)))
grid_dose <- numeric(length=length(time_seq)*length(dose_seq))
for(i in 1:length(dose_seq)){
  grid_dose[((i-1)*length(time_seq)+1):(i*length(time_seq))] <- rep(dose_seq[i],  times=length(time_seq))
}
grid_full$dose <- grid_dose


#'==============================================================================
## Model specifications ====
#'==============================================================================

#'------------------------------------------------------------------------------
#### Basics mu ----
#'------------------------------------------------------------------------------
#Define parameter from scenario 2 in Schürmeyer et al
params_simul <- c(0, 80, 3, 120, 10, 0.02)

model <- emax_emax

fit_fast <- emax_emax_fast

mu_formula <- emax_emax_formula

mu_start <-  c(E0=0, Emax_A= 100, ED_A=5,
               Emax_B= 250, ED_B=7,
               gamma=0.01)


#identify alert
resp_mat_true <- model(t=grid_full$time, 
                       d=grid_full$dose, 
                       theta=params_simul)          %>%
  cbind(grid_full, "response"=.)                        %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="response")

Rmax <- max(resp_mat_true) #-min(resp_mat_true) 0 per def
p80 <- 80
p50 <- 50

threshold80  <- (Rmax*p80)/100 
threshold50  <- (Rmax*p50)/100 

#True alert at fix time t=7
true_alert80<-dose_seq[min(which(model(t=7,d=dose_seq,theta = params_simul)>threshold80))]
true_alert50<-dose_seq[min(which(model(t=7,d=dose_seq,theta = params_simul)>threshold50))]


true_alert_relationship_id80 <- matrix(NA,nrow=length(time_seq),ncol=2)
for(i in length(time_seq):1){
  true_alert_relationship_id80[i,1] <- i
  true_alert_relationship_id80[i,2] <- min(subset(which(resp_mat_true>threshold80,arr.ind=T)[,2],
                                                  which(resp_mat_true>threshold80,arr.ind=T)[,1]==i))
}   

true_alert_relationship80 <- data.frame("time"=time_seq[true_alert_relationship_id80[,1]],
                                        "dose"=dose_seq[true_alert_relationship_id80[,2]])


true_alert_relationship_id50 <- matrix(NA,nrow=length(time_seq),ncol=2)
for(i in length(time_seq):1){
  true_alert_relationship_id50[i,1] <- i
  true_alert_relationship_id50[i,2] <- min(subset(which(resp_mat_true>threshold50,arr.ind=T)[,2],
                                                  which(resp_mat_true>threshold50,arr.ind=T)[,1]==i))
}   

true_alert_relationship50 <- data.frame("time"=time_seq[true_alert_relationship_id50[,1]],
                                        "dose"=dose_seq[true_alert_relationship_id50[,2]])


#'------------------------------------------------------------------------------
#### Basics sigma ----
#'------------------------------------------------------------------------------


sigma_formula <- ~ 1

sigma_coef <- log(30)

sigma_start <- 3.4

#'==============================================================================
## Design 3x3 factorial ====
#'==============================================================================

#'------------------------------------------------------------------------------
#### Design specifications ----
#'------------------------------------------------------------------------------


#Grid 3x3 factorial desing as described in Schürmeyer et al
grid9Design <- list(
                    weights = rep(1/9,9),
                    supPoints_time = c(0,0,0,max_time/2,max_time/2,max_time/2,max_time,max_time,max_time),
                    supPoints_dose = c(0,max_dose/2,max_dose,0,max_dose/2,max_dose,0,max_dose/2,max_dose)
)

#Number of the observations at dose dose combinations 
numObs_152 <- as.numeric(rndDesign(grid9Design$weights, 152))
numObs_90 <- as.numeric(rndDesign(grid9Design$weights, 90))
numObs_45 <- as.numeric(rndDesign(grid9Design$weights, 45))

#Doses 
DoseValA <- grid9Design$supPoints_time[which(numObs_152!=0)]
DoseValB <- grid9Design$supPoints_dose[which(numObs_152!=0)]
numObs_no_zero <- numObs_152[which(numObs_152!=0)]


#DF n=152
data_simul_des9_152 <- data.frame("time"=c(rep(DoseValA[1],times=numObs_no_zero[1]),
                                    rep(DoseValA[2],times=numObs_no_zero[2]),
                                    rep(DoseValA[3],times=numObs_no_zero[3]),
                                    rep(DoseValA[4],times=numObs_no_zero[4]),
                                    rep(DoseValA[5],times=numObs_no_zero[5]),
                                    rep(DoseValA[6],times=numObs_no_zero[6]),
                                    rep(DoseValA[7],times=numObs_no_zero[7]),
                                    rep(DoseValA[8],times=numObs_no_zero[8]),
                                    rep(DoseValA[9],times=numObs_no_zero[9])),
                         "dose"=c(rep(DoseValB[1],times=numObs_no_zero[1]),
                                    rep(DoseValB[2],times=numObs_no_zero[2]),
                                    rep(DoseValB[3],times=numObs_no_zero[3]),
                                    rep(DoseValB[4],times=numObs_no_zero[4]),
                                    rep(DoseValB[5],times=numObs_no_zero[5]),
                                    rep(DoseValB[6],times=numObs_no_zero[6]),
                                    rep(DoseValB[7],times=numObs_no_zero[7]),
                                    rep(DoseValB[8],times=numObs_no_zero[8]),
                                    rep(DoseValB[9],times=numObs_no_zero[9]))
)


#DF n=90
DoseValA <- grid9Design$supPoints_time[which(numObs_90!=0)]
DoseValB <- grid9Design$supPoints_dose[which(numObs_90!=0)]
numObs_no_zero <- numObs_90[which(numObs_90!=0)]

data_simul_des9_90 <- data.frame("time"=c(rep(DoseValA[1],times=numObs_no_zero[1]),
                                  rep(DoseValA[2],times=numObs_no_zero[2]),
                                  rep(DoseValA[3],times=numObs_no_zero[3]),
                                  rep(DoseValA[4],times=numObs_no_zero[4]),
                                  rep(DoseValA[5],times=numObs_no_zero[5]),
                                  rep(DoseValA[6],times=numObs_no_zero[6]),
                                  rep(DoseValA[7],times=numObs_no_zero[7]),
                                  rep(DoseValA[8],times=numObs_no_zero[8]),
                                  rep(DoseValA[9],times=numObs_no_zero[9])),
                         "dose"=c(rep(DoseValB[1],times=numObs_no_zero[1]),
                                  rep(DoseValB[2],times=numObs_no_zero[2]),
                                  rep(DoseValB[3],times=numObs_no_zero[3]),
                                  rep(DoseValB[4],times=numObs_no_zero[4]),
                                  rep(DoseValB[5],times=numObs_no_zero[5]),
                                  rep(DoseValB[6],times=numObs_no_zero[6]),
                                  rep(DoseValB[7],times=numObs_no_zero[7]),
                                  rep(DoseValB[8],times=numObs_no_zero[8]),
                                  rep(DoseValB[9],times=numObs_no_zero[9]))
)



#DF n=45
#Doses 
DoseValA <- grid9Design$supPoints_time[which(numObs_45!=0)]
DoseValB <- grid9Design$supPoints_dose[which(numObs_45!=0)]
numObs_no_zero <- numObs_45[which(numObs_45!=0)]

data_simul_des9_45 <- data.frame("time"=c(rep(DoseValA[1],times=numObs_no_zero[1]),
                                          rep(DoseValA[2],times=numObs_no_zero[2]),
                                          rep(DoseValA[3],times=numObs_no_zero[3]),
                                          rep(DoseValA[4],times=numObs_no_zero[4]),
                                          rep(DoseValA[5],times=numObs_no_zero[5]),
                                          rep(DoseValA[6],times=numObs_no_zero[6]),
                                          rep(DoseValA[7],times=numObs_no_zero[7]),
                                          rep(DoseValA[8],times=numObs_no_zero[8]),
                                          rep(DoseValA[9],times=numObs_no_zero[9])),
                                 "dose"=c(rep(DoseValB[1],times=numObs_no_zero[1]),
                                          rep(DoseValB[2],times=numObs_no_zero[2]),
                                          rep(DoseValB[3],times=numObs_no_zero[3]),
                                          rep(DoseValB[4],times=numObs_no_zero[4]),
                                          rep(DoseValB[5],times=numObs_no_zero[5]),
                                          rep(DoseValB[6],times=numObs_no_zero[6]),
                                          rep(DoseValB[7],times=numObs_no_zero[7]),
                                          rep(DoseValB[8],times=numObs_no_zero[8]),
                                          rep(DoseValB[9],times=numObs_no_zero[9]))
)



#'------------------------------------------------------------------------------
#### Data generation (example) ----
#'------------------------------------------------------------------------------

#n=152
set.seed(25)
data_simul_des9_152 <- simul(sd=sigma_coef,par=params_simul,time=data_simul_des9_152$time,dose=data_simul_des9_152$dose)

#n=90
set.seed(29)
data_simul_des9_90 <- simul(sd=sigma_coef,par=params_simul,time=data_simul_des9_90$time,dose=data_simul_des9_90$dose)

#n=45
set.seed(32)
data_simul_des9_45 <- simul(sd=sigma_coef,par=params_simul,time=data_simul_des9_45$time,dose=data_simul_des9_45$dose)


#'==============================================================================
## Design D-optimal ====
#'==============================================================================


#'------------------------------------------------------------------------------
#### Design specification ----
#'------------------------------------------------------------------------------


#D-Optimal desing as described in Schürmeyer et al
#Dopt <- read.csv("DoptDesign_Scenario5.csv")

DoptDes <- list(
                weights = c(0.1649657, 0.1661802, 0.1420768, 0.0609333, 0.1416149, 0.1661422, 0.1580869),
                supPoints_time = c(0.000000,  0.000000,  1.936057,  2.147924, 10.000000, 10.000000, 10.000000),
                supPoints_dose = c(0.000000, 12.000000, 12.000000,  4.218333,  3.852853,  0.000000, 12.000000)
)


#Number of the observations at dose dose combinations 
numObs_152 <- as.numeric(rndDesign(DoptDes$weights, 152))
numObs_90 <- as.numeric(rndDesign(DoptDes$weights, 90))
numObs_45 <- as.numeric(rndDesign(DoptDes$weights, 90))


#Doses 
DoseValA <- DoptDes$supPoints_time[which(numObs_152!=0)]
DoseValB <- DoptDes$supPoints_dose[which(numObs_152!=0)]
numObs_no_zero <- numObs_152[which(numObs_152!=0)]

#DF n=152
data_simul_dopt_152 <- data.frame("time"=c(rep(DoseValA[1],times=numObs_no_zero[1]),
                                  rep(DoseValA[2],times=numObs_no_zero[2]),
                                  rep(DoseValA[3],times=numObs_no_zero[3]),
                                  rep(DoseValA[4],times=numObs_no_zero[4]),
                                  rep(DoseValA[5],times=numObs_no_zero[5]),
                                  rep(DoseValA[6],times=numObs_no_zero[6]),
                                  rep(DoseValA[7],times=numObs_no_zero[7])),
                         "dose"=c(rep(DoseValB[1],times=numObs_no_zero[1]),
                                  rep(DoseValB[2],times=numObs_no_zero[2]),
                                  rep(DoseValB[3],times=numObs_no_zero[3]),
                                  rep(DoseValB[4],times=numObs_no_zero[4]),
                                  rep(DoseValB[5],times=numObs_no_zero[5]),
                                  rep(DoseValB[6],times=numObs_no_zero[6]),
                                  rep(DoseValB[7],times=numObs_no_zero[7]))
)


#Doses 
DoseValA <- DoptDes$supPoints_time[which(numObs_90!=0)]
DoseValB <- DoptDes$supPoints_dose[which(numObs_90!=0)]
numObs_no_zero <- numObs_90[which(numObs_90!=0)]

#DF n=90
data_simul_dopt_90 <- data.frame("time"=c(rep(DoseValA[1],times=numObs_no_zero[1]),
                                          rep(DoseValA[2],times=numObs_no_zero[2]),
                                          rep(DoseValA[3],times=numObs_no_zero[3]),
                                          rep(DoseValA[4],times=numObs_no_zero[4]),
                                          rep(DoseValA[5],times=numObs_no_zero[5]),
                                          rep(DoseValA[6],times=numObs_no_zero[6]),
                                          rep(DoseValA[7],times=numObs_no_zero[7])),
                                 "dose"=c(rep(DoseValB[1],times=numObs_no_zero[1]),
                                          rep(DoseValB[2],times=numObs_no_zero[2]),
                                          rep(DoseValB[3],times=numObs_no_zero[3]),
                                          rep(DoseValB[4],times=numObs_no_zero[4]),
                                          rep(DoseValB[5],times=numObs_no_zero[5]),
                                          rep(DoseValB[6],times=numObs_no_zero[6]),
                                          rep(DoseValB[7],times=numObs_no_zero[7]))
)


#Doses 
DoseValA <- DoptDes$supPoints_time[which(numObs_45!=0)]
DoseValB <- DoptDes$supPoints_dose[which(numObs_45!=0)]
numObs_no_zero <- numObs_45[which(numObs_45!=0)]

#DF n=90
data_simul_dopt_45 <- data.frame("time"=c(rep(DoseValA[1],times=numObs_no_zero[1]),
                                          rep(DoseValA[2],times=numObs_no_zero[2]),
                                          rep(DoseValA[3],times=numObs_no_zero[3]),
                                          rep(DoseValA[4],times=numObs_no_zero[4]),
                                          rep(DoseValA[5],times=numObs_no_zero[5]),
                                          rep(DoseValA[6],times=numObs_no_zero[6]),
                                          rep(DoseValA[7],times=numObs_no_zero[7])),
                                 "dose"=c(rep(DoseValB[1],times=numObs_no_zero[1]),
                                          rep(DoseValB[2],times=numObs_no_zero[2]),
                                          rep(DoseValB[3],times=numObs_no_zero[3]),
                                          rep(DoseValB[4],times=numObs_no_zero[4]),
                                          rep(DoseValB[5],times=numObs_no_zero[5]),
                                          rep(DoseValB[6],times=numObs_no_zero[6]),
                                          rep(DoseValB[7],times=numObs_no_zero[7]))
)


#'------------------------------------------------------------------------------
#### Data generation (example) ----
#'------------------------------------------------------------------------------

#n=152
set.seed(15)
data_simul_dopt_152 <- simul(sd=sigma_coef,par=params_simul,time=data_simul_dopt_152$time,dose=data_simul_dopt_152$dose)

#n=90
set.seed(19)
data_simul_dopt_90 <- simul(sd=sigma_coef,par=params_simul,time=data_simul_dopt_90$time,dose=data_simul_dopt_90$dose)

#n=45
set.seed(23)
data_simul_dopt_45 <- simul(sd=sigma_coef,par=params_simul,time=data_simul_dopt_45$time,dose=data_simul_dopt_45$dose)


#'------------------------------------------------------------------------------
## Save examples as templates ----
#'------------------------------------------------------------------------------
#we export the example data sets as templates for the simulation analysis
#as we run them on a server
Scenario2_designtemplates <- list("des9"=list("N152"=data_simul_des9_152,
                                              "N90"=data_simul_des9_90,
                                              "N45"=data_simul_des9_45),
                                  "dopt"=list("N152"=data_simul_dopt_152,
                                              "N90"=data_simul_dopt_90,
                                              "N45"=data_simul_dopt_45))

save(Scenario2_designtemplates,file="./simulation/Scenario2_designtemplates.RData")
#'==============================================================================
# Generate simulation runs ====
#'==============================================================================


#'==============================================================================
### Design 3x3 ====
#'==============================================================================


#n=152
#List of seeds for simulation runs (full)
set.seed(1)
Scenario2_seeds_des9_152 <-  runif(N, min = 0, max=1000000)


#List to store simulations and seeds in
Scenario2_simulated_data_des9_152 <- list()

#seed
set.seed(152)
for(i in 1:N){
  Scenario2_simulated_data_des9_152[[i]] <-simul(sd=sigma_coef,
                                                 par=params_simul,
                                                 time=data_simul_des9_152$time,
                                                 dose=data_simul_des9_152$dose)
}



#n=90
#List of seeds
#List of seeds for simulation runs (full)
set.seed(2)
Scenario2_seeds_des9_90 <-  runif(N, min = 0, max=1000000)

#List to store simulations and seeds in
Scenario2_simulated_data_des9_90 <- list()

#seed
set.seed(90)
for(i in 1:N){
  Scenario2_simulated_data_des9_90[[i]] <-simul(sd=sigma_coef,
                                                 par=params_simul,
                                                 time=data_simul_des9_90$time,
                                                 dose=data_simul_des9_90$dose)
}


#n=45
#List of seeds
#List of seeds for simulation runs (full algorithm)
set.seed(3)
Scenario2_seeds_des9_45 <-  runif(N, min = 0, max=1000000)


#List to store simulations and seeds in
Scenario2_simulated_data_des9_45 <- list()

#seed
set.seed(45)
for(i in 1:N){
  Scenario2_simulated_data_des9_45[[i]] <-simul(sd=sigma_coef,
                                                 par=params_simul,
                                                 time=data_simul_des9_45$time,
                                                 dose=data_simul_des9_45$dose)
}

Scenario2_des9 <- list(
  "N152"=list("seeds"=Scenario2_seeds_des9_152,
              "data"=Scenario2_simulated_data_des9_152),
  "N90"=list("seeds"=Scenario2_seeds_des9_90,
              "data"=Scenario2_simulated_data_des9_90),
  "N45"=list("seeds"=Scenario2_seeds_des9_45,
              "data"=Scenario2_simulated_data_des9_45)
)

save(Scenario2_des9,file="./simulation/simulated_data/Scenario2_des9.RData")
Scenario2_des9_N152 <- Scenario2_des9$N152
save(Scenario2_des9_N152,file="./simulation/simulated_data/Scenario2_des9_N152.RData")
Scenario2_des9_N90 <- Scenario2_des9$N90
save(Scenario2_des9_N90,file="./simulation/simulated_data/Scenario2_des9_N90.RData")
Scenario2_des9_N45 <- Scenario2_des9$N45
save(Scenario2_des9_N45,file="./simulation/simulated_data/Scenario2_des9_N45.RData")



#'==============================================================================
### Design D-Opt ====
#'==============================================================================


#n=152
#List of seeds for simulation runs (full)
set.seed(11)
Scenario2_seeds_dopt_152 <-  runif(N, min = 0, max=1000000)


#List to store simulations and seeds in
Scenario2_simulated_data_dopt_152 <- list()

#seed
set.seed(1520)
for(i in 1:N){
  Scenario2_simulated_data_dopt_152[[i]] <-simul(sd=sigma_coef,
                                                 par=params_simul,
                                                 time=data_simul_dopt_152$time,
                                                 dose=data_simul_dopt_152$dose)
}



#n=90
#List of seeds
#List of seeds for simulation runs (full)
set.seed(12)
Scenario2_seeds_dopt_90 <-  runif(N, min = 0, max=1000000)

#List to store simulations and seeds in
Scenario2_simulated_data_dopt_90 <- list()

#seed
set.seed(900)
for(i in 1:N){
  Scenario2_simulated_data_dopt_90[[i]] <-simul(sd=sigma_coef,
                                                par=params_simul,
                                                time=data_simul_dopt_90$time,
                                                dose=data_simul_dopt_90$dose)
}


#n=45
#List of seeds
#List of seeds for simulation runs (full)
set.seed(13)
Scenario2_seeds_dopt_45 <-  runif(N, min = 0, max=1000000)


#List to store simulations and seeds in
Scenario2_simulated_data_dopt_45 <- list()

#seed
set.seed(450)
for(i in 1:N){
  Scenario2_simulated_data_dopt_45[[i]] <-simul(sd=sigma_coef,
                                                par=params_simul,
                                                time=data_simul_dopt_45$time,
                                                dose=data_simul_dopt_45$dose)
}

Scenario2_dopt <- list(
  "N152"=list("seeds"=Scenario2_seeds_dopt_152,
              "data"=Scenario2_simulated_data_dopt_152),
  "N90"=list("seeds"=Scenario2_seeds_dopt_90,
             "data"=Scenario2_simulated_data_dopt_90),
  "N45"=list("seeds"=Scenario2_seeds_dopt_45,
             "data"=Scenario2_simulated_data_dopt_45)
)

save(Scenario2_dopt,file="./simulation/simulated_data/Scenario2_dopt.RData")

Scenario2_dopt_N152 <- Scenario2_dopt$N152
save(Scenario2_dopt_N152,file="./simulation/simulated_data/Scenario2_dopt_N152.RData")
Scenario2_dopt_N90 <- Scenario2_dopt$N90
save(Scenario2_dopt_N90,file="./simulation/simulated_data/Scenario2_dopt_N90.RData")
Scenario2_dopt_N45 <- Scenario2_dopt$N45
save(Scenario2_dopt_N45,file="./simulation/simulated_data/Scenario2_dopt_N45.RData")



#'==============================================================================
# Table with scenario infos ====
#'==============================================================================


table_scenario2 <- data.frame(
  "Scenario"=c("2 - Factorial 3x3 - N152","2 - Factorial 3x3 - N90","2 - Factorial 3x3 - N45",
               "2 - D-optimal - N152","2 - D-optimal - N90", "2 - D-optimal - N45"),
  "Parameters_mu"=rep(paste(round(params_simul,3),collapse=","),times=6),
  "Parameters_sigma"=rep(round(log(30),3),times=6),
  "Observations"=c(152,90,45,152,90,45),
  "Design"=c(rep("Factorial 3x3",times=3),rep("D-optimal",times=3))
)



if (file.exists("./plots_tables/201_simulation_scenarios.xlsx")) {
  wb <- loadWorkbook("./plots_tables/201_simulation_scenarios.xlsx")
  
  if ("Scenario 2" %in% names(wb)) {
    removeWorksheet(wb, "Scenario 2")
  }
} 

addWorksheet(wb, "Scenario 2")
writeData(wb, "Scenario 2", table_scenario2)
saveWorkbook(wb, "./plots_tables/201_simulation_scenarios.xlsx", overwrite = TRUE)



#extract designs for table
counts_des9_152 <- data_simul_des9_152 %>%
  group_by(time,dose) %>%
  summarise(
    n = n(),
    .groups = "drop"
  )

entry_des9_152 <- counts_des9_152 %>%
  transmute(
    txt = paste0(
      "((", time,
      ", ", dose,
      ",),", n, ")"
    )
  ) %>%
  pull(txt) %>%
  paste(collapse = "; ")

counts_des9_90 <- data_simul_des9_90 %>%
  group_by(time,dose) %>%
  summarise(
    n = n(),
    .groups = "drop"
  )

entry_des9_90 <- counts_des9_90 %>%
  transmute(
    txt = paste0(
      "((", time,
      ", ", dose,
      ",),", n, ")"
    )
  ) %>%
  pull(txt) %>%
  paste(collapse = "; ")


counts_des9_45 <- data_simul_des9_45 %>%
  group_by(time,dose) %>%
  summarise(
    n = n(),
    .groups = "drop"
  )

entry_des9_45 <- counts_des9_45 %>%
  transmute(
    txt = paste0(
      "((", time,
      ", ", dose,
      ",),", n, ")"
    )
  ) %>%
  pull(txt) %>%
  paste(collapse = "; ")




counts_dopt_152 <- data_simul_dopt_152 %>%
  group_by(time,dose) %>%
  summarise(
    n = n(),
    .groups = "drop"
  )

entry_dopt_152 <- counts_dopt_152 %>%
  transmute(
    txt = paste0(
      "((", time,
      ", ", dose,
      ",),", n, ")"
    )
  ) %>%
  pull(txt) %>%
  paste(collapse = "; ")

counts_dopt_90 <- data_simul_dopt_90 %>%
  group_by(time,dose) %>%
  summarise(
    n = n(),
    .groups = "drop"
  )

entry_dopt_90 <- counts_dopt_90 %>%
  transmute(
    txt = paste0(
      "((", time,
      ", ", dose,
      ",),", n, ")"
    )
  ) %>%
  pull(txt) %>%
  paste(collapse = "; ")


counts_dopt_45 <- data_simul_dopt_45 %>%
  group_by(time,dose) %>%
  summarise(
    n = n(),
    .groups = "drop"
  )

entry_dopt_45 <- counts_dopt_45 %>%
  transmute(
    txt = paste0(
      "((", time,
      ", ", dose,
      ",),", n, ")"
    )
  ) %>%
  pull(txt) %>%
  paste(collapse = "; ")

tale_design_scenario2 <- data.frame(
  "Scenario"=rep("2",times=6),
  "Design"=c("3x3 factorial N=152","3x3 factorial N=90","3x3 factorial N=45",
             "D-optimal N=152","D-optimal N=90","D-optimal N=45"),
  "Measurements"=c(entry_des9_152,entry_des9_90,entry_des9_45,
                   entry_dopt_152,entry_dopt_90,entry_dopt_45)
)



if (file.exists("./plots_tables/202_simulation_scenarios_design.xlsx")) {
  wb <- loadWorkbook("./plots_tables/202_simulation_scenarios_design.xlsx")
  
  if ("Scenario 2" %in% names(wb)) {
    removeWorksheet(wb, "Scenario 2")
  }
} 

addWorksheet(wb, "Scenario 2")
writeData(wb, "Scenario 2", tale_design_scenario2)
saveWorkbook(wb, "./plots_tables/202_simulation_scenarios_design.xlsx", overwrite = TRUE)




