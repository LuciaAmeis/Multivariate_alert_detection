#'##############################################################################
#                                                                              #
#                  Corresponding R Code to the Manuscript                      #
#                "Estimating effect thresholds and beyond:                     #
#              A flexible framework for multivariate alert detection"          #
#                                                                              #
#                                 Authors                                      #
#                    L. Ameis, N. Hagemann and K. Moellenhoff                  #
#                                                                              #
#                         Simulation - Scenario 1: Run simulation              #
#                                                                              #
#'##############################################################################
#'Of note, due to the computation time, the simulations were run on a server
#'Here, we show code that allows to run the simulations but also load
#'the results

#'==============================================================================
# Preparation ====
#'==============================================================================


#'==============================================================================
## Load functions without td2pLL ====
#'==============================================================================
#' Our server had problems installing the td2pLL package. Therefore we circumvented
#' the use for the simulation study
#' Therefore, we load the functions prepared accordingly
#' For details see base_TDR.R and base_cytotox_TDR.R

load("./simulation/base_cytotox_TDR_without_td2pLL.RData")

#Also, we need to rewrite the function td2pLL_fast
td2pLL_fast <- function (data){
  fit <- tryCatch({nlsLM(resp ~ 100-100*(dose^h/(dose^h+(Delta*time^(-gamma)+C0)^h)),
                         data = data,
                         lower=  c(h = 1,    #from td2pLL package
                                   delta = -3 * max_dose,
                                   gamma = ifelse(mu_start$gamma < 0, -10, 0.01),
                                   c0 = 0),
                         upper = c(h = 10,   #from td2pLL package
                                   delta = max_dose * 3,
                                   # gamma = 10,
                                   gamma = ifelse(mu_start$gamma < 0, -0.01, 10),
                                   c0 = max_dose* 3),
                         start = mu_start )}, error=function(e){
                           NA
                         })
  fit
}


#'==============================================================================
## Store analysis specific information ====
#'==============================================================================
#Bootstrap runs
B_out<-500
B_in<-25

#Number of simulation runs
N<-1000

#'==============================================================================
## Basics grid ====
#'==============================================================================


#Grid
#store study dependent data for later use
#time
min_time <- 1
max_time <- 7

#dose
min_dose <- 0
max_dose <- 10

#fineness of the grid
epsilon <- 0.1



#create the grid
time_seq <- seq(min_time, max_time, by=epsilon)   #time
dose_seq <- seq(min_dose, max_dose, by=epsilon)   #dose

grid_full      <- data.frame("time"=rep(time_seq, times=length(dose_seq)))
grid_dose <- numeric(length=length(time_seq)*length(dose_seq))
for(i in 1:length(dose_seq)){
  grid_dose[((i-1)*length(time_seq)+1):(i*length(time_seq))] <- rep(dose_seq[i],  times=length(time_seq))
}
grid_full$dose <- grid_dose

#'==============================================================================
## Basics mu ====
#'==============================================================================
#Define model and starting parameters for mean
model <- td2pLL

fit_fast <- td2pLL_fast

mu_formula <- td2pLL_formula

#Start value as used before
mu_start <- list(h = 3, Delta = 6, gamma = 2, C0 = 5)


#'==============================================================================
## Basics sigma starting values====
#'==============================================================================

#startvalue for constant assumption
#constant
sigma_start_simul_constant <- c(2)

#startvalues for complex model
#constant
sigma_start_simul_semiconstant <- c(2,0.1,-0.01,0.01,-0.001)


#small effect
sigma_start_simul_small <- c(2,0.2,-0.02,0.06,-0.001)

#medium effect
sigma_start_simul_medium <- c(2,0.2,-0.03,0.08,-0.002)


#large effect
sigma_start_simul_large <- c(2,0.3,-0.03,0.1,-0.002)



#'==============================================================================
# Run Simulations - full algorithm  ====
#'==============================================================================

#'==============================================================================
## Assume constant model for sigma ====
#'==============================================================================

sigma_formula <- ~ 1
sigma_start <- sigma_start_simul_constant


#'------------------------------------------------------------------------------
### Full data ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
#### Constant ----
#'------------------------------------------------------------------------------



if(file.exists("./simulation/server_results/Res_Scenario1_fulldata_assumeconstant_constant.RData")){
  load("./simulation/server_results/Res_Scenario1_fulldata_assumeconstant_constant.RData")
} else{
  #store results
  Res_Scenario1_fulldata_assumeconstant_constant <- list()
  
  for(i in 1:N){
  #load simulated data set
  dat_simul <- Scenario1_fulldata$constant$data[[i]]
  #run initial fit to simulated data
  fit_simul <- modelfit_robust(dat_simul)
  
  if(anyNA(fit_simul$coef)==T){
    res_simul <- NA
  } else{
  #set seed
  set.seed(Scenario1_fulldata$constant$seeds$assumeconstant$full[[i]])  
  seeds_simul <- runif(B_out, min = 0, max=1000000)
  outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                    par=fit_simul$coef,
                                    B=B_out,
                                    time=data_subset$time,
                                    dose=data_subset$dose,
                                    donor=data_subset$donor)
  crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                      B_in=B_in,
                                      B_out=B_out,
                                      sd=fit_simul$sd,
                                      par=fit_simul$coef,
                                      time=data_subset$time,
                                      dose=data_subset$dose,
                                      donor=data_subset$donor,
                                      seeds=seeds_simul,
                                      fixtime = 4)
  crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                             alpha=0.05,
                             fixtime=4)
  conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                c=crit.val_simul, 
                                outerboot = outerbootstrap_simul,
                                fixtime=4)
  
  res_simul <- list("initial_fit"=fit_simul,
#                    "boot"=outerbootstrap_simul,
#                    "crit_boot"=crit.val_boot_simul,
                    "crit_val"=crit.val_simul,
                    "conf"=conf.band_simul)
  }
  Res_Scenario1_fulldata_assumeconstant_constant[[i]] <- res_simul
  }
  save(Res_Scenario1_fulldata_assumeconstant_constant,file="./simulation/server_results/Res_Scenario1_fulldata_assumeconstant_constant.RData")
}



#'------------------------------------------------------------------------------
#### Small ----
#'------------------------------------------------------------------------------

if(file.exists("./simulation/server_results/Res_Scenario1_fulldata_assumeconstant_small.RData")){
  load("./simulation/server_results/Res_Scenario1_fulldata_assumeconstant_small.RData")
} else{
  #store results
  Res_Scenario1_fulldata_assumeconstant_small <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario1_fulldata$small$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario1_fulldata$small$seeds$assumeconstant$full[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=data_subset$time,
                                        dose=data_subset$dose,
                                        donor=data_subset$donor)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=data_subset$time,
                                          dose=data_subset$dose,
                                          donor=data_subset$donor,
                                          seeds=seeds_simul,
                                          fixtime = 4)
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=4)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=4)
      
      res_simul <- list("initial_fit"=fit_simul,
 #                       "boot"=outerbootstrap_simul,
#                        "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario1_fulldata_assumeconstant_small[[i]] <- res_simul
  }
  save(Res_Scenario1_fulldata_assumeconstant_small,file="./simulation/server_results/Res_Scenario1_fulldata_assumeconstant_small.RData")
}



#'------------------------------------------------------------------------------
#### Medium ----
#'------------------------------------------------------------------------------

if(file.exists("./simulation/server_results/Res_Scenario1_fulldata_assumeconstant_medium.RData")){
  load("./simulation/server_results/Res_Scenario1_fulldata_assumeconstant_medium.RData")
} else{
  #store results
  Res_Scenario1_fulldata_assumeconstant_medium <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario1_fulldata$medium$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario1_fulldata$medium$seeds$assumeconstant$full[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=data_subset$time,
                                        dose=data_subset$dose,
                                        donor=data_subset$donor)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=data_subset$time,
                                          dose=data_subset$dose,
                                          donor=data_subset$donor,
                                          seeds=seeds_simul,
                                          fixtime = 4)
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=4)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=4)
      
      res_simul <- list("initial_fit"=fit_simul,
 #                       "boot"=outerbootstrap_simul,
#                        "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario1_fulldata_assumeconstant_medium[[i]] <- res_simul
  }
  save(Res_Scenario1_fulldata_assumeconstant_medium,file="./simulation/server_results/Res_Scenario1_fulldata_assumeconstant_medium.RData")
}


#'------------------------------------------------------------------------------
#### Large ----
#'------------------------------------------------------------------------------

if(file.exists("./simulation/server_results/Res_Scenario1_fulldata_assumeconstant_large.RData")){
  load("./simulation/server_results/Res_Scenario1_fulldata_assumeconstant_large.RData")
} else{
  #store results
  Res_Scenario1_fulldata_assumeconstant_large <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario1_fulldata$large$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario1_fulldata$large$seeds$assumeconstant$full[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=data_subset$time,
                                        dose=data_subset$dose,
                                        donor=data_subset$donor)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=data_subset$time,
                                          dose=data_subset$dose,
                                          donor=data_subset$donor,
                                          seeds=seeds_simul,
                                          fixtime = 4)
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=4)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=4)
      
      res_simul <- list("initial_fit"=fit_simul,
 #                       "boot"=outerbootstrap_simul,
#                        "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario1_fulldata_assumeconstant_large[[i]] <- res_simul
  }
  save(Res_Scenario1_fulldata_assumeconstant_large,file="./simulation/server_results/Res_Scenario1_fulldata_assumeconstant_large.RData")
}



#'------------------------------------------------------------------------------
### Reduced data ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
#### Constant ----
#'------------------------------------------------------------------------------

if(file.exists("./simulation/server_results/Res_Scenario1_reduceddata_assumeconstant_constant.RData")){
  load("./simulation/server_results/Res_Scenario1_reduceddata_assumeconstant_constant.RData")
} else{
  #store results
  Res_Scenario1_reduceddata_assumeconstant_constant <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario1_reduceddata$constant$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario1_reduceddata$constant$seeds$assumeconstant$full[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=data_subset_reduced$time,
                                        dose=data_subset_reduced$dose,
                                        donor=data_subset_reduced$donor)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=data_subset_reduced$time,
                                          dose=data_subset_reduced$dose,
                                          donor=data_subset_reduced$donor,
                                          seeds=seeds_simul,
                                          fixtime = 4)
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=4)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=4)
      
      res_simul <- list("initial_fit"=fit_simul,
 #                       "boot"=outerbootstrap_simul,
#                        "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario1_reduceddata_assumeconstant_constant[[i]] <- res_simul
  }
  save(Res_Scenario1_reduceddata_assumeconstant_constant,file="./simulation/server_results/Res_Scenario1_reduceddata_assumeconstant_constant.RData")
}



#'------------------------------------------------------------------------------
#### Small ----
#'------------------------------------------------------------------------------

if(file.exists("./simulation/server_results/Res_Scenario1_reduceddata_assumeconstant_small.RData")){
  load("./simulation/server_results/Res_Scenario1_reduceddata_assumeconstant_small.RData")
} else{
  #store results
  Res_Scenario1_reduceddata_assumeconstant_small <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario1_reduceddata$small$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario1_reduceddata$small$seeds$assumeconstant$full[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=data_subset_reduced$time,
                                        dose=data_subset_reduced$dose,
                                        donor=data_subset_reduced$donor)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=data_subset_reduced$time,
                                          dose=data_subset_reduced$dose,
                                          donor=data_subset_reduced$donor,
                                          seeds=seeds_simul,
                                          fixtime = 4)
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=4)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=4)
      
      res_simul <- list("initial_fit"=fit_simul,
 #                       "boot"=outerbootstrap_simul,
#                        "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario1_reduceddata_assumeconstant_small[[i]] <- res_simul
  }
  save(Res_Scenario1_reduceddata_assumeconstant_small,file="./simulation/server_results/Res_Scenario1_reduceddata_assumeconstant_small.RData")
}



#'------------------------------------------------------------------------------
#### Medium ----
#'------------------------------------------------------------------------------

if(file.exists("./simulation/server_results/Res_Scenario1_reduceddata_assumeconstant_medium.RData")){
  load("./simulation/server_results/Res_Scenario1_reduceddata_assumeconstant_medium.RData")
} else{
  #store results
  Res_Scenario1_reduceddata_assumeconstant_medium <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario1_reduceddata$medium$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario1_reduceddata$medium$seeds$assumeconstant$full[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=data_subset_reduced$time,
                                        dose=data_subset_reduced$dose,
                                        donor=data_subset_reduced$donor)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=data_subset_reduced$time,
                                          dose=data_subset_reduced$dose,
                                          donor=data_subset_reduced$donor,
                                          seeds=seeds_simul,
                                          fixtime = 4)
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=4)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=4)
      
      res_simul <- list("initial_fit"=fit_simul,
 #                       "boot"=outerbootstrap_simul,
#                        "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario1_reduceddata_assumeconstant_medium[[i]] <- res_simul
  }
  save(Res_Scenario1_reduceddata_assumeconstant_medium,file="./simulation/server_results/Res_Scenario1_reduceddata_assumeconstant_medium.RData")
}


#'------------------------------------------------------------------------------
#### Large ----
#'------------------------------------------------------------------------------

if(file.exists("./simulation/server_results/Res_Scenario1_reduceddata_assumeconstant_large.RData")){
  load("./simulation/server_results/Res_Scenario1_reduceddata_assumeconstant_large.RData")
} else{
  #store results
  Res_Scenario1_reduceddata_assumeconstant_large <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario1_reduceddata$large$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario1_reduceddata$large$seeds$assumeconstant$full[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=data_subset_reduced$time,
                                        dose=data_subset_reduced$dose,
                                        donor=data_subset_reduced$donor)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=data_subset_reduced$time,
                                          dose=data_subset_reduced$dose,
                                          donor=data_subset_reduced$donor,
                                          seeds=seeds_simul,
                                          fixtime = 4)
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=4)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=4)
      
      res_simul <- list("initial_fit"=fit_simul,
 #                       "boot"=outerbootstrap_simul,
#                        "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario1_reduceddata_assumeconstant_large[[i]] <- res_simul
  }
  save(Res_Scenario1_reduceddata_assumeconstant_large,file="./simulation/server_results/Res_Scenario1_reduceddata_assumeconstant_large.RData")
}




#'==============================================================================
## Assume complex model for sigma ====
#'==============================================================================

sigma_formula <- ~ dose+I(dose^2)+time+I(dose^2):time

#'------------------------------------------------------------------------------
### Full data ----
#'------------------------------------------------------------------------------


#'------------------------------------------------------------------------------
#### Constant ----
#'------------------------------------------------------------------------------

sigma_start <- sigma_start_simul_semiconstant

if(file.exists("./simulation/server_results/Res_Scenario1_fulldata_assumecomplex_constant.RData")){
  load("./simulation/server_results/Res_Scenario1_fulldata_assumecomplex_constant.RData")
} else{
  #store results
  Res_Scenario1_fulldata_assumecomplex_constant <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario1_fulldata$constant$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario1_fulldata$constant$seeds$assumecomplex$full[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=data_subset$time,
                                        dose=data_subset$dose,
                                        donor=data_subset$donor)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=data_subset$time,
                                          dose=data_subset$dose,
                                          donor=data_subset$donor,
                                          seeds=seeds_simul,
                                          fixtime = 4)
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=4)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=4)
      
      res_simul <- list("initial_fit"=fit_simul,
 #                       "boot"=outerbootstrap_simul,
#                        "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario1_fulldata_assumecomplex_constant[[i]] <- res_simul
  }
  save(Res_Scenario1_fulldata_assumecomplex_constant,file="./simulation/server_results/Res_Scenario1_fulldata_assumecomplex_constant.RData")
}



#'------------------------------------------------------------------------------
#### Small ----
#'------------------------------------------------------------------------------

sigma_start <- sigma_start_simul_small

if(file.exists("./simulation/server_results/Res_Scenario1_fulldata_assumecomplex_small.RData")){
  load("./simulation/server_results/Res_Scenario1_fulldata_assumecomplex_small.RData")
} else{
  #store results
  Res_Scenario1_fulldata_assumecomplex_small <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario1_fulldata$small$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario1_fulldata$small$seeds$assumecomplex$full[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=data_subset$time,
                                        dose=data_subset$dose,
                                        donor=data_subset$donor)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=data_subset$time,
                                          dose=data_subset$dose,
                                          donor=data_subset$donor,
                                          seeds=seeds_simul,
                                          fixtime = 4)
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=4)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=4)
      
      res_simul <- list("initial_fit"=fit_simul,
 #                       "boot"=outerbootstrap_simul,
#                        "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario1_fulldata_assumecomplex_small[[i]] <- res_simul
  }
  save(Res_Scenario1_fulldata_assumecomplex_small,file="./simulation/server_results/Res_Scenario1_fulldata_assumecomplex_small.RData")
}



#'------------------------------------------------------------------------------
#### Medium ----
#'------------------------------------------------------------------------------

sigma_start <- sigma_start_simul_medium

if(file.exists("./simulation/server_results/Res_Scenario1_fulldata_assumecomplex_medium.RData")){
  load("./simulation/server_results/Res_Scenario1_fulldata_assumecomplex_medium.RData")
} else{
  #store results
  Res_Scenario1_fulldata_assumecomplex_medium <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario1_fulldata$medium$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario1_fulldata$medium$seeds$assumecomplex$full[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=data_subset$time,
                                        dose=data_subset$dose,
                                        donor=data_subset$donor)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=data_subset$time,
                                          dose=data_subset$dose,
                                          donor=data_subset$donor,
                                          seeds=seeds_simul,
                                          fixtime = 4)
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=4)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=4)
      
      res_simul <- list("initial_fit"=fit_simul,
 #                       "boot"=outerbootstrap_simul,
#                        "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario1_fulldata_assumecomplex_medium[[i]] <- res_simul
  }
  save(Res_Scenario1_fulldata_assumecomplex_medium,file="./simulation/server_results/Res_Scenario1_fulldata_assumecomplex_medium.RData")
}


#'------------------------------------------------------------------------------
#### Large ----
#'------------------------------------------------------------------------------

sigma_start <- sigma_start_simul_large

if(file.exists("./simulation/server_results/Res_Scenario1_fulldata_assumecomplex_large.RData")){
  load("./simulation/server_results/Res_Scenario1_fulldata_assumecomplex_large.RData")
} else{
  #store results
  Res_Scenario1_fulldata_assumecomplex_large <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario1_fulldata$large$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario1_fulldata$large$seeds$assumecomplex$full[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=data_subset$time,
                                        dose=data_subset$dose,
                                        donor=data_subset$donor)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=data_subset$time,
                                          dose=data_subset$dose,
                                          donor=data_subset$donor,
                                          seeds=seeds_simul,
                                          fixtime = 4)
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=4)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=4)
      
      res_simul <- list("initial_fit"=fit_simul,
 #                       "boot"=outerbootstrap_simul,
#                        "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario1_fulldata_assumecomplex_large[[i]] <- res_simul
  }
  save(Res_Scenario1_fulldata_assumecomplex_large,file="./simulation/server_results/Res_Scenario1_fulldata_assumecomplex_large.RData")
}



#'------------------------------------------------------------------------------
### Reduced data ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
#### Constant ----
#'------------------------------------------------------------------------------

sigma_start <- sigma_start_simul_semiconstant

if(file.exists("./simulation/server_results/Res_Scenario1_reduceddata_assumecomplex_constant.RData")){
  load("./simulation/server_results/Res_Scenario1_reduceddata_assumecomplex_constant.RData")
} else{
  #store results
  Res_Scenario1_reduceddata_assumecomplex_constant <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario1_reduceddata$constant$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario1_reduceddata$constant$seeds$assumecomplex$full[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=data_subset_reduced$time,
                                        dose=data_subset_reduced$dose,
                                        donor=data_subset_reduced$donor)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=data_subset_reduced$time,
                                          dose=data_subset_reduced$dose,
                                          donor=data_subset_reduced$donor,
                                          seeds=seeds_simul,
                                          fixtime = 4)
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=4)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=4)
      
      res_simul <- list("initial_fit"=fit_simul,
 #                       "boot"=outerbootstrap_simul,
#                        "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario1_reduceddata_assumecomplex_constant[[i]] <- res_simul
  }
  save(Res_Scenario1_reduceddata_assumecomplex_constant,file="./simulation/server_results/Res_Scenario1_reduceddata_assumecomplex_constant.RData")
}



#'------------------------------------------------------------------------------
#### Small ----
#'------------------------------------------------------------------------------

sigma_start <- sigma_start_simul_small

if(file.exists("./simulation/server_results/Res_Scenario1_reduceddata_assumecomplex_small.RData")){
  load("./simulation/server_results/Res_Scenario1_reduceddata_assumecomplex_small.RData")
} else{
  #store results
  Res_Scenario1_reduceddata_assumecomplex_small <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario1_reduceddata$small$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario1_reduceddata$small$seeds$assumecomplex$full[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=data_subset_reduced$time,
                                        dose=data_subset_reduced$dose,
                                        donor=data_subset_reduced$donor)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=data_subset_reduced$time,
                                          dose=data_subset_reduced$dose,
                                          donor=data_subset_reduced$donor,
                                          seeds=seeds_simul,
                                          fixtime = 4)
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=4)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=4)
      
      res_simul <- list("initial_fit"=fit_simul,
 #                       "boot"=outerbootstrap_simul,
#                        "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario1_reduceddata_assumecomplex_small[[i]] <- res_simul
  }
  save(Res_Scenario1_reduceddata_assumecomplex_small,file="./simulation/server_results/Res_Scenario1_reduceddata_assumecomplex_small.RData")
}



#'------------------------------------------------------------------------------
#### Medium ----
#'------------------------------------------------------------------------------

sigma_start <- sigma_start_simul_medium


if(file.exists("./simulation/server_results/Res_Scenario1_reduceddata_assumecomplex_medium.RData")){
  load("./simulation/server_results/Res_Scenario1_reduceddata_assumecomplex_medium.RData")
} else{
  #store results
  Res_Scenario1_reduceddata_assumecomplex_medium <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario1_reduceddata$medium$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario1_reduceddata$medium$seeds$assumecomplex$full[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=data_subset_reduced$time,
                                        dose=data_subset_reduced$dose,
                                        donor=data_subset_reduced$donor)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=data_subset_reduced$time,
                                          dose=data_subset_reduced$dose,
                                          donor=data_subset_reduced$donor,
                                          seeds=seeds_simul,
                                          fixtime = 4)
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=4)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=4)
      
      res_simul <- list("initial_fit"=fit_simul,
 #                       "boot"=outerbootstrap_simul,
#                        "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario1_reduceddata_assumecomplex_medium[[i]] <- res_simul
  }
  save(Res_Scenario1_reduceddata_assumecomplex_medium,file="./simulation/server_results/Res_Scenario1_reduceddata_assumecomplex_medium.RData")
}


#'------------------------------------------------------------------------------
#### Large ----
#'------------------------------------------------------------------------------

sigma_start <- sigma_start_simul_large


if(file.exists("./simulation/server_results/Res_Scenario1_reduceddata_assumecomplex_large.RData")){
  load("./simulation/server_results/Res_Scenario1_reduceddata_assumecomplex_large.RData")
} else{
  #store results
  Res_Scenario1_reduceddata_assumecomplex_large <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario1_reduceddata$large$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario1_reduceddata$large$seeds$assumecomplex$full[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=data_subset_reduced$time,
                                        dose=data_subset_reduced$dose,
                                        donor=data_subset_reduced$donor)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=data_subset_reduced$time,
                                          dose=data_subset_reduced$dose,
                                          donor=data_subset_reduced$donor,
                                          seeds=seeds_simul,
                                          fixtime = 4)
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=4)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=4)
      
      res_simul <- list("initial_fit"=fit_simul,
 #                       "boot"=outerbootstrap_simul,
#                        "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario1_reduceddata_assumecomplex_large[[i]] <- res_simul
  }
  save(Res_Scenario1_reduceddata_assumecomplex_large,file="./simulation/server_results/Res_Scenario1_reduceddata_assumecomplex_large.RData")
}





#'==============================================================================
# Run Simulations - fast algorithm  ====
#'==============================================================================

#'==============================================================================
## Assume constant model for sigma ====
#'==============================================================================


sigma_formula <- ~ 1
sigma_start <- sigma_start_simul_constant


#'------------------------------------------------------------------------------
### Full data ----
#'------------------------------------------------------------------------------


#'------------------------------------------------------------------------------
#### Constant ----
#'------------------------------------------------------------------------------



if(file.exists("./simulation/server_results/Res_Scenario1_fulldata_assumeconstant_fast_constant.RData")){
  load("./simulation/server_results/Res_Scenario1_fulldata_assumeconstant_fast_constant.RData")
} else{
  #store results
  Res_Scenario1_fulldata_assumeconstant_fast_constant <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario1_fulldata$constant$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario1_fulldata$constant$seeds$assumeconstant$fast[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=data_subset$time,
                                        dose=data_subset$dose,
                                        donor=data_subset$donor)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=data_subset$time,
                                          dose=data_subset$dose,
                                          donor=data_subset$donor,
                                          seeds=seeds_simul,
                                          fixtime = 4,
                                          fast_in = T)
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=4)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=4)
      
      res_simul <- list("initial_fit"=fit_simul,
 #                       "boot"=outerbootstrap_simul,
#                        "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario1_fulldata_assumeconstant_fast_constant[[i]] <- res_simul
  }
  save(Res_Scenario1_fulldata_assumeconstant_fast_constant,file="./simulation/server_results/Res_Scenario1_fulldata_assumeconstant_fast_constant.RData")
}



#'------------------------------------------------------------------------------
#### Small ----
#'------------------------------------------------------------------------------

if(file.exists("./simulation/server_results/Res_Scenario1_fulldata_assumeconstant_fast_small.RData")){
  load("./simulation/server_results/Res_Scenario1_fulldata_assumeconstant_fast_small.RData")
} else{
  #store results
  Res_Scenario1_fulldata_assumeconstant_fast_small <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario1_fulldata$small$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario1_fulldata$small$seeds$assumeconstant$fast[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=data_subset$time,
                                        dose=data_subset$dose,
                                        donor=data_subset$donor)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=data_subset$time,
                                          dose=data_subset$dose,
                                          donor=data_subset$donor,
                                          seeds=seeds_simul,
                                          fixtime = 4,
                                          fast_in = T)
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=4)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=4)
      
      res_simul <- list("initial_fit"=fit_simul,
 #                       "boot"=outerbootstrap_simul,
#                        "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario1_fulldata_assumeconstant_fast_small[[i]] <- res_simul
  }
  save(Res_Scenario1_fulldata_assumeconstant_fast_small,file="./simulation/server_results/Res_Scenario1_fulldata_assumeconstant_fast_small.RData")
}



#'------------------------------------------------------------------------------
#### Medium ----
#'------------------------------------------------------------------------------

if(file.exists("./simulation/server_results/Res_Scenario1_fulldata_assumeconstant_fast_medium.RData")){
  load("./simulation/server_results/Res_Scenario1_fulldata_assumeconstant_fast_medium.RData")
} else{
  #store results
  Res_Scenario1_fulldata_assumeconstant_fast_medium <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario1_fulldata$medium$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario1_fulldata$medium$seeds$assumeconstant$fast[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=data_subset$time,
                                        dose=data_subset$dose,
                                        donor=data_subset$donor)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=data_subset$time,
                                          dose=data_subset$dose,
                                          donor=data_subset$donor,
                                          seeds=seeds_simul,
                                          fixtime = 4,
                                          fast_in = T)
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=4)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=4)
      
      res_simul <- list("initial_fit"=fit_simul,
 #                       "boot"=outerbootstrap_simul,
#                        "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario1_fulldata_assumeconstant_fast_medium[[i]] <- res_simul
  }
  save(Res_Scenario1_fulldata_assumeconstant_fast_medium,file="./simulation/server_results/Res_Scenario1_fulldata_assumeconstant_fast_medium.RData")
}


#'------------------------------------------------------------------------------
#### Large ----
#'------------------------------------------------------------------------------

if(file.exists("./simulation/server_results/Res_Scenario1_fulldata_assumeconstant_fast_large.RData")){
  load("./simulation/server_results/Res_Scenario1_fulldata_assumeconstant_fast_large.RData")
} else{
  #store results
  Res_Scenario1_fulldata_assumeconstant_fast_large <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario1_fulldata$large$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario1_fulldata$large$seeds$assumeconstant$fast[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=data_subset$time,
                                        dose=data_subset$dose,
                                        donor=data_subset$donor)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=data_subset$time,
                                          dose=data_subset$dose,
                                          donor=data_subset$donor,
                                          seeds=seeds_simul,
                                          fixtime = 4,
                                          fast_in = T)
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=4)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=4)
      
      res_simul <- list("initial_fit"=fit_simul,
 #                       "boot"=outerbootstrap_simul,
#                        "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario1_fulldata_assumeconstant_fast_large[[i]] <- res_simul
  }
  save(Res_Scenario1_fulldata_assumeconstant_fast_large,file="./simulation/server_results/Res_Scenario1_fulldata_assumeconstant_fast_large.RData")
}



#'------------------------------------------------------------------------------
### Reduced algorithm ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
#### Constant ----
#'------------------------------------------------------------------------------

if(file.exists("./simulation/server_results/Res_Scenario1_reduceddata_assumeconstant_fast_constant.RData")){
  load("./simulation/server_results/Res_Scenario1_reduceddata_assumeconstant_fast_constant.RData")
} else{
  #store results
  Res_Scenario1_reduceddata_assumeconstant_fast_constant <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario1_reduceddata$constant$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario1_reduceddata$constant$seeds$assumeconstant$fast[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=data_subset_reduced$time,
                                        dose=data_subset_reduced$dose,
                                        donor=data_subset_reduced$donor)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=data_subset_reduced$time,
                                          dose=data_subset_reduced$dose,
                                          donor=data_subset_reduced$donor,
                                          seeds=seeds_simul,
                                          fixtime = 4,
                                          fast_in = T)
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=4)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=4)
      
      res_simul <- list("initial_fit"=fit_simul,
 #                       "boot"=outerbootstrap_simul,
#                        "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario1_reduceddata_assumeconstant_fast_constant[[i]] <- res_simul
  }
  save(Res_Scenario1_reduceddata_assumeconstant_fast_constant,file="./simulation/server_results/Res_Scenario1_reduceddata_assumeconstant_fast_constant.RData")
}



#'------------------------------------------------------------------------------
#### Small ----
#'------------------------------------------------------------------------------

if(file.exists("./simulation/server_results/Res_Scenario1_reduceddata_assumeconstant_fast_small.RData")){
  load("./simulation/server_results/Res_Scenario1_reduceddata_assumeconstant_fast_small.RData")
} else{
  #store results
  Res_Scenario1_reduceddata_assumeconstant_fast_small <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario1_reduceddata$small$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario1_reduceddata$small$seeds$assumeconstant$fast[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=data_subset_reduced$time,
                                        dose=data_subset_reduced$dose,
                                        donor=data_subset_reduced$donor)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=data_subset_reduced$time,
                                          dose=data_subset_reduced$dose,
                                          donor=data_subset_reduced$donor,
                                          seeds=seeds_simul,
                                          fixtime = 4,
                                          fast_in = T)
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=4)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=4)
      
      res_simul <- list("initial_fit"=fit_simul,
  #                      "boot"=outerbootstrap_simul,
 #                       "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario1_reduceddata_assumeconstant_fast_small[[i]] <- res_simul
  }
  save(Res_Scenario1_reduceddata_assumeconstant_fast_small,file="./simulation/server_results/Res_Scenario1_reduceddata_assumeconstant_fast_small.RData")
}



#'------------------------------------------------------------------------------
#### Medium ----
#'------------------------------------------------------------------------------

if(file.exists("./simulation/server_results/Res_Scenario1_reduceddata_assumeconstant_fast_medium.RData")){
  load("./simulation/server_results/Res_Scenario1_reduceddata_assumeconstant_fast_medium.RData")
} else{
  #store results
  Res_Scenario1_reduceddata_assumeconstant_fast_medium <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario1_reduceddata$medium$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario1_reduceddata$medium$seeds$assumeconstant$fast[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=data_subset_reduced$time,
                                        dose=data_subset_reduced$dose,
                                        donor=data_subset_reduced$donor)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=data_subset_reduced$time,
                                          dose=data_subset_reduced$dose,
                                          donor=data_subset_reduced$donor,
                                          seeds=seeds_simul,
                                          fixtime = 4,
                                          fast_in = T)
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=4)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=4)
      
      res_simul <- list("initial_fit"=fit_simul,
   #                     "boot"=outerbootstrap_simul,
  #                      "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario1_reduceddata_assumeconstant_fast_medium[[i]] <- res_simul
  }
  save(Res_Scenario1_reduceddata_assumeconstant_fast_medium,file="./simulation/server_results/Res_Scenario1_reduceddata_assumeconstant_fast_medium.RData")
}


#'------------------------------------------------------------------------------
#### Large ----
#'------------------------------------------------------------------------------

if(file.exists("./simulation/server_results/Res_Scenario1_reduceddata_assumeconstant_fast_large.RData")){
  load("./simulation/server_results/Res_Scenario1_reduceddata_assumeconstant_fast_large.RData")
} else{
  #store results
  Res_Scenario1_reduceddata_assumeconstant_fast_large <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario1_reduceddata$large$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario1_reduceddata$large$seeds$assumeconstant$fast[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=data_subset_reduced$time,
                                        dose=data_subset_reduced$dose,
                                        donor=data_subset_reduced$donor)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=data_subset_reduced$time,
                                          dose=data_subset_reduced$dose,
                                          donor=data_subset_reduced$donor,
                                          seeds=seeds_simul,
                                          fixtime = 4,
                                          fast_in = T)
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=4)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=4)
      
      res_simul <- list("initial_fit"=fit_simul,
   #                     "boot"=outerbootstrap_simul,
  #                      "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario1_reduceddata_assumeconstant_fast_large[[i]] <- res_simul
  }
  save(Res_Scenario1_reduceddata_assumeconstant_fast_large,file="./simulation/server_results/Res_Scenario1_reduceddata_assumeconstant_fast_large.RData")
}




#'==============================================================================
## Assume complex model for sigma ====
#'==============================================================================

sigma_formula <- ~ dose+I(dose^2)+time+I(dose^2):time

#'------------------------------------------------------------------------------
### Full algorithm ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
#### Constant ----
#'------------------------------------------------------------------------------

if(file.exists("./simulation/server_results/Res_Scenario1_fulldata_assumecomplex_fast_constant.RData")){
  load("./simulation/server_results/Res_Scenario1_fulldata_assumecomplex_fast_constant.RData")
} else{
  #store results
  Res_Scenario1_fulldata_assumecomplex_fast_constant <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario1_fulldata$constant$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario1_fulldata$constant$seeds$assumecomplex$fast[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=data_subset$time,
                                        dose=data_subset$dose,
                                        donor=data_subset$donor)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=data_subset$time,
                                          dose=data_subset$dose,
                                          donor=data_subset$donor,
                                          seeds=seeds_simul,
                                          fixtime = 4,
                                          fast_in = T)
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=4)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=4)
      
      res_simul <- list("initial_fit"=fit_simul,
   #                     "boot"=outerbootstrap_simul,
  #                      "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario1_fulldata_assumecomplex_fast_constant[[i]] <- res_simul
  }
  save(Res_Scenario1_fulldata_assumecomplex_fast_constant,file="./simulation/server_results/Res_Scenario1_fulldata_assumecomplex_fast_constant.RData")
}



#'------------------------------------------------------------------------------
#### Small ----
#'------------------------------------------------------------------------------

if(file.exists("./simulation/server_results/Res_Scenario1_fulldata_assumecomplex_fast_small.RData")){
  load("./simulation/server_results/Res_Scenario1_fulldata_assumecomplex_fast_small.RData")
} else{
  #store results
  Res_Scenario1_fulldata_assumecomplex_fast_small <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario1_fulldata$small$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario1_fulldata$small$seeds$assumecomplex$fast[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=data_subset$time,
                                        dose=data_subset$dose,
                                        donor=data_subset$donor)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=data_subset$time,
                                          dose=data_subset$dose,
                                          donor=data_subset$donor,
                                          seeds=seeds_simul,
                                          fixtime = 4,
                                          fast_in = T)
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=4)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=4)
      
      res_simul <- list("initial_fit"=fit_simul,
   #                     "boot"=outerbootstrap_simul,
  #                      "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario1_fulldata_assumecomplex_fast_small[[i]] <- res_simul
  }
  save(Res_Scenario1_fulldata_assumecomplex_fast_small,file="./simulation/server_results/Res_Scenario1_fulldata_assumecomplex_fast_small.RData")
}



#'------------------------------------------------------------------------------
#### Medium ----
#'------------------------------------------------------------------------------

if(file.exists("./simulation/server_results/Res_Scenario1_fulldata_assumecomplex_fast_medium.RData")){
  load("./simulation/server_results/Res_Scenario1_fulldata_assumecomplex_fast_medium.RData")
} else{
  #store results
  Res_Scenario1_fulldata_assumecomplex_fast_medium <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario1_fulldata$medium$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario1_fulldata$medium$seeds$assumecomplex$fast[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=data_subset$time,
                                        dose=data_subset$dose,
                                        donor=data_subset$donor)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=data_subset$time,
                                          dose=data_subset$dose,
                                          donor=data_subset$donor,
                                          seeds=seeds_simul,
                                          fixtime = 4,
                                          fast_in = T)
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=4)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=4)
      
      res_simul <- list("initial_fit"=fit_simul,
   #                     "boot"=outerbootstrap_simul,
  #                      "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario1_fulldata_assumecomplex_fast_medium[[i]] <- res_simul
  }
  save(Res_Scenario1_fulldata_assumecomplex_fast_medium,file="./simulation/server_results/Res_Scenario1_fulldata_assumecomplex_fast_medium.RData")
}


#'------------------------------------------------------------------------------
#### Large ----
#'------------------------------------------------------------------------------

if(file.exists("./simulation/server_results/Res_Scenario1_fulldata_assumecomplex_fast_large.RData")){
  load("./simulation/server_results/Res_Scenario1_fulldata_assumecomplex_fast_large.RData")
} else{
  #store results
  Res_Scenario1_fulldata_assumecomplex_fast_large <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario1_fulldata$large$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario1_fulldata$large$seeds$assumecomplex$fast[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=data_subset$time,
                                        dose=data_subset$dose,
                                        donor=data_subset$donor)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=data_subset$time,
                                          dose=data_subset$dose,
                                          donor=data_subset$donor,
                                          seeds=seeds_simul,
                                          fixtime = 4,
                                          fast_in = T)
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=4)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=4)
      
      res_simul <- list("initial_fit"=fit_simul,
   #                     "boot"=outerbootstrap_simul,
  #                      "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario1_fulldata_assumecomplex_fast_large[[i]] <- res_simul
  }
  save(Res_Scenario1_fulldata_assumecomplex_fast_large,file="./simulation/server_results/Res_Scenario1_fulldata_assumecomplex_fast_large.RData")
}



#'------------------------------------------------------------------------------
### Reduced data ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
#### Constant ----
#'------------------------------------------------------------------------------

if(file.exists("./simulation/server_results/Res_Scenario1_reduceddata_assumecomplex_fast_constant.RData")){
  load("./simulation/server_results/Res_Scenario1_reduceddata_assumecomplex_fast_constant.RData")
} else{
  #store results
  Res_Scenario1_reduceddata_assumecomplex_fast_constant <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario1_reduceddata$constant$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario1_reduceddata$constant$seeds$assumecomplex$fast[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=data_subset_reduced$time,
                                        dose=data_subset_reduced$dose,
                                        donor=data_subset_reduced$donor)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=data_subset_reduced$time,
                                          dose=data_subset_reduced$dose,
                                          donor=data_subset_reduced$donor,
                                          seeds=seeds_simul,
                                          fixtime = 4,
                                          fast_in = T)
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=4)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=4)
      
      res_simul <- list("initial_fit"=fit_simul,
   #                     "boot"=outerbootstrap_simul,
  #                      "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario1_reduceddata_assumecomplex_fast_constant[[i]] <- res_simul
  }
  save(Res_Scenario1_reduceddata_assumecomplex_fast_constant,file="./simulation/server_results/Res_Scenario1_reduceddata_assumecomplex_fast_constant.RData")
}



#'------------------------------------------------------------------------------
#### Small ----
#'------------------------------------------------------------------------------

if(file.exists("./simulation/server_results/Res_Scenario1_reduceddata_assumecomplex_fast_small.RData")){
  load("./simulation/server_results/Res_Scenario1_reduceddata_assumecomplex_fast_small.RData")
} else{
  #store results
  Res_Scenario1_reduceddata_assumecomplex_fast_small <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario1_reduceddata$small$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario1_reduceddata$small$seeds$assumecomplex$fast[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=data_subset_reduced$time,
                                        dose=data_subset_reduced$dose,
                                        donor=data_subset_reduced$donor)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=data_subset_reduced$time,
                                          dose=data_subset_reduced$dose,
                                          donor=data_subset_reduced$donor,
                                          seeds=seeds_simul,
                                          fixtime = 4,
                                          fast_in = T)
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=4)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=4)
      
      res_simul <- list("initial_fit"=fit_simul,
   #                     "boot"=outerbootstrap_simul,
  #                      "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario1_reduceddata_assumecomplex_fast_small[[i]] <- res_simul
  }
  save(Res_Scenario1_reduceddata_assumecomplex_fast_small,file="./simulation/server_results/Res_Scenario1_reduceddata_assumecomplex_fast_small.RData")
}



#'------------------------------------------------------------------------------
#### Medium ----
#'------------------------------------------------------------------------------

if(file.exists("./simulation/server_results/Res_Scenario1_reduceddata_assumecomplex_fast_medium.RData")){
  load("./simulation/server_results/Res_Scenario1_reduceddata_assumecomplex_fast_medium.RData")
} else{
  #store results
  Res_Scenario1_reduceddata_assumecomplex_fast_medium <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario1_reduceddata$medium$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario1_reduceddata$medium$seeds$assumecomplex$fast[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=data_subset_reduced$time,
                                        dose=data_subset_reduced$dose,
                                        donor=data_subset_reduced$donor)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=data_subset_reduced$time,
                                          dose=data_subset_reduced$dose,
                                          donor=data_subset_reduced$donor,
                                          seeds=seeds_simul,
                                          fixtime = 4,
                                          fast_in = T)
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=4)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=4)
      
      res_simul <- list("initial_fit"=fit_simul,
   #                     "boot"=outerbootstrap_simul,
  #                      "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario1_reduceddata_assumecomplex_fast_medium[[i]] <- res_simul
  }
  save(Res_Scenario1_reduceddata_assumecomplex_fast_medium,file="./simulation/server_results/Res_Scenario1_reduceddata_assumecomplex_fast_medium.RData")
}


#'------------------------------------------------------------------------------
#### Large ----
#'------------------------------------------------------------------------------

if(file.exists("./simulation/server_results/Res_Scenario1_reduceddata_assumecomplex_fast_large.RData")){
  load("./simulation/server_results/Res_Scenario1_reduceddata_assumecomplex_fast_large.RData")
} else{
  #store results
  Res_Scenario1_reduceddata_assumecomplex_fast_large <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario1_reduceddata$large$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario1_reduceddata$large$seeds$assumecomplex$fast[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=data_subset_reduced$time,
                                        dose=data_subset_reduced$dose,
                                        donor=data_subset_reduced$donor)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=data_subset_reduced$time,
                                          dose=data_subset_reduced$dose,
                                          donor=data_subset_reduced$donor,
                                          seeds=seeds_simul,
                                          fixtime = 4,
                                          fast_in = T)
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=4)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=4)
      
      res_simul <- list("initial_fit"=fit_simul,
   #                     "boot"=outerbootstrap_simul,
  #                      "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario1_reduceddata_assumecomplex_fast_large[[i]] <- res_simul
  }
  save(Res_Scenario1_reduceddata_assumecomplex_fast_large,file="./simulation/server_results/Res_Scenario1_reduceddata_assumecomplex_fast_large.RData")
}
