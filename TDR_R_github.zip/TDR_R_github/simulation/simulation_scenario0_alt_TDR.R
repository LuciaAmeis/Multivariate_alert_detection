#'##############################################################################
#                                                                              #
#                  Corresponding R Code to the Manuscript                      #
#                "Estimating effect thresholds and beyond:                     #
#              A flexible framework for multivariate alert detection"          #
#                                                                              #
#                                 Authors                                      #
#                    L. Ameis, N. Hagemann and K. Moellenhoff                  #
#                                                                              #
#                         Simulation - Scenario0_alt:Time-Dose                 #
#                                                                              #
#'##############################################################################

#Here we create a simulation scenario based on the case study

#'==============================================================================
# load case study data ====
#'==============================================================================
data(cytotox)                             #load data

data_subset <- cytotox    %>%             #From all data 
  filter(compound=="ASP") %>%             #Select compound
  dplyr::select(donor,time=expo,dose,resp)#Select only columns of interest 


donor_all <- data_subset$donor            #vector with information regarding
#donors

#generate data set with donor means

data_subset_reduced <- data_subset %>%
  group_by(time,dose,donor) %>%
  summarize(resp=mean(resp))

#'==============================================================================
# Store analysis specific information ====
#'==============================================================================
#Bootstrap runs
B_out<-500
B_in<-25

#Number of simulation runs
N<-1000

#'==============================================================================
## Basics grid ====
#'==============================================================================


#Grid
#store study dependent data for later use
#time
min_time <- 1
max_time <- 7

#dose
min_dose <- 0
max_dose <- 10

#fineness of the grid
epsilon <- 0.1



#create the grid
time_seq <- seq(min_time, max_time, by=epsilon)   #time
dose_seq <- seq(min_dose, max_dose, by=epsilon)   #dose

grid_full      <- data.frame("time"=rep(time_seq, times=length(dose_seq)))
grid_dose <- numeric(length=length(time_seq)*length(dose_seq))
for(i in 1:length(dose_seq)){
  grid_dose[((i-1)*length(time_seq)+1):(i*length(time_seq))] <- rep(dose_seq[i],  times=length(time_seq))
}
grid_full$dose <- grid_dose

#'==============================================================================
# Basics mu ====
#'==============================================================================
model <- schuettler

fit_fast <- schuettler_fast

mu_formula <- schuettler_formula

#Start value as used before
mu_start <- list(log2FC_max  = 49, slope  = -3, S_max = 0.2, t_max = 7,S_dur =1.5)


#Overall, we will model the mean as estimated
#by the td2pLL package, ignoring the variance
#structure
mu_simul_basis <- c(49, -3, 0.2,7,1.5)


#True alert at fix time t=4 (CECK IF NO FOUND)
true_alert_h0<-dose_seq[min(which(schuettler(t=4,d=dose_seq,theta = mu_simul_basis)>50))]

resp_mat_true_h0 <- model(t=grid_full$time, 
                          d=grid_full$dose, 
                          theta=mu_simul_basis)          %>%
  cbind(grid_full, "response"=.)                        %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="response")

true_alert_relationship_id_h0<- matrix(NA,nrow=length(time_seq),ncol=2)
for(i in length(time_seq):1){
  true_alert_relationship_id_h0[i,1] <- i
  true_alert_relationship_id_h0[i,2] <- min(subset(which(resp_mat_true_h0>50,arr.ind=T)[,2],
                                                   which(resp_mat_true_h0>50,arr.ind=T)[,1]==i))
}   

true_alert_relationship_h0 <- data.frame("time"=time_seq[true_alert_relationship_id_h0[,1]],
                                         "dose"=dose_seq[true_alert_relationship_id_h0[,2]])
#'==============================================================================
# Simulation scenario full data set ====
#'==============================================================================

#'------------------------------------------------------------------------------
## Model specification ----
#'------------------------------------------------------------------------------


#'------------------------------------------------------------------------------
#### Basics sigma from the data  ----
#'------------------------------------------------------------------------------
#' We will regard four different cases (constant,small,medium,large)
#' that differ in the extend of the dependence on the covariates
#' The medium case is as estimated from the data (see also Case study CASE2)


#Prepare data set
data_subset_sd <- data_subset          %>%      #combine data via sd
  group_by(time,dose,donor)            %>%
  summarize(resp_sd=sd(resp))


#CASE 2 (Case study): From Duda et al
sigma_formula_simul <- ~ dose+I(dose^2)+time+I(dose^2):time
#identify starting values for constant case
error_model <- glm(                             #estimate error model with glm 
  resp_sd ~ dose+I(dose^2)+time+I(dose^2):time,
  family = gaussian(link = "log"),              #Log-Link 
  data = data_subset_sd
)
summary(error_model)                            #start parameters for sd 

#save true values
sigma_basis_simul_medium <- coef(error_model)

#save similar starting values
sigma_start_simul_medium <- c(2,0.2,-0.03,0.08,-0.002)

#'==============================================================================
# Calculate other true parameters for sigma model ====
#'==============================================================================

#constant
sigma_basis_simul_constant <- c(sigma_basis_simul_medium[1])
#for constantant assumption
#save similar starting values
sigma_start_simul_constant <- c(2)

#for complex model
#constant effect
sigma_start_simul_semiconstant <- c(2,0.1,-0.01,0.01,-0.001)

#small effect
sigma_basis_simul_small <- c(sigma_basis_simul_medium[1],
                             0.75*sigma_basis_simul_medium[2:5])

#save similar starting values
sigma_start_simul_small <- c(2,0.2,-0.02,0.06,-0.001)

#lagre effect
sigma_basis_simul_large <- c(sigma_basis_simul_medium[1],
                             1.25*sigma_basis_simul_medium[2:5])

#save similar starting values
sigma_start_simul_large <- c(2,0.3,-0.03,0.1,-0.002)


#'==============================================================================
# Data generation example ====
#'==============================================================================

#'==============================================================================
## Full data set ====
#'==============================================================================

#constant case needs other formula for sigma
sigma_formula <- ~1

set.seed(17)
data_simul_constant_h0 <- simul(sd=sigma_basis_simul_constant,
                                par=mu_simul_basis,
                                time=data_subset$time,
                                dose = data_subset$dose,
                                donor = data_subset$donor)


#reset to complex sigma formula
sigma_formula <- sigma_formula_simul

#small
set.seed(112)
data_simul_small_h0 <- simul(sd=sigma_basis_simul_small,
                             par=mu_simul_basis,
                             time=data_subset$time,
                             dose = data_subset$dose,
                             donor = data_subset$donor)

#medium 
set.seed(123)
data_simul_medium_h0 <- simul(sd=sigma_basis_simul_medium,
                              par=mu_simul_basis,
                              time=data_subset$time,
                              dose = data_subset$dose,
                              donor = data_subset$donor)


#large
set.seed(137)
data_simul_large_h0 <- simul(sd=sigma_basis_simul_large,
                             par=mu_simul_basis,
                             time=data_subset$time,
                             dose = data_subset$dose,
                             donor = data_subset$donor)



#'==============================================================================
## Reduced data set ====
#'==============================================================================

#constant case needs other formula for sigma
sigma_formula <- ~1

set.seed(170)
data_simul_constant_reduced_h0 <- simul(sd=sigma_basis_simul_constant,
                                        par=mu_simul_basis,
                                        time=data_subset_reduced$time,
                                        dose = data_subset_reduced$dose,
                                        donor = data_subset_reduced$donor)


#reset to complex sigma formula
sigma_formula <- sigma_formula_simul

#small
set.seed(1312)
data_simul_small_reduced_h0 <- simul(sd=sigma_basis_simul_small,
                                     par=mu_simul_basis,
                                     time=data_subset_reduced$time,
                                     dose = data_subset_reduced$dose,
                                     donor = data_subset_reduced$donor)

#medium 
set.seed(1223)
data_simul_medium_reduced_h0 <- simul(sd=sigma_basis_simul_medium,
                                      par=mu_simul_basis,
                                      time=data_subset_reduced$time,
                                      dose = data_subset_reduced$dose,
                                      donor = data_subset_reduced$donor)


#large
set.seed(1137)
data_simul_large_reduced_h0 <- simul(sd=sigma_basis_simul_large,
                                     par=mu_simul_basis,
                                     time=data_subset_reduced$time,
                                     dose = data_subset_reduced$dose,
                                     donor = data_subset_reduced$donor)




#'==============================================================================
# Generate simulation runs ====
#'==============================================================================


#'==============================================================================
### Full data set ====
#'==============================================================================


#Constant
#constant case needs other formula for sigma
sigma_formula <- ~1
#List of seeds for simulation runs (full and fast algorithm)
set.seed(110)
#assume constant model
Scenario0_seeds_fulldata_assumeconstant_constant <-  runif(N, min = 0, max=1000000)
Scenario0_seeds_fulldata_assumeconstant_fast_constant <-  runif(N, min = 0, max=1000000)
#assume complex model
Scenario0_seeds_fulldata_assumecomplex_constant <-  runif(N, min = 0, max=1000000)
Scenario0_seeds_fulldata_assumecomplex_fast_constant <-  runif(N, min = 0, max=1000000)


#List to store simulations and seeds in
Scenario0_simulated_data_fulldata_constant <- list()

#seed
set.seed(11052)
for(i in 1:N){
  Scenario0_simulated_data_fulldata_constant[[i]] <- simul(sd=sigma_basis_simul_constant,
                                                           par=mu_simul_basis,
                                                           time=data_subset$time,
                                                           dose = data_subset$dose,
                                                           donor = data_subset$donor)
  
}


#reset to complex sigma formula
sigma_formula <- sigma_formula_simul


#small
#List of seeds for simulation runs (full and fast algorithm)
set.seed(120)
#assume constant model
Scenario0_seeds_fulldata_assumeconstant_small <-  runif(N, min = 0, max=1000000)
Scenario0_seeds_fulldata_assumeconstant_fast_small <-  runif(N, min = 0, max=1000000)
#assume complex model
Scenario0_seeds_fulldata_assumecomplex_small <-  runif(N, min = 0, max=1000000)
Scenario0_seeds_fulldata_assumecomplex_fast_small <-  runif(N, min = 0, max=1000000)

#List to store simulations and seeds in
Scenario0_simulated_data_fulldata_small <- list()

#seed
set.seed(1900)
for(i in 1:N){
  Scenario0_simulated_data_fulldata_small[[i]] <-simul(sd=sigma_basis_simul_small,
                                                       par=mu_simul_basis,
                                                       time=data_subset$time,
                                                       dose = data_subset$dose,
                                                       donor = data_subset$donor)
  
}

#medium
#List of seeds for simulation runs (full and fast algorithm)
set.seed(1200)
#assume constant model
Scenario0_seeds_fulldata_assumeconstant_medium <-  runif(N, min = 0, max=1000000)
Scenario0_seeds_fulldata_assumeconstant_fast_medium <-  runif(N, min = 0, max=1000000)
#assume complex model
Scenario0_seeds_fulldata_assumecomplex_medium <-  runif(N, min = 0, max=1000000)
Scenario0_seeds_fulldata_assumecomplex_fast_medium <-  runif(N, min = 0, max=1000000)

#List to store simulations and seeds in
Scenario0_simulated_data_fulldata_medium <- list()

#seed
set.seed(19000)
for(i in 1:N){
  Scenario0_simulated_data_fulldata_medium[[i]] <-simul(sd=sigma_basis_simul_medium,
                                                        par=mu_simul_basis,
                                                        time=data_subset$time,
                                                        dose = data_subset$dose,
                                                        donor = data_subset$donor)
  
}

#large
#List of seeds for simulation runs (full and fast algorithm)
set.seed(1201)
#assume constant model
Scenario0_seeds_fulldata_assumeconstant_large <-  runif(N, min = 0, max=1000000)
Scenario0_seeds_fulldata_assumeconstant_fast_large <-  runif(N, min = 0, max=1000000)
#assume complex model
Scenario0_seeds_fulldata_assumecomplex_large <-  runif(N, min = 0, max=1000000)
Scenario0_seeds_fulldata_assumecomplex_fast_large <-  runif(N, min = 0, max=1000000)

#List to store simulations and seeds in
Scenario0_simulated_data_fulldata_large <- list()

#seed
set.seed(19001)
for(i in 1:N){
  Scenario0_simulated_data_fulldata_large[[i]] <-simul(sd=sigma_basis_simul_large,
                                                       par=mu_simul_basis,
                                                       time=data_subset$time,
                                                       dose = data_subset$dose,
                                                       donor = data_subset$donor)
  
}

Scenario0_alt_fulldata <- list(
  "constant"=list("seeds"=list("assumeconstant"=list("full"=Scenario0_seeds_fulldata_assumeconstant_constant,
                                                     "fast"=Scenario0_seeds_fulldata_assumeconstant_fast_constant),
                               "assumecomplex"=list("full"=Scenario0_seeds_fulldata_assumecomplex_constant,
                                                    "fast"=Scenario0_seeds_fulldata_assumecomplex_fast_constant)),
                  "data"=Scenario0_simulated_data_fulldata_constant),
  "small"=list("seeds"=list("assumeconstant"=list("full"=Scenario0_seeds_fulldata_assumeconstant_small,
                                                  "fast"=Scenario0_seeds_fulldata_assumeconstant_fast_small),
                            "assumecomplex"=list("full"=Scenario0_seeds_fulldata_assumecomplex_small,
                                                 "fast"=Scenario0_seeds_fulldata_assumecomplex_fast_small)),
               "data"=Scenario0_simulated_data_fulldata_small),
  "medium"=list("seeds"=list("assumeconstant"=list("full"=Scenario0_seeds_fulldata_assumeconstant_medium,
                                                   "fast"=Scenario0_seeds_fulldata_assumeconstant_fast_medium),
                             "assumecomplex"=list("full"=Scenario0_seeds_fulldata_assumecomplex_medium,
                                                  "fast"=Scenario0_seeds_fulldata_assumecomplex_fast_medium)),
                "data"=Scenario0_simulated_data_fulldata_medium),
  "large"=list("seeds"=list("assumeconstant"=list("full"=Scenario0_seeds_fulldata_assumeconstant_large,
                                                  "fast"=Scenario0_seeds_fulldata_assumeconstant_fast_large),
                            "assumecomplex"=list("full"=Scenario0_seeds_fulldata_assumecomplex_large,
                                                 "fast"=Scenario0_seeds_fulldata_assumecomplex_fast_large)),
               "data"=Scenario0_simulated_data_fulldata_large)
)


save(Scenario0_alt_fulldata,file="./simulation/simulated_data/Scenario0_alt_fulldata.RData")



#'==============================================================================
### Reduced data set ====
#'==============================================================================


#Constant
#constant case needs other formula for sigma
sigma_formula <- ~1
#List of seeds for simulation runs (full and fast algorithm)
set.seed(1101)
#assume constant model
Scenario0_seeds_reduceddata_assumeconstant_constant <-  runif(N, min = 0, max=1000000)
Scenario0_seeds_reduceddata_assumeconstant_fast_constant <-  runif(N, min = 0, max=1000000)
#assume complex model
Scenario0_seeds_reduceddata_assumecomplex_constant <-  runif(N, min = 0, max=1000000)
Scenario0_seeds_reduceddata_assumecomplex_fast_constant <-  runif(N, min = 0, max=1000000)

#List to store simulations and seeds in
Scenario0_simulated_data_reduceddata_constant <- list()

#seed
set.seed(11052)
for(i in 1:N){
  Scenario0_simulated_data_reduceddata_constant[[i]] <- simul(sd=sigma_basis_simul_constant,
                                                              par=mu_simul_basis,
                                                              time=data_subset_reduced$time,
                                                              dose = data_subset_reduced$dose,
                                                              donor = data_subset_reduced$donor)
  
}


#reset to complex sigma formula
sigma_formula <- sigma_formula_simul


#small
#List of seeds for simulation runs (full and fast algorithm)
set.seed(1201)
Scenario0_seeds_reduceddata_assumeconstant_small <-  runif(N, min = 0, max=1000000)
Scenario0_seeds_reduceddata_assumeconstant_fast_small <-  runif(N, min = 0, max=1000000)
#assume complex model
Scenario0_seeds_reduceddata_assumecomplex_small <-  runif(N, min = 0, max=1000000)
Scenario0_seeds_reduceddata_assumecomplex_fast_small <-  runif(N, min = 0, max=1000000)

#List to store simulations and seeds in
Scenario0_simulated_data_reduceddata_small <- list()

#seed
set.seed(19001)
for(i in 1:N){
  Scenario0_simulated_data_reduceddata_small[[i]] <-simul(sd=sigma_basis_simul_small,
                                                          par=mu_simul_basis,
                                                          time=data_subset_reduced$time,
                                                          dose = data_subset_reduced$dose,
                                                          donor = data_subset_reduced$donor)
  
}

#medium
#List of seeds for simulation runs (full and fast algorithm)
set.seed(12001)
Scenario0_seeds_reduceddata_assumeconstant_medium <-  runif(N, min = 0, max=1000000)
Scenario0_seeds_reduceddata_assumeconstant_fast_medium <-  runif(N, min = 0, max=1000000)
#assume complex model
Scenario0_seeds_reduceddata_assumecomplex_medium <-  runif(N, min = 0, max=1000000)
Scenario0_seeds_reduceddata_assumecomplex_fast_medium <-  runif(N, min = 0, max=1000000)

#List to store simulations and seeds in
Scenario0_simulated_data_reduceddata_medium <- list()

#seed
set.seed(190001)
for(i in 1:N){
  Scenario0_simulated_data_reduceddata_medium[[i]] <-simul(sd=sigma_basis_simul_medium,
                                                           par=mu_simul_basis,
                                                           time=data_subset_reduced$time,
                                                           dose = data_subset_reduced$dose,
                                                           donor = data_subset_reduced$donor)
  
}

#large
#List of seeds for simulation runs (full and fast algorithm)
set.seed(12011)
Scenario0_seeds_reduceddata_assumeconstant_large <-  runif(N, min = 0, max=1000000)
Scenario0_seeds_reduceddata_assumeconstant_fast_large <-  runif(N, min = 0, max=1000000)
#assume complex model
Scenario0_seeds_reduceddata_assumecomplex_large <-  runif(N, min = 0, max=1000000)
Scenario0_seeds_reduceddata_assumecomplex_fast_large <-  runif(N, min = 0, max=1000000)

#List to store simulations and seeds in
Scenario0_simulated_data_reduceddata_large <- list()

#seed
set.seed(190011)
for(i in 1:N){
  Scenario0_simulated_data_reduceddata_large[[i]] <-simul(sd=sigma_basis_simul_large,
                                                          par=mu_simul_basis,
                                                          time=data_subset_reduced$time,
                                                          dose = data_subset_reduced$dose,
                                                          donor = data_subset_reduced$donor)
  
}

Scenario0_alt_reduceddata <- list(
  "constant"=list("seeds"=list("assumeconstant"=list("full"=Scenario0_seeds_reduceddata_assumeconstant_constant,
                                                     "fast"=Scenario0_seeds_reduceddata_assumeconstant_fast_constant),
                               "assumecomplex"=list("full"=Scenario0_seeds_reduceddata_assumecomplex_constant,
                                                    "fast"=Scenario0_seeds_reduceddata_assumecomplex_fast_constant)),
                  "data"=Scenario0_simulated_data_reduceddata_constant),
  "small"=list("seeds"=list("assumeconstant"=list("full"=Scenario0_seeds_reduceddata_assumeconstant_small,
                                                  "fast"=Scenario0_seeds_reduceddata_assumeconstant_fast_small),
                            "assumecomplex"=list("full"=Scenario0_seeds_reduceddata_assumecomplex_small,
                                                 "fast"=Scenario0_seeds_reduceddata_assumecomplex_fast_small)),
               "data"=Scenario0_simulated_data_reduceddata_small),
  "medium"=list("seeds"=list("assumeconstant"=list("full"=Scenario0_seeds_reduceddata_assumeconstant_medium,
                                                   "fast"=Scenario0_seeds_reduceddata_assumeconstant_fast_medium),
                             "assumecomplex"=list("full"=Scenario0_seeds_reduceddata_assumecomplex_medium,
                                                  "fast"=Scenario0_seeds_reduceddata_assumecomplex_fast_medium)),
                "data"=Scenario0_simulated_data_reduceddata_medium),
  "large"=list("seeds"=list("assumeconstant"=list("full"=Scenario0_seeds_reduceddata_assumeconstant_large,
                                                  "fast"=Scenario0_seeds_reduceddata_assumeconstant_fast_large),
                            "assumecomplex"=list("full"=Scenario0_seeds_reduceddata_assumecomplex_large,
                                                 "fast"=Scenario0_seeds_reduceddata_assumecomplex_fast_large)),
               "data"=Scenario0_simulated_data_reduceddata_large)
)

save(Scenario0_alt_reduceddata,file="./simulation/simulated_data/Scenario0_alt_reduceddata.RData")



#'==============================================================================
# Table with scenario infos ====
#'==============================================================================

table_scenario0_alt <- data.frame(
  "Scenario"=c("0 - Full - Simple","0 - Full -Small","0 - Full - Medium","0 - Full - Large",
               "0 - Reduced - Simple","0 - Reduced -Small","0 - Reduced - Medium","0 - Reduced - Large"),
  "Parameters_mu" =rep(paste(round(mu_simul_basis,1),collapse=","),times=8),
  "Parameters_sigma"=as.character(rep(c(paste(round(sigma_basis_simul_constant,3),collapse=","),
                                        paste(round(sigma_basis_simul_small,3),collapse=","),
                                        paste(round(sigma_basis_simul_medium,3),collapse=","),
                                        paste(round(sigma_basis_simul_large,3),collapse=",")),times=2)),
  "Observations"=c(rep(nrow(data_simul_constant_h0),times=4),
                   rep(nrow(data_simul_constant_reduced_h0),times=4)),
  "Design"=c(rep("Full",times=4),
             rep("Reduced",times=4))
)




if (file.exists("./plots_tables/201_simulation_scenarios.xlsx")) {
  wb <- loadWorkbook("./plots_tables/201_simulation_scenarios.xlsx")
  
  if ("Scenario 0_alt" %in% names(wb)) {
    removeWorksheet(wb, "Scenario 0_alt")
  }
} 

addWorksheet(wb, "Scenario 0_alt")
writeData(wb, "Scenario 0_alt", table_scenario0_alt)
saveWorkbook(wb, "./plots_tables/201_simulation_scenarios.xlsx", overwrite = TRUE)




counts_full <- data_simul_constant_h0 %>%
  group_by(time,dose) %>%
  summarise(
    n = n(),
    .groups = "drop"
  )

entry_char_full <- counts_full %>%
  transmute(
    txt = paste0(
      "((", time,
      ", ", dose,
      ",),", n, ")"
    )
  ) %>%
  pull(txt) %>%
  paste(collapse = "; ")

counts_reduced <- data_simul_constant_reduced_h0 %>%
  group_by(time,dose) %>%
  summarise(
    n = n(),
    .groups = "drop"
  )

entry_char_reduced <- counts_reduced %>%
  transmute(
    txt = paste0(
      "((", time,
      ", ", dose,
      ",),", n, ")"
    )
  ) %>%
  pull(txt) %>%
  paste(collapse = "; ")


tale_design_scenario0_alt <- data.frame(
  "Scenario"=rep("0",times=2),
  "Design"=c("Full","Reduced"),
  "Measurements"=c(entry_char_full,entry_char_reduced)
)





if (file.exists("./plots_tables/202_simulation_scenarios_design.xlsx")) {
  wb <- loadWorkbook("./plots_tables/202_simulation_scenarios_design.xlsx")
  
  if ("Scenario 0_alt" %in% names(wb)) {
    removeWorksheet(wb, "Scenario 0_alt")
  }
} 

addWorksheet(wb, "Scenario 0_alt")
writeData(wb, "Scenario 0_alt", tale_design_scenario0_alt)
saveWorkbook(wb, "./plots_tables/202_simulation_scenarios_design.xlsx", overwrite = TRUE)



