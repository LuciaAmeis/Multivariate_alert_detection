#'##############################################################################
#                                                                              #
#                  Corresponding R Code to the Manuscript                      #
#                "Estimating effect thresholds and beyond:                     #
#              A flexible framework for multivariate alert detection"          #
#                                                                              #
#                                 Authors                                      #
#                    L. Ameis, N. Hagemann and K. Moellenhoff                  #
#                                                                              #
#                         Simulation - Scenario 1: Analysis simulation         #
#                                                                              #
#'##############################################################################


#'==============================================================================
# Two dimensional analysis ====
#'==============================================================================

#'==============================================================================
## Analysis function ====
#'==============================================================================

analysis_2dim <- function(res){
  
  #2dim approach
  res_vec_2dim <- numeric(1000)
  faild_runs_2dim <- numeric(1000)
  for(i in 1:1000){
    if(anyNA(res[[i]])==T){
      faild_runs_2dim[i] <- 1
      alert <- NA  
    } else{
    #identify grid alert
    id<-min(which(res[[i]]$conf$fixtime<50))
    #check if last grid point is selected, then no alert was detected
    if(is.integer(id) && length(id) == 0){
      alert <- NA  
    }
    #save alert
    alert<-dose_seq[id]
    } 
    res_vec_2dim[i] <- alert
  }  
  
  #3dim approach
  res_vec_3dim <- numeric(1000)
  faild_runs_3dim <- numeric(1000)
  for(i in 1:1000){
    if(anyNA(res[[i]])==T){
      faild_runs_3dim[i] <- 1
      alert <- NA  
    } else{
      #identify grid alert
      conf_band_mat <- res[[i]]$conf$full   %>%
        cbind(grid_full, "cf"=. )                %>%
        reshape2::acast(., 
                        time~dose, 
                        value.var="cf")
      
      id <- min(which(conf_band_mat[31,]<50)) 
      #check if there is an alert
      if(is.integer(id) && length(id) == 0){
        alert <- NA  
      }
      #save alert
      alert<-dose_seq[id]
    } 
    res_vec_3dim[i] <- alert
  }  
  
  
  return(list("all_alerts_2dim"=res_vec_2dim,
              "all_alerts_3dim"=res_vec_3dim,
              "median_2dim"=median(res_vec_2dim,na.rm=T),
              "median_3dim"=median(res_vec_3dim,na.rm=T),
              "sd_2dim"=round(sd(res_vec_2dim,na.rm=T),3),
              "sd_3dim"=round(sd(res_vec_3dim,na.rm=T),3),
              "failed_runs_2dim"=sum(faild_runs_2dim),
              "failed_runs_3dim"=sum(faild_runs_3dim),
              "H0_reject_2dim"=sum(!is.na(res_vec_2dim)),
              "H0_reject_3dim"=sum(!is.na(res_vec_3dim))
  ))
}

if(file.exists("./simulation/010_scenario1_analysis_2d_intermediate.RData")){
  load("./simulation/010_scenario1_analysis_2d_intermediate.RData")
}else{

#'==============================================================================
## Full data set ====
#'==============================================================================

#'------------------------------------------------------------------------------
### Assume constant value for sd   ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
#### Assume constant value for sd - Full  ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
##### Case: Simple  ----
#'------------------------------------------------------------------------------

Res_alert_fixtime_Scenario1_fulldata_assumeconstant_constant <- analysis_2dim(Res_Scenario1_fulldata_assumeconstant_constant)

#'------------------------------------------------------------------------------
##### Case: Small  ----
#'------------------------------------------------------------------------------

Res_alert_fixtime_Scenario1_fulldata_assumeconstant_small <- analysis_2dim(Res_Scenario1_fulldata_assumeconstant_small)

#'------------------------------------------------------------------------------
##### Case: Medium  ----
#'------------------------------------------------------------------------------

Res_alert_fixtime_Scenario1_fulldata_assumeconstant_medium <- analysis_2dim(Res_Scenario1_fulldata_assumeconstant_medium)


#'------------------------------------------------------------------------------
##### Case: Large  ----
#'------------------------------------------------------------------------------

Res_alert_fixtime_Scenario1_fulldata_assumeconstant_large <- analysis_2dim(Res_Scenario1_fulldata_assumeconstant_large)


#'------------------------------------------------------------------------------
#### Assume constant value for sd - fast  ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
##### Case: Simple  ----
#'------------------------------------------------------------------------------

Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_constant <- analysis_2dim(Res_Scenario1_fulldata_assumeconstant_fast_constant)


#'------------------------------------------------------------------------------
##### Case: Small  ----
#'------------------------------------------------------------------------------

Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_small <- analysis_2dim(Res_Scenario1_fulldata_assumeconstant_fast_small)


#'------------------------------------------------------------------------------
##### Case: Medium  ----
#'------------------------------------------------------------------------------

Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_medium <- analysis_2dim(Res_Scenario1_fulldata_assumeconstant_fast_medium)


#'------------------------------------------------------------------------------
##### Case: Large  ----
#'------------------------------------------------------------------------------

Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_large <- analysis_2dim(Res_Scenario1_fulldata_assumeconstant_fast_large)



#'------------------------------------------------------------------------------
### Assume complex value for sd   ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
#### Assume complex value for sd - Full  ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
##### Case: Simple  ----
#'------------------------------------------------------------------------------

Res_alert_fixtime_Scenario1_fulldata_assumecomplex_constant <- analysis_2dim(Res_Scenario1_fulldata_assumecomplex_constant)



#'------------------------------------------------------------------------------
##### Case: Small  ----
#'------------------------------------------------------------------------------

Res_alert_fixtime_Scenario1_fulldata_assumecomplex_small <- analysis_2dim(Res_Scenario1_fulldata_assumecomplex_small)

#'------------------------------------------------------------------------------
##### Case: Medium  ----
#'------------------------------------------------------------------------------

Res_alert_fixtime_Scenario1_fulldata_assumecomplex_medium <- analysis_2dim(Res_Scenario1_fulldata_assumecomplex_medium)


#'------------------------------------------------------------------------------
##### Case: Large  ----
#'------------------------------------------------------------------------------

Res_alert_fixtime_Scenario1_fulldata_assumecomplex_large <- analysis_2dim(Res_Scenario1_fulldata_assumecomplex_large)




#'------------------------------------------------------------------------------
#### Assume complex value for sd - fast  ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
##### Case: Simple  ----
#'------------------------------------------------------------------------------

Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_constant <- analysis_2dim(Res_Scenario1_fulldata_assumecomplex_fast_constant)



#'------------------------------------------------------------------------------
##### Case: Small  ----
#'------------------------------------------------------------------------------

Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_small <- analysis_2dim(Res_Scenario1_fulldata_assumecomplex_fast_small)


#'------------------------------------------------------------------------------
##### Case: Medium  ----
#'------------------------------------------------------------------------------

Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_medium <- analysis_2dim(Res_Scenario1_fulldata_assumecomplex_fast_medium)


#'------------------------------------------------------------------------------
##### Case: Large  ----
#'------------------------------------------------------------------------------

Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_large <- analysis_2dim(Res_Scenario1_fulldata_assumecomplex_fast_large)




#'==============================================================================
## Reduced data set ====
#'==============================================================================


#'------------------------------------------------------------------------------
### Assume constant value for sd   ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
#### Assume constant value for sd - Full  ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
##### Case: Simple  ----
#'------------------------------------------------------------------------------

Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_constant <- analysis_2dim(Res_Scenario1_reduceddata_assumeconstant_constant)

#'------------------------------------------------------------------------------
##### Case: Small  ----
#'------------------------------------------------------------------------------

Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_small <- analysis_2dim(Res_Scenario1_reduceddata_assumeconstant_small)

#'------------------------------------------------------------------------------
##### Case: Medium  ----
#'------------------------------------------------------------------------------

Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_medium <- analysis_2dim(Res_Scenario1_reduceddata_assumeconstant_medium)


#'------------------------------------------------------------------------------
##### Case: Large  ----
#'------------------------------------------------------------------------------

Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_large <- analysis_2dim(Res_Scenario1_reduceddata_assumeconstant_large)


#'------------------------------------------------------------------------------
#### Assume constant value for sd - fast  ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
##### Case: Simple  ----
#'------------------------------------------------------------------------------

Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_constant <- analysis_2dim(Res_Scenario1_reduceddata_assumeconstant_fast_constant)


#'------------------------------------------------------------------------------
##### Case: Small  ----
#'------------------------------------------------------------------------------

Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_small <- analysis_2dim(Res_Scenario1_reduceddata_assumeconstant_fast_small)


#'------------------------------------------------------------------------------
##### Case: Medium  ----
#'------------------------------------------------------------------------------

Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_medium <- analysis_2dim(Res_Scenario1_reduceddata_assumeconstant_fast_medium)


#'------------------------------------------------------------------------------
##### Case: Large  ----
#'------------------------------------------------------------------------------

Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_large <- analysis_2dim(Res_Scenario1_reduceddata_assumeconstant_fast_large)



#'------------------------------------------------------------------------------
### Assume complex value for sd   ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
#### Assume complex value for sd - Full  ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
##### Case: Simple  ----
#'------------------------------------------------------------------------------

Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_constant <- analysis_2dim(Res_Scenario1_reduceddata_assumecomplex_constant)



#'------------------------------------------------------------------------------
##### Case: Small  ----
#'------------------------------------------------------------------------------

Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_small <- analysis_2dim(Res_Scenario1_reduceddata_assumecomplex_small)

#'------------------------------------------------------------------------------
##### Case: Medium  ----
#'------------------------------------------------------------------------------

Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_medium <- analysis_2dim(Res_Scenario1_reduceddata_assumecomplex_medium)


#'------------------------------------------------------------------------------
##### Case: Large  ----
#'------------------------------------------------------------------------------

Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_large <- analysis_2dim(Res_Scenario1_reduceddata_assumecomplex_large)




#'------------------------------------------------------------------------------
#### Assume complex value for sd - fast  ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
##### Case: Simple  ----
#'------------------------------------------------------------------------------

Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_constant <- analysis_2dim(Res_Scenario1_reduceddata_assumecomplex_fast_constant)



#'------------------------------------------------------------------------------
##### Case: Small  ----
#'------------------------------------------------------------------------------

Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_small <- analysis_2dim(Res_Scenario1_reduceddata_assumecomplex_fast_small)


#'------------------------------------------------------------------------------
##### Case: Medium  ----
#'------------------------------------------------------------------------------

Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_medium <- analysis_2dim(Res_Scenario1_reduceddata_assumecomplex_fast_medium)


#'------------------------------------------------------------------------------
##### Case: Large  ----
#'------------------------------------------------------------------------------

Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_large <- analysis_2dim(Res_Scenario1_reduceddata_assumecomplex_fast_large)

#'------------------------------------------------------------------------------
#### Save intermediate  ----
#'------------------------------------------------------------------------------

save( Res_alert_fixtime_Scenario1_fulldata_assumeconstant_constant,
      Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_constant,
      Res_alert_fixtime_Scenario1_fulldata_assumeconstant_small,
      Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_small,
      Res_alert_fixtime_Scenario1_fulldata_assumeconstant_medium,
      Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_medium,
      Res_alert_fixtime_Scenario1_fulldata_assumeconstant_large,
      Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_large,
      Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_constant,
      Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_constant,
      Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_small,
      Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_small,
      Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_medium,
      Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_medium,
      Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_large,
      Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_large,
      Res_alert_fixtime_Scenario1_fulldata_assumecomplex_constant,
      Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_constant,
      Res_alert_fixtime_Scenario1_fulldata_assumecomplex_small,
      Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_small,
      Res_alert_fixtime_Scenario1_fulldata_assumecomplex_medium,
      Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_medium,
      Res_alert_fixtime_Scenario1_fulldata_assumecomplex_large,
      Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_large,
      Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_constant,
      Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_constant,
      Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_small,
      Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_small,
      Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_medium,
      Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_medium,
      Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_large,
      Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_large,
      file="./simulation/010_scenario1_analysis_2d_intermediate.RData")
}


#'==============================================================================
## Generate Table with resutls ====
#'==============================================================================

table_results_scenario1_2d <- data.frame(
  "_"=c("Approach","Algorithm","Assumption","Scenario 1 - Full - Simple","Scenario 1 - Full -Small","Scenario 1 - Full - Medium","Scenario 1 - Full - Large",
               "Scenario 1 - Reduced - Simple","Scenario 1 - Reduced -Small","Scenario 1 - Reduced - Medium","Scenario 1 - Reduced - Large"),
  "H0_rejected_percent_2D_const"=c("2D","Normal","Constant",c(Res_alert_fixtime_Scenario1_fulldata_assumeconstant_constant$H0_reject_2dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumeconstant_small$H0_reject_2dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumeconstant_medium$H0_reject_2dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumeconstant_large$H0_reject_2dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_constant$H0_reject_2dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_small$H0_reject_2dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_medium$H0_reject_2dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_large$H0_reject_2dim)/10),
  "H0_rejected_percent_3D_const"=c("3D","Normal","Constant",c(Res_alert_fixtime_Scenario1_fulldata_assumeconstant_constant$H0_reject_3dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumeconstant_small$H0_reject_3dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumeconstant_medium$H0_reject_3dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumeconstant_large$H0_reject_3dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_constant$H0_reject_3dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_small$H0_reject_3dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_medium$H0_reject_3dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_large$H0_reject_3dim)/10),
  "H0_rejected_percent_2D_fast_const"=c("2D","Fast","Constant",c(Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_constant$H0_reject_2dim,
                                Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_small$H0_reject_2dim,
                                Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_medium$H0_reject_2dim,
                                Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_large$H0_reject_2dim,
                                Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_constant$H0_reject_2dim,
                                Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_small$H0_reject_2dim,
                                Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_medium$H0_reject_2dim,
                                Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_large$H0_reject_2dim)/10),
  "H0_rejected_percent_3D_fast_const"=c("3D","Fast","Constant",c(Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_constant$H0_reject_3dim,
                                Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_small$H0_reject_3dim,
                                Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_medium$H0_reject_3dim,
                                Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_large$H0_reject_3dim,
                                Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_constant$H0_reject_3dim,
                                Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_small$H0_reject_3dim,
                                Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_medium$H0_reject_3dim,
                                Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_large$H0_reject_3dim)/10),
  "Median_2D_const"=c("2D","Normal","Constant",Res_alert_fixtime_Scenario1_fulldata_assumeconstant_constant$median_2dim,
                      Res_alert_fixtime_Scenario1_fulldata_assumeconstant_small$median_2dim,
                      Res_alert_fixtime_Scenario1_fulldata_assumeconstant_medium$median_2dim,
                      Res_alert_fixtime_Scenario1_fulldata_assumeconstant_large$median_2dim,
                      Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_constant$median_2dim,
                      Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_small$median_2dim,
                      Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_medium$median_2dim,
                      Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_large$median_2dim),
  "Median_3D_const"=c("3D","Normal","Constant",Res_alert_fixtime_Scenario1_fulldata_assumeconstant_constant$median_3dim,
                      Res_alert_fixtime_Scenario1_fulldata_assumeconstant_small$median_3dim,
                      Res_alert_fixtime_Scenario1_fulldata_assumeconstant_medium$median_3dim,
                      Res_alert_fixtime_Scenario1_fulldata_assumeconstant_large$median_3dim,
                      Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_constant$median_3dim,
                      Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_small$median_3dim,
                      Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_medium$median_3dim,
                      Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_large$median_3dim),
  "Median_2D_fast_const"=c("2D","Fast","Constant",Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_constant$median_2dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_small$median_2dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_medium$median_2dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_large$median_2dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_constant$median_2dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_small$median_2dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_medium$median_2dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_large$median_2dim),
  "Median_3D_fast_const"=c("3D","Fast","Constant",Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_constant$median_3dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_small$median_3dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_medium$median_3dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_large$median_3dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_constant$median_3dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_small$median_3dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_medium$median_3dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_large$median_3dim),
  "SD_2D_const"=c("2D","Normal","Constant",Res_alert_fixtime_Scenario1_fulldata_assumeconstant_constant$sd_2dim,
                  Res_alert_fixtime_Scenario1_fulldata_assumeconstant_small$sd_2dim,
                  Res_alert_fixtime_Scenario1_fulldata_assumeconstant_medium$sd_2dim,
                  Res_alert_fixtime_Scenario1_fulldata_assumeconstant_large$sd_2dim,
                  Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_constant$sd_2dim,
                  Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_small$sd_2dim,
                  Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_medium$sd_2dim,
                  Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_large$sd_2dim),
  "SD_3D_const"=c("3D","Normal","Constant",Res_alert_fixtime_Scenario1_fulldata_assumeconstant_constant$sd_3dim,
                  Res_alert_fixtime_Scenario1_fulldata_assumeconstant_small$sd_3dim,
                  Res_alert_fixtime_Scenario1_fulldata_assumeconstant_medium$sd_3dim,
                  Res_alert_fixtime_Scenario1_fulldata_assumeconstant_large$sd_3dim,
                  Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_constant$sd_3dim,
                  Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_small$sd_3dim,
                  Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_medium$sd_3dim,
                  Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_large$sd_3dim),
  "SD_2D_fast_const"=c("2D","Fast","Constant",Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_constant$sd_2dim,
                       Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_small$sd_2dim,
                       Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_medium$sd_2dim,
                       Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_large$sd_2dim,
                       Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_constant$sd_2dim,
                       Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_small$sd_2dim,
                       Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_medium$sd_2dim,
                       Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_large$sd_2dim),
  "SD_3D_fast_const"=c("3D","Fast","Constant",Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_constant$sd_3dim,
                       Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_small$sd_3dim,
                       Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_medium$sd_3dim,
                       Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_large$sd_3dim,
                       Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_constant$sd_3dim,
                       Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_small$sd_3dim,
                       Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_medium$sd_3dim,
                       Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_large$sd_3dim),
  "Failed_runs_2D_const"=c("2D","Normal","Constant",Res_alert_fixtime_Scenario1_fulldata_assumeconstant_constant$failed_runs_2dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumeconstant_small$failed_runs_2dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumeconstant_medium$failed_runs_2dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumeconstant_large$failed_runs_2dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_constant$failed_runs_2dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_small$failed_runs_2dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_medium$failed_runs_2dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_large$failed_runs_2dim),
  "Failed_runs_3D_const"=c("3D","Normal","Constant",Res_alert_fixtime_Scenario1_fulldata_assumeconstant_constant$failed_runs_3dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumeconstant_small$failed_runs_3dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumeconstant_medium$failed_runs_3dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumeconstant_large$failed_runs_3dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_constant$failed_runs_3dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_small$failed_runs_3dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_medium$failed_runs_3dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_large$failed_runs_3dim),
  "Failed_runs_2D_fast_const"=c("2D","Fast","Constant",Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_constant$failed_runs_2dim,
                                Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_small$failed_runs_2dim,
                                Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_medium$failed_runs_2dim,
                                Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_large$failed_runs_2dim,
                                Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_constant$failed_runs_2dim,
                                Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_small$failed_runs_2dim,
                                Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_medium$failed_runs_2dim,
                                Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_large$failed_runs_2dim),
  "Failed_runs_3D_fast_const"=c("3D","Fast","Constant",Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_constant$failed_runs_3dim,
                                Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_small$failed_runs_3dim,
                                Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_medium$failed_runs_3dim,
                                Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_large$failed_runs_3dim,
                                Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_constant$failed_runs_3dim,
                                Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_small$failed_runs_3dim,
                                Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_medium$failed_runs_3dim,
                                Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_large$failed_runs_3dim),
  "H0_rejected_percent_2D_complex"=c("2D","Normal","Complex",c(Res_alert_fixtime_Scenario1_fulldata_assumecomplex_constant$H0_reject_2dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumecomplex_small$H0_reject_2dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumecomplex_medium$H0_reject_2dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumecomplex_large$H0_reject_2dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_constant$H0_reject_2dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_small$H0_reject_2dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_medium$H0_reject_2dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_large$H0_reject_2dim)/10),
  "H0_rejected_percent_3D_complex"=c("3D","Normal","Complex",c(Res_alert_fixtime_Scenario1_fulldata_assumecomplex_constant$H0_reject_3dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumecomplex_small$H0_reject_3dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumecomplex_medium$H0_reject_3dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumecomplex_large$H0_reject_3dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_constant$H0_reject_3dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_small$H0_reject_3dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_medium$H0_reject_3dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_large$H0_reject_3dim)/10),
  "H0_rejected_percent_2D_fast_complex"=c("2D","Fast","Complex",c(Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_constant$H0_reject_2dim,
                                Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_small$H0_reject_2dim,
                                Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_medium$H0_reject_2dim,
                                Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_large$H0_reject_2dim,
                                Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_constant$H0_reject_2dim,
                                Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_small$H0_reject_2dim,
                                Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_medium$H0_reject_2dim,
                                Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_large$H0_reject_2dim)/10),
  "H0_rejected_percent_3D_fast_complex"=c("3D","Fast","Complex",c(Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_constant$H0_reject_3dim,
                                Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_small$H0_reject_3dim,
                                Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_medium$H0_reject_3dim,
                                Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_large$H0_reject_3dim,
                                Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_constant$H0_reject_3dim,
                                Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_small$H0_reject_3dim,
                                Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_medium$H0_reject_3dim,
                                Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_large$H0_reject_3dim)/10),
  "Median_2D_complex"=c("2D","Normal","Complex",Res_alert_fixtime_Scenario1_fulldata_assumecomplex_constant$median_2dim,
                      Res_alert_fixtime_Scenario1_fulldata_assumecomplex_small$median_2dim,
                      Res_alert_fixtime_Scenario1_fulldata_assumecomplex_medium$median_2dim,
                      Res_alert_fixtime_Scenario1_fulldata_assumecomplex_large$median_2dim,
                      Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_constant$median_2dim,
                      Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_small$median_2dim,
                      Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_medium$median_2dim,
                      Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_large$median_2dim),
  "Median_3D_complex"=c("3D","Normal","Complex",Res_alert_fixtime_Scenario1_fulldata_assumecomplex_constant$median_3dim,
                      Res_alert_fixtime_Scenario1_fulldata_assumecomplex_small$median_3dim,
                      Res_alert_fixtime_Scenario1_fulldata_assumecomplex_medium$median_3dim,
                      Res_alert_fixtime_Scenario1_fulldata_assumecomplex_large$median_3dim,
                      Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_constant$median_3dim,
                      Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_small$median_3dim,
                      Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_medium$median_3dim,
                      Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_large$median_3dim),
  "Median_2D_fast_complex"=c("2D","Fast","Complex",Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_constant$median_2dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_small$median_2dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_medium$median_2dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_large$median_2dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_constant$median_2dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_small$median_2dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_medium$median_2dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_large$median_2dim),
  "Median_3D_fast_complex"=c("3D","Fast","Complex",Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_constant$median_3dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_small$median_3dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_medium$median_3dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_large$median_3dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_constant$median_3dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_small$median_3dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_medium$median_3dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_large$median_3dim),
  "SD_2D_complex"=c("2D","Normal","Complex",Res_alert_fixtime_Scenario1_fulldata_assumecomplex_constant$sd_2dim,
                  Res_alert_fixtime_Scenario1_fulldata_assumecomplex_small$sd_2dim,
                  Res_alert_fixtime_Scenario1_fulldata_assumecomplex_medium$sd_2dim,
                  Res_alert_fixtime_Scenario1_fulldata_assumecomplex_large$sd_2dim,
                  Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_constant$sd_2dim,
                  Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_small$sd_2dim,
                  Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_medium$sd_2dim,
                  Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_large$sd_2dim),
  "SD_3D_complex"=c("3D","Normal","Complex",Res_alert_fixtime_Scenario1_fulldata_assumecomplex_constant$sd_3dim,
                  Res_alert_fixtime_Scenario1_fulldata_assumecomplex_small$sd_3dim,
                  Res_alert_fixtime_Scenario1_fulldata_assumecomplex_medium$sd_3dim,
                  Res_alert_fixtime_Scenario1_fulldata_assumecomplex_large$sd_3dim,
                  Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_constant$sd_3dim,
                  Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_small$sd_3dim,
                  Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_medium$sd_3dim,
                  Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_large$sd_3dim),
  "SD_2D_fast_complex"=c("2D","Fast","Complex",Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_constant$sd_2dim,
                       Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_small$sd_2dim,
                       Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_medium$sd_2dim,
                       Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_large$sd_2dim,
                       Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_constant$sd_2dim,
                       Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_small$sd_2dim,
                       Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_medium$sd_2dim,
                       Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_large$sd_2dim),
  "SD_3D_fast_complex"=c("3D","Fast","Complex",Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_constant$sd_3dim,
                       Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_small$sd_3dim,
                       Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_medium$sd_3dim,
                       Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_large$sd_3dim,
                       Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_constant$sd_3dim,
                       Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_small$sd_3dim,
                       Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_medium$sd_3dim,
                       Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_large$sd_3dim),
  "Failed_runs_2D_complex"=c("2D","Normal","Complex",Res_alert_fixtime_Scenario1_fulldata_assumecomplex_constant$failed_runs_2dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumecomplex_small$failed_runs_2dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumecomplex_medium$failed_runs_2dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumecomplex_large$failed_runs_2dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_constant$failed_runs_2dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_small$failed_runs_2dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_medium$failed_runs_2dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_large$failed_runs_2dim),
  "Failed_runs_3D_complex"=c("3D","Normal","Complex",Res_alert_fixtime_Scenario1_fulldata_assumecomplex_constant$failed_runs_3dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumecomplex_small$failed_runs_3dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumecomplex_medium$failed_runs_3dim,
                           Res_alert_fixtime_Scenario1_fulldata_assumecomplex_large$failed_runs_3dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_constant$failed_runs_3dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_small$failed_runs_3dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_medium$failed_runs_3dim,
                           Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_large$failed_runs_3dim),
  "Failed_runs_2D_fast_complex"=c("2D","Fast","Complex",Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_constant$failed_runs_2dim,
                                Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_small$failed_runs_2dim,
                                Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_medium$failed_runs_2dim,
                                Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_large$failed_runs_2dim,
                                Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_constant$failed_runs_2dim,
                                Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_small$failed_runs_2dim,
                                Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_medium$failed_runs_2dim,
                                Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_large$failed_runs_2dim),
  "Failed_runs_3D_fast_complex"=c("3D","Fast","Complex",Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_constant$failed_runs_3dim,
                                Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_small$failed_runs_3dim,
                                Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_medium$failed_runs_3dim,
                                Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_large$failed_runs_3dim,
                                Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_constant$failed_runs_3dim,
                                Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_small$failed_runs_3dim,
                                Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_medium$failed_runs_3dim,
                                Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_large$failed_runs_3dim)
)


#Check
#View( as.data.frame(t(table_results_scenario1_2d)))

# write.xlsx(
#   as.data.frame(t(table_results_scenario1_2d)),
#   file = "./plots_tables/203_simulation_scenario1_results_2d_all.xlsx",
#   colNames = F,rowNames=T
# )


#Note, that the combinations constant - normal/fast are identical assumption wise
#They were run to compare the technical performance of both in general
#Since the performance is very similar, only the results of the fast algorithm
#are included in the paper, since there is an overall focus on the fast algorithm


#full data set
write.xlsx(
  as.data.frame(t(table_results_scenario1_2d))[-c(2,3,6,7,10,11,14,15,16,17,30,31,32,33),1:7],
  file = "./plots_tables/204_simulation_scenario1_results_2d_full.xlsx",
  colNames = F,rowNames=T
)

#reduced data set
write.xlsx(
  as.data.frame(t(table_results_scenario1_2d))[-c(2,3,6,7,10,11,14,15,16,17,30,31,32,33),c(1:3,8:11)],
  file = "./plots_tables/205_simulation_scenario1_results_2d_reduced.xlsx",
  colNames = F,rowNames=T
)





#'==============================================================================
# Three dimensional analysis ====
#'==============================================================================

#'==============================================================================
## Analysis function ====
#'==============================================================================

#rename for later use
true_alert_relationship_df <- true_alert_relationship %>%
  rename(d_true = dose)

#Help function to identify errors per time point
compute_errors_one_sim <- function(sim_df) {
  
  sim_df %>%
    rename(d_hat = dose) %>%
    inner_join(true_alert_relationship_df, by = "time") %>%   # regard overlap
    filter(!is.na(d_hat)&!is.na(d_true)) %>%                # identified doses
    mutate(error = d_hat - d_true) %>%
    dplyr::select(time, error)
}


analysis_3dim <- function(res,scenario_info,
                          design_info,
                          sd_info,
                          sigma_assumed_info,
                          algo_info){
  
  #2dim approach
  res_list <- list()
  no_alert <- numeric(1000) #already somewhat regarded above
  for(i in 1:1000){
    if(anyNA(res[[i]])==T){
      no_alert[i] <- 1
      alert <- F  
    } else{
      #identify grid alert
      conf_band_mat <- res[[i]]$conf$full   %>%
        cbind(grid_full, "cf"=. )                %>%
        reshape2::acast(., 
                        time~dose, 
                        value.var="cf")
      
      alert_id <- matrix(NA,nrow=length(time_seq),ncol=2)
      for(j in length(time_seq):1){
        alert_id[j,1] <- j
        alert_id[j,2] <- min(subset(which(conf_band_mat<50,arr.ind=T)[,2],
                                    which(conf_band_mat<50,arr.ind=T)[,1]==j))
      }
      if(sum(is.infinite(alert_id[,2])) == nrow(alert_id)){
        alert <- F  
        no_alert[i] <-1
      } else{
      alert <- data.frame("time"=time_seq[alert_id[,1]],
                         "dose"=dose_seq[alert_id[,2]])
      }
    }
    res_list[[i]] <- alert

  }  
  
  
  true_alert_tf <- true_alert_relationship$time[which(!is.na(true_alert_relationship$dose))]

  recall_vec <- numeric(1000)
  for(i in 1:1000){
    if(no_alert[i]!=1){
      alert_tf <- res_list[[i]]$time[which(!is.na(res_list[[i]]$dose))]
   recall_vec[i] <- length(intersect(true_alert_tf,alert_tf))/length(true_alert_tf)
    } else{
      recall_vec[i] <- NA
    }
  }

  precision_vec <- numeric(1000)
  for(i in 1:1000){
    if(no_alert[i]!=1){
      alert_tf <- res_list[[i]]$time[which(!is.na(res_list[[i]]$dose))]
      precision_vec[i] <- length(intersect(true_alert_tf,alert_tf))/length(alert_tf)
    } else{
      precision_vec[i] <- NA
    }
  }


  onset_err_vec <- numeric(1000)
  for(i in 1:1000){
    if(no_alert[i]!=1){
      alert_tf <- res_list[[i]]$time[which(!is.na(res_list[[i]]$dose))]
      onset_err_vec[i]<-min(alert_tf)-min(true_alert_tf)
    } else{
      onset_err_vec[i] <- NA
    }
  }

  offset_err_vec <- numeric(1000)
  for(i in 1:1000){
    if(no_alert[i]!=1){
      alert_tf <- res_list[[i]]$time[which(!is.na(res_list[[i]]$dose))]
      offset_err_vec[i]<-max(alert_tf)-max(true_alert_tf)
    } else{
      offset_err_vec[i] <- NA
    }
  }

  rmse_overlap <- numeric(1000)
  for(i in 1:1000){
    if(no_alert[i]!=1){
      alert_tf <- res_list[[i]]$time[which(!is.na(res_list[[i]]$dose))]

      alert <- res_list[[i]]
      truth_ol <- true_alert_relationship[true_alert_relationship$time %in% intersect(true_alert_tf,alert_tf), ]
      alert_ol   <- alert[alert$time %in% intersect(true_alert_tf,alert_tf), ]

      rmse_overlap[i] <- sqrt(mean((alert_ol$dose-truth_ol$dose)^2))
    } else{
      rmse_overlap[i] <- NA
    }
  }

  
  res_list_red <- Filter(
    function(x) is.data.frame(x),
    res_list
  )
    
  errors_case <- purrr::imap_dfr(
    res_list_red,
    ~ compute_errors_one_sim(.x) %>%
      mutate(sim = .y)
  )
  
  
  case_info <- data.frame(
    scenario = scenario_info,
    design = design_info,
    sd = sd_info,
    sigma_assumed = sigma_assumed_info,
    algo = algo_info
  )
  
  errors_case <- errors_case %>%
    mutate(
      scenario = case_info$scenario,
      design = case_info$design,
      sd=case_info$sd,
      sigma_assumed = case_info$sigma_assumed,
      algo = case_info$algo
    )
  
 df_errors  <- errors_case %>%
    group_by(design, sigma_assumed, sd, algo, time) %>%
    summarise(
      med_error = median(error),
      q10 = quantile(error, 0.1),
      q90 = quantile(error, 0.9),
      .groups = "drop"
    )
  
  
  return(list("info"=c(scenario_info,design_info,sd_info,sigma_assumed_info,algo_info),
              "all_alert_relatioships"=res_list,
              "errors"=df_errors,
              "recall"=recall_vec,
              "precision"=precision_vec,
              "onset_err"=onset_err_vec,
              "offset_err"=offset_err_vec,
              "rmse_overlap"=rmse_overlap,
              "H0_rejected"=1000-sum(no_alert)
              )
  )
}

if(file.exists("./simulation/020_scenario1_analysis_3d_intermediate.RData")){
  load("./simulation/020_scenario1_analysis_3d_intermediate.RData")
}else{

#'==============================================================================
## Full data set ====
#'==============================================================================

#'------------------------------------------------------------------------------
### Assume constant value for sd   ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
#### Assume constant value for sd - Full  ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
##### Case: Simple  ----
#'------------------------------------------------------------------------------

Res_alert_3d_Scenario1_fulldata_assumeconstant_constant <- analysis_3dim(Res_Scenario1_fulldata_assumeconstant_constant,
                                                                         scenario_info = "Scenario 1",
                                                                         design_info = "Full",
                                                                         sd_info="Simple",
                                                                         sigma_assumed_info="Constant",
                                                                         algo_info="Normal")

#'------------------------------------------------------------------------------
##### Case: Small  ----
#'------------------------------------------------------------------------------

Res_alert_3d_Scenario1_fulldata_assumeconstant_small <- analysis_3dim(Res_Scenario1_fulldata_assumeconstant_small,
                                                                      scenario_info = "Scenario 1",
                                                                      design_info = "Full",
                                                                      sd_info="Small",
                                                                      sigma_assumed_info="Constant",
                                                                      algo_info="Normal")

#'------------------------------------------------------------------------------
##### Case: Medium  ----
#'------------------------------------------------------------------------------

Res_alert_3d_Scenario1_fulldata_assumeconstant_medium <- analysis_3dim(Res_Scenario1_fulldata_assumeconstant_medium,
                                                                       scenario_info = "Scenario 1",
                                                                       design_info = "Full",
                                                                       sd_info="Medium",
                                                                       sigma_assumed_info="Constant",
                                                                       algo_info="Normal")


#'------------------------------------------------------------------------------
##### Case: Large  ----
#'------------------------------------------------------------------------------

Res_alert_3d_Scenario1_fulldata_assumeconstant_large <- analysis_3dim(Res_Scenario1_fulldata_assumeconstant_large,
                                                                      scenario_info = "Scenario 1",
                                                                      design_info = "Full",
                                                                      sd_info="Large",
                                                                      sigma_assumed_info="Constant",
                                                                      algo_info="Normal")


#'------------------------------------------------------------------------------
#### Assume constant value for sd - fast  ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
##### Case: Simple  ----
#'------------------------------------------------------------------------------

Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_constant <- analysis_3dim(Res_Scenario1_fulldata_assumeconstant_fast_constant,
                                                                              scenario_info = "Scenario 1",
                                                                              design_info = "Full",
                                                                              sd_info="Simple",
                                                                              sigma_assumed_info="Constant",
                                                                              algo_info="Fast")


#'------------------------------------------------------------------------------
##### Case: Small  ----
#'------------------------------------------------------------------------------

Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_small <- analysis_3dim(Res_Scenario1_fulldata_assumeconstant_fast_small,
                                                                           scenario_info = "Scenario 1",
                                                                           design_info = "Full",
                                                                           sd_info="Small",
                                                                           sigma_assumed_info="Constant",
                                                                           algo_info="Fast")


#'------------------------------------------------------------------------------
##### Case: Medium  ----
#'------------------------------------------------------------------------------

Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_medium <- analysis_3dim(Res_Scenario1_fulldata_assumeconstant_fast_medium,
                                                                            scenario_info = "Scenario 1",
                                                                            design_info = "Full",
                                                                            sd_info="Medium",
                                                                            sigma_assumed_info="Constant",
                                                                            algo_info="Fast")


#'------------------------------------------------------------------------------
##### Case: Large  ----
#'------------------------------------------------------------------------------

Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_large <- analysis_3dim(Res_Scenario1_fulldata_assumeconstant_fast_large,
                                                                           scenario_info = "Scenario 1",
                                                                           design_info = "Full",
                                                                           sd_info="Large",
                                                                           sigma_assumed_info="Constant",
                                                                           algo_info="Fast")



#'------------------------------------------------------------------------------
### Assume complex value for sd   ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
#### Assume complex value for sd - Full  ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
##### Case: Simple  ----
#'------------------------------------------------------------------------------

Res_alert_3d_Scenario1_fulldata_assumecomplex_constant <- analysis_3dim(Res_Scenario1_fulldata_assumecomplex_constant,
                                                                        scenario_info = "Scenario 1",
                                                                        design_info = "Full",
                                                                        sd_info="Simple",
                                                                        sigma_assumed_info="Complex",
                                                                        algo_info="Normal")



#'------------------------------------------------------------------------------
##### Case: Small  ----
#'------------------------------------------------------------------------------

Res_alert_3d_Scenario1_fulldata_assumecomplex_small <- analysis_3dim(Res_Scenario1_fulldata_assumecomplex_small,
                                                                     scenario_info = "Scenario 1",
                                                                     design_info = "Full",
                                                                     sd_info="Small",
                                                                     sigma_assumed_info="Complex",
                                                                     algo_info="Normal")

#'------------------------------------------------------------------------------
##### Case: Medium  ----
#'------------------------------------------------------------------------------

Res_alert_3d_Scenario1_fulldata_assumecomplex_medium <- analysis_3dim(Res_Scenario1_fulldata_assumecomplex_medium,
                                                                      scenario_info = "Scenario 1",
                                                                      design_info = "Full",
                                                                      sd_info="Medium",
                                                                      sigma_assumed_info="Complex",
                                                                      algo_info="Normal")


#'------------------------------------------------------------------------------
##### Case: Large  ----
#'------------------------------------------------------------------------------

Res_alert_3d_Scenario1_fulldata_assumecomplex_large <- analysis_3dim(Res_Scenario1_fulldata_assumecomplex_large,
                                                                     scenario_info = "Scenario 1",
                                                                     design_info = "Full",
                                                                     sd_info="Large",
                                                                     sigma_assumed_info="Complex",
                                                                     algo_info="Normal")




#'------------------------------------------------------------------------------
#### Assume complex value for sd - fast  ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
##### Case: Simple  ----
#'------------------------------------------------------------------------------

Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_constant <- analysis_3dim(Res_Scenario1_fulldata_assumecomplex_fast_constant,
                                                                             scenario_info = "Scenario 1",
                                                                             design_info = "Full",
                                                                             sd_info="Simple",
                                                                             sigma_assumed_info="Complex",
                                                                             algo_info="Fast")



#'------------------------------------------------------------------------------
##### Case: Small  ----
#'------------------------------------------------------------------------------

Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_small <- analysis_3dim(Res_Scenario1_fulldata_assumecomplex_fast_small,
                                                                          scenario_info = "Scenario 1",
                                                                          design_info = "Full",
                                                                          sd_info="Small",
                                                                          sigma_assumed_info="Complex",
                                                                          algo_info="Fast")


#'------------------------------------------------------------------------------
##### Case: Medium  ----
#'------------------------------------------------------------------------------

Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_medium <- analysis_3dim(Res_Scenario1_fulldata_assumecomplex_fast_medium,
                                                                           scenario_info = "Scenario 1",
                                                                           design_info = "Full",
                                                                           sd_info="Medium",
                                                                           sigma_assumed_info="Complex",
                                                                           algo_info="Fast")


#'------------------------------------------------------------------------------
##### Case: Large  ----
#'------------------------------------------------------------------------------

Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_large <- analysis_3dim(Res_Scenario1_fulldata_assumecomplex_fast_large,
                                                                          scenario_info = "Scenario 1",
                                                                          design_info = "Full",
                                                                          sd_info="Large",
                                                                          sigma_assumed_info="Complex",
                                                                          algo_info="Fast")




#'==============================================================================
## Reduced data set ====
#'==============================================================================


#'------------------------------------------------------------------------------
### Assume constant value for sd   ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
#### Assume constant value for sd - Full  ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
##### Case: Simple  ----
#'------------------------------------------------------------------------------

Res_alert_3d_Scenario1_reduceddata_assumeconstant_constant <- analysis_3dim(Res_Scenario1_reduceddata_assumeconstant_constant,
                                                                            scenario_info = "Scenario 1",
                                                                            design_info = "Reduced",
                                                                            sd_info="Simple",
                                                                            sigma_assumed_info="Constant",
                                                                            algo_info="Normal")

#'------------------------------------------------------------------------------
##### Case: Small  ----
#'------------------------------------------------------------------------------

Res_alert_3d_Scenario1_reduceddata_assumeconstant_small <- analysis_3dim(Res_Scenario1_reduceddata_assumeconstant_small,
                                                                         scenario_info = "Scenario 1",
                                                                         design_info = "Reduced",
                                                                         sd_info="Small",
                                                                         sigma_assumed_info="Constant",
                                                                         algo_info="Normal")

#'------------------------------------------------------------------------------
##### Case: Medium  ----
#'------------------------------------------------------------------------------

Res_alert_3d_Scenario1_reduceddata_assumeconstant_medium <- analysis_3dim(Res_Scenario1_reduceddata_assumeconstant_medium,
                                                                          scenario_info = "Scenario 1",
                                                                          design_info = "Reduced",
                                                                          sd_info="Medium",
                                                                          sigma_assumed_info="Constant",
                                                                          algo_info="Normal")


#'------------------------------------------------------------------------------
##### Case: Large  ----
#'------------------------------------------------------------------------------

Res_alert_3d_Scenario1_reduceddata_assumeconstant_large <- analysis_3dim(Res_Scenario1_reduceddata_assumeconstant_large,
                                                                         scenario_info = "Scenario 1",
                                                                         design_info = "Reduced",
                                                                         sd_info="Large",
                                                                         sigma_assumed_info="Constant",
                                                                         algo_info="Normal")


#'------------------------------------------------------------------------------
#### Assume constant value for sd - fast  ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
##### Case: Simple  ----
#'------------------------------------------------------------------------------

Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_constant <- analysis_3dim(Res_Scenario1_reduceddata_assumeconstant_fast_constant,
                                                                                 scenario_info = "Scenario 1",
                                                                                 design_info = "Reduced",
                                                                                 sd_info="Simple",
                                                                                 sigma_assumed_info="Constant",
                                                                                 algo_info="Fast")


#'------------------------------------------------------------------------------
##### Case: Small  ----
#'------------------------------------------------------------------------------

Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_small <- analysis_3dim(Res_Scenario1_reduceddata_assumeconstant_fast_small,
                                                                              scenario_info = "Scenario 1",
                                                                              design_info = "Reduced",
                                                                              sd_info="Small",
                                                                              sigma_assumed_info="Constant",
                                                                              algo_info="Fast")


#'------------------------------------------------------------------------------
##### Case: Medium  ----
#'------------------------------------------------------------------------------

Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_medium <- analysis_3dim(Res_Scenario1_reduceddata_assumeconstant_fast_medium,
                                                                               scenario_info = "Scenario 1",
                                                                               design_info = "Reduced",
                                                                               sd_info="Medium",
                                                                               sigma_assumed_info="Constant",
                                                                               algo_info="Fast")


#'------------------------------------------------------------------------------
##### Case: Large  ----
#'------------------------------------------------------------------------------

Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_large <- analysis_3dim(Res_Scenario1_reduceddata_assumeconstant_fast_large,
                                                                              scenario_info = "Scenario 1",
                                                                              design_info = "Reduced",
                                                                              sd_info="Large",
                                                                              sigma_assumed_info="Constant",
                                                                              algo_info="Fast")



#'------------------------------------------------------------------------------
### Assume complex value for sd   ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
#### Assume complex value for sd - Full  ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
##### Case: Simple  ----
#'------------------------------------------------------------------------------

Res_alert_3d_Scenario1_reduceddata_assumecomplex_constant <- analysis_3dim(Res_Scenario1_reduceddata_assumecomplex_constant,
                                                                           scenario_info = "Scenario 1",
                                                                           design_info = "Reduced",
                                                                           sd_info="Simple",
                                                                           sigma_assumed_info="Complex",
                                                                           algo_info="Normal")



#'------------------------------------------------------------------------------
##### Case: Small  ----
#'------------------------------------------------------------------------------

Res_alert_3d_Scenario1_reduceddata_assumecomplex_small <- analysis_3dim(Res_Scenario1_reduceddata_assumecomplex_small,
                                                                        scenario_info = "Scenario 1",
                                                                        design_info = "Reduced",
                                                                        sd_info="Small",
                                                                        sigma_assumed_info="Complex",
                                                                        algo_info="Normal")

#'------------------------------------------------------------------------------
##### Case: Medium  ----
#'------------------------------------------------------------------------------

Res_alert_3d_Scenario1_reduceddata_assumecomplex_medium <- analysis_3dim(Res_Scenario1_reduceddata_assumecomplex_medium,
                                                                         scenario_info = "Scenario 1",
                                                                         design_info = "Reduced",
                                                                         sd_info="Medium",
                                                                         sigma_assumed_info="Complex",
                                                                         algo_info="Normal")


#'------------------------------------------------------------------------------
##### Case: Large  ----
#'------------------------------------------------------------------------------

Res_alert_3d_Scenario1_reduceddata_assumecomplex_large <- analysis_3dim(Res_Scenario1_reduceddata_assumecomplex_large,
                                                                        scenario_info = "Scenario 1",
                                                                        design_info = "Reduced",
                                                                        sd_info="Large",
                                                                        sigma_assumed_info="Complex",
                                                                        algo_info="Normal")




#'------------------------------------------------------------------------------
#### Assume complex value for sd - fast  ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
##### Case: Simple  ----
#'------------------------------------------------------------------------------

Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_constant <- analysis_3dim(Res_Scenario1_reduceddata_assumecomplex_fast_constant,
                                                                                scenario_info = "Scenario 1",
                                                                                design_info = "Reduced",
                                                                                sd_info="Simple",
                                                                                sigma_assumed_info="Complex",
                                                                                algo_info="Fast")



#'------------------------------------------------------------------------------
##### Case: Small  ----
#'------------------------------------------------------------------------------

Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_small <- analysis_3dim(Res_Scenario1_reduceddata_assumecomplex_fast_small,
                                                                             scenario_info = "Scenario 1",
                                                                             design_info = "Reduced",
                                                                             sd_info="Small",
                                                                             sigma_assumed_info="Complex",
                                                                             algo_info="Fast")


#'------------------------------------------------------------------------------
##### Case: Medium  ----
#'------------------------------------------------------------------------------

Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_medium <- analysis_3dim(Res_Scenario1_reduceddata_assumecomplex_fast_medium,
                                                                              scenario_info = "Scenario 1",
                                                                              design_info = "Reduced",
                                                                              sd_info="Medium",
                                                                              sigma_assumed_info="Complex",
                                                                              algo_info="Fast")


#'------------------------------------------------------------------------------
##### Case: Large  ----
#'------------------------------------------------------------------------------

Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_large <- analysis_3dim(Res_Scenario1_reduceddata_assumecomplex_fast_large,
                                                                             scenario_info = "Scenario 1",
                                                                             design_info = "Reduced",
                                                                             sd_info="Large",
                                                                             sigma_assumed_info="Complex",
                                                                             algo_info="Fast")


#'------------------------------------------------------------------------------
#### Save intermediate  ----
#'------------------------------------------------------------------------------

save( Res_alert_3d_Scenario1_fulldata_assumeconstant_constant,
      Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_constant,
      Res_alert_3d_Scenario1_fulldata_assumeconstant_small,
      Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_small,
      Res_alert_3d_Scenario1_fulldata_assumeconstant_medium,
      Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_medium,
      Res_alert_3d_Scenario1_fulldata_assumeconstant_large,
      Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_large,
      Res_alert_3d_Scenario1_reduceddata_assumeconstant_constant,
      Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_constant,
      Res_alert_3d_Scenario1_reduceddata_assumeconstant_small,
      Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_small,
      Res_alert_3d_Scenario1_reduceddata_assumeconstant_medium,
      Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_medium,
      Res_alert_3d_Scenario1_reduceddata_assumeconstant_large,
      Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_large,
      Res_alert_3d_Scenario1_fulldata_assumecomplex_constant,
      Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_constant,
      Res_alert_3d_Scenario1_fulldata_assumecomplex_small,
      Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_small,
      Res_alert_3d_Scenario1_fulldata_assumecomplex_medium,
      Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_medium,
      Res_alert_3d_Scenario1_fulldata_assumecomplex_large,
      Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_large,
      Res_alert_3d_Scenario1_reduceddata_assumecomplex_constant,
      Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_constant,
      Res_alert_3d_Scenario1_reduceddata_assumecomplex_small,
      Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_small,
      Res_alert_3d_Scenario1_reduceddata_assumecomplex_medium,
      Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_medium,
      Res_alert_3d_Scenario1_reduceddata_assumecomplex_large,
      Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_large,
      file="./simulation/020_scenario1_analysis_3d_intermediate.RData")
}

#'==============================================================================
## Generate Table with resutls ====
#'==============================================================================

table_results_scenario1_3d <- data.frame(
  "_"=c("Algorithm","Assumption","Scenario 1 - Full - Simple","Scenario 1 - Full -Small","Scenario 1 - Full - Medium","Scenario 1 - Full - Large",
        "Scenario 1 - Reduced - Simple","Scenario 1 - Reduced -Small","Scenario 1 - Reduced - Medium","Scenario 1 - Reduced - Large"),
  "H0_rejected_precent_const"=c("Normal","Constant",c(Res_alert_3d_Scenario1_fulldata_assumeconstant_constant$H0_rejected,
                                            Res_alert_3d_Scenario1_fulldata_assumeconstant_small$H0_rejected,
                                            Res_alert_3d_Scenario1_fulldata_assumeconstant_medium$H0_rejected,
                                            Res_alert_3d_Scenario1_fulldata_assumeconstant_large$H0_rejected,
                                            Res_alert_3d_Scenario1_reduceddata_assumeconstant_constant$H0_rejected,
                                            Res_alert_3d_Scenario1_reduceddata_assumeconstant_small$H0_rejected,
                                            Res_alert_3d_Scenario1_reduceddata_assumeconstant_medium$H0_rejected,
                                            Res_alert_3d_Scenario1_reduceddata_assumeconstant_large$H0_rejected)/10),
  "H0_rejected_percent_const_fast"=c("Fast","Constant",c(Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_constant$H0_rejected,
                        Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_small$H0_rejected,
                        Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_medium$H0_rejected,
                        Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_large$H0_rejected,
                        Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_constant$H0_rejected,
                        Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_small$H0_rejected,
                        Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_medium$H0_rejected,
                        Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_large$H0_rejected)/10),
  "H0_rejected_percent_complex"=c("Normal","Complex",c(Res_alert_3d_Scenario1_fulldata_assumecomplex_constant$H0_rejected,
                        Res_alert_3d_Scenario1_fulldata_assumecomplex_small$H0_rejected,
                        Res_alert_3d_Scenario1_fulldata_assumecomplex_medium$H0_rejected,
                        Res_alert_3d_Scenario1_fulldata_assumecomplex_large$H0_rejected,
                        Res_alert_3d_Scenario1_reduceddata_assumecomplex_constant$H0_rejected,
                        Res_alert_3d_Scenario1_reduceddata_assumecomplex_small$H0_rejected,
                        Res_alert_3d_Scenario1_reduceddata_assumecomplex_medium$H0_rejected,
                        Res_alert_3d_Scenario1_reduceddata_assumecomplex_large$H0_rejected)/10),
  "H0_rejected_percent_complex_fast"=c("Fast","Complex",c(Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_constant$H0_rejected,
                             Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_small$H0_rejected,
                             Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_medium$H0_rejected,
                             Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_large$H0_rejected,
                             Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_constant$H0_rejected,
                             Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_small$H0_rejected,
                             Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_medium$H0_rejected,
                             Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_large$H0_rejected)/10),
  "Mean_recall_percent_const"=c("Normal","Constant",round(c(mean(Res_alert_3d_Scenario1_fulldata_assumeconstant_constant$recall,na.rm=T),
                                              mean(Res_alert_3d_Scenario1_fulldata_assumeconstant_small$recall,na.rm=T),
                                              mean(Res_alert_3d_Scenario1_fulldata_assumeconstant_medium$recall,na.rm=T),
                                              mean(Res_alert_3d_Scenario1_fulldata_assumeconstant_large$recall,na.rm=T),
                                              mean(Res_alert_3d_Scenario1_reduceddata_assumeconstant_constant$recall,na.rm=T),
                                              mean(Res_alert_3d_Scenario1_reduceddata_assumeconstant_small$recall,na.rm=T),
                                              mean(Res_alert_3d_Scenario1_reduceddata_assumeconstant_medium$recall,na.rm=T),
                                              mean(Res_alert_3d_Scenario1_reduceddata_assumeconstant_large$recall,na.rm=T)
                                              ),3)*100),
  "Mean_recall_percent_const_fast"=c("Fast","Constant",round(c(mean(Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_constant$recall,na.rm=T),
                                                    mean(Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_small$recall,na.rm=T),
                                                    mean(Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_medium$recall,na.rm=T),
                                                    mean(Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_large$recall,na.rm=T),
                                                    mean(Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_constant$recall,na.rm=T),
                                                    mean(Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_small$recall,na.rm=T),
                                                    mean(Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_medium$recall,na.rm=T),
                                                    mean(Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_large$recall,na.rm=T)
  ),3)*100),
  "Mean_recall_percent_complex"=c("Normal","Complex",round(c(mean(Res_alert_3d_Scenario1_fulldata_assumecomplex_constant$recall,na.rm=T),
                                                    mean(Res_alert_3d_Scenario1_fulldata_assumecomplex_small$recall,na.rm=T),
                                                    mean(Res_alert_3d_Scenario1_fulldata_assumecomplex_medium$recall,na.rm=T),
                                                    mean(Res_alert_3d_Scenario1_fulldata_assumecomplex_large$recall,na.rm=T),
                                                    mean(Res_alert_3d_Scenario1_reduceddata_assumecomplex_constant$recall,na.rm=T),
                                                    mean(Res_alert_3d_Scenario1_reduceddata_assumecomplex_small$recall,na.rm=T),
                                                    mean(Res_alert_3d_Scenario1_reduceddata_assumecomplex_medium$recall,na.rm=T),
                                                    mean(Res_alert_3d_Scenario1_reduceddata_assumecomplex_large$recall,na.rm=T)
  ),3)*100),
  "Mean_recall_percent_complex_fast"=c("Fast","Complex",round(c(mean(Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_constant$recall,na.rm=T),
                                                       mean(Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_small$recall,na.rm=T),
                                                       mean(Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_medium$recall,na.rm=T),
                                                       mean(Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_large$recall,na.rm=T),
                                                       mean(Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_constant$recall,na.rm=T),
                                                       mean(Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_small$recall,na.rm=T),
                                                       mean(Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_medium$recall,na.rm=T),
                                                       mean(Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_large$recall,na.rm=T)
  ),3)*100),
  "SD_recall_percent_const"=c("Normal","Constant",round(c(sd(Res_alert_3d_Scenario1_fulldata_assumeconstant_constant$recall,na.rm=T),
                                              sd(Res_alert_3d_Scenario1_fulldata_assumeconstant_small$recall,na.rm=T),
                                              sd(Res_alert_3d_Scenario1_fulldata_assumeconstant_medium$recall,na.rm=T),
                                              sd(Res_alert_3d_Scenario1_fulldata_assumeconstant_large$recall,na.rm=T),
                                              sd(Res_alert_3d_Scenario1_reduceddata_assumeconstant_constant$recall,na.rm=T),
                                              sd(Res_alert_3d_Scenario1_reduceddata_assumeconstant_small$recall,na.rm=T),
                                              sd(Res_alert_3d_Scenario1_reduceddata_assumeconstant_medium$recall,na.rm=T),
                                              sd(Res_alert_3d_Scenario1_reduceddata_assumeconstant_large$recall,na.rm=T)
  ),3)*100),
  "SD_recall_percent_const_fast"=c("Fast","Constant",round(c(sd(Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_constant$recall,na.rm=T),
                                                  sd(Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_small$recall,na.rm=T),
                                                  sd(Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_medium$recall,na.rm=T),
                                                  sd(Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_large$recall,na.rm=T),
                                                  sd(Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_constant$recall,na.rm=T),
                                                  sd(Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_small$recall,na.rm=T),
                                                  sd(Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_medium$recall,na.rm=T),
                                                  sd(Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_large$recall,na.rm=T)
  ),3)*100),
  "SD_recall_percent_complex"=c("Normal","Complex",round(c(sd(Res_alert_3d_Scenario1_fulldata_assumecomplex_constant$recall,na.rm=T),
                                                  sd(Res_alert_3d_Scenario1_fulldata_assumecomplex_small$recall,na.rm=T),
                                                  sd(Res_alert_3d_Scenario1_fulldata_assumecomplex_medium$recall,na.rm=T),
                                                  sd(Res_alert_3d_Scenario1_fulldata_assumecomplex_large$recall,na.rm=T),
                                                  sd(Res_alert_3d_Scenario1_reduceddata_assumecomplex_constant$recall,na.rm=T),
                                                  sd(Res_alert_3d_Scenario1_reduceddata_assumecomplex_small$recall,na.rm=T),
                                                  sd(Res_alert_3d_Scenario1_reduceddata_assumecomplex_medium$recall,na.rm=T),
                                                  sd(Res_alert_3d_Scenario1_reduceddata_assumecomplex_large$recall,na.rm=T)
  ),3)*100),
  "SD_recall_percent_complex_fast"=c("Fast","Complex",round(c(sd(Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_constant$recall,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_small$recall,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_medium$recall,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_large$recall,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_constant$recall,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_small$recall,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_medium$recall,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_large$recall,na.rm=T)
  ),3)*100),
  "Mean_precision_percent_const"=c("Normal","Constant",round(c(mean(Res_alert_3d_Scenario1_fulldata_assumeconstant_constant$precision,na.rm=T),
                                                  mean(Res_alert_3d_Scenario1_fulldata_assumeconstant_small$precision,na.rm=T),
                                                  mean(Res_alert_3d_Scenario1_fulldata_assumeconstant_medium$precision,na.rm=T),
                                                  mean(Res_alert_3d_Scenario1_fulldata_assumeconstant_large$precision,na.rm=T),
                                                  mean(Res_alert_3d_Scenario1_reduceddata_assumeconstant_constant$precision,na.rm=T),
                                                  mean(Res_alert_3d_Scenario1_reduceddata_assumeconstant_small$precision,na.rm=T),
                                                  mean(Res_alert_3d_Scenario1_reduceddata_assumeconstant_medium$precision,na.rm=T),
                                                  mean(Res_alert_3d_Scenario1_reduceddata_assumeconstant_large$precision,na.rm=T)
  ),3)*100),
  "Mean_precision_percent_const_fast"=c("Fast","Constant",round(c(mean(Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_constant$precision,na.rm=T),
                                                 mean(Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_small$precision,na.rm=T),
                                                 mean(Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_medium$precision,na.rm=T),
                                                 mean(Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_large$precision,na.rm=T),
                                                 mean(Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_constant$precision,na.rm=T),
                                                 mean(Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_small$precision,na.rm=T),
                                                 mean(Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_medium$precision,na.rm=T),
                                                 mean(Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_large$precision,na.rm=T)
  ),3)*100),
  "Mean_precision_percent_complex"=c("Normal","Complex",round(c(mean(Res_alert_3d_Scenario1_fulldata_assumecomplex_constant$precision,na.rm=T),
                                                 mean(Res_alert_3d_Scenario1_fulldata_assumecomplex_small$precision,na.rm=T),
                                                 mean(Res_alert_3d_Scenario1_fulldata_assumecomplex_medium$precision,na.rm=T),
                                                 mean(Res_alert_3d_Scenario1_fulldata_assumecomplex_large$precision,na.rm=T),
                                                 mean(Res_alert_3d_Scenario1_reduceddata_assumecomplex_constant$precision,na.rm=T),
                                                 mean(Res_alert_3d_Scenario1_reduceddata_assumecomplex_small$precision,na.rm=T),
                                                 mean(Res_alert_3d_Scenario1_reduceddata_assumecomplex_medium$precision,na.rm=T),
                                                 mean(Res_alert_3d_Scenario1_reduceddata_assumecomplex_large$precision,na.rm=T)
  ),3)*100),
  "Mean_precision_percent_complex_fast"=c("Fast","Complex",round(c(mean(Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_constant$precision,na.rm=T),
                                                    mean(Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_small$precision,na.rm=T),
                                                    mean(Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_medium$precision,na.rm=T),
                                                    mean(Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_large$precision,na.rm=T),
                                                    mean(Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_constant$precision,na.rm=T),
                                                    mean(Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_small$precision,na.rm=T),
                                                    mean(Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_medium$precision,na.rm=T),
                                                    mean(Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_large$precision,na.rm=T)
  ),3)*100),
  "SD_precision_percent_const"=c("Normal","Constant",round(c(sd(Res_alert_3d_Scenario1_fulldata_assumeconstant_constant$precision,na.rm=T),
                                                 sd(Res_alert_3d_Scenario1_fulldata_assumeconstant_small$precision,na.rm=T),
                                                 sd(Res_alert_3d_Scenario1_fulldata_assumeconstant_medium$precision,na.rm=T),
                                                 sd(Res_alert_3d_Scenario1_fulldata_assumeconstant_large$precision,na.rm=T),
                                                 sd(Res_alert_3d_Scenario1_reduceddata_assumeconstant_constant$precision,na.rm=T),
                                                 sd(Res_alert_3d_Scenario1_reduceddata_assumeconstant_small$precision,na.rm=T),
                                                 sd(Res_alert_3d_Scenario1_reduceddata_assumeconstant_medium$precision,na.rm=T),
                                                 sd(Res_alert_3d_Scenario1_reduceddata_assumeconstant_large$precision,na.rm=T)
  ),3)*100),
  "SD_precision_percent_const_fast"=c("Fast","Constant",round(c(sd(Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_constant$precision,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_small$precision,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_medium$precision,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_large$precision,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_constant$precision,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_small$precision,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_medium$precision,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_large$precision,na.rm=T)
  ),3)*100),
  "SD_precision_percent_complex"=c("Normal","Complex",round(c(sd(Res_alert_3d_Scenario1_fulldata_assumecomplex_constant$precision,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_fulldata_assumecomplex_small$precision,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_fulldata_assumecomplex_medium$precision,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_fulldata_assumecomplex_large$precision,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_reduceddata_assumecomplex_constant$precision,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_reduceddata_assumecomplex_small$precision,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_reduceddata_assumecomplex_medium$precision,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_reduceddata_assumecomplex_large$precision,na.rm=T)
  ),3)*100),
  "SD_precision_percent_complex_fast"=c("Fast","Complex",round(c(sd(Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_constant$precision,na.rm=T),
                                                          sd(Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_small$precision,na.rm=T),
                                                          sd(Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_medium$precision,na.rm=T),
                                                          sd(Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_large$precision,na.rm=T),
                                                          sd(Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_constant$precision,na.rm=T),
                                                          sd(Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_small$precision,na.rm=T),
                                                          sd(Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_medium$precision,na.rm=T),
                                                          sd(Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_large$precision,na.rm=T)
  ),3)*100),
 "Mean_onset_err_const" =c("Normal","Constant",round(c(mean(Res_alert_3d_Scenario1_fulldata_assumeconstant_constant$onset_err,na.rm=T),
                                 mean(Res_alert_3d_Scenario1_fulldata_assumeconstant_small$onset_err,na.rm=T),
                                 mean(Res_alert_3d_Scenario1_fulldata_assumeconstant_medium$onset_err,na.rm=T),
                                 mean(Res_alert_3d_Scenario1_fulldata_assumeconstant_large$onset_err,na.rm=T),
                                 mean(Res_alert_3d_Scenario1_reduceddata_assumeconstant_constant$onset_err,na.rm=T),
                                 mean(Res_alert_3d_Scenario1_reduceddata_assumeconstant_small$onset_err,na.rm=T),
                                 mean(Res_alert_3d_Scenario1_reduceddata_assumeconstant_medium$onset_err,na.rm=T),
                                 mean(Res_alert_3d_Scenario1_reduceddata_assumeconstant_large$onset_err,na.rm=T)
  ),3)),
 "Mean_onset_err_const_fast" =c("Fast","Constant",round(c(mean(Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_constant$onset_err,na.rm=T),
                                                 mean(Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_small$onset_err,na.rm=T),
                                                 mean(Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_medium$onset_err,na.rm=T),
                                                 mean(Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_large$onset_err,na.rm=T),
                                                 mean(Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_constant$onset_err,na.rm=T),
                                                 mean(Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_small$onset_err,na.rm=T),
                                                 mean(Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_medium$onset_err,na.rm=T),
                                                 mean(Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_large$onset_err,na.rm=T)
 ),3)),
 "Mean_onset_err_complex" =c("Normal","Complex",round(c(mean(Res_alert_3d_Scenario1_fulldata_assumecomplex_constant$onset_err,na.rm=T),
                                                 mean(Res_alert_3d_Scenario1_fulldata_assumecomplex_small$onset_err,na.rm=T),
                                                 mean(Res_alert_3d_Scenario1_fulldata_assumecomplex_medium$onset_err,na.rm=T),
                                                 mean(Res_alert_3d_Scenario1_fulldata_assumecomplex_large$onset_err,na.rm=T),
                                                 mean(Res_alert_3d_Scenario1_reduceddata_assumecomplex_constant$onset_err,na.rm=T),
                                                 mean(Res_alert_3d_Scenario1_reduceddata_assumecomplex_small$onset_err,na.rm=T),
                                                 mean(Res_alert_3d_Scenario1_reduceddata_assumecomplex_medium$onset_err,na.rm=T),
                                                 mean(Res_alert_3d_Scenario1_reduceddata_assumecomplex_large$onset_err,na.rm=T)
 ),3)),
 "Mean_onset_err_complex_fast" =c("Fast","Complex",round(c(mean(Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_constant$onset_err,na.rm=T),
                                                    mean(Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_small$onset_err,na.rm=T),
                                                    mean(Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_medium$onset_err,na.rm=T),
                                                    mean(Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_large$onset_err,na.rm=T),
                                                    mean(Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_constant$onset_err,na.rm=T),
                                                    mean(Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_small$onset_err,na.rm=T),
                                                    mean(Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_medium$onset_err,na.rm=T),
                                                    mean(Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_large$onset_err,na.rm=T)
 ),3)),
 "SD_onset_err_const" =c("Normal","Constant",round(c(sd(Res_alert_3d_Scenario1_fulldata_assumeconstant_constant$onset_err,na.rm=T),
                                                 sd(Res_alert_3d_Scenario1_fulldata_assumeconstant_small$onset_err,na.rm=T),
                                                 sd(Res_alert_3d_Scenario1_fulldata_assumeconstant_medium$onset_err,na.rm=T),
                                                 sd(Res_alert_3d_Scenario1_fulldata_assumeconstant_large$onset_err,na.rm=T),
                                                 sd(Res_alert_3d_Scenario1_reduceddata_assumeconstant_constant$onset_err,na.rm=T),
                                                 sd(Res_alert_3d_Scenario1_reduceddata_assumeconstant_small$onset_err,na.rm=T),
                                                 sd(Res_alert_3d_Scenario1_reduceddata_assumeconstant_medium$onset_err,na.rm=T),
                                                 sd(Res_alert_3d_Scenario1_reduceddata_assumeconstant_large$onset_err,na.rm=T)
 ),3)),
 "SD_onset_err_const_fast" =c("Fast","Constant",round(c(sd(Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_constant$onset_err,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_small$onset_err,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_medium$onset_err,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_large$onset_err,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_constant$onset_err,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_small$onset_err,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_medium$onset_err,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_large$onset_err,na.rm=T)
 ),3)),
 "SD_onset_err_complex" =c("Normal","Complex",round(c(sd(Res_alert_3d_Scenario1_fulldata_assumecomplex_constant$onset_err,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_fulldata_assumecomplex_small$onset_err,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_fulldata_assumecomplex_medium$onset_err,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_fulldata_assumecomplex_large$onset_err,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_reduceddata_assumecomplex_constant$onset_err,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_reduceddata_assumecomplex_small$onset_err,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_reduceddata_assumecomplex_medium$onset_err,na.rm=T),
                                                     sd(Res_alert_3d_Scenario1_reduceddata_assumecomplex_large$onset_err,na.rm=T)
 ),3)),
 "SD_onset_err_complex_fast" =c("Fast","Complex",round(c(sd(Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_constant$onset_err,na.rm=T),
                                                        sd(Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_small$onset_err,na.rm=T),
                                                        sd(Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_medium$onset_err,na.rm=T),
                                                        sd(Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_large$onset_err,na.rm=T),
                                                        sd(Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_constant$onset_err,na.rm=T),
                                                        sd(Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_small$onset_err,na.rm=T),
                                                        sd(Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_medium$onset_err,na.rm=T),
                                                        sd(Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_large$onset_err,na.rm=T)
 ),3)),
 "Mean_offset_err_const"=c("Normal","Constant",round(c(mean(Res_alert_3d_Scenario1_fulldata_assumeconstant_constant$offset_err,na.rm=T),
                                mean(Res_alert_3d_Scenario1_fulldata_assumeconstant_small$offset_err,na.rm=T),
                                mean(Res_alert_3d_Scenario1_fulldata_assumeconstant_medium$offset_err,na.rm=T),
                                mean(Res_alert_3d_Scenario1_fulldata_assumeconstant_large$offset_err,na.rm=T),
                                mean(Res_alert_3d_Scenario1_reduceddata_assumeconstant_constant$offset_err,na.rm=T),
                                mean(Res_alert_3d_Scenario1_reduceddata_assumeconstant_small$offset_err,na.rm=T),
                                mean(Res_alert_3d_Scenario1_reduceddata_assumeconstant_medium$offset_err,na.rm=T),
                                mean(Res_alert_3d_Scenario1_reduceddata_assumeconstant_large$offset_err,na.rm=T)
 ),3)),
 "Mean_offset_err_const_fast"=c("Fast","Constant",round(c(mean(Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_constant$offset_err,na.rm=T),
                                                       mean(Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_small$offset_err,na.rm=T),
                                                       mean(Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_medium$offset_err,na.rm=T),
                                                       mean(Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_large$offset_err,na.rm=T),
                                                       mean(Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_constant$offset_err,na.rm=T),
                                                       mean(Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_small$offset_err,na.rm=T),
                                                       mean(Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_medium$offset_err,na.rm=T),
                                                       mean(Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_large$offset_err,na.rm=T)
 ),3)),
 "Mean_offset_err_complex"=c("Normal","Complex",round(c(mean(Res_alert_3d_Scenario1_fulldata_assumecomplex_constant$offset_err,na.rm=T),
                                                       mean(Res_alert_3d_Scenario1_fulldata_assumecomplex_small$offset_err,na.rm=T),
                                                       mean(Res_alert_3d_Scenario1_fulldata_assumecomplex_medium$offset_err,na.rm=T),
                                                       mean(Res_alert_3d_Scenario1_fulldata_assumecomplex_large$offset_err,na.rm=T),
                                                       mean(Res_alert_3d_Scenario1_reduceddata_assumecomplex_constant$offset_err,na.rm=T),
                                                       mean(Res_alert_3d_Scenario1_reduceddata_assumecomplex_small$offset_err,na.rm=T),
                                                       mean(Res_alert_3d_Scenario1_reduceddata_assumecomplex_medium$offset_err,na.rm=T),
                                                       mean(Res_alert_3d_Scenario1_reduceddata_assumecomplex_large$offset_err,na.rm=T)
 ),3)),
 "Mean_offset_err_complex_fast"=c("Fast","Complex",round(c(mean(Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_constant$offset_err,na.rm=T),
                                                          mean(Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_small$offset_err,na.rm=T),
                                                          mean(Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_medium$offset_err,na.rm=T),
                                                          mean(Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_large$offset_err,na.rm=T),
                                                          mean(Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_constant$offset_err,na.rm=T),
                                                          mean(Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_small$offset_err,na.rm=T),
                                                          mean(Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_medium$offset_err,na.rm=T),
                                                          mean(Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_large$offset_err,na.rm=T)
 ),3)),
 "SD_offset_err_const"=c("Normal","Constant",round(c(sd(Res_alert_3d_Scenario1_fulldata_assumeconstant_constant$offset_err,na.rm=T),
                                                 sd(Res_alert_3d_Scenario1_fulldata_assumeconstant_small$offset_err,na.rm=T),
                                                 sd(Res_alert_3d_Scenario1_fulldata_assumeconstant_medium$offset_err,na.rm=T),
                                                 sd(Res_alert_3d_Scenario1_fulldata_assumeconstant_large$offset_err,na.rm=T),
                                                 sd(Res_alert_3d_Scenario1_reduceddata_assumeconstant_constant$offset_err,na.rm=T),
                                                 sd(Res_alert_3d_Scenario1_reduceddata_assumeconstant_small$offset_err,na.rm=T),
                                                 sd(Res_alert_3d_Scenario1_reduceddata_assumeconstant_medium$offset_err,na.rm=T),
                                                 sd(Res_alert_3d_Scenario1_reduceddata_assumeconstant_large$offset_err,na.rm=T)
 ),3)),
 "SD_offset_err_const_fast"=c("Fast","Constant",round(c(sd(Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_constant$offset_err,na.rm=T),
                                               sd(Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_small$offset_err,na.rm=T),
                                               sd(Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_medium$offset_err,na.rm=T),
                                               sd(Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_large$offset_err,na.rm=T),
                                               sd(Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_constant$offset_err,na.rm=T),
                                               sd(Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_small$offset_err,na.rm=T),
                                               sd(Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_medium$offset_err,na.rm=T),
                                               sd(Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_large$offset_err,na.rm=T)
 ),3)),
 "SD_offset_err_complex"=c("Normal","Complex",round(c(sd(Res_alert_3d_Scenario1_fulldata_assumecomplex_constant$offset_err,na.rm=T),
                                               sd(Res_alert_3d_Scenario1_fulldata_assumecomplex_small$offset_err,na.rm=T),
                                               sd(Res_alert_3d_Scenario1_fulldata_assumecomplex_medium$offset_err,na.rm=T),
                                               sd(Res_alert_3d_Scenario1_fulldata_assumecomplex_large$offset_err,na.rm=T),
                                               sd(Res_alert_3d_Scenario1_reduceddata_assumecomplex_constant$offset_err,na.rm=T),
                                               sd(Res_alert_3d_Scenario1_reduceddata_assumecomplex_small$offset_err,na.rm=T),
                                               sd(Res_alert_3d_Scenario1_reduceddata_assumecomplex_medium$offset_err,na.rm=T),
                                               sd(Res_alert_3d_Scenario1_reduceddata_assumecomplex_large$offset_err,na.rm=T)
 ),3)),
 "SD_offset_err_complex_fast"=c("Fast","Complex",round(c(sd(Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_constant$offset_err,na.rm=T),
                                                  sd(Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_small$offset_err,na.rm=T),
                                                  sd(Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_medium$offset_err,na.rm=T),
                                                  sd(Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_large$offset_err,na.rm=T),
                                                  sd(Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_constant$offset_err,na.rm=T),
                                                  sd(Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_small$offset_err,na.rm=T),
                                                  sd(Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_medium$offset_err,na.rm=T),
                                                  sd(Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_large$offset_err,na.rm=T)
 ),3))
)


#Check
#View(as.data.frame(t(table_results_scenario1_3d)))


# write.xlsx(
#   as.data.frame(t(table_results_scenario1_3d)),
#   file = "./plots_tables/206_simulation_scenario1_results_3d_all.xlsx",
#   colNames = F,rowNames=T
# )

#Note, that the combinations constant - normal/fast are identical assumption wise
#They were run to compare the technical performance of both in general
#Since the performance is very similar, only the results of the fast algorithm
#are included in the paper, since there is an overall focus on the fast algorithm


#full data set
write.xlsx(
  as.data.frame(t(table_results_scenario1_3d))[-c(2,6,10,14,18,22,26,30,34),1:6],
  file = "./plots_tables/207_simulation_scenario1_results_3d_full.xlsx",
  colNames = F,rowNames=T
)

#reduced data set
write.xlsx(
  as.data.frame(t(table_results_scenario1_3d))[-c(2,6,10,14,18,22,26,30,34),c(1:2,7:10)],
  file = "./plots_tables/208_simulation_scenario1_results_3d_reduced.xlsx",
  colNames = F,rowNames=T
)

