#'##############################################################################
#                                                                              #
#                  Corresponding R Code to the Manuscript                      #
#                "Estimating effect thresholds and beyond:                     #
#              A flexible framework for multivariate alert detection"          #
#                                                                              #
#                                 Authors                                      #
#                    L. Ameis, N. Hagemann and K. Moellenhoff                  #
#                                                                              #
#                         Simulation - Scenario 1: Run simulation              #
#                                                                              #
#'##############################################################################
#'Of note, due to the computation time, the simulations were run on a server
#'Here, we show code that allows to run the simulations but also load
#'the results

#'==============================================================================
# Preparation ====
#'==============================================================================

#'==============================================================================
## Load functions without td2pLL ====
#'==============================================================================
#' Our server had problems installing the td2pLL package. Therefore we circumvented
#' the use for the simulation study
#' Therefore, we load the functions prepared accordingly
#' For details see base_TDR.R and base_cytotox_TDR.R

#load("./simulation/base_cytotox_TDR_without_td2pLL.RData")

#'==============================================================================
## Store analysis specific information ====
#'==============================================================================
#Bootstrap runs
B_out<-500
B_in<-25

#Number of simulation runs
N<-1000

#'==============================================================================
## Basics grid ====
#'==============================================================================


#Grid
# Define design region
min_time <- 0
max_time <- 10
min_dose <- 0
max_dose <- 12

#fineness of the grid
epsilon <- 0.1

time_seq <- seq(min_time, max_time, by=epsilon)   #time
dose_seq <- seq(min_dose, max_dose, by=epsilon)   #dose

grid_full      <- data.frame("time"=rep(time_seq, times=length(dose_seq)))
grid_dose <- numeric(length=length(time_seq)*length(dose_seq))
for(i in 1:length(dose_seq)){
  grid_dose[((i-1)*length(time_seq)+1):(i*length(time_seq))] <- rep(dose_seq[i],  times=length(time_seq))
}
grid_full$dose <- grid_dose



#'==============================================================================
## Basics mu ====
#'==============================================================================
#Define model and starting parameters for mean
#Define parameter from scenario 2 in Schürmeyer et al
params_simul <- c(0, 80, 3, 120, 10, 0.02)

model <- emax_emax

fit_fast <- emax_emax_fast

mu_formula <- emax_emax_formula

mu_start <-  c(E0=0, Emax_A= 100, ED_A=5,
               Emax_B= 250, ED_B=7,
               gamma=0.01)

#'==============================================================================
## Basics sigma starting values====
#'==============================================================================

sigma_formula <- ~ 1

sigma_start <- 3.4


#'==============================================================================
# Run Simulations - Design 3x3  ====
#'==============================================================================


#'------------------------------------------------------------------------------
### N=152 ----
#'------------------------------------------------------------------------------


if(file.exists("./simulation/server_results/Res_Scenario2_des9_152.RData")){
  load("./simulation/server_results/Res_Scenario2_des9_152.RData")
} else{
  #store results
  Res_Scenario2_des9_152 <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario2_des9$N152$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust_fast(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario2_des9$N152$seeds[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=Scenario2_designtemplates$des9$N152$time,
                                        dose=Scenario2_designtemplates$des9$N152$dose,
                                        donor=Scenario2_designtemplates$des9$N152$donor,
                                        fast = T)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=Scenario2_designtemplates$des9$N152$time,
                                          dose=Scenario2_designtemplates$des9$N152$dose,
                                          donor=Scenario2_designtemplates$des9$N152$donor,
                                          seeds=seeds_simul,
                                          fixtime = 7,
                                          fast_in = T,
                                          upper_or_lower="lower")
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=7)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=7,
                                    upper_or_lower="lower")
      
      res_simul <- list("initial_fit"=fit_simul,
#                        "boot"=outerbootstrap_simul,
#                        "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario2_des9_152[[i]] <- res_simul
  }
  save(Res_Scenario2_des9_152,file="./simulation/server_results/Res_Scenario2_des9_152.RData")
}



#'------------------------------------------------------------------------------
### N=90 ----
#'------------------------------------------------------------------------------


if(file.exists("./simulation/server_results/Res_Scenario2_des9_90.RData")){
  load("./simulation/server_results/Res_Scenario2_des9_90.RData")
} else{
  #store results
  Res_Scenario2_des9_90 <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario2_des9$N90$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust_fast(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario2_des9$N90$seeds[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=Scenario2_designtemplates$des9$N90$time,
                                        dose=Scenario2_designtemplates$des9$N90$dose,
                                        donor=Scenario2_designtemplates$des9$N90$donor,
                                        fast = T)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=Scenario2_designtemplates$des9$N90$time,
                                          dose=Scenario2_designtemplates$des9$N90$dose,
                                          donor=Scenario2_designtemplates$des9$N90$donor,
                                          seeds=seeds_simul,
                                          fixtime = 7,
                                          fast_in = T,
                                          upper_or_lower="lower")
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=7)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=7,
                                    upper_or_lower="lower")
      
      res_simul <- list("initial_fit"=fit_simul,
 #                       "boot"=outerbootstrap_simul,
#                        "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario2_des9_90[[i]] <- res_simul
  }
  save(Res_Scenario2_des9_90,file="./simulation/server_results/Res_Scenario2_des9_90.RData")
}



#'------------------------------------------------------------------------------
### N=45 ----
#'------------------------------------------------------------------------------


if(file.exists("./simulation/server_results/Res_Scenario2_des9_45.RData")){
  load("./simulation/server_results/Res_Scenario2_des9_45.RData")
} else{
  #store results
  Res_Scenario2_des9_45 <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario2_des9$N45$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust_fast(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario2_des9$N45$seeds[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=Scenario2_designtemplates$des9$N45$time,
                                        dose=Scenario2_designtemplates$des9$N45$dose,
                                        donor=Scenario2_designtemplates$des9$N45$donor,
                                        fast = T)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=Scenario2_designtemplates$des9$N45$time,
                                          dose=Scenario2_designtemplates$des9$N45$dose,
                                          donor=Scenario2_designtemplates$des9$N45$donor,
                                          seeds=seeds_simul,
                                          fixtime = 7,
                                          fast_in = T,
                                          upper_or_lower="lower")
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=7)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=7,
                                    upper_or_lower="lower")
      
      res_simul <- list("initial_fit"=fit_simul,
 #                       "boot"=outerbootstrap_simul,
#                        "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario2_des9_45[[i]] <- res_simul
  }
  save(Res_Scenario2_des9_45,file="./simulation/server_results/Res_Scenario2_des9_45.RData")
}



#'==============================================================================
# Run Simulations - D-opt  ====
#'==============================================================================


#'------------------------------------------------------------------------------
### N=152 ----
#'------------------------------------------------------------------------------


if(file.exists("./simulation/server_results/Res_Scenario2_dopt_152.RData")){
  load("./simulation/server_results/Res_Scenario2_dopt_152.RData")
} else{
  #store results
  Res_Scenario2_dopt_152 <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario2_dopt$N152$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust_fast(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario2_dopt$N152$seeds[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=Scenario2_designtemplates$dopt$N152$time,
                                        dose=Scenario2_designtemplates$dopt$N152$dose,
                                        donor=Scenario2_designtemplates$dopt$N152$donor,
                                        fast = T)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=Scenario2_designtemplates$dopt$N152$time,
                                          dose=Scenario2_designtemplates$dopt$N152$dose,
                                          donor=Scenario2_designtemplates$dopt$N152$donor,
                                          seeds=seeds_simul,
                                          fixtime = 7,
                                          fast_in = T,
                                          upper_or_lower="lower")
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=7)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=7,
                                    upper_or_lower="lower")
      
      res_simul <- list("initial_fit"=fit_simul,
 #                       "boot"=outerbootstrap_simul,
#                        "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario2_dopt_152[[i]] <- res_simul
  }
  save(Res_Scenario2_dopt_152,file="./simulation/server_results/Res_Scenario2_dopt_152.RData")
}



#'------------------------------------------------------------------------------
### N=90 ----
#'------------------------------------------------------------------------------


if(file.exists("./simulation/server_results/Res_Scenario2_dopt_90.RData")){
  load("./simulation/server_results/Res_Scenario2_dopt_90.RData")
} else{
  #store results
  Res_Scenario2_dopt_90 <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario2_dopt$N90$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust_fast(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario2_dopt$N90$seeds[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=Scenario2_designtemplates$dopt$N90$time,
                                        dose=Scenario2_designtemplates$dopt$N90$dose,
                                        donor=Scenario2_designtemplates$dopt$N90$donor,
                                        fast = T)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=Scenario2_designtemplates$dopt$N90$time,
                                          dose=Scenario2_designtemplates$dopt$N90$dose,
                                          donor=Scenario2_designtemplates$dopt$N90$donor,
                                          seeds=seeds_simul,
                                          fixtime = 7,
                                          fast_in = T,
                                          upper_or_lower="lower")
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=7)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=7,
                                    upper_or_lower="lower")
      
      res_simul <- list("initial_fit"=fit_simul,
 #                       "boot"=outerbootstrap_simul,
#                        "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario2_dopt_90[[i]] <- res_simul
  }
  save(Res_Scenario2_dopt_90,file="./simulation/server_results/Res_Scenario2_dopt_90.RData")
}



#'------------------------------------------------------------------------------
### N=45 ----
#'------------------------------------------------------------------------------


if(file.exists("./simulation/server_results/Res_Scenario2_dopt_45.RData")){
  load("./simulation/server_results/Res_Scenario2_dopt_45.RData")
} else{
  #store results
  Res_Scenario2_dopt_45 <- list()
  
  for(i in 1:N){
    #load simulated data set
    dat_simul <- Scenario2_dopt$N45$data[[i]]
    #run initial fit to simulated data
    fit_simul <- modelfit_robust_fast(dat_simul)
    
    if(anyNA(fit_simul$coef)==T){
      res_simul <- NA
    } else{
      #set seed
      set.seed(Scenario2_dopt$N45$seeds[[i]])  
      seeds_simul <- runif(B_out, min = 0, max=1000000)
      outerbootstrap_simul <- bootstrap(sd=fit_simul$sd,
                                        par=fit_simul$coef,
                                        B=B_out,
                                        time=Scenario2_designtemplates$dopt$N45$time,
                                        dose=Scenario2_designtemplates$dopt$N45$dose,
                                        donor=Scenario2_designtemplates$dopt$N45$donor,
                                        fast = T)
      crit.val_boot_simul <- critval_boot(outerboot=outerbootstrap_simul,
                                          B_in=B_in,
                                          B_out=B_out,
                                          sd=fit_simul$sd,
                                          par=fit_simul$coef,
                                          time=Scenario2_designtemplates$dopt$N45$time,
                                          dose=Scenario2_designtemplates$dopt$N45$dose,
                                          donor=Scenario2_designtemplates$dopt$N45$donor,
                                          seeds=seeds_simul,
                                          fixtime = 7,
                                          fast_in = T,
                                          upper_or_lower="lower")
      crit.val_simul <- crit.val(crit.val.boot=crit.val_boot_simul$res,
                                 alpha=0.05,
                                 fixtime=7)
      conf.band_simul <- conf.bands(par=fit_simul$coef, 
                                    c=crit.val_simul, 
                                    outerboot = outerbootstrap_simul,
                                    fixtime=7,
                                    upper_or_lower="lower")
      
      res_simul <- list("initial_fit"=fit_simul,
 #                       "boot"=outerbootstrap_simul,
#                        "crit_boot"=crit.val_boot_simul,
                        "crit_val"=crit.val_simul,
                        "conf"=conf.band_simul)
    }
    Res_Scenario2_dopt_45[[i]] <- res_simul
  }
  save(Res_Scenario2_dopt_45,file="./simulation/server_results/Res_Scenario2_dopt_45.RData")
}

