#'##############################################################################
#                                                                              #
#                  Corresponding R Code to the Manuscript                      #
#                "Estimating effect thresholds and beyond:                     #
#              A flexible framework for multivariate alert detection"          #
#                                                                              #
#                                 Authors                                      #
#                    L. Ameis, N. Hagemann and K. Moellenhoff                  #
#                                                                              #
#                              Plot generation                                 #
#                                                                              #
#'##############################################################################

use_python(python="please set to save location of python istallation",required = T) #Python313 was used
import("kaleido") #version 0.1.0.post1
import("plotly")  #version 5.3.1

#'==============================================================================
# Clean 3dimensional plots ====
#'==============================================================================

#Of note, this function utilizes tmp files, that are stored in the folder plots_tables/tmp_plots
#They are automatically deleted if clean_tmp_file==T

save_and_clean_3d_plots <- function(p,p_file_name,save_file=T){
  path_tmp <- paste0("./plots_tables/tmp_plots/",p_file_name,".pdf")
  save_image(p,path_tmp)
  img1 <- image_read_pdf(path_tmp)
  img_trim1 <- image_trim(img1)
  if(save_file==T){
    path <- paste0("./plots_tables/",p_file_name,".pdf")
    image_write(img_trim1, path, format = "pdf")
  }
  if(clean_tmp_file==T){
    file.remove(path_tmp)
  }
  
  return(wrap_elements(full=rasterGrob(as.raster(img_trim1))))
}

#'==============================================================================
# Explanatory plots ====
#'==============================================================================

#'------------------------------------------------------------------------------
## Grid - Explainatory plots ----
#'------------------------------------------------------------------------------

#time
min_time <- 1
max_time <- 7

#dose
min_dose <- 0
max_dose <- 10

#fineness of the grid
epsilon <- 0.1



#create the grid
time_seq <- seq(min_time, max_time, by=epsilon)   #time
dose_seq <- seq(min_dose, max_dose, by=epsilon)   #dose

grid_full      <- data.frame("time"=rep(time_seq, times=length(dose_seq)))
grid_dose <- numeric(length=length(time_seq)*length(dose_seq))
for(i in 1:length(dose_seq)){
  grid_dose[((i-1)*length(time_seq)+1):(i*length(time_seq))] <- rep(dose_seq[i],  times=length(time_seq))
}
grid_full$dose <- grid_dose




#'------------------------------------------------------------------------------
## Data fit and fixed time ----
#'------------------------------------------------------------------------------
#'

#Data basis (td2pLL, full data set, case 2)

mu_formula <- td2pLL_formula


#Prepare data set
data_subset_sd <- data_subset          %>%      #combine data via sd
  group_by(time,dose,donor)            %>%
  summarize(resp_sd=sd(resp))


#CASE 1:
sigma_formula_case1 <- ~ 1
#identify starting values for constant case
error_model <- glm(                             #estimate error model with glm 
  resp_sd ~ 1,
  family = gaussian(link = "log"),              #Log-Link 
  data = data_subset_sd
)
summary(error_model)                            #start parameters for sd 

sigma_start_case1 <- coef(error_model)

mu_start <- list(h = 3, Delta = 6, gamma = 2, C0 = 5)

#Fit gamlss
td2pLL_fit_gamlss_nl_donor_case1<-nlgamlss( y= resp,
                                            mu.fo = mu_formula, 
                                            sigma.fo = sigma_formula_case1,
                                            mu.start = mu_start,                         
                                            sigma.start = sigma_start_case1,                                                 # Startwerte für sigma
                                            family = NO(),                                                                  # Normalverteilung
                                            data = data_subset
)



resp_gamlss_nl_donor<- abs(td2pLL(t=grid_full$time, 
                                  d=grid_full$dose, 
                                  theta=coef(td2pLL_fit_gamlss_nl_donor_case1))-td2pLL(t=rep(4,times=nrow(grid_full)), 
                                                                                 d=rep(0,times=nrow(grid_full)), 
                                                                                 theta=coef(td2pLL_fit_gamlss_nl_donor_case1)))          %>%
  cbind(grid_full, "response"=.)                   %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="response")

conf_band_mat_gamlssnl_donor <- centered_td2pLL_analysis_gamlssnl_donor_CASE1$conf$full   %>%
  cbind(grid_full, "cf"=. )           %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

alert_gamlssnl_donor <- matrix(NA,nrow=length(time_seq),ncol=2)
for(i in length(time_seq):1){
  alert_gamlssnl_donor[i,1] <- i
  alert_gamlssnl_donor[i,2] <- min(subset(which(conf_band_mat_gamlssnl_donor>50,arr.ind=T)[,2],
                                          which(conf_band_mat_gamlssnl_donor>50,T)[,1]==i))
}

which(rownames(conf_band_mat_gamlssnl_donor)==4)
#31


fig_exp <- plot_ly(showlegend=F)                %>%
  layout(scene = list(  camera = list(
    eye = list(x = 0.2, y = 2.5, z = 1)  #Camera eye
  ),
  xaxis = list(title = list( text = 'Dose',
                                                 font = list(size = 18)),
                                   tickfont = list(size = 13),
                                   showticklabels=F),  #Basic layout
                      yaxis = list(title = list( text = 'Time',
                                                 font = list(size = 18)),
                                   tickfont = list(size = 13),
                                   showticklabels=F),
                      zaxis = list(title = list( text ='Response',
                                                 font = list(size = 18)),
                                   tickfont = list(size = 13),
                                   showticklabels=F)),
         legend = list(itemsizing = "constant",
                       font = list(size = 15),
                       x = 100,
                       y= 0.5)
  )                                                                %>%
  add_surface(x=colnames(resp_gamlss_nl_donor),
              y=rownames(resp_gamlss_nl_donor),
              z=resp_gamlss_nl_donor,
              colorscale=list(c(0,1),
                              c("black","grey")),
              colorbar="",
              showscale=F,
              opacity=0.5)                                  %>%
  add_surface(x=colnames(conf_band_mat_gamlssnl_donor),
              y=rownames(conf_band_mat_gamlssnl_donor),
              z=conf_band_mat_gamlssnl_donor,
              colorscale=list(c(0,1),
                              c("darkblue","lightblue")),
              colorbar="",
              showscale=F,
              opacity=0.75
  )                                            %>%
  add_surface(x=colnames(Threshold),
              y=rownames(Threshold),
              z=Threshold,
              colorscale=list(c(0,1),
                              c("firebrick","red")),
              colorbar="",
              showscale=F
  )                                             %>%
  add_trace(x = dose_seq, 
            y = rep(4,times=length(dose_seq)), 
            z = abs(td2pLL(t=rep(4,times=length(dose_seq)),
                           d=dose_seq,
                           theta=coef(td2pLL_fit_gamlss_nl_donor_case1))-rep(100,times=length(dose_seq))),
            line=list(color = 'black', width = 2),
            type="scatter3d",mode="lines",
            showlegend=F)                              %>%
  add_trace(x = dose_seq, 
            y = rep(4,times=length(dose_seq)), 
            z = conf_band_mat_gamlssnl_donor[31,],
            line=list(color = 'blue', width = 2,dash="dash"),
            type="scatter3d",mode="lines",
            showlegend=F)                              %>%
  add_trace(x = dose_seq[alert_gamlssnl_donor[,2]], 
            y = time_seq[alert_gamlssnl_donor[,1]], 
            z = rep(0,times=length(time_seq)),
            line=list(color = 'red', width = 1),
            type="scatter3d",mode="lines",
            showlegend=F)       %>%
  add_text(x=2,y=6,z=50,text="\U1D6CC",textfont=list(size = 17, color="darkred"),
           showlegend=F) %>%
  add_text(x=5,y=4,z=55,text="Fit",textfont=list(size = 17, color="black"),
           showlegend=F)    %>%
  add_text(x=10,y=5,z=13,text="Confidence Plane",textfont=list(size = 17, color="darkblue"),
           showlegend=F)                                                         %>%
  add_text(x=5,y=7,z=-0,text="Alert",textfont=list(size = 17,color="red"),
           showlegend=F)  %>%
  style(name = "", traces = 1) %>%
  style(name = "", traces = 2) %>%
  style(name = "", traces = 3) %>%
  style(name = "", traces = 4) %>%
  style(name = "", traces = 5) %>%
  style(name = "", traces = 6) 

fig_exp

#htmlwidgets::saveWidget(as_widget(fig_gamlssnl_donor_chp), "./plots_tables/td2pLL_gamlssnl_donor_chp.html")

fig_exp_cleaned <- save_and_clean_3d_plots(p=fig_exp,p_file_name = "001_fig_exp",save=F)


#'------------------------------------------------------------------------------
## 2dim confidence band 2d vs 3d comparison ----
#'------------------------------------------------------------------------------


#2dvs3d comparison
min(which(centered_td2pLL_analysis_gamlssnl_donor_CASE1$conf$fix>50))
#63

min(which(conf_band_mat_gamlssnl_donor[31,]>50))
#67

gg_exp_cb <- ggplot(data.frame(x=dose_seq,
                               y1=abs(td2pLL(t=rep(4,times=length(dose_seq)),
                                             d=dose_seq,
                                             theta=coef(td2pLL_fit_gamlss_nl_donor_case1))-rep(100,times=length(dose_seq))),
                               y2=conf_band_mat_gamlssnl_donor[31,],
                               y3=centered_td2pLL_analysis_gamlssnl_donor_CASE1$conf$fix),
                    aes(x=x))                                                        +
  geom_line(aes(x=x,y=y1,col="black"))                                              +
  geom_line(aes(x=x,y=y2,col="blue",linetype="dashed"))                                   +
  geom_line(aes(x=x,y=y3,col="blue",linetype="solid"))                                   +
  scale_color_manual(values=c("black","blue"),labels=c("Model fit","CB")) +
  scale_linetype_manual(values=c("dashed","solid"),labels=c("3D","2D")) +
  xlab("Dose")                                                 +
  ylab("Response")                                                      +
  geom_hline(yintercept=50,col="orangered2")                            +
  geom_vline(xintercept=dose_seq[67],col="orangered2",linetype="dotted") +
  geom_vline(xintercept=dose_seq[63],col="orangered2",linetype="dotdash") +
  theme(axis.title=element_text(size=8),
        legend.text=element_text(size=7),
        legend.title=element_blank(),
        axis.text.x=element_blank(),
        axis.text.y=element_blank(),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white")) +
  annotate("text",x=2,y=53,label=expression(lambda),col="orangered2")

gg_exp_cb
#ggsave("./plots_tables/002_gg_exp.pdf",width=5,height=5,unit="cm")



#'------------------------------------------------------------------------------
## Alert ----
#'------------------------------------------------------------------------------

gg_exp_alert <- ggplot(data=data.frame(y1 = dose_seq[alert_gamlssnl_donor[,2]], 
                                       x1 = time_seq[alert_gamlssnl_donor[,1]]), aes(x=x1,y=y1)) +
  annotate(geom="point",y=6.6,x=4,size=2,col="orangered2") +
  geom_line(aes(col="orangered2"))+
  xlab("Time") +
  ylab("Dose") +
  ylim(10,0) +
  xlim(7,1) +
  scale_color_manual(values="orangered2",labels="Alert")+
  theme(axis.title=element_text(size=8),
        legend.text=element_text(size=7),
        legend.title=element_blank(),
        axis.text.x=element_blank(),
        axis.text.y=element_blank(),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white")) +
  coord_flip()
gg_exp_alert
#ggsave("./plots_tables/003_alert_exp.pdf",width=5,height=5,unit="cm")


#'------------------------------------------------------------------------------
#### Combine explainatory plots ----
#'------------------------------------------------------------------------------

#2dim plots combined
#gg_exp_cb+gg_exp_alert+plot_layout(guides="collect")
#ggsave("./plots_tables/003_5_2dexp.pdf",width=12,height=6,unit="cm")

design <-
  "AAB
   CCD
  "
gg_exp_cb+guide_area()+fig_exp_cleaned+gg_exp_alert+
plot_layout(design=design,guides="collect") + plot_annotation(tag_levels = 'A') & 
theme(plot.tag = element_text(size = 8))

ggsave("./plots_tables/001_fig_exp_full.pdf",width=12,height=12,unit="cm")


#'==============================================================================
# Case Study ====
#'==============================================================================

#'------------------------------------------------------------------------------
## Grid - Case study ----
#'------------------------------------------------------------------------------

#time
min_time <- 1
max_time <- 7

#dose
min_dose <- 0
max_dose <- 10

#fineness of the grid
epsilon <- 0.1



#create the grid
time_seq <- seq(min_time, max_time, by=epsilon)   #time
dose_seq <- seq(min_dose, max_dose, by=epsilon)   #dose

grid_full      <- data.frame("time"=rep(time_seq, times=length(dose_seq)))
grid_dose <- numeric(length=length(time_seq)*length(dose_seq))
for(i in 1:length(dose_seq)){
  grid_dose[((i-1)*length(time_seq)+1):(i*length(time_seq))] <- rep(dose_seq[i],  times=length(time_seq))
}
grid_full$dose <- grid_dose



#'==============================================================================
## Data analysis - Basic ====
#'==============================================================================

own_color_palett <- vector(length = 30)
for(i in 1:30){
  own_color_palett[i] <- rgb(50+i*5,100+i*5,50+i*5,max=255)
}

#'------------------------------------------------------------------------------
### Figure Data ----
#'------------------------------------------------------------------------------

fig_data <- plot_ly(data_subset,       #only compound of interest
                    x = ~dose, 
                    y = ~time, 
                    z = ~resp, 
                    color = ~donor,    #show different donors by color and symbol  
                    symbol=~donor,
                    colors=c('chartreuse4','#0C4B8E','darkgoldenrod1'),
                    symbols=c("circle","square","diamond"),
                    mode="markers",
                    type = "scatter3d",
                    marker = list(size = 3))                %>%
  style(name = "Donor 1", traces = 1) %>%
  style(name = "Donor 2", traces = 2) %>%
  style(name = "Donor 3", traces = 3) %>%
  layout(scene = list(   camera = list(
    eye = list(x = 4, y = 1.3, z = 0.5)  # Camera eye
  ),
  xaxis = list(title = list( text = 'Dose',
                                                 font = list(size = 24)),
                                   tickfont = list(size = 15)),  #Basic layout
                      yaxis = list(title = list( text = 'Time',
                                                 font = list(size = 24)),
                                   tickfont = list(size = 15)),
                      zaxis = list(title = list( text ='Response',
                                                 font = list(size = 24)),
                                   tickfont = list(size = 15))),
         legend = list(itemsizing = "constant",
                       font = list(size = 15),
                       x = 100,
                       y= 0.5)
  )

fig_data  #generate plot

#htmlwidgets::saveWidget(as_widget(fig_data), "./plots_tables/data_plot.html")




#'==============================================================================
## Analysis plot function ====
#'==============================================================================


#'------------------------------------------------------------------------------
### Simplified Case ----
#'------------------------------------------------------------------------------
#Here we define a function, that generates all plots for one case
#set model beforehands

plot_analysis <- function(dat,fit,res,fixtime=4, model,
                          col_cb=c("darkblue","lightblue"),
                          col_alert="red",
                          lty_alert="solid",
                          col_cb_2dim="blue",
                          col_alert_2dim="orangered2",
                          lty_alert_2dim="solid",
                          title_cb="",
                          title_sd="",
                          title_2dim = "",
                          marker_size_fit_cb=3,
                          marker_size_sd=3,
                          camera_fit=list(x = 4, y = 1.3, z = 0.5),
                          camera_cb=list(x = 0.2, y = 2.5, z = 0.2),
                          size_3dim_fit_cb=c(24,15,17),
                          size_2dim =c(17,19,7,21),
                          size_3dim_sd=c(24,15,17)){
  
  #model choice
  if(model=="td2pLL"){
    model <- td2pLL
  } else{
    if(model=="schuettler"){
      model <- schuettler
    }
    
  }
  
  #Prep basic fit
  resp_gamlss_nl_donor<- model(t=grid_full$time, 
                                d=grid_full$dose, 
                                theta=coef(fit))          %>%
    cbind(grid_full, "response"=.)                        %>%
    reshape2::acast(., 
                    time~dose, 
                    value.var="response")
  
  
  #plot basic fit
  fig_gamlss_nl_donor <- plot_ly()                          %>%
    add_markers(dat,       #only compound of interest
                x = dat$dose, 
                y = dat$time, 
                z = dat$resp, 
                color = dat$donor,    #show donors by color and symbol  
                symbol= dat$donor,
                colors=c('chartreuse4','#0C4B8E','darkgoldenrod1'),
                symbols=c("circle","square","diamond"),
                marker = list(size = marker_size_fit_cb))                                                 %>%
    layout(
           scene = list(      camera = list(
             eye = camera_fit  # Camera eye
           ),
           xaxis = list(title = list( text = 'Dose',
                                                   font = list(size = size_3dim_fit_cb[1])),
                                     tickfont = list(size = size_3dim_fit_cb[2])),  #Basic layout
                        yaxis = list(title = list( text = 'Time',
                                                   font = list(size = size_3dim_fit_cb[1])),
                                     tickfont = list(size = size_3dim_fit_cb[2])),
                        zaxis = list(title = list( text ='Response',
                                                   font = list(size = size_3dim_fit_cb[1])),
                                     tickfont = list(size = size_3dim_fit_cb[2]))),
           legend = list(itemsizing = "constant",
                         font = list(size = size_3dim_fit_cb[2]),
                         x = 100,
                         y= 0.5)
    )                                                                %>%
    add_surface(x=colnames(resp_gamlss_nl_donor),
                y=rownames(resp_gamlss_nl_donor),
                z=resp_gamlss_nl_donor,
                colorscale=list(c(0,1),
                                c("black","grey")),
                colorbar="",
                showscale=F) %>%
    add_trace(x = dose_seq, 
              y = rep(fixtime,times=length(dose_seq)), 
              z = model(t=rep(fixtime,times=length(dose_seq)),
                        d=dose_seq,
                        theta=coef(fit)),
              line=list(color = 'black', width = 2),
              type="scatter3d",mode="lines",
              showlegend=F)   %>%
    add_text(x=5,y=5,z=70,text="Fit",textfont=list(size = size_3dim_fit_cb[3], color="black"),showlegend=F) %>%
    add_text(x=5,y=3.5,z=max(dat$resp),text=title_cb,textfont=list(size = size_3dim_fit_cb[1], color="black"),showlegend=F) 
  
  
  fig_gamlss_nl_donor$x$layout$margin$b <- 1
  fig_gamlss_nl_donor$x$layout$margin$l <- 1
  fig_gamlss_nl_donor$x$layout$margin$t <- 1
  fig_gamlss_nl_donor$x$layout$margin$r <- 1
  
  #Conf plot
  conf_band_mat_gamlssnl_donor <- res$conf$full   %>%
    cbind(grid_full, "cf"=. )           %>%
    reshape2::acast(., 
                    time~dose, 
                    value.var="cf")
  
  alert_gamlssnl_donor <- matrix(NA,nrow=length(time_seq),ncol=2)
  for(i in length(time_seq):1){
    alert_gamlssnl_donor[i,1] <- i
    alert_gamlssnl_donor[i,2] <- min(subset(which(conf_band_mat_gamlssnl_donor<50,arr.ind=T)[,2],
                                            which(conf_band_mat_gamlssnl_donor<50,T)[,1]==i))
  }
  
  #identify grid fixpoint (standard is 4)
  grid_tp <-which(rownames(conf_band_mat_gamlssnl_donor)==fixtime)

  #confidence plane
  fig_gamlssnl_donor_chp_only <- plot_ly(showlegend=F)                %>%
    layout(scene = list(camera = list(
      eye = camera_cb),
      xaxis = list(title = list( text = 'Dose',
                                 font = list(size = size_3dim_fit_cb[1])),
                   tickfont = list(size = size_3dim_fit_cb[2])),  #Basic layout
      yaxis = list(title = list( text = 'Time',
                                 font = list(size = size_3dim_fit_cb[1])),
                   tickfont = list(size = size_3dim_fit_cb[2])),
      zaxis = list(title = list( text ='Response',
                                 font = list(size = size_3dim_fit_cb[1])),
                   tickfont = list(size = size_3dim_fit_cb[2])),
      bgcolor = "rgba(0,0,0,0)"),
      legend = list(itemsizing = "constant",
                    font = list(size = size_3dim_fit_cb[2]),
                    x = 100,
                    y= 0.5),
      margin=list(l=0, r=0, t=0, b=0)
    )                                                                %>%
    add_surface(x=colnames(conf_band_mat_gamlssnl_donor),
                y=rownames(conf_band_mat_gamlssnl_donor),
                z=conf_band_mat_gamlssnl_donor,
                colorscale=list(c(0,1),
                                col_cb),
                colorbar="",
                showscale=F,
                opacity=0.75
    )                                            %>%
    add_surface(x=colnames(Threshold),
                y=rownames(Threshold),
                z=Threshold,
                colorscale=list(c(0,1),
                                c("firebrick","red")),
                colorbar="",
                showscale=F
    )                                             %>%
    add_trace(x = dose_seq, 
              y = rep(fixtime,times=length(dose_seq)), 
              z = conf_band_mat_gamlssnl_donor[grid_tp,],
              line=list(color = col_cb[1], width = 2,dash="dash"),
              type="scatter3d",mode="lines",
              showlegend=F)                              %>%
    add_trace(x = dose_seq[alert_gamlssnl_donor[,2]], 
              y = time_seq[alert_gamlssnl_donor[,1]], 
              z = rep(0,times=length(time_seq)),
              line=list(color = col_alert, width = 1,dash=lty_alert),
              type="scatter3d",mode="lines",
              showlegend=F)       %>%
    add_text(x=2.5,y=6.5,z=43,text="\U1D6CC",textfont=list(size = size_3dim_fit_cb[3], color="darkred"),
             showlegend=F) %>%
    add_text(x=7,y=1,z=90,text="Confidence Plane",textfont=list(size = size_3dim_fit_cb[3], color=col_cb[1]),
             showlegend=F)                                                         %>%
    add_text(x=6,y=5,z=-5,text="Alert",textfont=list(size = size_3dim_fit_cb[3],color=col_alert),
             showlegend=F)  %>%
    add_text(x=5,y=3.5,z=max(dat$resp),text=title_cb,textfont=list(size = size_3dim_fit_cb[1], color="black"),showlegend=F) 

  
  fig_gamlssnl_donor_chp_only$x$layout$margin$b <- 1
  fig_gamlssnl_donor_chp_only$x$layout$margin$l <- 1
  fig_gamlssnl_donor_chp_only$x$layout$margin$t <- 1
  fig_gamlssnl_donor_chp_only$x$layout$margin$r <- 1
  
  #plot fit an confidence plane
  fig_gamlssnl_donor_chp <- plot_ly(showlegend=F)                %>%
    add_markers(dat,       #only compound of interest
                x = dat$dose, 
                y = dat$time, 
                z = dat$resp, 
                color = dat$donor,    #show donors by color and symbol  
                symbol= dat$donor,
                colors=c('chartreuse4','#0C4B8E','darkgoldenrod1'),
                symbols=c("circle","square","diamond"),
                marker = list(size = marker_size_fit_cb))                                          %>% 
    layout(scene = list(camera = list(
      eye = camera_cb),
      xaxis = list(title = list( text = 'Dose',
                                 font = list(size = size_3dim_fit_cb[1])),
                   tickfont = list(size = size_3dim_fit_cb[2])),  #Basic layout
      yaxis = list(title = list( text = 'Time',
                                 font = list(size = size_3dim_fit_cb[1])),
                   tickfont = list(size = size_3dim_fit_cb[2])),
      zaxis = list(title = list( text ='Response',
                                 font = list(size = size_3dim_fit_cb[1])),
                   tickfont = list(size = size_3dim_fit_cb[2])),
      bgcolor = "rgba(0,0,0,0)"),
      legend = list(itemsizing = "constant",
                    font = list(size = size_3dim_fit_cb[2]),
                    x = 100,
                    y= 0.5),
      margin=list(l=0, r=0, t=0, b=0)
    )                                                                %>%
    add_surface(x=colnames(resp_gamlss_nl_donor),
                y=rownames(resp_gamlss_nl_donor),
                z=resp_gamlss_nl_donor,
                colorscale=list(c(0,1),
                                c("black","grey")),
                colorbar="",
                showscale=F,
                opacity=0.75)                                  %>%
    add_surface(x=colnames(conf_band_mat_gamlssnl_donor),
                y=rownames(conf_band_mat_gamlssnl_donor),
                z=conf_band_mat_gamlssnl_donor,
                colorscale=list(c(0,1),
                                col_cb),
                colorbar="",
                showscale=F,
                opacity=0.75
    )                                            %>%
    add_surface(x=colnames(Threshold),
                y=rownames(Threshold),
                z=Threshold,
                colorscale=list(c(0,1),
                                c("firebrick","red")),
                colorbar="",
                showscale=F
    )                                             %>%
    add_trace(x = dose_seq, 
              y = rep(fixtime,times=length(dose_seq)), 
              z = model(t=rep(fixtime,times=length(dose_seq)),
                        d=dose_seq,
                        theta=coef(fit)),
              line=list(color = 'black', width = 2),
              type="scatter3d",mode="lines",
              showlegend=F)                              %>%
    add_trace(x = dose_seq, 
              y = rep(fixtime,times=length(dose_seq)), 
              z = conf_band_mat_gamlssnl_donor[grid_tp,],
              line=list(color = col_cb[1], width = 2,dash="dash"),
              type="scatter3d",mode="lines",
              showlegend=F)                              %>%
    add_trace(x = dose_seq[alert_gamlssnl_donor[,2]], 
              y = time_seq[alert_gamlssnl_donor[,1]], 
              z = rep(0,times=length(time_seq)),
              line=list(color = col_alert, width = 1,dash=lty_alert),
              type="scatter3d",mode="lines",
              showlegend=F)       %>%
    add_text(x=2.5,y=6.5,z=43,text="\U1D6CC",textfont=list(size = size_3dim_fit_cb[3], color="darkred"),
             showlegend=F) %>%
    add_text(x=0.5,y=4.5,z=60,text="Fit",textfont=list(size = size_3dim_fit_cb[3], color="black"),
             showlegend=F)    %>%
    add_text(x=7,y=1,z=90,text="Confidence Plane",textfont=list(size = size_3dim_fit_cb[3], color=col_cb[1]),
             showlegend=F)                                                         %>%
    add_text(x=6,y=5,z=-5,text="Alert",textfont=list(size = size_3dim_fit_cb[3],color=col_alert),
             showlegend=F)  %>%
    add_text(x=5,y=3.5,z=max(dat$resp),text=title_cb,textfont=list(size = size_3dim_fit_cb[1], color="black"),showlegend=F) 
  
  fig_gamlssnl_donor_chp$x$layout$margin$b <- 1
  fig_gamlssnl_donor_chp$x$layout$margin$l <- 1
  fig_gamlssnl_donor_chp$x$layout$margin$t <- 1
  fig_gamlssnl_donor_chp$x$layout$margin$r <- 1
  
  
  #plot 3dim alert
  gg_alert <- ggplot(data=data.frame(x1 = dose_seq[alert_gamlssnl_donor[,2]], 
                         y1 = time_seq[alert_gamlssnl_donor[,1]]), aes(x=y1,y=x1)) +
    geom_line(aes(x=y1,y=x1,col=col_alert_2dim,linetype=lty_alert_2dim))+
    scale_color_manual(values=c(col_alert_2dim),labels=c("alert")) +
    scale_linetype_manual(values=c(lty_alert_2dim),labels=c("")) +
    guides(linetype = "none") +
    xlab("Time") +
    ylab("Dose") +
    ggtitle(title_2dim) +
    ylim(10,0) +
    xlim(7,1) +
    theme(axis.title=element_text(size=size_2dim[1]),
          legend.text=element_text(size=size_2dim[2]),
          plot.title = element_text(size=size_2dim[4]),
          legend.title=element_blank(),
          panel.background = element_rect(fill = "gray96",
                                          colour = "gray96",
                                          size = 0.5, linetype = "solid"),
          panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                          colour = "white"), 
          panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                          colour = "white")) +
    coord_flip()
  
  
  #identify 2dim result
  dim2alert <- min(which(res$conf$fixtime<50))
  
  #identify 3dim results for fixtime
  dim3alert <- min(which(conf_band_mat_gamlssnl_donor[grid_tp,]<50))

  
  #plot 2dim results
  gg_2dim_res <- ggplot(data.frame(x=dose_seq,
                                   y1=model(t=rep(fixtime,times=length(dose_seq)),
                                             d=dose_seq,
                                             theta=coef(fit)),
                                   y2=conf_band_mat_gamlssnl_donor[grid_tp,],
                                   y3=res$conf$fixtime),
                        aes(x=x))                                                        +
    geom_line(aes(x=x,y=y1,col="black",linetype="solid"))                                              +
    geom_line(aes(x=x,y=y2,col=col_cb_2dim,linetype="dashed"))                                   +
    geom_line(aes(x=x,y=y3,col=col_cb_2dim,linetype="solid"))    +
    scale_color_manual(values=c("black",col_cb_2dim),labels=c("Model fit","CB")) +
    scale_linetype_manual(values=c("dashed","solid"),labels=c("3D","2D")) +
    xlab("Dose")                                                 +
    ylab("Response")                                                      +
    ggtitle(title_2dim) +
    geom_hline(yintercept=50,col="orangered2")  +
    annotate("text",x=1,y=55,label=expression(lambda),size=size_2dim[3],col="orangered2")+
    geom_vline(xintercept=dose_seq[dim3alert],col=col_alert_2dim,linetype="dotted") +
    geom_vline(xintercept=dose_seq[dim2alert],col=col_alert_2dim,linetype="dotdash") +
    theme(axis.title=element_text(size=size_2dim[1]),
          legend.text=element_text(size=size_2dim[2]),
          plot.title = element_text(size=size_2dim[4]),
          legend.title=element_blank(),
          panel.background = element_rect(fill = "gray96",
                                          colour = "gray96",
                                          size = 0.5, linetype = "solid"),
          panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                          colour = "white"), 
          panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                          colour = "white")) 
  #sd fit
  dat_sd <- dat          %>%      #combine data via sd
    group_by(time,dose)            %>%
    summarize(resp_sd=sd(resp))
  
  resp_sd_gamlss_nl_donor <- sigma_function(fit$sigma.coefficients,
                                            time=grid_full$time,
                                            dose=grid_full$dose,
                                            sig.f=fit$sigma.formula)  %>%
    exp(.)                                                            %>%
    cbind(grid_full, "response"=.)                   %>%
    reshape2::acast(., 
                    time~dose, 
                    value.var="response")
  
  fig_sd_fit <- plot_ly()       %>%
    add_markers(dat_sd,       #only compound of interest
                x = dat_sd$dose, 
                y = dat_sd$time, 
                z = dat_sd$resp_sd, 
                marker = list(size = marker_size_sd),
                showlegend=F)                %>%
    add_surface(x=colnames(resp_sd_gamlss_nl_donor),
                y=rownames(resp_sd_gamlss_nl_donor),
                z=resp_sd_gamlss_nl_donor,
                colorscale=list(c(0,1),
                                c("black","grey")),
                colorbar="",
                showscale=F,
                opacity=0.85) %>%
    layout(scene = list(xaxis = list(title = list( text = 'Dose',
                                                   font = list(size = size_3dim_sd[1])),
                                     tickfont = list(size = size_3dim_sd[2])),  #Basic layout
                        yaxis = list(title = list( text = 'Time',
                                                   font = list(size = size_3dim_sd[1])),
                                     tickfont = list(size = size_3dim_sd[2])),
                        zaxis = list(title = list( text ='Response',
                                                   font = list(size = size_3dim_sd[1])),
                                     tickfont = list(size = size_3dim_sd[2]))),
           legend = list(itemsizing = "constant",
                         font = list(size = size_3dim_sd[2]),
                         x = 100,
                         y= 0.5)
    )  %>%
    add_text(x=5,y=3.5,z=max(dat_sd$resp_sd),text=title_sd,textfont=list(size = size_3dim_sd[1], color="black"),showlegend=F) 
 
  
  fig_sd_fit$x$layout$margin$b <- 1
  fig_sd_fit$x$layout$margin$l <- 1
  fig_sd_fit$x$layout$margin$t <- 1
  fig_sd_fit$x$layout$margin$r <- 1
  
  
  return(list("fit"=fig_gamlss_nl_donor,
              "dim2res"=gg_2dim_res,
              "conf_fit"=fig_gamlssnl_donor_chp,
              "conf"=fig_gamlssnl_donor_chp_only,
              "alert_plot"=gg_alert,
              "sd_fit"=fig_sd_fit))
}



add_to_plot_analysis <- function(dat,fit,res,fixtime=4, model, plot_to_add_to,
                                 plot_type,
                                 add_col_fit=c("black","grey"),
                                 add_col_alert="orangered2",
                                 add_col_dim2res=c("black","blue","blue"),
                                 add_lty_dim2res=c("solid","solid","dashed"),
                                 add_lty_alert=c("solid"),
                                 add_col_alert_dim2res=c("orangered2","orangered2"),
                                 add_lty_alert_dim2res=c("dotdash","dotted"),
                                 add_col_fit_cb=c("black","grey","darkblue","lightblue","orangered2"),
                                 add_col_cb=c("darkgreen","lightgreen","goldenrod3"),
                                 add_col_sd=c("black","grey")){
  
  
  
  #fit add model fit
  #cb add confidence plane
  #fit_cb add both fit and confidence plane
  #alert add alert 
  #dim2res add cb at fixtime
  #sd sd fit plot
  
  #model choice
  if(model=="td2pLL"){
    model <- td2pLL
  } else{
    if(model=="schuettler"){
      model <- schuettler
    }
    
  }
  
  #Prep basic fit
  resp_gamlss_nl_donor<- model(t=grid_full$time, 
                               d=grid_full$dose, 
                               theta=coef(fit))          %>%
    cbind(grid_full, "response"=.)                        %>%
    reshape2::acast(., 
                    time~dose, 
                    value.var="response")
  
  #prep conf band
  conf_band_mat_gamlssnl_donor <- res$conf$full   %>%
    cbind(grid_full, "cf"=. )           %>%
    reshape2::acast(., 
                    time~dose, 
                    value.var="cf")
  
  #identify 3dim alert
  alert_gamlssnl_donor <- matrix(NA,nrow=length(time_seq),ncol=2)
  for(i in length(time_seq):1){
    alert_gamlssnl_donor[i,1] <- i
    alert_gamlssnl_donor[i,2] <- min(subset(which(conf_band_mat_gamlssnl_donor<50,arr.ind=T)[,2],
                                            which(conf_band_mat_gamlssnl_donor<50,T)[,1]==i))
  }
  
  #identify grid fixtime 
  grid_tp <-which(rownames(conf_band_mat_gamlssnl_donor)==fixtime)
  
  
  #identify 2dim result
  dim2alert <- min(which(res$conf$fixtime<50))
  
  #identify 3dim results
  dim3alert <- min(which(conf_band_mat_gamlssnl_donor[grid_tp,]<50))
  
  #prep sd fit
  dat_sd <- dat          %>%      #combine data via sd
    group_by(time,dose)            %>%
    summarize(resp_sd=sd(resp))
  
  
  resp_sd_gamlss_nl_donor <- sigma_function(fit$sigma.coefficients,
                                            time=grid_full$time,
                                            dose=grid_full$dose,
                                            sig.f=fit$sigma.formula)  %>%
    exp(.)                                                            %>%
    cbind(grid_full, "response"=.)                   %>%
    reshape2::acast(., 
                    time~dose, 
                    value.var="response") 
  
  
  if(plot_type=="fit"){
    
  added_plot <-  plot_to_add_to %>% 
              add_surface(x=colnames(resp_gamlss_nl_donor),
                          y=rownames(resp_gamlss_nl_donor),
                          z=resp_gamlss_nl_donor,
                          colorscale=list(c(0,1),
                                          add_col_fit),
                          colorbar="",
                          showscale=F)  %>%
              add_trace(x = dose_seq, 
                        y = rep(fixtime,times=length(dose_seq)), 
                        z = model(t=rep(fixtime,times=length(dose_seq)),
                                  d=dose_seq,
                                  theta=coef(fit)),
                        line=list(color = add_col_fit[1], width = 2),
                        type="scatter3d",mode="lines",
                        showlegend=F)   %>%
    style(name = "Donor 1", traces = 1) %>%
    style(name = "Donor 2", traces = 2) %>%
    style(name = "Donor 3", traces = 3) 
  
  
  }
  
  
  if(plot_type=="dim2res"){
    added_plot <- plot_to_add_to +
                  geom_line(data=data.frame(x=dose_seq,
                             y1=model(t=rep(fixtime,times=length(dose_seq)),
                                      d=dose_seq,
                                      theta=coef(fit)),
                             y2=conf_band_mat_gamlssnl_donor[grid_tp,],
                             y3=res$conf$fixtime),aes(x=x,y=y1,col=add_col_dim2res[1], linetype=add_lty_dim2res[1]) )  +
                  geom_line(data=data.frame(x=dose_seq,
                                 y1=model(t=rep(fixtime,times=length(dose_seq)),
                                           d=dose_seq,
                                           theta=coef(fit)),
                                  y2=conf_band_mat_gamlssnl_donor[grid_tp,],
                                y3=res$conf$fixtime),aes(x=x,y=y2,col=add_col_dim2res[3], linetype=add_lty_dim2res[3])) +
     geom_line(data=data.frame(x=dose_seq,
                               y1=model(t=rep(fixtime,times=length(dose_seq)),
                                        d=dose_seq,
                                        theta=coef(fit)),
                               y2=conf_band_mat_gamlssnl_donor[grid_tp,],
                               y3=res$conf$fixtime),aes(x=x,y=y3,col=add_col_dim2res[2], linetype=add_lty_dim2res[2])) +
     geom_vline(xintercept=dose_seq[dim3alert],col=add_col_alert_dim2res[2],linetype=add_lty_alert_dim2res[2]) +
    geom_vline(xintercept=dose_seq[dim2alert],col=add_col_alert_dim2res[1],linetype=add_lty_alert_dim2res[1]) 
  
  }
  
  
  if(plot_type=="alert"){
    added_plot <-   plot_to_add_to +
                 geom_line(data=data.frame(x1 = dose_seq[alert_gamlssnl_donor[,2]], 
                                            y1 = time_seq[alert_gamlssnl_donor[,1]]), 
                             aes(x=y1,y=x1, col=add_col_alert,linetype = add_lty_alert))
  
  }
  
  if(plot_type=="fit_cb"){
    added_plot <-   plot_to_add_to %>%
                add_surface(x=colnames(resp_gamlss_nl_donor),
                            y=rownames(resp_gamlss_nl_donor),
                            z=resp_gamlss_nl_donor,
                            colorscale=list(c(0,1),
                                            c(add_col_fit_cb[1],add_col_fit_cb[2])),
                            colorbar="",
                            showscale=F,
                            opacity=0.75)                                  %>%
    add_surface(x=colnames(conf_band_mat_gamlssnl_donor),
                y=rownames(conf_band_mat_gamlssnl_donor),
                z=conf_band_mat_gamlssnl_donor,
                colorscale=list(c(0,1),
                                c(add_col_fit_cb[3],add_col_fit_cb[4])),
                colorbar="",
                showscale=F,
                opacity=0.75
    )                                                     %>%
    add_trace(x = dose_seq, 
              y = rep(fixtime,times=length(dose_seq)), 
              z = model(t=rep(fixtime,times=length(dose_seq)),
                        d=dose_seq,
                        theta=coef(fit)),
              line=list(color = add_col_fit_cb[1], width = 2),
              type="scatter3d",mode="lines",
              showlegend=F)                              %>%
    add_trace(x = dose_seq, 
              y = rep(fixtime,times=length(dose_seq)), 
              z = conf_band_mat_gamlssnl_donor[grid_tp,],
              line=list(color = add_col_fit_cb[3], width = 2,dash="dash"),
              type="scatter3d",mode="lines",
              showlegend=F)                              %>%
    add_trace(x = dose_seq[alert_gamlssnl_donor[,2]], 
              y = time_seq[alert_gamlssnl_donor[,1]], 
              z = rep(0,times=length(time_seq)),
              line=list(color = add_col_fit_cb[5], width = 1),
              type="scatter3d",mode="lines",
              showlegend=F)  
  
  
  
  }
  
  
  if(plot_type=="cb"){
    added_plot <-   plot_to_add_to %>%
      add_surface(x=colnames(conf_band_mat_gamlssnl_donor),
                  y=rownames(conf_band_mat_gamlssnl_donor),
                  z=conf_band_mat_gamlssnl_donor,
                  colorscale=list(c(0,1),
                                  c(add_col_cb[1],add_col_cb[2])),
                  colorbar="",
                  showscale=F,
                  opacity=0.75
      )                                                     %>%
      add_trace(x = dose_seq, 
                y = rep(fixtime,times=length(dose_seq)), 
                z = conf_band_mat_gamlssnl_donor[grid_tp,],
                line=list(color = add_col_cb[1], width = 2,dash="dash"),
                type="scatter3d",mode="lines",
                showlegend=F)                              %>%
      add_trace(x = dose_seq[alert_gamlssnl_donor[,2]], 
                y = time_seq[alert_gamlssnl_donor[,1]], 
                z = rep(0,times=length(time_seq)),
                line=list(color = add_col_cb[3], width = 1),
                type="scatter3d",mode="lines",
                showlegend=F)  
    
    
  }
  
  
  if(plot_type=="sd"){
    added_plot <-   plot_to_add_to %>%
      add_surface(x=colnames(resp_sd_gamlss_nl_donor),
                  y=rownames(resp_sd_gamlss_nl_donor),
                  z=resp_sd_gamlss_nl_donor,
                  colorscale=list(c(0,1),
                                  add_col_sd),
                  colorbar="",
                  showscale=F,
                  opacity=0.85) 
    
  }
  return(added_plot)
}


#'------------------------------------------------------------------------------
### Centered Case ----
#'------------------------------------------------------------------------------

#Here we define a function, that generates all plots for one case
#set model beforehands

plot_analysis_centered <- function(dat,fit,res,fixtime=4,fixdose=0, model,
                                   col_cb=c("darkblue","lightblue"),
                                   col_alert="red",
                                   lty_alert = "solid",
                                   col_cb_2dim="blue",
                                   col_alert_2dim="orangered2",
                                   lty_alert_2dim="solid",
                                   title_cb = "",
                                   title_2dim = "",
                                   title_sd= "",
                                   camera_fit=list(x = 4, y = 1.3, z = 0.5),
                                   camera_cb=list(x = 0.2, y = 2.5, z = 0.2),
                                   marker_size_sd=3,
                                   size_3dim_fit_cb=c(24,15,17),
                                   size_2dim =c(17,19,7,21),
                                   size_3dim_sd=c(24,15,17)){
  
  #model choice
  if(model=="td2pLL"){
    model <- td2pLL
  } else{
    if(model=="schuettler"){
      model <- schuettler
    }
    
  }
  
  #Prep basic fit
  resp_gamlss_nl_donor<- abs(model(t=grid_full$time, 
                                    d=grid_full$dose, 
                                    theta=coef(fit))-model(t=rep(fixtime,times=nrow(grid_full)), 
                                                                                   d=rep(fixdose,times=nrow(grid_full)), 
                                                                                   theta=coef(fit)))          %>%
    cbind(grid_full, "response"=.)                        %>%
    reshape2::acast(., 
                    time~dose, 
                    value.var="response")
  
  
  #plot basic fit
  fig_gamlss_nl_donor <- plot_ly()                          %>%
    layout(scene = list(   camera = list(
      eye =camera_fit),xaxis = list(title = list( text = 'Dose',
                                                   font = list(size = size_3dim_fit_cb[1])),
                                     tickfont = list(size = size_3dim_fit_cb[2])),  #Basic layout
                        yaxis = list(title = list( text = 'Time',
                                                   font = list(size = size_3dim_fit_cb[1])),
                                     tickfont = list(size = size_3dim_fit_cb[2])),
                        zaxis = list(title = list( text ='Response',
                                                   font = list(size = size_3dim_fit_cb[1])),
                                     tickfont = list(size = size_3dim_fit_cb[2]))),
           legend = list(itemsizing = "constant",
                         font = list(size = size_3dim_fit_cb[2]),
                         x = 100,
                         y= 0.5)
    )                                                                %>%
    add_surface(x=colnames(resp_gamlss_nl_donor),
                y=rownames(resp_gamlss_nl_donor),
                z=resp_gamlss_nl_donor,
                colorscale=list(c(0,1),
                                c("black","grey")),
                colorbar="",
                showscale=F) %>%
    add_trace(x = dose_seq, 
              y = rep(fixtime,times=length(dose_seq)), 
              z = abs(model(t=rep(fixtime,times=length(dose_seq)),
                             d=dose_seq,
                             theta=coef(fit))-model(t=rep(fixtime,times=length(dose_seq)),
                                                    d=rep(fixdose,times=length(dose_seq)),
                                                    theta=coef(fit))),
              line=list(color = "black", width = 2),
              type="scatter3d",mode="lines",
              showlegend=F)   %>%
     add_text(x=5,y=5,z=70,text="Fit",textfont=list(size = size_3dim_fit_cb[3], color="black"),showlegend=F) %>%
     add_text(x=5,y=3.5,z=100,text=title_cb,textfont=list(size = size_3dim_fit_cb[1], color="black"),showlegend=F) 

  fig_gamlss_nl_donor$x$layout$margin$b <- 1
  fig_gamlss_nl_donor$x$layout$margin$l <- 1
  fig_gamlss_nl_donor$x$layout$margin$t <- 1
  fig_gamlss_nl_donor$x$layout$margin$r <- 1
  
  #Conf plot
  conf_band_mat_gamlssnl_donor <- res$conf$full   %>%
    cbind(grid_full, "cf"=. )           %>%
    reshape2::acast(., 
                    time~dose, 
                    value.var="cf")
  
  alert_gamlssnl_donor <- matrix(NA,nrow=length(time_seq),ncol=2)
  for(i in length(time_seq):1){
    alert_gamlssnl_donor[i,1] <- i
   alert_gamlssnl_donor[i,2] <- min(subset(which(conf_band_mat_gamlssnl_donor>50,arr.ind=T)[,2],
                                            which(conf_band_mat_gamlssnl_donor>50,T)[,1]==i))
  }
  
  
  #identify grid fixpoint (standard is 4)
  grid_tp <-which(rownames(conf_band_mat_gamlssnl_donor)==fixtime)
  
  #confidence plane
  fig_gamlssnl_donor_chp_only <- plot_ly(showlegend=F)                %>%
    layout(scene = list(camera = list(
     eye = camera_cb),
      xaxis = list(title = list( text = 'Dose',
                                 font = list(size = size_3dim_fit_cb[1])),
                   tickfont = list(size = size_3dim_fit_cb[2])),  #Basic layout
      yaxis = list(title = list( text = 'Time',
                                 font = list(size = size_3dim_fit_cb[1])),
                   tickfont = list(size = size_3dim_fit_cb[2])),
     zaxis = list(title = list( text ='Response',
                                 font = list(size = size_3dim_fit_cb[1])),
                   tickfont = list(size = size_3dim_fit_cb[2])),
      bgcolor = "rgba(0,0,0,0)"),
      legend = list(itemsizing = "constant",
                    font = list(size = size_3dim_fit_cb[2]),
                    x = 100,
                    y= 0.5)
    )                                                                %>%
    add_surface(x=colnames(conf_band_mat_gamlssnl_donor),
                y=rownames(conf_band_mat_gamlssnl_donor),
                z=conf_band_mat_gamlssnl_donor,
                colorscale=list(c(0,1),
                                col_cb),
                colorbar="",
                showscale=F,
                opacity=0.75
    )                                            %>%
    add_surface(x=colnames(Threshold),
                y=rownames(Threshold),
                z=Threshold,
                colorscale=list(c(0,1),
                                c("firebrick","red")),
                colorbar="",
                showscale=F
    )                                             %>%
    add_trace(x = dose_seq, 
              y = rep(fixtime,times=length(dose_seq)), 
              z = conf_band_mat_gamlssnl_donor[grid_tp,],
              line=list(color = col_cb[1], width = 2,dash="dash"),
              type="scatter3d",mode="lines",
              showlegend=F)                              %>%
    add_trace(x = dose_seq[alert_gamlssnl_donor[,2]], 
              y = time_seq[alert_gamlssnl_donor[,1]], 
              z = rep(0,times=length(time_seq)),
              line=list(color = col_alert, width = 1,dash=lty_alert),
              type="scatter3d",mode="lines",
              showlegend=F)       %>%
    add_text(x=2.5,y=6.5,z=50,text="\U1D6CC",textfont=list(size = size_3dim_fit_cb[3], color="darkred"),
             showlegend=F) %>%
    add_text(x=7,y=1,z=80,text="Confidence Plane",textfont=list(size = size_3dim_fit_cb[3], color=col_cb[1]),
             showlegend=F)                                                         %>%
    add_text(x=6,y=5,z=-5,text="Alert",textfont=list(size = size_3dim_fit_cb[3],color=col_alert),
             showlegend=F)  %>%
    add_text(x=5,y=3.5,z=100,text=title_cb,textfont=list(size = size_3dim_fit_cb[1], color="black"),showlegend=F) 
  
  fig_gamlssnl_donor_chp_only$x$layout$margin$b <- 1
  fig_gamlssnl_donor_chp_only$x$layout$margin$l <- 1
  fig_gamlssnl_donor_chp_only$x$layout$margin$t <- 1
  fig_gamlssnl_donor_chp_only$x$layout$margin$r <- 1
  
    
  #plot fit an confidence plane
  fig_gamlssnl_donor_chp <- plot_ly(showlegend=F)                %>%
    layout(scene = list(camera = list(
      eye = camera_cb),
      xaxis = list(title = list( text = 'Dose',
                                 font = list(size = size_3dim_fit_cb[1])),
                   tickfont = list(size = size_3dim_fit_cb[2])),  #Basic layout
      yaxis = list(title = list( text = 'Time',
                                 font = list(size = size_3dim_fit_cb[1])),
                   tickfont = list(size = size_3dim_fit_cb[2])),
      zaxis = list(title = list( text ='Response',
                                 font = list(size = size_3dim_fit_cb[1])),
                   tickfont = list(size = size_3dim_fit_cb[2])),
      bgcolor = "rgba(0,0,0,0)"),
      legend = list(itemsizing = "constant",
                    font = list(size = size_3dim_fit_cb[2]),
                    x = 100,
                    y= 0.5)
    )                                                                %>%
    add_surface(x=colnames(resp_gamlss_nl_donor),
                y=rownames(resp_gamlss_nl_donor),
                z=resp_gamlss_nl_donor,
                colorscale=list(c(0,1),
                                c("black","grey")),
                colorbar="",
                showscale=F,
                opacity=0.75)                                  %>%
    add_surface(x=colnames(conf_band_mat_gamlssnl_donor),
                y=rownames(conf_band_mat_gamlssnl_donor),
                z=conf_band_mat_gamlssnl_donor,
                colorscale=list(c(0,1),
                                col_cb),
                colorbar="",
                showscale=F,
                opacity=0.75
    )                                            %>%
    add_surface(x=colnames(Threshold),
                y=rownames(Threshold),
                z=Threshold,
                colorscale=list(c(0,1),
                                c("firebrick","red")),
                colorbar="",
                showscale=F
    )                                             %>%
    add_trace(x = dose_seq, 
              y = rep(fixtime,times=length(dose_seq)), 
              z = abs(model(t=rep(fixtime,times=length(dose_seq)),
                            d=dose_seq,
                            theta=coef(fit))-model(t=rep(fixtime,times=length(dose_seq)),
                                                   d=rep(fixdose,times=length(dose_seq)),
                                                         theta=coef(fit))),
              line=list(color = 'black', width = 2),
              type="scatter3d",mode="lines",
              showlegend=F)                              %>%    
    add_trace(x = dose_seq, 
              y = rep(fixtime,times=length(dose_seq)), 
              z = conf_band_mat_gamlssnl_donor[grid_tp,],
              line=list(color = col_cb[1], width = 2,dash="dash"),
              type="scatter3d",mode="lines",
              showlegend=F)                              %>%
    add_trace(x = dose_seq[alert_gamlssnl_donor[,2]], 
              y = time_seq[alert_gamlssnl_donor[,1]], 
              z = rep(0,times=length(time_seq)),
              line=list(color = col_alert, width = 1,dash=lty_alert),
              type="scatter3d",mode="lines",
              showlegend=F)       %>%
    add_text(x=2.5,y=6.5,z=50,text="\U1D6CC",textfont=list(size = size_3dim_fit_cb[3], color="darkred"),
             showlegend=F) %>%
    add_text(x=5,y=5,z=85,text="Fit",textfont=list(size = size_3dim_fit_cb[3], color="black"),
             showlegend=F)    %>%
    add_text(x=7,y=1,z=70,text="Confidence Plane",textfont=list(size = size_3dim_fit_cb[3], color=col_cb[1]),
             showlegend=F)                                                         %>%
    add_text(x=6,y=5,z=-5,text="Alert",textfont=list(size = size_3dim_fit_cb[3],color=col_alert),
             showlegend=F)  %>%
    add_text(x=5,y=3.5,z=100,text=title_cb,textfont=list(size = size_3dim_fit_cb[1], color="black"),showlegend=F) 
  
  fig_gamlssnl_donor_chp$x$layout$margin$b <- 1
  fig_gamlssnl_donor_chp$x$layout$margin$l <- 1
  fig_gamlssnl_donor_chp$x$layout$margin$t <- 1
  fig_gamlssnl_donor_chp$x$layout$margin$r <- 1
  
  
  #plot 3dim alert
  gg_alert <- ggplot(data=data.frame(x1 = dose_seq[alert_gamlssnl_donor[,2]], 
                                     y1 = time_seq[alert_gamlssnl_donor[,1]]), aes(x=y1,y=x1)) +
    geom_line(aes(x=y1,y=x1,col=col_alert_2dim,linetype=lty_alert_2dim))+
    scale_color_manual(values=c(col_alert_2dim),labels=c("alert")) +
    scale_linetype_manual(values=c(lty_alert_2dim),labels=c("")) +
    guides(linetype="none") +
    xlab("Time") +
    ylab("Dose") +
    ylim(10,0) +
    xlim(7,1) +
    ggtitle(title_2dim)+
    theme(axis.title=element_text(size=size_2dim[1]),
          legend.text=element_text(size=size_2dim[2]),
          legend.title=element_blank(),
          plot.title = element_text(size=size_2dim[4]),
          panel.background = element_rect(fill = "gray96",
                                          colour = "gray96",
                                          size = 0.5, linetype = "solid"),
          panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                          colour = "white"), 
          panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                          colour = "white")) +
    coord_flip()
  
  
  #identify 2dim result
  dim2alert <- min(which(res$conf$fix>50))
  
  #identify 3dim results for fixtime
  dim3alert <- min(which(conf_band_mat_gamlssnl_donor[grid_tp,]>50))
  
  
  #plot 2dim results
  gg_2dim_res <- ggplot(data.frame(x1=dose_seq,
                                   y1= abs(model(t=rep(fixtime,times=length(dose_seq)), 
                                                d=dose_seq, 
                                                theta=coef(fit))-model(t=rep(fixtime,times=length(dose_seq)), 
                                                                       d=rep(fixdose,times=length(dose_seq)), 
                                                                       theta=coef(fit))),  
                                   y2=conf_band_mat_gamlssnl_donor[grid_tp,],
                                   y3=res$conf$fix),
                        aes(x=x1))                                                        +
    geom_line(aes(x=x1,y=y1,col="black",linetype="solid"))                                              +
    geom_line(aes(x=x1,y=y2,col=col_cb_2dim,linetype="dashed"))                                   +
    geom_line(aes(x=x1,y=y3,col=col_cb_2dim,linetype="solid"))    +
   scale_color_manual(values=c("black",col_cb_2dim),labels=c("Model fit","CB")) +
   scale_linetype_manual(values=c("dashed","solid"),labels=c("3D","2D")) +
   xlab("Dose")                                                 +
    ylab("Response")                                                      +
    ggtitle(title_2dim)+
     geom_hline(yintercept=50,col="orangered2")        +
    annotate("text",x=1,y=55,label=expression(lambda),col="orangered2",size=size_2dim[3])+
    geom_vline(xintercept=dose_seq[dim3alert],col=col_alert_2dim,linetype="dotted") +
    geom_vline(xintercept=dose_seq[dim2alert],col=col_alert_2dim,linetype="dotdash") +
    theme(axis.title=element_text(size=size_2dim[1]),
          legend.text=element_text(size=size_2dim[2]),
          legend.title=element_blank(),
         panel.background = element_rect(fill = "gray96",
                                          colour = "gray96",
                                          size = 0.5, linetype = "solid"),
          panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                          colour = "white"), 
          panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                          colour = "white")) 
  
  
  #sd fit
  dat_sd <- dat          %>%      #combine data via sd
    group_by(time,dose)            %>%
    summarize(resp_sd=sd(resp))
  
  resp_sd_gamlss_nl_donor <- sigma_function(fit$sigma.coefficients,
                                            time=grid_full$time,
                                            dose=grid_full$dose,
                                            sig.f=fit$sigma.formula)  %>%
    exp(.)                                                            %>%
    cbind(grid_full, "response"=.)                   %>%
    reshape2::acast(., 
                    time~dose, 
                    value.var="response")
  
  fig_sd_fit <- plot_ly()       %>%
    add_markers(dat_sd,       #only compound of interest
                x = dat_sd$dose, 
                y = dat_sd$time, 
                z = dat_sd$resp_sd, 
                marker = list(size = marker_size_sd),
                showlegend=F)                %>%
    add_surface(x=colnames(resp_sd_gamlss_nl_donor),
                y=rownames(resp_sd_gamlss_nl_donor),
                z=resp_sd_gamlss_nl_donor,
                colorscale=list(c(0,1),
                                c("black","grey")),
                colorbar="",
                showscale=F,
                opacity=0.85) %>%
    layout(scene = list(  xaxis = list(title = list( text = 'Dose',
                                                   font = list(size = size_3dim_sd[1])),
                                     tickfont = list(size = size_3dim_sd[2])),  #Basic layout
                        yaxis = list(title = list( text = 'Time',
                                                   font = list(size = size_3dim_sd[1])),
                                     tickfont = list(size = size_3dim_sd[2])),
                        zaxis = list(title = list( text ='Response',
                                                   font = list(size = size_3dim_sd[1])),
                                     tickfont = list(size = size_3dim_sd[2]))),
           legend = list(itemsizing = "constant",
                         font = list(size = size_3dim_sd[2]),
                         x = 100,
                         y= 0.5)
    )  %>%
    add_text(x=5,y=3.5,z=max(dat_sd$resp_sd),text=title_sd,textfont=list(size = size_3dim_fit_cb[1], color="black"),showlegend=F) 
  
  fig_sd_fit$x$layout$margin$b <- 1
  fig_sd_fit$x$layout$margin$l <- 1
  fig_sd_fit$x$layout$margin$t <- 1
  fig_sd_fit$x$layout$margin$r <- 1
  
  
  return(list("fit"=fig_gamlss_nl_donor,
              "dim2res"=gg_2dim_res,
              "conf_fit"=fig_gamlssnl_donor_chp,
              "conf"=fig_gamlssnl_donor_chp_only,
              "alert_plot"=gg_alert,
              "sd_fit"=fig_sd_fit
)
)
}



add_to_plot_analysis_centered <- function(dat,fit,res,fixtime=4,fixdose=0, model,
                                 plot_to_add_to, plot_type,
                                 add_col_fit=c("black","grey"),
                                 add_col_alert="orangered2",
                                 add_col_dim2res=c("black","blue","blue"),
                                 add_lty_dim2res=c("solid","solid","dashed"),
                                 add_col_alert_dim2res=c("orangered2","orangered2"),
                                 add_lty_alert_dim2res=c("dotdash","dotted"),
                                 add_col_fit_cb=c("black","grey","darkblue","lightblue","orangered2"),
                                 add_col_cb=c("darkgreen","lightgreen","goldenrod3"),
                                 add_col_sd=c("black","grey")){
  
  
  
  #fit add model fit
  #cb add confidence plane
  #fit_cb add both fit and confidence plane
  #alert add alert 
  #dim2res add cb at fixtime
  #sd fit of sd
  
  #model choice
  if(model=="td2pLL"){
    model <- td2pLL
  } else{
    if(model=="schuettler"){
      model <- schuettler
    }
    
  }
  
  #Prep basic fit
  resp_gamlss_nl_donor<- abs(model(t=grid_full$time, 
                                   d=grid_full$dose, 
                                   theta=coef(fit))-model(t=rep(fixtime,times=nrow(grid_full)), 
                                                          d=rep(fixdose,times=nrow(grid_full)), 
                                                          theta=coef(fit)))          %>%
    cbind(grid_full, "response"=.)                        %>%
    reshape2::acast(., 
                    time~dose, 
                    value.var="response")
  
  
 #prep conf band
  conf_band_mat_gamlssnl_donor <- res$conf$full   %>%
    cbind(grid_full, "cf"=. )           %>%
    reshape2::acast(., 
                    time~dose, 
                    value.var="cf")
  
  alert_gamlssnl_donor <- matrix(NA,nrow=length(time_seq),ncol=2)
  for(i in length(time_seq):1){
    alert_gamlssnl_donor[i,1] <- i
    alert_gamlssnl_donor[i,2] <- min(subset(which(conf_band_mat_gamlssnl_donor>50,arr.ind=T)[,2],
                                            which(conf_band_mat_gamlssnl_donor>50,T)[,1]==i))
  }
  
  #identify grid fixtime 
  grid_tp <-which(rownames(conf_band_mat_gamlssnl_donor)==fixtime)
  
  
  #identify 2dim result
  dim2alert <- min(which(res$conf$fix>50))
  
  #identify 3dim results
  dim3alert <- min(which(conf_band_mat_gamlssnl_donor[grid_tp,]>50))
  
  #prep sd fit
  dat_sd <- dat          %>%      #combine data via sd
    group_by(time,dose)            %>%
    summarize(resp_sd=sd(resp))
  
  
  resp_sd_gamlss_nl_donor <- sigma_function(fit$sigma.coefficients,
                                            time=grid_full$time,
                                            dose=grid_full$dose,
                                            sig.f=fit$sigma.formula)  %>%
    exp(.)                                                            %>%
    cbind(grid_full, "response"=.)                   %>%
    reshape2::acast(., 
                    time~dose, 
                    value.var="response") 
  
  
  if(plot_type=="fit"){
    
    added_plot <-  plot_to_add_to %>% 
      add_surface(x=colnames(resp_gamlss_nl_donor),
                  y=rownames(resp_gamlss_nl_donor),
                  z=resp_gamlss_nl_donor,
                  colorscale=list(c(0,1),
                                  add_col_fit),
                  colorbar="",
                  showscale=F) %>%
      add_trace(x = dose_seq, 
                y = rep(fixtime,times=length(dose_seq)), 
                z = abs(model(t=rep(fixtime,times=length(dose_seq)), 
                              d=dose_seq, 
                              theta=coef(fit))-model(t=rep(fixtime,times=length(dose_seq)), 
                                                     d=rep(fixdose,times=length(dose_seq)), 
                                                     theta=coef(fit))),
                line=list(color = add_col_fit[1], width = 2),
                type="scatter3d",mode="lines",
                showlegend=F) 
    
    
  }
  
  
  if(plot_type=="dim2res"){
    added_plot <- plot_to_add_to +
      geom_line(data=data.frame(x=dose_seq,
                                y1=abs(model(t=rep(fixtime,times=length(dose_seq)), 
                                             d=dose_seq, 
                                             theta=coef(fit))-model(t=rep(fixtime,times=length(dose_seq)), 
                                                                    d=rep(fixdose,times=length(dose_seq)), 
                                                                    theta=coef(fit))),
                                y2=conf_band_mat_gamlssnl_donor[grid_tp,],
                                y3=res$conf$fix),aes(x=x,y=y1,col=add_col_dim2res[1], linetype=add_lty_dim2res[1]) )  +
      geom_line(data=data.frame(x=dose_seq,
                                y1=abs(model(t=rep(fixtime,times=length(dose_seq)), 
                                             d=dose_seq, 
                                             theta=coef(fit))-model(t=rep(fixtime,times=length(dose_seq)), 
                                                                    d=rep(fixdose,times=length(dose_seq)), 
                                                                    theta=coef(fit))),
                                y2=conf_band_mat_gamlssnl_donor[grid_tp,],
                                y3=res$conf$fix),aes(x=x,y=y2,col=add_col_dim2res[3], linetype=add_lty_dim2res[3])) +
      geom_line(data=data.frame(x=dose_seq,
                                y1=abs(model(t=rep(fixtime,times=length(dose_seq)), 
                                             d=dose_seq, 
                                             theta=coef(fit))-model(t=rep(fixtime,times=length(dose_seq)), 
                                                                    d=rep(fixdose,times=length(dose_seq)), 
                                                                    theta=coef(fit))),
                                y2=conf_band_mat_gamlssnl_donor[grid_tp,],
                                y3=res$conf$fix),aes(x=x,y=y3,col=add_col_dim2res[2], linetype=add_lty_dim2res[2])) +
      geom_vline(xintercept=dose_seq[dim3alert],col=add_col_alert_dim2res[2],linetype=add_lty_alert_dim2res[2]) +
      geom_vline(xintercept=dose_seq[dim2alert],col=add_col_alert_dim2res[1],linetype=add_lty_alert_dim2res[1]) 
    
  }
  
  
  if(plot_type=="alert"){
    added_plot <-   plot_to_add_to +
      geom_line(data=data.frame(x1 = dose_seq[alert_gamlssnl_donor[,2]], 
                                y1 = time_seq[alert_gamlssnl_donor[,1]]), 
                aes(x=y1,y=x1, col=add_col_alert))
    
  }
  
  if(plot_type=="fit_cb"){
    added_plot <-   plot_to_add_to %>%
      add_surface(x=colnames(resp_gamlss_nl_donor),
                  y=rownames(resp_gamlss_nl_donor),
                  z=resp_gamlss_nl_donor,
                  colorscale=list(c(0,1),
                                  c(add_col_fit_cb[1],add_col_fit_cb[2])),
                  colorbar="",
                  showscale=F,
                  opacity=0.75)                                  %>%
      add_surface(x=colnames(conf_band_mat_gamlssnl_donor),
                  y=rownames(conf_band_mat_gamlssnl_donor),
                  z=conf_band_mat_gamlssnl_donor,
                  colorscale=list(c(0,1),
                                  c(add_col_fit_cb[3],add_col_fit_cb[4])),
                  colorbar="",
                  showscale=F,
                  opacity=0.75
      )                                                     %>%
      add_trace(x = dose_seq, 
                y = rep(fixtime,times=length(dose_seq)), 
                z = abs(model(t=rep(fixtime,times=length(dose_seq)), 
                              d=dose_seq, 
                              theta=coef(fit))-model(t=rep(fixtime,times=length(dose_seq)), 
                                                     d=rep(fixdose,times=length(dose_seq)), 
                                                     theta=coef(fit))),
                line=list(color = add_col_fit_cb[1], width = 2),
                type="scatter3d",mode="lines",
                showlegend=F)                              %>%
      add_trace(x = dose_seq, 
                y = rep(fixtime,times=length(dose_seq)), 
                z = conf_band_mat_gamlssnl_donor[grid_tp,],
                line=list(color = add_col_fit_cb[3], width = 2,dash="dash"),
                type="scatter3d",mode="lines",
                showlegend=F)                              %>%
      add_trace(x = dose_seq[alert_gamlssnl_donor[,2]], 
                y = time_seq[alert_gamlssnl_donor[,1]], 
                z = rep(0,times=length(time_seq)),
                line=list(color = add_col_fit_cb[5], width = 1),
                type="scatter3d",mode="lines",
                showlegend=F)  
    
    
   
  }
  
  
  if(plot_type=="cb"){
    added_plot <-   plot_to_add_to %>%
      add_surface(x=colnames(conf_band_mat_gamlssnl_donor),
                  y=rownames(conf_band_mat_gamlssnl_donor),
                  z=conf_band_mat_gamlssnl_donor,
                  colorscale=list(c(0,1),
                                  c(add_col_cb[1],add_col_cb[2])),
                  colorbar="",
                  showscale=F,
                  opacity=0.75      
                  )                                                     %>%
      add_trace(x = dose_seq, 
                y = rep(fixtime,times=length(dose_seq)), 
                z = conf_band_mat_gamlssnl_donor[grid_tp,],
                line=list(color = add_col_cb[1], width = 2,dash="dash"),
                type="scatter3d",mode="lines",
                showlegend=F)                              %>%
      add_trace(x = dose_seq[alert_gamlssnl_donor[,2]], 
                y = time_seq[alert_gamlssnl_donor[,1]], 
                z = rep(0,times=length(time_seq)),
                line=list(color = add_col_cb[3], width = 1),
                type="scatter3d",mode="lines",
                showlegend=F)  
    
    
  }
  if(plot_type=="sd"){
    added_plot <-   plot_to_add_to %>%
      add_surface(x=colnames(resp_sd_gamlss_nl_donor),
                  y=rownames(resp_sd_gamlss_nl_donor),
                  z=resp_sd_gamlss_nl_donor,
                  colorscale=list(c(0,1),
                                  add_col_sd),
                  colorbar="",
                  showscale=F,
                  opacity=0.85) 
    
  }
  
  return(added_plot)
}



#'==============================================================================
## Analysis case study- Simplified ====
#'==============================================================================

#'------------------------------------------------------------------------------
### td2pLL -----
#' -----------------------------------------------------------------------------


#'------------------------------------------------------------------------------
#### td2pLL (fixtime=4) -----
#' -----------------------------------------------------------------------------

#case1
p_res_td2pLL_case1 <- plot_analysis(dat=data_subset,
              fit=td2pLL_fit_gamlss_nl_donor_case1,
              res=td2pLL_analysis_gamlssnl_donor_CASE1,
              model="td2pLL",
              col_cb = c("cornflowerblue","lightblue"),
              col_alert = "orange",
              col_cb_2dim="lightblue",
              col_alert_2dim = "orange",
              marker_size_fit_cb = 2,
              title_cb = "td2pLL: Constant (normal alg.)",
              title_2dim = "td2pLL: Constant (normal alg.)",
              size_3dim_fit_cb = c(13,13,13),
              size_2dim = c(17,19,7,21) )

#case2
p_res_td2pLL_case2 <- plot_analysis(dat=data_subset,
              fit=td2pLL_fit_gamlss_nl_donor_case2,
              res=td2pLL_analysis_gamlssnl_donor_CASE2,
              marker_size_fit_cb = 2,
              col_cb = c("cornflowerblue","lightblue"),
              col_alert="peru",
              col_cb_2dim="lightblue",
              col_alert_2dim = "peru",
              title_cb = "td2pLL: Complex (normal alg.)",
              title_2dim = "td2pLL: Complex (normal alg.)",
              model="td2pLL",
              size_3dim_fit_cb = c(13,13,13),
              size_2dim = c(17,19,7,21))




#'------------------------------------------------------------------------------
#### td2pLL (fixtime/fast) ----
#' -----------------------------------------------------------------------------

#case1
p_res_td2pLL_fast_case1 <- plot_analysis(dat=data_subset,
              fit=td2pLL_fit_gamlss_nl_donor_case1,
              res=td2pLL_analysis_gamlssnl_donor_fast_CASE1,
              model="td2pLL",
          #    col_cb = c("cornflowerblue","lightblue"),
           #   col_alert = "orange",
          #    col_cb_2dim="lightblue",
           #   col_alert_2dim = "orange",
              title_cb = "td2pLL: Constant",
              title_2dim  = "td2pLL: Constant", 
              marker_size_fit_cb = 2,
              size_3dim_fit_cb = c(13,13,13),
              size_2dim = c(17,19,7,21))

#case2
p_res_td2pLL_fast_case2 <- plot_analysis(dat=data_subset,
              fit=td2pLL_fit_gamlss_nl_donor_case2,
              res=td2pLL_analysis_gamlssnl_donor_fast_CASE2,
              col_alert = "brown",
              col_alert_2dim = "brown",
              title_cb = "td2pLL: Complex",
              title_2dim = "td2pLL: Complex",
              model="td2pLL",
              marker_size_fit_cb = 2,
              size_3dim_fit_cb = c(13,13,13),
              size_2dim = c(17,19,7,21))



#'------------------------------------------------------------------------------
#### td2pLL (fixtime=4/reduced) ----
#' -----------------------------------------------------------------------------

#case1
p_res_td2pLL_reduced_case1 <- plot_analysis(dat=data_subset_reduced,
              fit=td2pLL_fit_gamlss_nl_donor_reduced_case1,
              res=td2pLL_analysis_gamlssnl_donor_reduced_CASE1,
              model="td2pLL",
              marker_size_fit_cb = 2,
              col_cb = c("cornflowerblue","lightblue"),
              col_alert = "orange",
              col_cb_2dim="lightblue",
              col_alert_2dim = "orange",
              title_cb = "td2pLL: Constant (reduced/normal alg.)",
              title_2dim = "td2pLL: Constant (reduced/normal alg.)",
              size_3dim_fit_cb = c(13,13,13),
              size_2dim = c(17,19,7,21))

#case2
p_res_td2pLL_reduced_case2 <- plot_analysis(dat=data_subset_reduced,
              fit=td2pLL_fit_gamlss_nl_donor_reduced_case2,
              res=td2pLL_analysis_gamlssnl_donor_reduced_CASE2,
              col_cb = c("cornflowerblue","lightblue"),
              col_alert = "peru",
              col_cb_2dim="lightblue",
              col_alert_2dim = "peru",
              model="td2pLL",
              title_cb = "td2pLL: Complex (reduced/normal alg.)",
              title_2dim = "td2pLL: Complex (reduced/normal alg.)",
              marker_size_fit_cb = 2,
              size_3dim_fit_cb =c(13,13,13),
              size_2dim = c(17,19,7,21))





#'------------------------------------------------------------------------------
#### td2pLL (fixtime/fast/reduced) ----
#' -----------------------------------------------------------------------------

#case1
p_res_td2pLL_fast_reduced_case1 <- plot_analysis(dat=data_subset_reduced,
              fit=td2pLL_fit_gamlss_nl_donor_reduced_case1,
              res=td2pLL_analysis_gamlssnl_donor_fast_reduced_CASE1,
              model="td2pLL",
              title_cb = "td2pLL: Constant (reduced)",
              title_2dim = "td2pLL: Constant (reduced)",
              marker_size_fit_cb = 2,
              size_3dim_fit_cb = c(13,13,13),
              size_2dim = c(17,19,7,21))

#case2
p_res_td2pLL_fast_reduced_case2 <- plot_analysis(dat=data_subset_reduced,
              fit=td2pLL_fit_gamlss_nl_donor_reduced_case2,
              res=td2pLL_analysis_gamlssnl_donor_fast_reduced_CASE2,
              col_alert = "brown",
              col_alert_2dim = "brown",
              model="td2pLL",
              title_cb = "td2pLL: Complex (reduced)",
              title_2dim = "td2pLL: Complex (reduced)",
              marker_size_fit_cb = 2,
              size_3dim_fit_cb = c(13,13,13),
              size_2dim = c(17,19,7,21))


#'------------------------------------------------------------------------------
### schuettler -----
#' -----------------------------------------------------------------------------



#'------------------------------------------------------------------------------
#### schuettler (fixtime=4) -----
#' -----------------------------------------------------------------------------

#case1
p_res_schuettler_case1 <- plot_analysis(dat=data_subset,
                                    fit=schuettler_fit_gamlss_nl_donor_case1,
                                    res=schuettler_analysis_gamlssnl_donor_CASE1,
                                    model="schuettler",
                                    col_cb = c("cornflowerblue","lightblue"),
                                    col_alert = "orange",
                                    col_cb_2dim="lightblue",
                                    col_alert_2dim = "orange",
                                    marker_size_fit_cb = 2,
                                    title_cb = "schuettler: Constant (normal alg.)",
                                    title_2dim = "schuettler: Constant (normal alg.)",
                                    size_3dim_fit_cb = c(13,13,13),
                                    size_2dim = c(17,19,7,21))

#case2
p_res_schuettler_case2 <- plot_analysis(dat=data_subset,
                                    fit=schuettler_fit_gamlss_nl_donor_case2,
                                    res=schuettler_analysis_gamlssnl_donor_CASE2,
                                    marker_size_fit_cb = 2,
                                    col_cb = c("cornflowerblue","lightblue"),
                                    col_alert="peru",
                                    col_cb_2dim="lightblue",
                                    col_alert_2dim = "peru",
                                    title_cb = "schuettler: Complex (normal alg.)",
                                    title_2dim = "schuettler: Complex (normal alg.)",
                                    model="schuettler",
                                    size_3dim_fit_cb = c(13,13,13),
                                    size_2dim =c(17,19,7,21))




#'------------------------------------------------------------------------------
#### schuettler (fixtime/fast) ----
#' -----------------------------------------------------------------------------

#case1
p_res_schuettler_fast_case1 <- plot_analysis(dat=data_subset,
                                         fit=schuettler_fit_gamlss_nl_donor_case1,
                                         res=schuettler_analysis_gamlssnl_donor_fast_CASE1,
                                         model="schuettler",
                                         title_cb = "schuettler: Constant",
                                         title_2dim  = "schuettler: Constant", 
                                         marker_size_fit_cb = 2,
                                         size_3dim_fit_cb = c(13,13,13),
                                         size_2dim = c(17,19,7,21))

#case2
p_res_schuettler_fast_case2 <- plot_analysis(dat=data_subset,
                                         fit=schuettler_fit_gamlss_nl_donor_case2,
                                         res=schuettler_analysis_gamlssnl_donor_fast_CASE2,
                                         col_alert = "brown",
                                         title_cb = "schuettler: Complex",
                                         title_2dim = "schuettler: Complex",
                                         col_alert_2dim = "brown",                                         model="schuettler",
                                         marker_size_fit_cb = 2,
                                         size_3dim_fit_cb = c(13,13,13),
                                         size_2dim = c(17,19,7,21))



#'------------------------------------------------------------------------------
#### schuettler (fixtime=4/reduced) ----
#' -----------------------------------------------------------------------------

#case1
p_res_schuettler_reduced_case1 <- plot_analysis(dat=data_subset_reduced,
                                            fit=schuettler_fit_gamlss_nl_donor_reduced_case1,
                                            res=schuettler_analysis_gamlssnl_donor_reduced_CASE1,
                                            model="schuettler",
                                            col_cb = c("cornflowerblue","lightblue"),
                                            col_alert = "orange",
                                            col_cb_2dim="lightblue",
                                            col_alert_2dim = "orange",
                                            marker_size_fit_cb = 2,
                                            title_cb = "schuettler: Constant (reduced/normal alg.)",
                                            title_2dim = "schuettler: Constant (reduced/normal alg.)",
                                            size_3dim_fit_cb = c(13,13,13),
                                            size_2dim = c(17,19,7,21))

#case2
p_res_schuettler_reduced_case2 <- plot_analysis(dat=data_subset_reduced,
                                            fit=schuettler_fit_gamlss_nl_donor_reduced_case2,
                                            res=schuettler_analysis_gamlssnl_donor_reduced_CASE2,
                                            model="schuettler",
                                            col_cb = c("cornflowerblue","lightblue"),
                                            col_alert = "peru",
                                            col_cb_2dim="lightblue",
                                            col_alert_2dim = "peru",
                                            title_cb = "schuettler: Complex (reduced/normal alg.)",
                                            title_2dim = "schuettler: Complex (reduced/normal alg.)",
                                            marker_size_fit_cb = 2,
                                            size_3dim_fit_cb =c(13,13,13),
                                            size_2dim = c(17,19,7,21))





#'------------------------------------------------------------------------------
#### schuettler (fixtime/fast/reduced) ----
#' -----------------------------------------------------------------------------

#case1
p_res_schuettler_fast_reduced_case1 <- plot_analysis(dat=data_subset_reduced,
                                                 fit=schuettler_fit_gamlss_nl_donor_reduced_case1,
                                                 res=schuettler_analysis_gamlssnl_donor_fast_reduced_CASE1,
                                                 model="schuettler",
                                                 title_cb = "schuettler: Constant (reduced)",
                                                 title_2dim = "schuettler: Constant (reduced)",
                                                 marker_size_fit_cb = 2,
                                                 size_3dim_fit_cb = c(13,13,13),
                                                 size_2dim = c(17,19,7,21))

#case2
p_res_schuettler_fast_reduced_case2 <- plot_analysis(dat=data_subset_reduced,
                                                 fit=schuettler_fit_gamlss_nl_donor_reduced_case2,
                                                 res=schuettler_analysis_gamlssnl_donor_fast_reduced_CASE2,
                                                 col_alert = "brown",
                                                 col_alert_2dim = "brown",
                                                 model="schuettler",
                                                 title_cb = "schuettler: Complex (reduced)",
                                                 title_2dim = "schuettler: Complex (reduced)",
                                                 marker_size_fit_cb = 2,
                                                 size_3dim_fit_cb = c(13,13,13),
                                                 size_2dim = c(17,19,7,21))


#'==============================================================================
## Comparing cases ====
#'==============================================================================

#'------------------------------------------------------------------------------
###  SD fit ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
####  td2pLL full ----
#'------------------------------------------------------------------------------

sd_comp_fit <- add_to_plot_analysis(dat=data_subset,fit=td2pLL_fit_gamlss_nl_donor_case2,     #Case 1 and 2
                     res=td2pLL_analysis_gamlssnl_donor_CASE2,model="td2pLL",
                     plot_to_add_to=p_res_td2pLL_case1$sd_fit,
                     plot_type="sd",
                     add_col_sd = c("lightslategrey","lightsteelblue"))  %>%
  add_text(x=9,y=2,z=17,text="Constant",textfont=list(size = 18, color="black"),
           showlegend=F)                                                 %>%
  add_text(x=7,y=5,z=20,text="Complex",textfont=list(size = 18, color="lightsteelblue"),
           showlegend=F)                                                 %>%
  layout(
    .,
    scene = list(
      camera = list(
        eye = list(x = 2, y = 3.5, z = 0.5)  # Camera eye
      )
    )
  )                                                    

sd_comp_fit

save_and_clean_3d_plots(p=sd_comp_fit,p_file_name="002_fig_td2pll_sd_comp",save_file=T)


#'------------------------------------------------------------------------------
####  td2pLL reduced ----
#'------------------------------------------------------------------------------

sd_comp_fit <- add_to_plot_analysis(dat=data_subset_reduced,fit=td2pLL_fit_gamlss_nl_donor_reduced_case2,     #Case 1 and 2
                                    res=td2pLL_analysis_gamlssnl_donor_reduced_CASE2,model="td2pLL",
                                    plot_to_add_to=p_res_td2pLL_reduced_case1$sd_fit,
                                    plot_type="sd",
                       add_col_sd = c("lightslategrey","lightsteelblue"))  %>%
  add_text(x=7,y=2,z=13,text="Constant",textfont=list(size = 18, color="black"),
           showlegend=F)                                                 %>%
  add_text(x=3,y=5,z=9,text="Complex",textfont=list(size = 18, color="lightsteelblue"),
           showlegend=F)                                                 %>%
  layout(
    .,
    scene = list(
      camera = list(
        eye = list(x = 2, y = 3.5, z = 0.5)  # Camera eye
      )
    )
  )                                                    

sd_comp_fit

save_and_clean_3d_plots(p=sd_comp_fit,p_file_name="003_fig_td2pll_sd_comp_reduced",save_file=T)


#'------------------------------------------------------------------------------
####  schuettler full ----
#'------------------------------------------------------------------------------

sd_comp_fit <- add_to_plot_analysis(dat=data_subset,fit=schuettler_fit_gamlss_nl_donor_case2,     #Case 1 and 2
                                    res=schuettler_analysis_gamlssnl_donor_CASE2,model="schuettler",
                                    plot_to_add_to=p_res_schuettler_case1$sd_fit,
                                    plot_type="sd",
                       add_col_sd = c("lightslategrey","lightsteelblue"))  %>%
  add_text(x=9,y=2,z=17,text="Constant",textfont=list(size = 18, color="black"),
           showlegend=F)                                                 %>%
  add_text(x=7,y=5,z=20,text="Complex",textfont=list(size = 18, color="lightsteelblue"),
           showlegend=F)                                                 %>%
  layout(
    .,
    scene = list(
      camera = list(
        eye = list(x = 2, y = 3.5, z = 0.5)  # Camera eye
      )
    )
  )                                                    

sd_comp_fit


save_and_clean_3d_plots(p=sd_comp_fit,p_file_name="004_fig_schuettler_sd_comp",save_file=T)



#'------------------------------------------------------------------------------
####  schuettler reduced ----
#'------------------------------------------------------------------------------

sd_comp_fit <- add_to_plot_analysis(dat=data_subset_reduced,fit=schuettler_fit_gamlss_nl_donor_reduced_case2,     #Case 1 and 2
                                    res=schuettler_analysis_gamlssnl_donor_reduced_CASE2,model="schuettler",
                                    plot_to_add_to=p_res_schuettler_reduced_case1$sd_fit,
                                    plot_type="sd",
                       add_col_sd = c("lightslategrey","lightsteelblue"))  %>%
  add_text(x=7,y=2,z=13,text="Constant",textfont=list(size = 18, color="black"),
           showlegend=F)                                                 %>%
  add_text(x=3,y=5,z=8,text="Complex",textfont=list(size = 18, color="lightsteelblue"),
           showlegend=F)                                                 %>%
  layout(
    .,
    scene = list(
      camera = list(
        eye = list(x = 2, y = 3.5, z = 0.5)  # Camera eye
      )
    )
  )                                                    

sd_comp_fit

save_and_clean_3d_plots(p=sd_comp_fit,p_file_name="005_fig_schuettler_sd_comp_reduced",save_file=T)


#'------------------------------------------------------------------------------
### CB comparison ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
##### td2pLL ----
#'------------------------------------------------------------------------------


p_res_td2pLL_case1_fast_conf_fit_cleaned <- save_and_clean_3d_plots( p = p_res_td2pLL_fast_case1$conf_fit,
                                                                p_file_name = "p_res_td2pll_case1_tmp",
                                                                save_file = F )
p_res_td2pLL_case2_fast_conf_fit_cleaned <- save_and_clean_3d_plots( p = p_res_td2pLL_fast_case2$conf_fit,
                                                                p_file_name = "p_res_td2pll_case2_tmp",
                                                                save_file = F )


p_res_td2pLL_reduced_case1_fast_conf_fit_cleaned <- save_and_clean_3d_plots( p = p_res_td2pLL_fast_reduced_case1$conf_fit,
                                                                p_file_name = "p_res_td2pll_reduced_case1_tmp",
                                                                save_file = F )
p_res_td2pLL_reduced_case2_fast_conf_fit_cleaned <- save_and_clean_3d_plots( p = p_res_td2pLL_fast_reduced_case2$conf_fit,
                                                                p_file_name = "p_res_td2pll_reduced_case2_tmp",
                                                                save_file = F )


#'------------------------------------------------------------------------------
##### schuettler ----
#'------------------------------------------------------------------------------


p_res_schuettler_case1_fast_conf_fit_cleaned <- save_and_clean_3d_plots( p = p_res_schuettler_fast_case1$conf_fit,
                                                                p_file_name = "p_res_schuettler_case1_tmp",
                                                                save_file = F )
p_res_schuettler_case2_fast_conf_fit_cleaned <- save_and_clean_3d_plots( p = p_res_schuettler_fast_case2$conf_fit,
                                                                p_file_name = "p_res_schuettler_case2_tmp",
                                                                save_file = F )


p_res_schuettler_reduced_case1_fast_conf_fit_cleaned <- save_and_clean_3d_plots( p = p_res_schuettler_fast_reduced_case1$conf_fit,
                                                                        p_file_name = "p_res_schuettler_reduced_case1_tmp",
                                                                        save_file = F )
p_res_schuettler_reduced_case2_fast_conf_fit_cleaned <- save_and_clean_3d_plots( p = p_res_schuettler_fast_reduced_case2$conf_fit,
                                                                        p_file_name = "p_res_schuettler_reduced_case2_tmp",
                                                                        save_file = F )


#'------------------------------------------------------------------------------
##### Combining Plots ----
#'------------------------------------------------------------------------------

#Smallest AIC
(p_res_td2pLL_case1_fast_conf_fit_cleaned+p_res_schuettler_case2_fast_conf_fit_cleaned)/
  (p_res_td2pLL_reduced_case1_fast_conf_fit_cleaned+p_res_td2pLL_reduced_case2_fast_conf_fit_cleaned)
ggsave("./plots_tables/006_fig_3d_res_smallest_aic.pdf",width=12,height=12,unit="cm")



#Larger AIC
(p_res_schuettler_case1_fast_conf_fit_cleaned+p_res_td2pLL_case2_fast_conf_fit_cleaned)/
  (p_res_schuettler_reduced_case1_fast_conf_fit_cleaned+p_res_schuettler_reduced_case2_fast_conf_fit_cleaned)
ggsave("./plots_tables/007_fig_3d_res_larger_aic.pdf",width=12,height=12,unit="cm")


#'------------------------------------------------------------------------------
### 2 dim results ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
#### Conf bands ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
#####  td2pLL full ----
#'------------------------------------------------------------------------------

# confband_comp_td2pLL_case1 <- add_to_plot_analysis(dat=data_subset,fit=td2pLL_fit_gamlss_nl_donor_case1,     #Case 1 and 2
#                                     res=td2pLL_analysis_gamlssnl_donor_CASE1,model="td2pLL",
#                                     plot_to_add_to=p_res_td2pLL_fast_case1$dim2res,
#                                     plot_type="dim2res",
#                                     add_col_dim2res = c("black","lightblue","lightblue"),
#                                     add_col_alert_dim2res = "orange") +
#                                     scale_color_manual(values=c("black","blue","lightblue"),labels=c("Model fit","CB (fast)", "CB (normal)")) 
  
confband_comp_td2pLL_case1 <-  p_res_td2pLL_fast_case1$dim2res  +
                                 theme(legend.position = "none")
  
confband_comp_td2pLL_case2 <- add_to_plot_analysis(dat=data_subset,fit=td2pLL_fit_gamlss_nl_donor_case2,     #Case 1 and 2
                                                   res=td2pLL_analysis_gamlssnl_donor_CASE2,model="td2pLL",
                                                   plot_to_add_to=p_res_td2pLL_fast_case2$dim2res,
                                                   plot_type="dim2res",
                                                   add_col_dim2res = c("black","lightblue","lightblue"),
                                                   add_col_alert_dim2res = "peru") +
                              scale_color_manual(values=c("black","blue","lightblue"),labels=c("Model fit","CB (fast)", "CB (normal)")) 



#'------------------------------------------------------------------------------
#####  td2pLL reduced ----
#'------------------------------------------------------------------------------

# confband_comp_td2pLL_reduced_case1 <- add_to_plot_analysis(dat=data_subset,fit=td2pLL_fit_gamlss_nl_donor_reduced_case1,     #Case 1 and 2
#                                                    res=td2pLL_analysis_gamlssnl_donor_reduced_CASE1,model="td2pLL",
#                                                    plot_to_add_to=p_res_td2pLL_fast_reduced_case1$dim2res,
#                                                    plot_type="dim2res",
#                                                    add_col_dim2res = c("black","lightblue","lightblue"),
#                                                    add_col_alert_dim2res = "orange") +
#   scale_color_manual(values=c("black","blue","lightblue"),labels=c("Model fit","CB (fast)", "CB (normal)")) 

confband_comp_td2pLL_reduced_case1 <-p_res_td2pLL_fast_reduced_case1$dim2res +
                                     theme(legend.position = "none")

confband_comp_td2pLL_reduced_case2 <- add_to_plot_analysis(dat=data_subset,fit=td2pLL_fit_gamlss_nl_donor_reduced_case2,     #Case 1 and 2
                                                           res=td2pLL_analysis_gamlssnl_donor_reduced_CASE2,model="td2pLL",
                                                           plot_to_add_to=p_res_td2pLL_fast_reduced_case2$dim2res,
                                                           plot_type="dim2res",
                                                           add_col_dim2res = c("black","lightblue","lightblue"),
                                                           add_col_alert_dim2res = "peru") +
  scale_color_manual(values=c("black","blue","lightblue"),labels=c("Model fit","CB (fast)", "CB (normal)")) 





#'------------------------------------------------------------------------------
#####  schuettler full ----
#'------------------------------------------------------------------------------

# confband_comp_schuettler_case1 <- add_to_plot_analysis(dat=data_subset,fit=schuettler_fit_gamlss_nl_donor_case1,     #Case 1 and 2
#                                                    res=schuettler_analysis_gamlssnl_donor_CASE1,model="schuettler",
#                                                    plot_to_add_to=p_res_schuettler_fast_case1$dim2res,
#                                                    plot_type="dim2res",
#                                                    add_col_dim2res = c("black","lightblue","lightblue"),
#                                                    add_col_alert_dim2res = "orange") +
#   scale_color_manual(values=c("black","blue","lightblue"),labels=c("Model fit","CB (fast)", "CB (normal)")) 
# 

confband_comp_schuettler_case1 <- p_res_schuettler_fast_case1$dim2res+
  theme(legend.position = "none")

confband_comp_schuettler_case2 <- add_to_plot_analysis(dat=data_subset,fit=schuettler_fit_gamlss_nl_donor_case2,     #Case 1 and 2
                                                   res=schuettler_analysis_gamlssnl_donor_CASE2,model="schuettler",
                                                   plot_to_add_to=p_res_schuettler_fast_case2$dim2res,
                                                   plot_type="dim2res",
                                                   add_col_dim2res = c("black","lightblue","lightblue"),
                                                   add_col_alert_dim2res = "peru") +
  scale_color_manual(values=c("black","blue","lightblue"),labels=c("Model fit","CB (fast)", "CB (normal)")) 



#'------------------------------------------------------------------------------
#####  schuettler reduced ----
#'------------------------------------------------------------------------------

# confband_comp_schuettler_reduced_case1 <- add_to_plot_analysis(dat=data_subset,fit=schuettler_fit_gamlss_nl_donor_reduced_case1,     #Case 1 and 2
#                                                            res=schuettler_analysis_gamlssnl_donor_reduced_CASE1,model="schuettler",
#                                                            plot_to_add_to=p_res_schuettler_fast_reduced_case1$dim2res,
#                                                            plot_type="dim2res",
#                                                            add_col_dim2res = c("black","lightblue","lightblue"),
#                                                            add_col_alert_dim2res = "orange") +
#   scale_color_manual(values=c("black","blue","lightblue"),labels=c("Model fit","CB (fast)", "CB (normal)")) 

confband_comp_schuettler_reduced_case1 <- p_res_schuettler_fast_reduced_case1$dim2res+
  theme(legend.position = "none")

confband_comp_schuettler_reduced_case2 <- add_to_plot_analysis(dat=data_subset,fit=schuettler_fit_gamlss_nl_donor_reduced_case2,     #Case 1 and 2
                                                           res=schuettler_analysis_gamlssnl_donor_reduced_CASE2,model="schuettler",
                                                           plot_to_add_to=p_res_schuettler_fast_reduced_case2$dim2res,
                                                           plot_type="dim2res",
                                                           add_col_dim2res = c("black","lightblue","lightblue"),
                                                           add_col_alert_dim2res = "peru") +
  scale_color_manual(values=c("black","blue","lightblue"),labels=c("Model fit","CB (fast)", "CB (normal)")) 



#'------------------------------------------------------------------------------
#### Alert ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
#####  Smallest AIC full  ----
#'------------------------------------------------------------------------------

# First_step <- add_to_plot_analysis(dat=data_subset,fit=td2pLL_fit_gamlss_nl_donor_case1,     #Case 1 and 2
#                      res=td2pLL_analysis_gamlssnl_donor_CASE1,model="td2pLL",
#                      plot_to_add_to=p_res_td2pLL_fast_case1$alert_plot,
#                      plot_type="alert",
#                      add_col_alert =  "orange") + 
#   scale_color_manual(values=c("orange","orangered2"),labels=c("Constant (normal)","Constant (fast)")) 

First_step <- p_res_td2pLL_fast_case1$alert_plot+
  scale_color_manual(values=c("orangered2"),labels=c("Constant (fast)")) 

Second_step<-add_to_plot_analysis(dat=data_subset,fit=schuettler_fit_gamlss_nl_donor_case2,     #Case 1 and 2
                     res=schuettler_analysis_gamlssnl_donor_fast_CASE2,model="schuettler",
                     plot_to_add_to=First_step,
                     plot_type="alert",
                     add_col_alert = "brown") +
  scale_color_manual(values=c("brown","orangered2"),labels=c("Complex (fast)","Constant (fast)"))


Alert_comp_smallest_aic_all <- add_to_plot_analysis(dat=data_subset,fit=schuettler_fit_gamlss_nl_donor_case2,     #Case 1 and 2
                                  res=schuettler_analysis_gamlssnl_donor_CASE2,model="schuettler",
                                  plot_to_add_to=Second_step,
                                  plot_type="alert",
                                  add_col_alert = "peru") +
  scale_color_manual(values=c("brown","orangered2","peru"),labels=c("Complex (fast)","Constant (fast)","Complex (normal)","Case 2 (fast)"))+
  ggtitle("Alerts") +
  annotate("point", x = 4, y = 6.8, color = "orangered2", size = 2)+
  annotate("point", x = 4, y = 5.6, color = "peru", size = 2)+
  annotate("point", x = 4, y = 5.4, color = "brown", size = 2)
  

#Alert_comp_smallest_aic_all

Alert_comp_smallest_aic<-Second_step+
  ggtitle("Alerts") +
  scale_color_manual(values=c("brown","orangered2"),labels=c("Complex","Constant"))+
  annotate("point", x = 4, y = 6.8, color = "orangered2", size = 2)+
  annotate("point", x = 4, y = 5.4, color = "brown", size = 2)

#'------------------------------------------------------------------------------
#####  Smallest AIC  reduced ----
#'------------------------------------------------------------------------------

# First_step <- add_to_plot_analysis(dat=data_subset_reduced,fit=td2pLL_fit_gamlss_nl_donor_reduced_case1,     #Case 1 and 2
#                      res=td2pLL_analysis_gamlssnl_donor_reduced_CASE1,model="td2pLL",
#                      plot_to_add_to=p_res_td2pLL_fast_case1_reduced$alert_plot,
#                      plot_type="alert",
#                      add_col_alert =  "orange") + 
#   scale_color_manual(values=c("orange","orangered2"),labels=c("Constant (normal)","Constant (fast)")) 

First_step <- p_res_td2pLL_fast_reduced_case1$alert_plot+
  scale_color_manual(values=c("orangered2"),labels=c("Constant (fast)")) 

Second_step<-add_to_plot_analysis(dat=data_subset_reduced,fit=td2pLL_fit_gamlss_nl_donor_reduced_case2,     #Case 1 and 2
                                  res=td2pLL_analysis_gamlssnl_donor_fast_reduced_CASE2,model="td2pLL",
                                  plot_to_add_to=First_step,
                                  plot_type="alert",
                                  add_col_alert = "brown") +
  scale_color_manual(values=c("brown","orangered2"),labels=c("Complex (fast)","Constant (fast)"))


Alert_comp_smallest_aic_reduced_all <- add_to_plot_analysis(dat=data_subset_reduced,fit=td2pLL_fit_gamlss_nl_donor_reduced_case2,     #Case 1 and 2
                                                res=td2pLL_analysis_gamlssnl_donor_reduced_CASE2,model="td2pLL",
                                                plot_to_add_to=Second_step,
                                                plot_type="alert",
                                                add_col_alert = "peru") +
  scale_color_manual(values=c("brown","orangered2","peru"),labels=c("Complex (fast)","Constant (fast)","Complex (normal)","Case 2 (fast)"))+
  ggtitle("Alerts") +
  annotate("point", x = 4, y = 7.9, color = "orangered2", size = 2)+
  annotate("point", x = 4, y = 6.8, color = "peru", size = 2)+
  annotate("point", x = 4, y = 6.7, color = "brown", size = 2)


Alert_comp_smallest_aic_reduced<-Second_step+
  ggtitle("Alerts") +
  scale_color_manual(values=c("brown","orangered2"),labels=c("Complex","Constant"))+
  annotate("point", x = 4, y = 7.9, color = "orangered2", size = 2)+
  annotate("point", x = 4, y = 6.7, color = "brown", size = 2)

#'------------------------------------------------------------------------------
#####  Larger AIC full  ----
#'------------------------------------------------------------------------------

# First_step <- add_to_plot_analysis(dat=data_subset,fit=schuettler_fit_gamlss_nl_donor_case1,     #Case 1 and 2
#                      res=schuettler_analysis_gamlssnl_donor_CASE1,model="schuettler",
#                      plot_to_add_to=p_res_schuettler_fast_case1$alert_plot,
#                      plot_type="alert",
#                      add_col_alert =  "orange") + 
#   scale_color_manual(values=c("orange","orangered2"),labels=c("Constant (normal)","Constant (fast)")) 

First_step <- p_res_schuettler_fast_case1$alert_plot+
  scale_color_manual(values=c("orangered2"),labels=c("Constant (fast)")) 

Second_step<-add_to_plot_analysis(dat=data_subset,fit=td2pLL_fit_gamlss_nl_donor_case2,     #Case 1 and 2
                                  res=td2pLL_analysis_gamlssnl_donor_fast_CASE2,model="td2pLL",
                                  plot_to_add_to=First_step,
                                  plot_type="alert",
                                  add_col_alert = "brown") +
  scale_color_manual(values=c("brown","orangered2"),labels=c("Complex (fast)","Constant (fast)"))


Alert_comp_largest_aic_all <- add_to_plot_analysis(dat=data_subset,fit=td2pLL_fit_gamlss_nl_donor_case2,     #Case 1 and 2
                                                res=td2pLL_analysis_gamlssnl_donor_CASE2,model="td2pLL",
                                                plot_to_add_to=Second_step,
                                                plot_type="alert",
                                                add_col_alert = "peru") +
  scale_color_manual(values=c("brown","orangered2","peru"),labels=c("Complex (fast)","Constant (fast)","Complex (normal)","Case 2 (fast)"))+
  ggtitle("Alerts") +
  annotate("point", x = 4, y = 6.8, color = "orangered2", size = 2)+
  annotate("point", x = 4, y = 5.6, color = "peru", size = 2)+
  annotate("point", x = 4, y = 5.4, color = "brown", size = 2)


#Alert_comp_largest_aic_all

Alert_comp_largest_aic<-Second_step+
  ggtitle("Alerts") +
  scale_color_manual(values=c("brown","orangered2"),labels=c("Complex","Constant"))+
  annotate("point", x = 4, y = 6.8, color = "orangered2", size = 2)+
  annotate("point", x = 4, y = 5.4, color = "brown", size = 2)

#'------------------------------------------------------------------------------
#####  Largest AIC  reduced ----
#'------------------------------------------------------------------------------

# First_step <- add_to_plot_analysis(dat=data_subset_reduced,fit=schuettler_fit_gamlss_nl_donor_reduced_case1,     #Case 1 and 2
#                      res=schuettler_analysis_gamlssnl_donor_reduced_CASE1,model="schuettler",
#                      plot_to_add_to=p_res_schuettler_fast_case1_reduced$alert_plot,
#                      plot_type="alert",
#                      add_col_alert =  "orange") + 
#   scale_color_manual(values=c("orange","orangered2"),labels=c("Constant (normal)","Constant (fast)")) 

First_step <- p_res_schuettler_fast_reduced_case1$alert_plot+
  scale_color_manual(values=c("orangered2"),labels=c("Constant (fast)")) 

Second_step<-add_to_plot_analysis(dat=data_subset_reduced,fit=schuettler_fit_gamlss_nl_donor_reduced_case2,     #Case 1 and 2
                                  res=schuettler_analysis_gamlssnl_donor_fast_reduced_CASE2,model="schuettler",
                                  plot_to_add_to=First_step,
                                  plot_type="alert",
                                  add_col_alert = "brown") +
  scale_color_manual(values=c("brown","orangered2"),labels=c("Complex (fast)","Constant (fast)"))


Alert_comp_largest_aic_reduced_all <- add_to_plot_analysis(dat=data_subset_reduced,fit=schuettler_fit_gamlss_nl_donor_reduced_case2,     #Case 1 and 2
                                                res=schuettler_analysis_gamlssnl_donor_reduced_CASE2,model="schuettler",
                                                plot_to_add_to=Second_step,
                                                plot_type="alert",
                                                add_col_alert = "peru") +
  scale_color_manual(values=c("brown","orangered2","peru"),labels=c("Complex (fast)","Constant (fast)","Complex (normal)","Case 2 (fast)"))+
  ggtitle("Alerts") +
  annotate("point", x = 4, y = 8.3, color = "orangered2", size = 2)+
  annotate("point", x = 4, y = 7.9, color = "peru", size = 2)+
  annotate("point", x = 4, y = 7.3, color = "brown", size = 2)


Alert_comp_largest_aic_reduced<-Second_step+
  ggtitle("Alerts") +
  scale_color_manual(values=c("brown","orangered2"),labels=c("Complex","Constant"))+
  annotate("point", x = 4, y = 8.3, color = "orangered2", size = 2)+
  annotate("point", x = 4, y = 7.3, color = "brown", size = 2)

#'------------------------------------------------------------------------------
#### Combined Plots ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
#####  Smallest AIC   ----
#'------------------------------------------------------------------------------

#Full plot
(confband_comp_td2pLL_case1+confband_comp_schuettler_case2+Alert_comp_smallest_aic_all)/
(confband_comp_td2pLL_reduced_case1+confband_comp_td2pLL_reduced_case2+Alert_comp_smallest_aic_reduced_all)+
  plot_layout(guides = "collect")

ggsave("./plots_tables/115_fig_2dim_res_smallest_aic_full.pdf",height=12,width=15)

#only fast
(p_res_td2pLL_fast_case1$dim2res+p_res_schuettler_fast_case2$dim2res+Alert_comp_smallest_aic)/
(p_res_td2pLL_fast_reduced_case1$dim2res+p_res_td2pLL_fast_reduced_case2$dim2res+Alert_comp_smallest_aic_reduced)+
  plot_layout(guides = "collect")  
  
ggsave("./plots_tables/008_fig_2dim_res_smallest_aic.pdf",height=12,width=15)

#'------------------------------------------------------------------------------
#####  Larger AIC   ----
#'------------------------------------------------------------------------------

#full plot
(confband_comp_schuettler_case1+confband_comp_td2pLL_case2+Alert_comp_largest_aic_all)/
  (confband_comp_schuettler_reduced_case1+confband_comp_schuettler_reduced_case2+Alert_comp_largest_aic_reduced_all)+
  plot_layout(guides = "collect")

ggsave("./plots_tables/116_fig_2dim_res_larger_aic_full.pdf",height=12,width=15)


# #Only fast
# (p_res_schuettler_fast_case1$dim2res+p_res_td2pLL_fast_case2$dim2res+Alert_comp_largest_aic)/
#   (p_res_schuettler_fast_reduced_case1$dim2res+p_res_schuettler_fast_reduced_case2$dim2res+Alert_comp_largest_aic_reduced)+
#   plot_layout(guides = "collect")  

#' 
#' #'==============================================================================
#' ## Analysis case study- Centered ====
#' #'==============================================================================
#' 
#' #'------------------------------------------------------------------------------
#' ### td2pLL -----
#' #' -----------------------------------------------------------------------------
#' 
#' 
#' #'------------------------------------------------------------------------------
#' #### td2pLL (fixtime=4) -----
#' #' -----------------------------------------------------------------------------
#' 
#' #case1
#' p_res_td2pLL_centered_case1 <- plot_analysis_centered(dat=data_subset,
#'                                     fit=td2pLL_fit_gamlss_nl_donor_case1,
#'                                     res=centered_td2pLL_analysis_gamlssnl_donor_CASE1,
#'                                     model="td2pLL",
#'                                     title_cb = "td2pLL: Case 1",
#'                                     title_2dim = "td2pLL: Case 1",
#'                                     size_3dim_fit_cb = c(13,13,13),
#'                                     size_2dim = c(17,19,7,21) )
#' 
#' #case2
#' p_res_td2pLL_centered_case2 <- plot_analysis_centered(dat=data_subset,
#'                                     fit=td2pLL_fit_gamlss_nl_donor_case2,
#'                                     res=centered_td2pLL_analysis_gamlssnl_donor_CASE2,
#'                                     col_alert = "brown",
#'                                     title_cb = "td2pLL: Case 2",
#'                                     title_2dim = "td2pLL: Case 2",
#'                                     col_alert_2dim = "brown",
#'                                     model="td2pLL",
#'                                     size_3dim_fit_cb = c(13,13,13),
#'                                     size_2dim = c(17,19,7,21))
#' 
#' 
#' 
#' 
#' #'------------------------------------------------------------------------------
#' #### td2pLL (fixtime/fast) ----
#' #' -----------------------------------------------------------------------------
#' 
#' #case1
#' p_res_td2pLL_fast_centered_case1 <- plot_analysis_centered(dat=data_subset,
#'                                          fit=td2pLL_fit_gamlss_nl_donor_case1,
#'                                          res=centered_td2pLL_analysis_gamlssnl_donor_fast_CASE1,
#'                                          model="td2pLL",
#'                                          col_cb = c("cornflowerblue","lightblue"),
#'                                          col_alert = "orange",
#'                                          col_cb_2dim="lightblue",
#'                                          col_alert_2dim = "orange",
#'                                          title_cb = "td2pLL: Case 1 (fast alg.)",
#'                                          title_2dim  = "td2pLL: Case 1 (fast alg.)", 
#'                                          size_3dim_fit_cb = c(13,13,13),
#'                                          size_2dim = c(17,19,7,21))
#' 
#' #case2
#' p_res_td2pLL_centered_fast_case2 <- plot_analysis_centered(dat=data_subset,
#'                                          fit=td2pLL_fit_gamlss_nl_donor_case2,
#'                                          res=centered_td2pLL_analysis_gamlssnl_donor_fast_CASE2,
#'                                          col_cb = c("cornflowerblue","lightblue"),
#'                                          col_alert="peru",
#'                                          col_cb_2dim="lightblue",
#'                                          col_alert_2dim = "peru",
#'                                          title_cb = "td2pLL: Case 2 (fast alg.)",
#'                                          title_2dim = "td2pLL: Case 2 (fast alg.)",
#'                                          model="td2pLL",
#'                                          size_3dim_fit_cb = c(13,13,13),
#'                                          size_2dim = c(17,19,7,21))
#' 
#' 
#' 
#' #'------------------------------------------------------------------------------
#' #### td2pLL (fixtime=4/reduced) ----
#' #' -----------------------------------------------------------------------------
#' 
#' #case1
#' p_res_td2pLL_centered_reduced_case1 <- plot_analysis_centered(dat=data_subset_reduced,
#'                                             fit=td2pLL_fit_gamlss_nl_donor_reduced_case1,
#'                                             res=centered_td2pLL_analysis_gamlssnl_donor_reduced_CASE1,
#'                                             model="td2pLL",
#'                                             title_cb = "td2pLL: Case 1 (reduced data)",
#'                                             title_2dim = "td2pLL: Case 1 (reduced data)",
#'                                             size_3dim_fit_cb = c(13,13,13),
#'                                             size_2dim = c(17,19,7,21))
#' 
#' #case2
#' p_res_td2pLL_centered_reduced_case2 <- plot_analysis_centered(dat=data_subset_reduced,
#'                                             fit=td2pLL_fit_gamlss_nl_donor_reduced_case2,
#'                                             res=centered_td2pLL_analysis_gamlssnl_donor_reduced_CASE2,
#'                                             col_alert = "brown",
#'                                             col_alert_2dim = "brown",
#'                                             model="td2pLL",
#'                                             title_cb = "td2pLL: Case 2 (reduced data)",
#'                                             title_2dim = "td2pLL: Case 2 (reduced data)",
#'                                             size_3dim_fit_cb = c(13,13,13),
#'                                             size_2dim = c(17,19,7,21))
#' 
#' 
#' 
#' 
#' 
#' #'------------------------------------------------------------------------------
#' #### td2pLL (fixtime/fast/reduced) ----
#' #' -----------------------------------------------------------------------------
#' 
#' #case1
#' p_res_td2pLL_centered_fast_reduced_case1 <- plot_analysis_centered(dat=data_subset_reduced,
#'                                                  fit=td2pLL_fit_gamlss_nl_donor_reduced_case1,
#'                                                  res=centered_td2pLL_analysis_gamlssnl_donor_fast_reduced_CASE1,
#'                                                  col_cb = c("cornflowerblue","lightblue"),
#'                                                  col_alert = "orange",
#'                                                  col_cb_2dim="lightblue",
#'                                                  col_alert_2dim = "orange",
#'                                                  model="td2pLL",
#'                                                  title_cb = "td2pLL: Case 1 (reduced data/fast alg.)",
#'                                                  title_2dim = "td2pLL: Case 1 (reduced data/fast alg.)",
#'                                                  size_3dim_fit_cb = c(13,13,13),
#'                                                  size_2dim = c(17,19,7,21))
#' 
#' #case2
#' p_res_td2pLL_centered_fast_reduced_case2 <- plot_analysis_centered(dat=data_subset_reduced,
#'                                                  fit=td2pLL_fit_gamlss_nl_donor_reduced_case2,
#'                                                  res=centered_td2pLL_analysis_gamlssnl_donor_fast_reduced_CASE2,
#'                                                  col_cb = c("cornflowerblue","lightblue"),
#'                                                  col_alert = "peru",
#'                                                  col_cb_2dim="lightblue",
#'                                                  col_alert_2dim = "peru",
#'                                                  model="td2pLL",
#'                                                  title_cb = "td2pLL: Case 2 (reduced data/fast alg.)",
#'                                                  title_2dim = "td2pLL: Case 2 (reduced data/fast alg.)",
#'                                                  size_3dim_fit_cb = c(13,13,13),
#'                                                  size_2dim = c(17,19,7,21))
#' 
#' 
#' #'------------------------------------------------------------------------------
#' ### schuettler -----
#' #' -----------------------------------------------------------------------------
#' 
#' 
#' 
#' #'------------------------------------------------------------------------------
#' #### schuettler (fixtime=4) -----
#' #' -----------------------------------------------------------------------------
#' 
#' #case1
#' p_res_schuettler_centered_case1 <- plot_analysis_centered(dat=data_subset,
#'                                         fit=schuettler_fit_gamlss_nl_donor_case1,
#'                                         res=centered_schuettler_analysis_gamlssnl_donor_CASE1,
#'                                         model="schuettler",
#'                                         title_cb = "schuettler: Case 1",
#'                                         title_2dim = "schuettler: Case 1",
#'                                         size_3dim_fit_cb = c(13,13,13),
#'                                         size_2dim = c(17,19,7,21))
#' 
#' #case2
#' p_res_schuettler_centered_case2 <- plot_analysis_centered(dat=data_subset,
#'                                         fit=schuettler_fit_gamlss_nl_donor_case2,
#'                                         res=centered_schuettler_analysis_gamlssnl_donor_CASE2,
#'                                         col_alert = "brown",
#'                                         title_cb = "schuettler: Case 2",
#'                                         title_2dim = "schuettler:Case 2",
#'                                         col_alert_2dim = "brown",
#'                                         model="schuettler",
#'                                         size_3dim_fit_cb = c(13,13,13),
#'                                         size_2dim = c(17,19,7,21))
#' 
#' 
#' 
#' 
#' #'------------------------------------------------------------------------------
#' #### schuettler (fixtime/fast) ----
#' #' -----------------------------------------------------------------------------
#' 
#' #case1
#' p_res_schuettler_centered_fast_case1 <- plot_analysis_centered(dat=data_subset,
#'                                              fit=schuettler_fit_gamlss_nl_donor_case1,
#'                                              res=centered_schuettler_analysis_gamlssnl_donor_fast_CASE1,
#'                                              model="schuettler",
#'                                              col_cb = c("cornflowerblue","lightblue"),
#'                                              col_alert = "orange",
#'                                              col_cb_2dim="lightblue",
#'                                              col_alert_2dim = "orange",
#'                                              title_cb = "schuettler: Case 1 (fast alg.)",
#'                                              title_2dim  = "schuettler: Case 1 (fast alg.)", 
#'                                              size_3dim_fit_cb = c(13,13,13),
#'                                              size_2dim = c(17,19,7,21))
#' 
#' #case2
#' p_res_schuettler_centered_fast_case2 <- plot_analysis_centered(dat=data_subset,
#'                                              fit=schuettler_fit_gamlss_nl_donor_case2,
#'                                              res=centered_schuettler_analysis_gamlssnl_donor_fast_CASE2,
#'                                              col_cb = c("cornflowerblue","lightblue"),
#'                                              col_alert="peru",
#'                                              col_cb_2dim="lightblue",
#'                                              col_alert_2dim = "peru",
#'                                              title_cb = "schuettler: Case 2 (fast alg.)",
#'                                              title_2dim = "schuettler: Case 2 (fast alg.)",
#'                                              model="schuettler",
#'                                              size_3dim_fit_cb = c(13,13,13),
#'                                              size_2dim = c(17,19,7,21))
#' 
#' 
#' 
#' #'------------------------------------------------------------------------------
#' #### schuettler (fixtime=4/reduced) ----
#' #' -----------------------------------------------------------------------------
#' 
#' #case1
#' p_res_schuettler_centered_reduced_case1 <- plot_analysis_centered(dat=data_subset_reduced,
#'                                                 fit=schuettler_fit_gamlss_nl_donor_reduced_case1,
#'                                                 res=centered_schuettler_analysis_gamlssnl_donor_reduced_CASE1,
#'                                                 model="schuettler",
#'                                                 title_cb = "schuettler: Case 1 (reduced data)",
#'                                                 title_2dim = "schuettler: Case 1 (reduced data)",
#'                                                 size_3dim_fit_cb = c(13,13,13),
#'                                                 size_2dim = c(17,19,7,21))
#' 
#' #case2
#' p_res_schuettler_centered_reduced_case2 <- plot_analysis_centered(dat=data_subset_reduced,
#'                                                 fit=schuettler_fit_gamlss_nl_donor_reduced_case2,
#'                                                 res=centered_schuettler_analysis_gamlssnl_donor_reduced_CASE2,
#'                                                 col_alert = "brown",
#'                                                 col_alert_2dim = "brown",
#'                                                 model="schuettler",
#'                                                 title_cb = "schuettler: Case 2 (reduced data)",
#'                                                 title_2dim = "schuettler: Case 2 (reduced data)",
#'                                                 size_3dim_fit_cb = c(13,13,13),
#'                                                 size_2dim = c(17,19,7,21))
#' 
#' 
#' 
#' 
#' 
#' #'------------------------------------------------------------------------------
#' #### schuettler (fixtime/fast/reduced) ----
#' #' -----------------------------------------------------------------------------
#' 
#' #case1
#' p_res_schuettler_centered_fast_reduced_case1 <- plot_analysis_centered(dat=data_subset_reduced,
#'                                                      fit=schuettler_fit_gamlss_nl_donor_reduced_case1,
#'                                                      res=centered_schuettler_analysis_gamlssnl_donor_fast_reduced_CASE1,
#'                                                      col_cb = c("cornflowerblue","lightblue"),
#'                                                      col_alert = "orange",
#'                                                      col_cb_2dim="lightblue",
#'                                                      col_alert_2dim = "orange",
#'                                                      model="schuettler",
#'                                                      title_cb = "schuettler: Case 1 (reduced data/fast alg.)",
#'                                                      title_2dim = "schuettler: Case 1 (reduced data/fast alg.)",
#'                                                      size_3dim_fit_cb = c(13,13,13),
#'                                                      size_2dim = c(17,19,7,21))
#' 
#' #case2
#' p_res_schuettler_centered_fast_reduced_case2 <- plot_analysis_centered(dat=data_subset_reduced,
#'                                                      fit=schuettler_fit_gamlss_nl_donor_reduced_case2,
#'                                                      res=centered_schuettler_analysis_gamlssnl_donor_fast_reduced_CASE2,
#'                                                      col_cb = c("cornflowerblue","lightblue"),
#'                                                      col_alert = "peru",
#'                                                      col_cb_2dim="lightblue",
#'                                                      col_alert_2dim = "peru",
#'                                                      model="schuettler",
#'                                                      title_cb = "schuettler: Case 2 (reduced data/fast alg.)",
#'                                                      title_2dim = "schuettler: Case 2 (reduced data/fast alg.)",
#'                                                      size_3dim_fit_cb = c(13,13,13),
#'                                                      size_2dim = c(17,19,7,21))
#' 
#' 
#' #'==============================================================================
#' ## Comparing cases ====
#' #'==============================================================================
#' 
#' #'------------------------------------------------------------------------------
#' ### CB comparison ----
#' #'------------------------------------------------------------------------------
#' 
#' #'------------------------------------------------------------------------------
#' ##### td2pLL ----
#' #'------------------------------------------------------------------------------
#' 
#' 
#' p_res_td2pLL_centered_case1_conf_fit_cleaned <- save_and_clean_3d_plots( p = p_res_td2pLL_centered_case1$conf_fit,
#'                                                                 p_file_name = "p_res_td2pll_centered_case1_tmp",
#'                                                                 save_file = F )
#' p_res_td2pLL_centered_case2_conf_fit_cleaned <- save_and_clean_3d_plots( p = p_res_td2pLL_centered_case2$conf_fit,
#'                                                                 p_file_name = "p_res_td2pll_centered_case2_tmp",
#'                                                                 save_file = F )
#' 
#' 
#' p_res_td2pLL_centered_reduced_case1_conf_fit_cleaned <- save_and_clean_3d_plots( p = p_res_td2pLL_centered_reduced_case1$conf_fit,
#'                                                                         p_file_name = "p_res_td2pll_centered_reduced_case1_tmp",
#'                                                                         save_file = F )
#' p_res_td2pLL_centered_reduced_case2_conf_fit_cleaned <- save_and_clean_3d_plots( p = p_res_td2pLL_centered_reduced_case2$conf_fit,
#'                                                                         p_file_name = "p_res_td2pll_centered_reduced_case2_tmp",
#'                                                                         save_file = F )
#' 
#' 
#' #'------------------------------------------------------------------------------
#' ##### schuettler ----
#' #'------------------------------------------------------------------------------
#' 
#' 
#' p_res_schuettler_centered_case1_conf_fit_cleaned <- save_and_clean_3d_plots( p = p_res_schuettler_centered_case1$conf_fit,
#'                                                                     p_file_name = "p_res_schuettler_centered_case1_tmp",
#'                                                                     save_file = F )
#' p_res_schuettler_centered_case2_conf_fit_cleaned <- save_and_clean_3d_plots( p = p_res_schuettler_centered_case2$conf_fit,
#'                                                                     p_file_name = "p_res_schuettler_centered_case2_tmp",
#'                                                                     save_file = F )
#' 
#' 
#' p_res_schuettler_centered_reduced_case1_conf_fit_cleaned <- save_and_clean_3d_plots( p = p_res_schuettler_centered_reduced_case1$conf_fit,
#'                                                                             p_file_name = "p_res_schuettler_centered_reduced_case1_tmp",
#'                                                                             save_file = F )
#' p_res_schuettler_centered_reduced_case2_conf_fit_cleaned <- save_and_clean_3d_plots( p = p_res_schuettler_centered_reduced_case2$conf_fit,
#'                                                                             p_file_name = "p_res_schuettler_centered_reduced_case2_tmp",
#'                                                                             save_file = F )
#' 
#' 
#' #'------------------------------------------------------------------------------
#' ##### Combining Plots ----
#' #'------------------------------------------------------------------------------
#' 
#' #Smallest AIC
#' (p_res_td2pLL_centered_case1_conf_fit_cleaned+p_res_schuettler_centered_case2_conf_fit_cleaned)/
#'   (p_res_td2pLL_centered_reduced_case1_conf_fit_cleaned+p_res_td2pLL_centered_reduced_case2_conf_fit_cleaned)
#' ggsave("./plots_tables/106_fig_centered_3d_res_smallest_aic.pdf",width=12,height=12,unit="cm")
#' 
#' 
#' 
#' #Larger AIC
#' (p_res_schuettler_centered_case1_conf_fit_cleaned+p_res_td2pLL_centered_case2_conf_fit_cleaned)/
#'   (p_res_schuettler_centered_reduced_case1_conf_fit_cleaned+p_res_schuettler_centered_reduced_case2_conf_fit_cleaned)
#' ggsave("./plots_tables/107_fig_centered_3d_res_larger_aic.pdf",width=12,height=12,unit="cm")
#' 
#' 
#' #'------------------------------------------------------------------------------
#' ### 2 dim results ----
#' #'------------------------------------------------------------------------------
#' 
#' #'------------------------------------------------------------------------------
#' #### Conf bands ----
#' #'------------------------------------------------------------------------------
#' 
#' #'------------------------------------------------------------------------------
#' #####  td2pLL full ----
#' #'------------------------------------------------------------------------------
#' 
#' confband_comp_td2pLL_centered_case1 <- add_to_plot_analysis_centered(dat=data_subset,fit=td2pLL_fit_gamlss_nl_donor_case1,     #Case 1 and 2
#'                                                    res=centered_td2pLL_analysis_gamlssnl_donor_fast_CASE1,model="td2pLL",
#'                                                    plot_to_add_to=p_res_td2pLL_centered_case1$dim2res,
#'                                                    plot_type="dim2res",
#'                                                    add_col_dim2res = c("black","lightblue","lightblue"),
#'                                                    add_col_alert_dim2res = "orange") +
#'   scale_color_manual(values=c("black","blue","lightblue"),labels=c("Model fit","CB (normal)", "CB (fast)")) 
#' 
#' 
#' confband_comp_td2pLL_centered_case2 <- add_to_plot_analysis_centered(dat=data_subset,fit=td2pLL_fit_gamlss_nl_donor_case2,     #Case 1 and 2
#'                                                    res=centered_td2pLL_analysis_gamlssnl_donor_fast_CASE2,model="td2pLL",
#'                                                    plot_to_add_to=p_res_td2pLL_centered_case2$dim2res,
#'                                                    plot_type="dim2res",
#'                                                    add_col_dim2res = c("black","lightblue","lightblue"),
#'                                                    add_col_alert_dim2res = "peru") +
#'   scale_color_manual(values=c("black","blue","lightblue"),labels=c("Model fit","CB (normal)", "CB (fast)")) 
#' 
#' 
#' 
#' #'------------------------------------------------------------------------------
#' #####  td2pLL reduced ----
#' #'------------------------------------------------------------------------------
#' 
#' confband_comp_td2pLL_centered_reduced_case1 <- add_to_plot_analysis_centered(dat=data_subset,fit=td2pLL_fit_gamlss_nl_donor_reduced_case1,     #Case 1 and 2
#'                                                            res=centered_td2pLL_analysis_gamlssnl_donor_fast_reduced_CASE1,model="td2pLL",
#'                                                            plot_to_add_to=p_res_td2pLL_centered_reduced_case1$dim2res,
#'                                                            plot_type="dim2res",
#'                                                            add_col_dim2res = c("black","lightblue","lightblue"),
#'                                                            add_col_alert_dim2res = "orange") +
#'   scale_color_manual(values=c("black","blue","lightblue"),labels=c("Model fit","CB (normal)", "CB (fast)")) 
#' 
#' confband_comp_td2pLL_centered_reduced_case2 <- add_to_plot_analysis_centered(dat=data_subset,fit=td2pLL_fit_gamlss_nl_donor_reduced_case2,     #Case 1 and 2
#'                                                            res=centered_td2pLL_analysis_gamlssnl_donor_fast_reduced_CASE2,model="td2pLL",
#'                                                            plot_to_add_to=p_res_td2pLL_centered_reduced_case2$dim2res,
#'                                                            plot_type="dim2res",
#'                                                            add_col_dim2res = c("black","lightblue","lightblue"),
#'                                                            add_col_alert_dim2res = "peru") +
#'   scale_color_manual(values=c("black","blue","lightblue"),labels=c("Model fit","CB (normal)", "CB (fast)")) 
#' 
#' 
#' 
#' 
#' 
#' #'------------------------------------------------------------------------------
#' #####  schuettler full ----
#' #'------------------------------------------------------------------------------
#' 
#' confband_comp_schuettler_centered_case1 <- add_to_plot_analysis_centered(dat=data_subset,fit=schuettler_fit_gamlss_nl_donor_case1,     #Case 1 and 2
#'                                                        res=centered_schuettler_analysis_gamlssnl_donor_fast_CASE1,model="schuettler",
#'                                                        plot_to_add_to=p_res_schuettler_centered_case1$dim2res,
#'                                                        plot_type="dim2res",
#'                                                        add_col_dim2res = c("black","lightblue","lightblue"),
#'                                                        add_col_alert_dim2res = "orange") +
#'   scale_color_manual(values=c("black","blue","lightblue"),labels=c("Model fit","CB (normal)", "CB (fast)")) 
#' 
#' 
#' confband_comp_schuettler_centered_case2 <- add_to_plot_analysis_centered(dat=data_subset,fit=schuettler_fit_gamlss_nl_donor_case2,     #Case 1 and 2
#'                                                        res=centered_schuettler_analysis_gamlssnl_donor_fast_CASE2,model="schuettler",
#'                                                        plot_to_add_to=p_res_schuettler_centered_case2$dim2res,
#'                                                        plot_type="dim2res",
#'                                                        add_col_dim2res = c("black","lightblue","lightblue"),
#'                                                        add_col_alert_dim2res = "peru") +
#'   scale_color_manual(values=c("black","blue","lightblue"),labels=c("Model fit","CB (normal)", "CB (fast)")) 
#' 
#' 
#' 
#' #'------------------------------------------------------------------------------
#' #####  schuettler reduced ----
#' #'------------------------------------------------------------------------------
#' 
#' confband_comp_schuettler_centered_reduced_case1 <- add_to_plot_analysis_centered(dat=data_subset,fit=schuettler_fit_gamlss_nl_donor_reduced_case1,     #Case 1 and 2
#'                                                                res=centered_schuettler_analysis_gamlssnl_donor_fast_reduced_CASE1,model="schuettler",
#'                                                                plot_to_add_to=p_res_schuettler_centered_reduced_case1$dim2res,
#'                                                                plot_type="dim2res",
#'                                                                add_col_dim2res = c("black","lightblue","lightblue"),
#'                                                                add_col_alert_dim2res = "orange") +
#'   scale_color_manual(values=c("black","blue","lightblue"),labels=c("Model fit","CB (normal)", "CB (fast)")) 
#' 
#' confband_comp_schuettler_centered_reduced_case2 <- add_to_plot_analysis_centered(dat=data_subset,fit=schuettler_fit_gamlss_nl_donor_reduced_case2,     #Case 1 and 2
#'                                                                res=centered_schuettler_analysis_gamlssnl_donor_fast_reduced_CASE2,model="schuettler",
#'                                                                plot_to_add_to=p_res_schuettler_centered_reduced_case2$dim2res,
#'                                                                plot_type="dim2res",
#'                                                                add_col_dim2res = c("black","lightblue","lightblue"),
#'                                                                add_col_alert_dim2res = "peru") +
#'   scale_color_manual(values=c("black","blue","lightblue"),labels=c("Model fit","CB (normal)", "CB (fast)")) 
#' 
#' 
#' 
#' #'------------------------------------------------------------------------------
#' #### Alert ----
#' #'------------------------------------------------------------------------------
#' 
#' #'------------------------------------------------------------------------------
#' #####  Smallest AIC full  ----
#' #'------------------------------------------------------------------------------
#' 
#' First_step <- add_to_plot_analysis_centered(dat=data_subset,fit=td2pLL_fit_gamlss_nl_donor_case1,     #Case 1 and 2
#'                                    res=centered_td2pLL_analysis_gamlssnl_donor_fast_CASE1,model="td2pLL",
#'                                    plot_to_add_to=p_res_td2pLL_centered_case1$alert_plot,
#'                                    plot_type="alert",
#'                                    add_col_alert =  "orange") + 
#'   scale_color_manual(values=c("orange","orangered2"),labels=c("Case 1 (fast)","Case 1 (normal)")) 
#' 
#' 
#' Second_step<-add_to_plot_analysis_centered(dat=data_subset,fit=schuettler_fit_gamlss_nl_donor_case2,     #Case 1 and 2
#'                                   res=centered_schuettler_analysis_gamlssnl_donor_CASE2,model="schuettler",
#'                                   plot_to_add_to=First_step,
#'                                   plot_type="alert",
#'                                   add_col_alert = "brown") +
#'   scale_color_manual(values=c("brown","orange","orangered2"),labels=c("Case 2 (normal)","Case 1 (fast)","Case 1 (normal)"))
#' 
#' 
#' Alert_comp_centered_smallest_aic <- add_to_plot_analysis_centered(dat=data_subset,fit=schuettler_fit_gamlss_nl_donor_case2,     #Case 1 and 2
#'                                                 res=centered_schuettler_analysis_gamlssnl_donor_fast_CASE2,model="schuettler",
#'                                                 plot_to_add_to=Second_step,
#'                                                 plot_type="alert",
#'                                                 add_col_alert = "peru") +
#'   scale_color_manual(values=c("brown","orange","orangered2","peru"),labels=c("Case 2 (normal)","Case 1 (fast)","Case 1 (normal)","Case 2 (fast)"))+
#'   ggtitle("Alerts")+
#'   geom_vline(xintercept = 4,col="darkgrey")
#' 
#' 
#' 
#' 
#' #'------------------------------------------------------------------------------
#' #####  Smallest AIC  reduced ----
#' #'------------------------------------------------------------------------------
#' First_step <- add_to_plot_analysis_centered(dat=data_subset_reduced,fit=td2pLL_fit_gamlss_nl_donor_reduced_case2,     #Case 1 and 2
#'                                    res=centered_td2pLL_analysis_gamlssnl_donor_reduced_CASE2,model="td2pLL",
#'                                    plot_to_add_to=p_res_td2pLL_centered_reduced_case1$alert_plot,
#'                                    plot_type="alert",
#'                                    add_col_alert =  "brown") + 
#'   scale_color_manual(values=c("brown","orangered2"),labels=c("Case 2 (normal)","Case 1 (normal)")) 
#' 
#' 
#' Second_step<-add_to_plot_analysis_centered(dat=data_subset_reduced,fit=td2pLL_fit_gamlss_nl_donor_reduced_case1,     #Case 1 and 2
#'                                   res=centered_td2pLL_analysis_gamlssnl_donor_fast_reduced_CASE1,model="td2pLL",
#'                                   plot_to_add_to=First_step,
#'                                   plot_type="alert",
#'                                   add_col_alert = "orange") +
#'   scale_color_manual(values=c("brown","orange","orangered2"),labels=c("Case 2 (normal)","Case 1 (fast)","Case 1 (normal)"))
#' 
#' 
#' Alert_comp_centered_smallest_aic_reduced <- add_to_plot_analysis_centered(dat=data_subset_reduced,fit=td2pLL_fit_gamlss_nl_donor_reduced_case2,     #Case 1 and 2
#'                                                         res=centered_td2pLL_analysis_gamlssnl_donor_fast_reduced_CASE2,model="td2pLL",
#'                                                         plot_to_add_to=Second_step,
#'                                                         plot_type="alert",
#'                                                         add_col_alert = "peru") +
#'   scale_color_manual(values=c("brown","orange","orangered2","peru"),labels=c("Case 2 (normal)","Case 1 (fast)","Case 1 (normal)","Case 2 (fast)"))+
#'   guides(color="none") +
#'   ggtitle("Alerts (reduced data)")+
#'   geom_vline(xintercept = 4,col="darkgrey")
#' 
#' 
#' 
#' 
#' #'------------------------------------------------------------------------------
#' #####  Larger AIC full ----
#' #'------------------------------------------------------------------------------
#' 
#' 
#' First_step <- add_to_plot_analysis_centered(dat=data_subset,fit=schuettler_fit_gamlss_nl_donor_case1,     #Case 1 and 2
#'                                    res=centered_schuettler_analysis_gamlssnl_donor_fast_CASE1,model="schuettler",
#'                                    plot_to_add_to=p_res_schuettler_centered_case1$alert_plot,
#'                                    plot_type="alert",
#'                                    add_col_alert =  "orange") + 
#'   scale_color_manual(values=c("orange","orangered2"),labels=c("Case 1 (fast)","Case 1 (normal)")) 
#' 
#' 
#' Second_step<-add_to_plot_analysis_centered(dat=data_subset,fit=td2pLL_fit_gamlss_nl_donor_case2,     #Case 1 and 2
#'                                   res=centered_td2pLL_analysis_gamlssnl_donor_CASE2,model="td2pLL",
#'                                   plot_to_add_to=First_step,
#'                                   plot_type="alert",
#'                                   add_col_alert = "brown") +
#'   scale_color_manual(values=c("brown","orange","orangered2"),labels=c("Case 2 (normal)","Case 1 (fast)","Case 1 (normal)"))
#' 
#' 
#' Alert_comp_centered_larger_aic <- add_to_plot_analysis_centered(dat=data_subset,fit=td2pLL_fit_gamlss_nl_donor_case2,     #Case 1 and 2
#'                                               res=centered_td2pLL_analysis_gamlssnl_donor_fast_CASE2,model="td2pLL",
#'                                               plot_to_add_to=Second_step,
#'                                               plot_type="alert",
#'                                               add_col_alert = "peru") +
#'   scale_color_manual(values=c("brown","orange","orangered2","peru"),labels=c("Case 2 (normal)","Case 1 (fast)","Case 1 (normal)","Case 2 (fast)")) +
#'   ggtitle("Alerts")+
#'   geom_vline(xintercept = 4,col="darkgrey")
#' 
#' 
#' 
#' 
#' 
#' #'------------------------------------------------------------------------------
#' #####  Larger AIC  reduced ----
#' #'------------------------------------------------------------------------------
#' 
#' First_step <- add_to_plot_analysis_centered(dat=data_subset_reduced,fit=schuettler_fit_gamlss_nl_donor_reduced_case2,     #Case 1 and 2
#'                                    res=centered_schuettler_analysis_gamlssnl_donor_reduced_CASE2,model="schuettler",
#'                                    plot_to_add_to=p_res_schuettler_centered_reduced_case1$alert_plot,
#'                                    plot_type="alert",
#'                                    add_col_alert =  "brown") + 
#'   scale_color_manual(values=c("brown","orangered2"),labels=c("Case 2 (normal)","Case 1 (normal)")) 
#' 
#' 
#' Second_step<-add_to_plot_analysis_centered(dat=data_subset_reduced,fit=schuettler_fit_gamlss_nl_donor_reduced_case1,     #Case 1 and 2
#'                                   res=centered_schuettler_analysis_gamlssnl_donor_fast_reduced_CASE1,model="schuettler",
#'                                   plot_to_add_to=First_step,
#'                                   plot_type="alert",
#'                                   add_col_alert = "orange") +
#'   scale_color_manual(values=c("brown","orange","orangered2"),labels=c("Case 2 (normal)","Case 1 (fast)","Case 1 (normal)"))
#' 
#' 
#' Alert_comp_centered_larger_aic_reduced <- add_to_plot_analysis_centered(dat=data_subset_reduced,fit=schuettler_fit_gamlss_nl_donor_reduced_case2,     #Case 1 and 2
#'                                                       res=centered_schuettler_analysis_gamlssnl_donor_fast_reduced_CASE2,model="schuettler",
#'                                                       plot_to_add_to=Second_step,
#'                                                       plot_type="alert",
#'                                                       add_col_alert = "peru") +
#'   scale_color_manual(values=c("brown","orange","orangered2","peru"),labels=c("Case 2 (normal)","Case 1 (fast)","Case 1 (normal)","Case 2 (fast)"))+
#'   guides(color="none") +
#'   ggtitle("Alerts (reduced data)")+
#'   geom_vline(xintercept = 4,col="darkgrey")
#' 
#' 
#' 
#' #'------------------------------------------------------------------------------
#' #### Combined Plots ----
#' #'------------------------------------------------------------------------------
#' 
#' #'------------------------------------------------------------------------------
#' #####  Smallest AIC   ----
#' #'------------------------------------------------------------------------------
#' 
#' (confband_comp_td2pLL_centered_case1+confband_comp_schuettler_centered_case2+Alert_comp_centered_smallest_aic)/
#'   (confband_comp_td2pLL_centered_reduced_case1+confband_comp_td2pLL_centered_reduced_case2+Alert_comp_centered_smallest_aic_reduced)+
#'   plot_layout(guides = "collect")
#' 
#' ggsave("./plots_tables/108_fig_centered_2dim_res_smallest_aic.pdf",height=12,width=15)
#' 
#' 
#' #'------------------------------------------------------------------------------
#' #####  Larger aic   ----
#' #'------------------------------------------------------------------------------
#' 
#' 
#' (confband_comp_schuettler_centered_case1+confband_comp_td2pLL_centered_case2+Alert_comp_centered_larger_aic)/
#'   (confband_comp_schuettler_centered_reduced_case1+confband_comp_schuettler_centered_reduced_case2+Alert_comp_centered_larger_aic_reduced)+
#'   plot_layout(guides = "collect")
#' 
#' ggsave("./plots_tables/109_fig_centered_2dim_res_larger_aic.pdf",height=12,width=15)
#' 

#'==============================================================================
# Simulation  ====
#'==============================================================================

#'==============================================================================
## Simulation plot function ====
#'==============================================================================

#'------------------------------------------------------------------------------
### Scenario depiction ----
#'------------------------------------------------------------------------------
# Here we define a function, that depicts the simulation scenarios

plot_simulation_scenarios <- function(dat,fit_true,fixtime, model_name,
                                      col_alert="red",
                                      lty_alert="solid",
                                      title_cb="",
                                      axis_title,
                                      threshold,
                                      marker_size_fit_cb=3,
                                      camera_cb=list(x = 0.2, y = 2.5, z = 0.2),
                                      size_3dim_fit_cb=c(24,15,17),
                                      fit_place = c(x=0.5,y=4.5,z=60),
                                      lambda_place= c(x=2.5,y=6.5,z=43),
                                      alert_place = c(x=6,y=5,z=-5) ){
  
  if(model_name=="td2pLL"){
    #grid for time-dose case
    #time
    min_time <- 1
    max_time <- 7
    
    #dose
    min_dose <- 0
    max_dose <- 10
    
    #fineness of the grid
    epsilon <- 0.1
    
    
    
    #create the grid
    time_seq <- seq(min_time, max_time, by=epsilon)   #time
    dose_seq <- seq(min_dose, max_dose, by=epsilon)   #dose
    
    grid_full      <- data.frame("time"=rep(time_seq, times=length(dose_seq)))
    grid_dose <- numeric(length=length(time_seq)*length(dose_seq))
    for(i in 1:length(dose_seq)){
      grid_dose[((i-1)*length(time_seq)+1):(i*length(time_seq))] <- rep(dose_seq[i],  times=length(time_seq))
    }
    grid_full$dose <- grid_dose
    
    model <- td2pLL
    
  } else{
  if(model_name=="emax_emax"){
    
    
    #Grid for dose-dose case
    #Dose 1 (time)
    min_time <- 0
    max_time <- 10
    
    #Dose 2(dose)
    min_dose <- 0
    max_dose <- 12
    
    #fineness of the grid
    epsilon <- 0.1
    
    time_seq <- seq(min_time, max_time, by=epsilon)   #time
    dose_seq <- seq(min_dose, max_dose, by=epsilon)   #dose
    
    grid_full      <- data.frame("time"=rep(time_seq, times=length(dose_seq)))
    grid_dose <- numeric(length=length(time_seq)*length(dose_seq))
    for(i in 1:length(dose_seq)){
      grid_dose[((i-1)*length(time_seq)+1):(i*length(time_seq))] <- rep(dose_seq[i],  times=length(time_seq))
    }
    grid_full$dose <- grid_dose
    
    
    model <- emax_emax
    
  }}
  
  #full plot
  resp_mat_test <- model(t=grid_full$time, 
                         d=grid_full$dose, 
                         theta=fit_true)          %>%
    cbind(grid_full, "response"=.)                        %>%
    reshape2::acast(., 
                    time~dose, 
                    value.var="response")
  
  if(model_name=="emax_emax"){
  alert_test <- matrix(NA,nrow=length(time_seq),ncol=2)
  for(i in length(time_seq):1){
    alert_test[i,1] <- i
    alert_test[i,2] <- min(subset(which(resp_mat_test>threshold,arr.ind=T)[,2],
                                            which(resp_mat_test>threshold,T)[,1]==i))
  }
  } else{
    if(model_name=="td2pLL"){
      alert_test <- matrix(NA,nrow=length(time_seq),ncol=2)
      for(i in length(time_seq):1){
        alert_test[i,1] <- i
        alert_test[i,2] <- min(subset(which(resp_mat_test<threshold,arr.ind=T)[,2],
                                      which(resp_mat_test<threshold,T)[,1]==i))
      }   
      
      
    }
    
  }

  Threshold_plane <- grid_full                                    %>%
    cbind(.,"th"=rep(threshold))  %>%
    reshape2::acast(., 
                    time~dose, 
                    value.var="th")
  
  
p <-  plot_ly()                %>%
    add_markers(dat,       #only compound of interest
                x = dat$dose, 
                y = dat$time, 
                z = dat$resp, 
                marker = list(size = marker_size_fit_cb),
                showlegend=F) %>%
  layout(scene = list(camera = list(
    eye = camera_cb),
    xaxis = list(range=c(min_dose,max_dose),
                 title = list(text=axis_title[2],
                               font = list(size = size_3dim_fit_cb[1])),
                 tickfont = list(size = size_3dim_fit_cb[2])),  #Basic layout
    yaxis = list(range=c(min_time,max_time),
                 title = list( text=axis_title[1],
                               font = list(size = size_3dim_fit_cb[1])),
                 tickfont = list(size = size_3dim_fit_cb[2])),
    zaxis = list(title = list( text ='Response',
                               font = list(size = size_3dim_fit_cb[1])),
                 tickfont = list(size = size_3dim_fit_cb[2])),
    bgcolor = "rgba(0,0,0,0)"),
    legend = list(itemsizing = "constant",
                  font = list(size = size_3dim_fit_cb[2]),
                  x = 100,
                  y= 0.5),
    margin=list(l=0, r=0, t=0, b=0)
  )  %>%
    add_surface(x=colnames(resp_mat_test),
                y=rownames(resp_mat_test),
                z=resp_mat_test,
                colorscale=list(c(0,1),
                                c("black","grey")),
                colorbar="",
                showscale=F,
                opacity=0.5)              %>%
  add_surface(x=colnames(Threshold_plane),
              y=rownames(Threshold_plane),
              z=Threshold_plane,
              colorscale=list(c(0,1),
                              c("firebrick","red")),
              colorbar="",
              showscale=F
  )                                             %>%
    add_trace(x = dose_seq, 
              y = rep(fixtime,times=length(dose_seq)), 
              z = model(t=rep(fixtime,times=length(dose_seq)),
                        d=dose_seq,
                        theta=fit_true),
              line=list(color = 'black', width = 2),
              type="scatter3d",mode="lines",
              showlegend=F)    %>%
  add_trace(x = dose_seq[alert_test[,2]], 
            y = time_seq[alert_test[,1]], 
            z = rep(0,times=length(time_seq)),
            line=list(color = col_alert, width = 1,dash=lty_alert),
            type="scatter3d",mode="lines",
            showlegend=F)       %>%
  add_text(x=lambda_place[1],y=lambda_place[2],z=lambda_place[3],text="\U1D6CC",textfont=list(size = size_3dim_fit_cb[3], color="darkred"),
           showlegend=F) %>%
  add_text(x=fit_place[1],y=fit_place[2],z=fit_place[3],text="Fit",textfont=list(size = size_3dim_fit_cb[3], color="black"),
           showlegend=F)                                                         %>%
  add_text(x=alert_place[1],y=alert_place[2],z=alert_place[3],text="Alert",textfont=list(size = size_3dim_fit_cb[3],color=col_alert),
           showlegend=F)  %>%
    add_text(x=5,y=3.5,z=max(dat$resp),text=title_cb,textfont=list(size = size_3dim_fit_cb[3], color="black"),showlegend=F) 
  
p$x$layout$margin$b <- 1
p$x$layout$margin$l <- 1
p$x$layout$margin$t <- 1
p$x$layout$margin$r <- 1

  
p_gg <- save_and_clean_3d_plots( p = p,
                         p_file_name = "p_tmp",
                         save_file = F )

 return(list("p"=p,"p_gg"=p_gg))  
  
}


#'==============================================================================
## Simulation - explainatory ====
#'==============================================================================

#'==============================================================================
### Scenario 1 ====
#'==============================================================================

#'------------------------------------------------------------------------------
#####  Mean   ----
#'------------------------------------------------------------------------------


p_scenario1_mean <- plot_simulation_scenarios(dat=data_simul_medium_reduced,
                                              fit_true = c(2.887804, 5.922101, 1.771404, 4.796278),
                                              fixtime=4,
                                              model_name="td2pLL",
                                              title_cb="",
                                              camera_cb=list(x = 2.5, y = 2.5, z = 0.7),
                                              axis_title = c("Time", "Dose"),
                                              lambda_place = c(y=9,x=2,z=45),
                                              threshold = 50               
)


#'------------------------------------------------------------------------------
#####  SD ----
#'------------------------------------------------------------------------------



resp_sd_simple <- sigma_function(sigma_basis_simul_small[1],
                                 time=grid_full$time,
                                 dose=grid_full$dose,
                                 sig.f=~1)  %>%
  exp(.)                                                            %>%
  cbind(grid_full, "response"=.)                   %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="response")

resp_sd_small <- sigma_function(sigma_basis_simul_small,
                                 time=grid_full$time,
                                 dose=grid_full$dose,
                                 sig.f=~dose + I(dose^2) + time + I(dose^2):time)  %>%
  exp(.)                                                            %>%
  cbind(grid_full, "response"=.)                   %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="response")

resp_sd_medium <- sigma_function(sigma_basis_simul_medium,
                                  time=grid_full$time,
                                  dose=grid_full$dose,
                                  sig.f=~dose + I(dose^2) + time + I(dose^2):time)  %>%
  exp(.)                                                            %>%
  cbind(grid_full, "response"=.)                   %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="response")


resp_sd_large <- sigma_function(sigma_basis_simul_large,
                                     time=grid_full$time,
                                     dose=grid_full$dose,
                                     sig.f=~dose + I(dose^2) + time + I(dose^2):time)  %>%
  exp(.)                                                            %>%
  cbind(grid_full, "response"=.)                   %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="response")


fig_sd_scenario1 <- plot_ly()       %>%
  add_surface(x=colnames(resp_sd_simple),
              y=rownames(resp_sd_simple),
              z=resp_sd_simple,
              colorscale=list(c(0,1),
                              c("black","grey")),
              colorbar="",
              showscale=F,
              opacity=0.85) %>%
  add_surface(x=colnames(resp_sd_small),
              y=rownames(resp_sd_small),
              z=resp_sd_small,
              colorscale=list(c(0,1),
                              c("black","grey")),
              colorbar="",
              showscale=F,
              opacity=0.85) %>%
  add_surface(x=colnames(resp_sd_medium),
              y=rownames(resp_sd_medium),
              z=resp_sd_medium,
              colorscale=list(c(0,1),
                              c("lightslategrey","lightsteelblue")),
              colorbar="",
              showscale=F,
              opacity=0.85) %>%
  add_surface(x=colnames(resp_sd_large),
              y=rownames(resp_sd_large),
              z=resp_sd_large,
              colorscale=list(c(0,1),
                              c("darkslategrey","slategrey")),
              colorbar="",
              showscale=F,
              opacity=0.85) %>%
  layout(scene = list(camera = list(
    eye = list(x = 0.2, y =3.5, z = 0.2)),
    xaxis = list(title = list( text = 'Dose',
                               font = list(size = 24)),
                 tickfont = list(size = 15)),  #Basic layout
    yaxis = list(title = list( text = 'Time',
                               font = list(size = 24)),
                 tickfont = list(size = 15)),
    zaxis = list(title = list( text ='Response',
                               font = list(size = 24)),
                 tickfont = list(size = 15))),
    legend = list(itemsizing = "constant",
                  font = list(size = 15),
                  x = 100,
                  y= 0.5)
  )  %>%
  add_text(x=2,y=3,z=7.5,text="Simple",textfont=list(size = 17, color="black"),showlegend=F) %>%
  add_text(x=9,y=3,z=10,text="Small",textfont=list(size = 17, color="black"),showlegend=F) %>%
  add_text(x=8.5,y=3,z=12,text="Medium",textfont=list(size = 17, color="lightsteelblue"),showlegend=F) %>%
  add_text(x=8,y=3,z=15,text="Large",textfont=list(size = 17, color="darkslategrey"),showlegend=F) %>%
 add_text(x=5,y=3.5,z=24,text="",textfont=list(size = 24, color="black"),showlegend=F) 

fig_sd_scenario1$x$layout$margin$b <- 1
fig_sd_scenario1$x$layout$margin$l <- 1
fig_sd_scenario1$x$layout$margin$t <- 1
fig_sd_scenario1$x$layout$margin$r <- 1


p_scenario1_sd_gg <- save_and_clean_3d_plots( p = fig_sd_scenario1,
                                              p_file_name = "p_tmp",
                                              save_file = F )


#'==============================================================================
### Scenario 2 ====
#'==============================================================================

#'------------------------------------------------------------------------------
#####  3x3 Design   ----
#'------------------------------------------------------------------------------

#des9
p_scenario2_des9 <- plot_simulation_scenarios(dat=data_simul_des9_90,
                          fit_true = c(0, 80, 3, 120, 10, 0.02),
                          fixtime=7,
                          model_name="emax_emax",
                          camera_cb=list(x = -2, y = -2, z = 0.7),
                          title_cb="",
                          axis_title = c("Dose 1", "Dose 2"),
                          threshold = threshold80,
                          fit_place = c(x=7,y=1,z=90),
                          lambda_place= c(x=1,y=5,z=threshold80-5),
                          alert_place = c(x=6,y=9,z=-15)                
)


#'------------------------------------------------------------------------------
#####  Dopt   ----
#'------------------------------------------------------------------------------

#dopt
p_scenario2_dopt <- plot_simulation_scenarios(dat=data_simul_dopt_90,
                          fit_true = c(0, 80, 3, 120, 10, 0.02),
                          fixtime=7,
                          model_name="emax_emax",
                          camera_cb=list(x = -2, y = -2, z = 0.7),
                          title_cb="",
                          axis_title = c("Dose 1", "Dose 2"),
                          threshold = threshold80,
                          fit_place = c(x=7,y=1,z=90),
                          lambda_place= c(x=1,y=5,z=threshold80-5),
                          alert_place = c(x=6,y=9,z=-15)                
                          )

#'==============================================================================
### Combined Plot ====
#'==============================================================================

(p_scenario1_mean$p_gg+p_scenario1_sd_gg)/
(p_scenario2_des9$p_gg+p_scenario2_dopt$p_gg)+
plot_annotation(tag_levels = 'A',
            title = '') & 
  theme(plot.tag = element_text(size = 25),plot.title = element_text(size=23))


ggsave("./plots_tables/010_fig_simulation_scenarios.pdf",height=12,width=15)



#'==============================================================================
## Simulation - Results ====
#'==============================================================================

#'==============================================================================
### Scenario 1 ====
#'==============================================================================



#'------------------------------------------------------------------------------
#####  2D analysis   ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
######  H0 reject  ----
#'------------------------------------------------------------------------------


#Full plot
df_reslist <- tibble(
  value = c(
    # Res_alert_fixtime_Scenario1_fulldata_assumeconstant_constant$H0_reject_2dim,
    # Res_alert_fixtime_Scenario1_fulldata_assumeconstant_constant$H0_reject_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_constant$H0_reject_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_constant$H0_reject_3dim,
    # Res_alert_fixtime_Scenario1_fulldata_assumeconstant_small$H0_reject_2dim,
    # Res_alert_fixtime_Scenario1_fulldata_assumeconstant_small$H0_reject_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_small$H0_reject_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_small$H0_reject_3dim,
    # Res_alert_fixtime_Scenario1_fulldata_assumeconstant_medium$H0_reject_2dim,
    # Res_alert_fixtime_Scenario1_fulldata_assumeconstant_medium$H0_reject_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_medium$H0_reject_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_medium$H0_reject_3dim,
    # Res_alert_fixtime_Scenario1_fulldata_assumeconstant_large$H0_reject_2dim,
    # Res_alert_fixtime_Scenario1_fulldata_assumeconstant_large$H0_reject_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_large$H0_reject_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_large$H0_reject_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_constant$H0_reject_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_constant$H0_reject_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_constant$H0_reject_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_constant$H0_reject_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_small$H0_reject_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_small$H0_reject_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_small$H0_reject_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_small$H0_reject_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_medium$H0_reject_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_medium$H0_reject_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_medium$H0_reject_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_medium$H0_reject_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_large$H0_reject_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_large$H0_reject_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_large$H0_reject_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_large$H0_reject_3dim,
    # Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_constant$H0_reject_2dim,
    # Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_constant$H0_reject_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_constant$H0_reject_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_constant$H0_reject_3dim,
    # Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_small$H0_reject_2dim,
    # Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_small$H0_reject_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_small$H0_reject_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_small$H0_reject_3dim,
    # Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_medium$H0_reject_2dim,
    # Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_medium$H0_reject_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_medium$H0_reject_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_medium$H0_reject_3dim,
    # Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_large$H0_reject_2dim,
    # Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_large$H0_reject_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_large$H0_reject_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_large$H0_reject_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_constant$H0_reject_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_constant$H0_reject_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_constant$H0_reject_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_constant$H0_reject_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_small$H0_reject_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_small$H0_reject_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_small$H0_reject_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_small$H0_reject_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_medium$H0_reject_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_medium$H0_reject_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_medium$H0_reject_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_medium$H0_reject_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_large$H0_reject_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_large$H0_reject_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_large$H0_reject_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_large$H0_reject_3dim
  )/10,
  case =
    c(#"Simple_full_constant_2D_normal",
    #   "Simple_full_constant_3D_normal",
      "Simple_full_constant_2D_fast",
      "Simple_full_constant_3D_fast",
      # "Small_full_constant_2D_normal",
      # "Small_full_constant_3D_normal",
      "Small_full_constant_2D_fast",
      "Small_full_constant_3D_fast",
      # "Medium_full_constant_2D_normal",
      # "Medium_full_constant_3D_normal",
      "Medium_full_constant_2D_fast",
      "Medium_full_constant_3D_fast",
      # "Large_full_constant_2D_normal",
      # "Large_full_constant_3D_normal",
      "Large_full_constant_2D_fast",
      "Large_full_constant_3D_fast",
      "Simple_full_complex_2D_normal",
      "Simple_full_complex_3D_normal",
      "Simple_full_complex_2D_fast",
      "Simple_full_complex_3D_fast",
      "Small_full_complex_2D_normal",
      "Small_full_complex_3D_normal",
      "Small_full_complex_2D_fast",
      "Small_full_complex_3D_fast",
      "Medium_full_complex_2D_normal",
      "Medium_full_complex_3D_normal",
      "Medium_full_complex_2D_fast",
      "Medium_full_complex_3D_fast",
      "Large_full_complex_2D_normal",
      "Large_full_complex_3D_normal",
      "Large_full_complex_2D_fast",
      "Large_full_complex_3D_fast",
      # "Simple_reduced_constant_2D_normal",
      # "Simple_reduced_constant_3D_normal",
      "Simple_reduced_constant_2D_fast",
      "Simple_reduced_constant_3D_fast",
      # "Small_reduced_constant_2D_normal",
      # "Small_reduced_constant_3D_normal",
      "Small_reduced_constant_2D_fast",
      "Small_reduced_constant_3D_fast",
      # "Medium_reduced_constant_2D_normal",
      # "Medium_reduced_constant_3D_normal",
      "Medium_reduced_constant_2D_fast",
      "Medium_reduced_constant_3D_fast",
      # "Large_reduced_constant_2D_normal",
      # "Large_reduced_constant_3D_normal",
      "Large_reduced_constant_2D_fast",
      "Large_reduced_constant_3D_fast",
      "Simple_reduced_complex_2D_normal",
      "Simple_reduced_complex_3D_normal",
      "Simple_reduced_complex_2D_fast",
      "Simple_reduced_complex_3D_fast",
      "Small_reduced_complex_2D_normal",
      "Small_reduced_complex_3D_normal",
      "Small_reduced_complex_2D_fast",
      "Small_reduced_complex_3D_fast",
      "Medium_reduced_complex_2D_normal",
      "Medium_reduced_complex_3D_normal",
      "Medium_reduced_complex_2D_fast",
      "Medium_reduced_complex_3D_fast",
      "Large_reduced_complex_2D_normal",
      "Large_reduced_complex_3D_normal",
      "Large_reduced_complex_2D_fast",
      "Large_reduced_complex_3D_fast")
  
)

df_reslist_cases <- df_reslist %>%
  mutate(
    algo = factor(ifelse(grepl("_fast", case), "Fast", "Normal"),levels=c("Normal","Fast")),
    design = factor(ifelse(grepl("_full",case), "Full","Reduced"),levels=c("Full","Reduced")),
    sigma_assumed = factor(ifelse(grepl("_constant",case), "Constant","Complex"),levels=c("Constant","Complex")),  
    sd     = factor(sub("_.*", "", case),levels=c("Simple","Small","Medium","Large")),              # Simple / Small / Medium / Large
    dim      = factor(ifelse(grepl("_2D", case), "2D", "3D"))
  )


#Full plot
ggplot(df_reslist_cases, aes(x = sd, y = value,
               color = sigma_assumed,
               shape = dim)) +
  geom_point(
    position = position_jitterdodge(
      jitter.width = 0.2,   
      dodge.width  = 0.75     
    ),
    size = 2.5,
    alpha = 0.7
  ) +
  scale_color_manual(values = c("firebrick3","darkorange"),labels=c("Constant","Complex"))+
  facet_grid(design ~ algo) +
  labs(
    y =  expression(H[0]~"rejected (%)"),
    x = "",
    color = "Sigma assumed",
    shape = "Dimension"
  ) +
  theme(      axis.title=element_text(size=17),
              axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1),
              legend.text=element_text(size=19),
              plot.title = element_text(size=21),
              strip.text = element_text(size = 15),
              legend.title=element_blank(),
              panel.background = element_rect(fill = "gray96",
                                              colour = "gray96",
                                              size = 0.5, linetype = "solid"),
              panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                              colour = "white"), 
              panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                              colour = "white"))

ggsave(file="./plots_tables/113_fig_simulation_res_h0_reject_all_scenario1.pdf",width=5,height=5)


#Fast only
p_h0_reject_scen1 <- ggplot(df_reslist_cases%>%filter(algo!="Normal")%>%as.data.frame(), aes(x = sd, y = value,
                             color = sigma_assumed,
                             shape = dim)) +
  geom_point(
    position = position_jitterdodge(
      jitter.width = 0.2,   
      dodge.width  = 0.75     
    ),
    size = 2.5,
    alpha = 0.7
  ) +
  scale_color_manual(values = c("firebrick3","darkorange"),labels=c("Constant","Complex"))+
  facet_wrap(~design) +
  labs(
    y =  expression(H[0]~"rejected (%)"),
    x = "",
    color = "Sigma assumed",
    shape = "Dimension"
  ) +
  theme(      axis.title=element_text(size=17),
              axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1),
              legend.text=element_text(size=19),
              plot.title = element_text(size=21),
              strip.text = element_text(size = 15),
              legend.title=element_blank(),
              panel.background = element_rect(fill = "gray96",
                                              colour = "gray96",
                                              size = 0.5, linetype = "solid"),
              panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                              colour = "white"), 
              panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                              colour = "white"))

#'------------------------------------------------------------------------------
######  Median error  ----
#'------------------------------------------------------------------------------

# Full data assume constant
df_reslist <- tibble(
  value = c(
    # Res_alert_fixtime_Scenario1_fulldata_assumeconstant_constant$all_alerts_2dim,
    # Res_alert_fixtime_Scenario1_fulldata_assumeconstant_constant$all_alerts_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_constant$all_alerts_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_constant$all_alerts_3dim,
    # Res_alert_fixtime_Scenario1_fulldata_assumeconstant_small$all_alerts_2dim,
    # Res_alert_fixtime_Scenario1_fulldata_assumeconstant_small$all_alerts_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_small$all_alerts_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_small$all_alerts_3dim,
    # Res_alert_fixtime_Scenario1_fulldata_assumeconstant_medium$all_alerts_2dim,
    # Res_alert_fixtime_Scenario1_fulldata_assumeconstant_medium$all_alerts_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_medium$all_alerts_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_medium$all_alerts_3dim,
    # Res_alert_fixtime_Scenario1_fulldata_assumeconstant_large$all_alerts_2dim,
    # Res_alert_fixtime_Scenario1_fulldata_assumeconstant_large$all_alerts_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_large$all_alerts_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_large$all_alerts_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_constant$all_alerts_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_constant$all_alerts_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_constant$all_alerts_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_constant$all_alerts_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_small$all_alerts_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_small$all_alerts_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_small$all_alerts_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_small$all_alerts_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_medium$all_alerts_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_medium$all_alerts_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_medium$all_alerts_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_medium$all_alerts_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_large$all_alerts_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_large$all_alerts_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_large$all_alerts_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_large$all_alerts_3dim,
    # Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_constant$all_alerts_2dim,
    # Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_constant$all_alerts_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_constant$all_alerts_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_constant$all_alerts_3dim,
    # Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_small$all_alerts_2dim,
    # Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_small$all_alerts_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_small$all_alerts_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_small$all_alerts_3dim,
    # Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_medium$all_alerts_2dim,
    # Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_medium$all_alerts_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_medium$all_alerts_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_medium$all_alerts_3dim,
    # Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_large$all_alerts_2dim,
    # Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_large$all_alerts_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_large$all_alerts_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_large$all_alerts_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_constant$all_alerts_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_constant$all_alerts_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_constant$all_alerts_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_constant$all_alerts_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_small$all_alerts_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_small$all_alerts_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_small$all_alerts_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_small$all_alerts_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_medium$all_alerts_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_medium$all_alerts_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_medium$all_alerts_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_medium$all_alerts_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_large$all_alerts_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_large$all_alerts_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_large$all_alerts_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_large$all_alerts_3dim
  ),
  case = rep(
    c(#"Simple_full_constant_2D_normal",
      #"Simple_full_constant_3D_normal",
      "Simple_full_constant_2D_fast",
      "Simple_full_constant_3D_fast",
      # "Small_full_constant_2D_normal",
      # "Small_full_constant_3D_normal",
      "Small_full_constant_2D_fast",
      "Small_full_constant_3D_fast",
      # "Medium_full_constant_2D_normal",
      # "Medium_full_constant_3D_normal",
      "Medium_full_constant_2D_fast",
      "Medium_full_constant_3D_fast",
      # "Large_full_constant_2D_normal",
      # "Large_full_constant_3D_normal",
      "Large_full_constant_2D_fast",
      "Large_full_constant_3D_fast",
      "Simple_full_complex_2D_normal",
      "Simple_full_complex_3D_normal",
      "Simple_full_complex_2D_fast",
      "Simple_full_complex_3D_fast",
      "Small_full_complex_2D_normal",
      "Small_full_complex_3D_normal",
      "Small_full_complex_2D_fast",
      "Small_full_complex_3D_fast",
      "Medium_full_complex_2D_normal",
      "Medium_full_complex_3D_normal",
      "Medium_full_complex_2D_fast",
      "Medium_full_complex_3D_fast",
      "Large_full_complex_2D_normal",
      "Large_full_complex_3D_normal",
      "Large_full_complex_2D_fast",
      "Large_full_complex_3D_fast",
      # "Simple_reduced_constant_2D_normal",
      # "Simple_reduced_constant_3D_normal",
      "Simple_reduced_constant_2D_fast",
      "Simple_reduced_constant_3D_fast",
      # "Small_reduced_constant_2D_normal",
      # "Small_reduced_constant_3D_normal",
      "Small_reduced_constant_2D_fast",
      "Small_reduced_constant_3D_fast",
      # "Medium_reduced_constant_2D_normal",
      # "Medium_reduced_constant_3D_normal",
      "Medium_reduced_constant_2D_fast",
      "Medium_reduced_constant_3D_fast",
      # "Large_reduced_constant_2D_normal",
      # "Large_reduced_constant_3D_normal",
      "Large_reduced_constant_2D_fast",
      "Large_reduced_constant_3D_fast",
      "Simple_reduced_complex_2D_normal",
      "Simple_reduced_complex_3D_normal",
      "Simple_reduced_complex_2D_fast",
      "Simple_reduced_complex_3D_fast",
      "Small_reduced_complex_2D_normal",
      "Small_reduced_complex_3D_normal",
      "Small_reduced_complex_2D_fast",
      "Small_reduced_complex_3D_fast",
      "Medium_reduced_complex_2D_normal",
      "Medium_reduced_complex_3D_normal",
      "Medium_reduced_complex_2D_fast",
      "Medium_reduced_complex_3D_fast",
      "Large_reduced_complex_2D_normal",
      "Large_reduced_complex_3D_normal",
      "Large_reduced_complex_2D_fast",
      "Large_reduced_complex_3D_fast"),
    each = 1000
  )
)



df_median <- tibble(
  median_values = c(
    # Res_alert_fixtime_Scenario1_fulldata_assumeconstant_constant$median_2dim,
    # Res_alert_fixtime_Scenario1_fulldata_assumeconstant_constant$median_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_constant$median_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_constant$median_3dim,
    # Res_alert_fixtime_Scenario1_fulldata_assumeconstant_small$median_2dim,
    # Res_alert_fixtime_Scenario1_fulldata_assumeconstant_small$median_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_small$median_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_small$median_3dim,
    # Res_alert_fixtime_Scenario1_fulldata_assumeconstant_medium$median_2dim,
    # Res_alert_fixtime_Scenario1_fulldata_assumeconstant_medium$median_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_medium$median_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_medium$median_3dim,
    # Res_alert_fixtime_Scenario1_fulldata_assumeconstant_large$median_2dim,
    # Res_alert_fixtime_Scenario1_fulldata_assumeconstant_large$median_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_large$median_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumeconstant_fast_large$median_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_constant$median_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_constant$median_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_constant$median_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_constant$median_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_small$median_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_small$median_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_small$median_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_small$median_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_medium$median_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_medium$median_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_medium$median_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_medium$median_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_large$median_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_large$median_3dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_large$median_2dim,
    Res_alert_fixtime_Scenario1_fulldata_assumecomplex_fast_large$median_3dim,
    # Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_constant$median_2dim,
    # Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_constant$median_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_constant$median_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_constant$median_3dim,
    # Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_small$median_2dim,
    # Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_small$median_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_small$median_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_small$median_3dim,
    # Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_medium$median_2dim,
    # Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_medium$median_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_medium$median_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_medium$median_3dim,
    # Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_large$median_2dim,
    # Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_large$median_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_large$median_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumeconstant_fast_large$median_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_constant$median_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_constant$median_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_constant$median_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_constant$median_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_small$median_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_small$median_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_small$median_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_small$median_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_medium$median_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_medium$median_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_medium$median_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_medium$median_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_large$median_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_large$median_3dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_large$median_2dim,
    Res_alert_fixtime_Scenario1_reduceddata_assumecomplex_fast_large$median_3dim
  ),
  case = 
    c(#"Simple_full_constant_2D_normal",
      #"Simple_full_constant_3D_normal",
      "Simple_full_constant_2D_fast",
      "Simple_full_constant_3D_fast",
      # "Small_full_constant_2D_normal",
      # "Small_full_constant_3D_normal",
      "Small_full_constant_2D_fast",
      "Small_full_constant_3D_fast",
      # "Medium_full_constant_2D_normal",
      # "Medium_full_constant_3D_normal",
      "Medium_full_constant_2D_fast",
      "Medium_full_constant_3D_fast",
      # "Large_full_constant_2D_normal",
      # "Large_full_constant_3D_normal",
      "Large_full_constant_2D_fast",
      "Large_full_constant_3D_fast",
      "Simple_full_complex_2D_normal",
      "Simple_full_complex_3D_normal",
      "Simple_full_complex_2D_fast",
      "Simple_full_complex_3D_fast",
      "Small_full_complex_2D_normal",
      "Small_full_complex_3D_normal",
      "Small_full_complex_2D_fast",
      "Small_full_complex_3D_fast",
      "Medium_full_complex_2D_normal",
      "Medium_full_complex_3D_normal",
      "Medium_full_complex_2D_fast",
      "Medium_full_complex_3D_fast",
      "Large_full_complex_2D_normal",
      "Large_full_complex_3D_normal",
      "Large_full_complex_2D_fast",
      "Large_full_complex_3D_fast",
      # "Simple_reduced_constant_2D_normal",
      # "Simple_reduced_constant_3D_normal",
      "Simple_reduced_constant_2D_fast",
      "Simple_reduced_constant_3D_fast",
      # "Small_reduced_constant_2D_normal",
      # "Small_reduced_constant_3D_normal",
      "Small_reduced_constant_2D_fast",
      "Small_reduced_constant_3D_fast",
      # "Medium_reduced_constant_2D_normal",
      # "Medium_reduced_constant_3D_normal",
      "Medium_reduced_constant_2D_fast",
      "Medium_reduced_constant_3D_fast",
      # "Large_reduced_constant_2D_normal",
      # "Large_reduced_constant_3D_normal",
      "Large_reduced_constant_2D_fast",
      "Large_reduced_constant_3D_fast",
      "Simple_reduced_complex_2D_normal",
      "Simple_reduced_complex_3D_normal",
      "Simple_reduced_complex_2D_fast",
      "Simple_reduced_complex_3D_fast",
      "Small_reduced_complex_2D_normal",
      "Small_reduced_complex_3D_normal",
      "Small_reduced_complex_2D_fast",
      "Small_reduced_complex_3D_fast",
      "Medium_reduced_complex_2D_normal",
      "Medium_reduced_complex_3D_normal",
      "Medium_reduced_complex_2D_fast",
      "Medium_reduced_complex_3D_fast",
      "Large_reduced_complex_2D_normal",
      "Large_reduced_complex_3D_normal",
      "Large_reduced_complex_2D_fast",
      "Large_reduced_complex_3D_fast")
  
)



df_count <- df_reslist %>%
  dplyr::count(case, value) %>%
  mutate(
    algo = factor(ifelse(grepl("_fast", case), "Fast", "Normal"),levels=c("Normal","Fast")),
    design = factor(ifelse(grepl("_full",case), "Full","Reduced"),levels=c("Full","Reduced")),
    sigma_assumed = factor(ifelse(grepl("_constant",case), "Constant","Complex"),levels=c("Constant","Complex")),
    n_plot   = ifelse(algo == "Fast", n, -n),  ,
    sd     = factor(sub("_.*", "", case),levels=c("Simple","Small","Medium","Large")),              # Simple / Small / Medium / Large
    dim      = factor(ifelse(grepl("_2D", case), "2D", "3D"))
  )



df_normal <- df_count %>%  filter(algo == "Normal")
df_fast <- df_count %>%  filter(algo == "Fast")


#full plot
p <- ggplot(df_normal,
            aes(x = value, y = n_plot,
                col=sd,
                fill = sd) ) +
  geom_vline(xintercept=true_alert,
             col="orangered2")+
  geom_area(
    alpha = 0.3,
    position = "identity"
  ) +
  geom_area(
    data = df_fast,
    aes(
      x = value,
      y = n_plot,
      fill = sd,
      colour = sd
    ),
    alpha = 0.3,
    position = "identity"
  ) +    
  annotate(geom="text",label="Fast",x=9,y=200,size=5) +
  annotate(geom="text",label="Normal",x=9,y=-200,size=5) +
  ylim(-325,325)+                     #scale all the same
  scale_y_continuous(               #such that counts are positive for normal and fast
    labels = function(x) abs(x)
  )+
  scale_x_discrete(labels=c(4,5,6,7,8,9,10))+
  xlim(3.5,10) +
  geom_hline(yintercept = 0) +
  scale_fill_manual(
    values = c(
      Simple = "gray25",
      Small ="forestgreen",
      Medium = "goldenrod1",
      Large = "royalblue"
    )
  ) +
  scale_color_manual(
    values = c(
      Simple = "gray25",
      Small ="forestgreen",
      Medium = "goldenrod1",
      Large = "royalblue"
    )
  )  +
  facet_grid(design~dim+sigma_assumed)+
  labs(
    title= "",
    x = "Dose",
    y = "Counts",
    fill = ""
  ) +
  theme(      axis.title=element_text(size=17),
              legend.text=element_text(size=19),
              plot.title = element_text(size=21),
              strip.text = element_text(size = 15),
              legend.title=element_blank(),
              panel.background = element_rect(fill = "gray96",
                                              colour = "gray96",
                                              size = 0.5, linetype = "solid"),
              panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                              colour = "white"), 
              panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                              colour = "white")) +
  guides(colour = "none") 


df_median_prep <- df_median %>%
  mutate(
    algo = factor(ifelse(grepl("_fast", case), "Fast", "Normal"),levels=c("Normal","Fast")),
    design = factor(ifelse(grepl("_full",case), "Full","Reduced"),levels=c("Full","Reduced")),
    sigma_assumed = factor(ifelse(grepl("_constant",case), "Constant","Complex"),levels=c("Constant","Complex")),
    sd     = factor(sub("_.*", "", case),levels=c("Simple","Small","Medium","Large")),              # Simple / Small / Medium / Large
    dim      = factor(ifelse(grepl("_2D", case), "2D", "3D")),
    y_end     = ifelse(algo == "Fast", Inf, -Inf)
  )


p_2d_counts_per_t_all <- p +
  geom_segment(
    data = df_median_prep,
    aes(
      x = median_values,
      xend = median_values,
      y = 0,
      yend = y_end,
      colour = sd
    ),
    linewidth = 0.5,
    linetype="dashed",
    alpha=1
  ) +
  coord_cartesian(ylim = c(-325,
                           325))


p_2d_counts_per_t
ggsave(file="./plots_tables/112_fig_simulation_res_median_alert_2d_scenario1.pdf",width=10,height=10)


#reduced plot
p <- ggplot(df_fast,
            aes(x = value, y = n_plot,
                col=sd,
                fill = sd) ) +
  geom_vline(xintercept=true_alert,
             col="orangered2")+
  geom_area(
    alpha = 0.3,
    position = "identity"
  ) +
  ylim(0,325)+                     #scale all the same
  scale_x_discrete(labels=c(4,5,6,7,8,9,10))+
  xlim(3.5,10) +
  geom_hline(yintercept = 0) +
  scale_fill_manual(
    values = c(
      Simple = "gray25",
      Small ="forestgreen",
      Medium = "goldenrod1",
      Large = "royalblue"
    )
  ) +
  scale_color_manual(
    values = c(
      Simple = "gray25",
      Small ="forestgreen",
      Medium = "goldenrod1",
      Large = "royalblue"
    )
  )  +
  facet_grid(design~dim+sigma_assumed)+
  labs(
    title= "",
    x = "Dose",
    y = "Counts",
    fill = ""
  ) +
  theme(      axis.title=element_text(size=17),
              legend.text=element_text(size=19),
              plot.title = element_text(size=21),
              strip.text = element_text(size = 15),
              legend.title=element_blank(),
              panel.background = element_rect(fill = "gray96",
                                              colour = "gray96",
                                              size = 0.5, linetype = "solid"),
              panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                              colour = "white"), 
              panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                              colour = "white")) +
  guides(colour = "none") 



p_2d_counts_per_t <- p +
  geom_segment(
    data = df_median_prep %>% filter(algo!="Normal"),
    aes(
      x = median_values,
      xend = median_values,
      y = 0,
      yend = y_end,
      colour = sd
    ),
    linewidth = 0.5,
    linetype="dashed",
    alpha=1
  ) +
  coord_cartesian(ylim = c(0,
                           325))

#p_2d_counts_per_t


#'------------------------------------------------------------------------------
#####  3D analysis   ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
######  Median error  ----
#'------------------------------------------------------------------------------



#median error plot per time point 
#combine results
df_res <-rbind(#Res_alert_3d_Scenario1_fulldata_assumeconstant_constant$errors,
               #Res_alert_3d_Scenario1_fulldata_assumeconstant_small$errors,
               #Res_alert_3d_Scenario1_fulldata_assumeconstant_medium$errors,
               #Res_alert_3d_Scenario1_fulldata_assumeconstant_large$errors,
               Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_constant$errors,
               Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_small$errors,
               Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_medium$errors,
               Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_large$errors,
               Res_alert_3d_Scenario1_fulldata_assumecomplex_constant$errors,
               Res_alert_3d_Scenario1_fulldata_assumecomplex_small$errors,
               Res_alert_3d_Scenario1_fulldata_assumecomplex_medium$errors,
               Res_alert_3d_Scenario1_fulldata_assumecomplex_large$errors,
               Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_constant$errors,
               Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_small$errors,
               Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_medium$errors,
               Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_large$errors,
               #Res_alert_3d_Scenario1_reduceddata_assumeconstant_constant$errors,
               #Res_alert_3d_Scenario1_reduceddata_assumeconstant_small$errors,
               #Res_alert_3d_Scenario1_reduceddata_assumeconstant_medium$errors,
               #Res_alert_3d_Scenario1_reduceddata_assumeconstant_large$errors,
               Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_constant$errors,
               Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_small$errors,
               Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_medium$errors,
               Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_large$errors,
               Res_alert_3d_Scenario1_reduceddata_assumecomplex_constant$errors,
               Res_alert_3d_Scenario1_reduceddata_assumecomplex_small$errors,
               Res_alert_3d_Scenario1_reduceddata_assumecomplex_medium$errors,
               Res_alert_3d_Scenario1_reduceddata_assumecomplex_large$errors,
               Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_constant$errors,
               Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_small$errors,
               Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_medium$errors,
               Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_large$errors)

df_res$sd <- factor(df_res$sd,levels=c("Simple","Small","Medium","Large")) 
df_res$design <- factor(df_res$design,levels=c("Full","Reduced"))
df_res$sigma_assumed <- factor(df_res$sigma_assumed,levels=c("Constant","Complex"))
df_res$algo <- factor(df_res$algo,levels=c("Fast","Normal"))

#full plot
p_alert_3d_errors_all <-  ggplot(
  df_res     , 
  aes(x = time, y = med_error, fill = sd)
) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "grey50") +
  geom_ribbon(aes(ymin = q10, ymax = q90), alpha = 0.3) +
  geom_line(aes(x = time, y = med_error, color = factor(sd), fill = factor(sd)),linewidth = 0.9) +
  scale_fill_manual(
    values = c(
      Simple = "gray25",
      Small ="forestgreen",
      Medium = "goldenrod1",
      Large = "royalblue"
    )
  ) +
  scale_color_manual(
    values = c(
      Simple = "gray25",
      Small ="forestgreen",
      Medium = "goldenrod1",
      Large = "royalblue"
    )
  )  +
  facet_grid(design~algo+sigma_assumed
  )+
  labs(
    title= "",
    x = "Time",
    y = "Median Error",
    fill = ""
  ) +
  theme(      axis.title=element_text(size=17),
              legend.text=element_text(size=19),
              plot.title = element_text(size=21),
              strip.text = element_text(size = 15),
              legend.title=element_blank(),
              panel.background = element_rect(fill = "gray96",
                                              colour = "gray96",
                                              size = 0.5, linetype = "solid"),
              panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                              colour = "white"), 
              panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                              colour = "white")) +
  guides(colour = "none") 

#p_alert_3d_errors_all

#ggsave(file="./plots_tables/012_fig_simulation_res_scenario1_3dim_alerterror.pdf",width=12,height=10)

#reduced plot
p_alert_3d_errors <-  ggplot(
  df_res%>%filter(algo!="Normal")     , 
  aes(x = time, y = med_error, fill = sd)
) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "grey50") +
  geom_ribbon(aes(ymin = q10, ymax = q90), alpha = 0.3) +
  geom_line(aes(x = time, y = med_error, color = factor(sd), fill = factor(sd)),linewidth = 0.9) +
  scale_fill_manual(
    values = c(
      Simple = "gray25",
      Small ="forestgreen",
      Medium = "goldenrod1",
      Large = "royalblue"
    )
  ) +
  scale_color_manual(
    values = c(
      Simple = "gray25",
      Small ="forestgreen",
      Medium = "goldenrod1",
      Large = "royalblue"
    )
  )  +
  facet_grid(design~sigma_assumed
  )+
  labs(
    title= "",
    x = "Time",
    y = "Median Error",
    fill = ""
  ) +
  theme(      axis.title=element_text(size=17),
              legend.text=element_text(size=19),
              plot.title = element_text(size=21),
              strip.text = element_text(size = 15),
              legend.title=element_blank(),
              panel.background = element_rect(fill = "gray96",
                                              colour = "gray96",
                                              size = 0.5, linetype = "solid"),
              panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                              colour = "white"), 
              panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                              colour = "white")) +
  guides(colour = "none",fill="none") 


#p_alert_3d_errors

#'------------------------------------------------------------------------------
######  RMSE Boxplots    ----
#'------------------------------------------------------------------------------


cases_df <- rbind(
  # Res_alert_3d_Scenario1_fulldata_assumeconstant_constant$info,
  Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_constant$info,
  # Res_alert_3d_Scenario1_fulldata_assumeconstant_small$info,
  Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_small$info,
  # Res_alert_3d_Scenario1_fulldata_assumeconstant_medium$info,
  Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_medium$info,
  # Res_alert_3d_Scenario1_fulldata_assumeconstant_large$info,
  Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_large$info,   
  Res_alert_3d_Scenario1_fulldata_assumecomplex_constant$info,
  Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_constant$info,
  Res_alert_3d_Scenario1_fulldata_assumecomplex_small$info,
  Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_small$info,
  Res_alert_3d_Scenario1_fulldata_assumecomplex_medium$info,
  Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_medium$info,
  Res_alert_3d_Scenario1_fulldata_assumecomplex_large$info,
  Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_large$info,
  # Res_alert_3d_Scenario1_reduceddata_assumeconstant_constant$info,
  Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_constant$info,
  # Res_alert_3d_Scenario1_reduceddata_assumeconstant_small$info,
  Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_small$info,
  # Res_alert_3d_Scenario1_reduceddata_assumeconstant_medium$info,
  Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_medium$info,
  # Res_alert_3d_Scenario1_reduceddata_assumeconstant_large$info,
  Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_large$info,   
  Res_alert_3d_Scenario1_reduceddata_assumecomplex_constant$info,
  Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_constant$info,
  Res_alert_3d_Scenario1_reduceddata_assumecomplex_small$info,
  Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_small$info,
  Res_alert_3d_Scenario1_reduceddata_assumecomplex_medium$info,
  Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_medium$info,
  Res_alert_3d_Scenario1_reduceddata_assumecomplex_large$info,
  Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_large$info
)  %>% as.data.frame()

colnames(cases_df) <- c("Scenario","Design","sd","sigma_assumed","algo")

cases_df$case <- 1:24 


rmse_reslist <- list(
  # Res_alert_3d_Scenario1_fulldata_assumeconstant_constant$rmse_overlap,
  Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_constant$rmse_overlap,
  # Res_alert_3d_Scenario1_fulldata_assumeconstant_small$rmse_overlap,
  Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_small$rmse_overlap,
  # Res_alert_3d_Scenario1_fulldata_assumeconstant_medium$rmse_overlap,
  Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_medium$rmse_overlap,
  # Res_alert_3d_Scenario1_fulldata_assumeconstant_large$rmse_overlap,
  Res_alert_3d_Scenario1_fulldata_assumeconstant_fast_large$rmse_overlap,
  Res_alert_3d_Scenario1_fulldata_assumecomplex_constant$rmse_overlap,
  Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_constant$rmse_overlap,
  Res_alert_3d_Scenario1_fulldata_assumecomplex_small$rmse_overlap,
  Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_small$rmse_overlap,
  Res_alert_3d_Scenario1_fulldata_assumecomplex_medium$rmse_overlap,
  Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_medium$rmse_overlap,
  Res_alert_3d_Scenario1_fulldata_assumecomplex_large$rmse_overlap,
  Res_alert_3d_Scenario1_fulldata_assumecomplex_fast_large$rmse_overlap,
  # Res_alert_3d_Scenario1_reduceddata_assumeconstant_constant$rmse_overlap,
  Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_constant$rmse_overlap,
  # Res_alert_3d_Scenario1_reduceddata_assumeconstant_small$rmse_overlap,
  Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_small$rmse_overlap,
  # Res_alert_3d_Scenario1_reduceddata_assumeconstant_medium$rmse_overlap,
  Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_medium$rmse_overlap,
  # Res_alert_3d_Scenario1_reduceddata_assumeconstant_large$rmse_overlap,
  Res_alert_3d_Scenario1_reduceddata_assumeconstant_fast_large$rmse_overlap,
  Res_alert_3d_Scenario1_reduceddata_assumecomplex_constant$rmse_overlap,
  Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_constant$rmse_overlap,
  Res_alert_3d_Scenario1_reduceddata_assumecomplex_small$rmse_overlap,
  Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_small$rmse_overlap,
  Res_alert_3d_Scenario1_reduceddata_assumecomplex_medium$rmse_overlap,
  Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_medium$rmse_overlap,
  Res_alert_3d_Scenario1_reduceddata_assumecomplex_large$rmse_overlap,
  Res_alert_3d_Scenario1_reduceddata_assumecomplex_fast_large$rmse_overlap
)


df_rmse <- imap_dfr(
  rmse_reslist,
  function(rmse_vec, case_id) {
    
    tibble(
      case = case_id,
      rmse = rmse_vec
    )
  }
)


df_rmse <- df_rmse %>%
  left_join(cases_df, by = "case")


df_rmse$sd <- factor(df_rmse$sd,levels=c("Simple","Small","Medium","Large")) 
df_rmse$algo <- factor(df_rmse$algo,levels= c("Fast","Normal"))
df_rmse$sigma_assumed <- factor(df_rmse$sigma_assumed, levels=c("Constant","Complex"))

#full plot
p_3d_rmse_all <- ggplot(
  df_rmse,
  aes(
    x = sigma_assumed,
    y = rmse,
    fill = sd,
    color=sd
  )
) +
  geom_boxplot(
    outlier.alpha = 0.3,
    width = 0.7,
    alpha=0.5
  ) +
  facet_grid(
    Design ~ algo
  ) +
  labs(
    x = "Variance level",
    y = "RMSE",
    fill = "Algorithm"
  ) +
  scale_fill_manual(
    values = c(
      Simple = "gray25",
      Small ="forestgreen",
      Medium = "goldenrod1",
      Large = "royalblue"
    )
  ) +
  scale_color_manual(
    values = c(
      Simple = "gray25",
      Small ="forestgreen",
      Medium = "goldenrod1",
      Large = "royalblue"
    )
  ) +
  theme( axis.title=element_text(size=17),
         axis.text.x =element_text(size=13),
         legend.text=element_text(size=19),
         plot.title = element_text(size=21),
         strip.text = element_text(size = 15),
         legend.title=element_blank(),
         panel.background = element_rect(fill = "gray96",
                                         colour = "gray96",
                                         size = 0.5, linetype = "solid"),
         panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                         colour = "white"), 
         panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                         colour = "white"),
         legend.position = "bottom"
  ) +
  guides(color="none",fill="none")


#p_3d_rmse_all


p_3d_rmse <- ggplot(
  df_rmse%>% filter(algo!="Normal"),
  aes(
    x = sigma_assumed,
    y = rmse,
    fill = sd,
    color=sd
  )
) +
  geom_boxplot(
    outlier.alpha = 0.3,
    width = 0.7,
    alpha=0.5
  ) +
  facet_wrap(
    ~Design 
  ) +
  labs(
    x = "Variance level",
    y = "RMSE",
    fill = "Algorithm"
  ) +
  scale_fill_manual(
    values = c(
      Simple = "gray25",
      Small ="forestgreen",
      Medium = "goldenrod1",
      Large = "royalblue"
    )
  ) +
  scale_color_manual(
    values = c(
      Simple = "gray25",
      Small ="forestgreen",
      Medium = "goldenrod1",
      Large = "royalblue"
    )
  ) +
  theme( axis.title=element_text(size=17),
         axis.text.x =element_text(size=13),
         legend.text=element_text(size=19),
         plot.title = element_text(size=21),
         strip.text = element_text(size = 15),
         legend.title=element_blank(),
         panel.background = element_rect(fill = "gray96",
                                         colour = "gray96",
                                         size = 0.5, linetype = "solid"),
         panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                         colour = "white"), 
         panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                         colour = "white"),
         legend.position = "bottom"
  ) +
  guides(color="none",fill="none")


#p_3d_rmse

#'------------------------------------------------------------------------------
#####  Combine Plot   ----
#'------------------------------------------------------------------------------

design <- "
AAAB
CCDD
"

p_2d_counts_per_t + guide_area() + 
p_alert_3d_errors +  p_3d_rmse + 
plot_layout(design=design,guides="collect")+plot_annotation(tag_levels = 'A',
                                                            title = 'Scenario 1 - Results') & 
  theme(plot.tag = element_text(size = 15),plot.title = element_text(size=23))
ggsave(file="./plots_tables/011_fig_simulation_res_scenario1.pdf",width=13,height=13)

#with normal algorithm for the supp
p_alert_3d_errors_all +  p_3d_rmse_all +guide_area() +
  plot_layout(ncol=3,guides="collect")+plot_annotation(tag_levels = 'A') & 
  theme(plot.tag = element_text(size = 15),plot.title = element_text(size=23))
ggsave(file="./plots_tables/114_fig_simulation_res_3d_scenario1.pdf",width=13,height=7)


#'==============================================================================
### Scenario 2 ====
#'==============================================================================

#'------------------------------------------------------------------------------
#####  2D analysis   ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
######  H0 rejected  ----
#'------------------------------------------------------------------------------


df_reslist <- tibble(
  value = c(
    Res_alert_fixtime_Scenario2_des9_152$H0_reject_2dim,
    Res_alert_fixtime_Scenario2_des9_152$H0_reject_3dim,
    Res_alert_fixtime_Scenario2_des9_90$H0_reject_2dim,
    Res_alert_fixtime_Scenario2_des9_90$H0_reject_3dim,
    Res_alert_fixtime_Scenario2_des9_45$H0_reject_2dim,
    Res_alert_fixtime_Scenario2_des9_45$H0_reject_3dim,
    Res_alert_fixtime_Scenario2_dopt_152$H0_reject_2dim,
    Res_alert_fixtime_Scenario2_dopt_152$H0_reject_3dim,
    Res_alert_fixtime_Scenario2_dopt_90$H0_reject_2dim,
    Res_alert_fixtime_Scenario2_dopt_90$H0_reject_3dim,
    Res_alert_fixtime_Scenario2_dopt_45$H0_reject_2dim,
    Res_alert_fixtime_Scenario2_dopt_45$H0_reject_3dim
  )/10,
  case = 
    c("Des9_N152_2D",
      "Des9_N152_3D",
      "Des9_N90_2D",
      "Des9_N90_3D",
      "Des9_N45_2D",
      "Des9_N45_3D",
      "Dopt_N152_2D",
      "Dopt_N152_3D",
      "Dopt_N90_2D",
      "Dopt_N90_3D",
      "Dopt_N45_2D",
      "Dopt_N45_3D")
)

df_reslist_cases <- df_reslist %>%
  mutate(
    design = factor(ifelse(grepl("Des9_",case), "Factorial 3x3","D-optimal"),levels=c("Factorial 3x3","D-optimal")),
    numobsv     = factor(sub(".*_(N[0-9]+)_.*", "\\1", case),levels=c("N152","N90","N45")),              # Simple / Small / Medium / Large
    dim      = factor(ifelse(grepl("_2D", case), "2D", "3D"))
  )


p_h0_reject_scen2 <- ggplot(df_reslist_cases, aes(x = numobsv, y = value,
                             shape = dim)) +
  geom_point(
    position = position_jitterdodge(
      jitter.width = 0.2,   
      dodge.width  = 0.75     
    ),
    size = 2.5,
    alpha = 0.7,
    col="firebrick3"
  ) +
  facet_wrap(~ design) +
  labs(
    y =  expression(H[0]~"rejected (%)"),
    x = "",
    color = "Sigma assumed",
    shape = "Dimension"
  ) +
  theme(      axis.title=element_text(size=17),
              axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1),
              legend.text=element_text(size=19),
              plot.title = element_text(size=21),
              strip.text = element_text(size = 15),
              legend.title=element_blank(),
              legend.position = "none",
              panel.background = element_rect(fill = "gray96",
                                              colour = "gray96",
                                              size = 0.5, linetype = "solid"),
              panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                              colour = "white"), 
              panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                              colour = "white"))


#'------------------------------------------------------------------------------
######  Median error  ----
#'------------------------------------------------------------------------------

# Full data 
df_reslist <- tibble(
  value = c(
    Res_alert_fixtime_Scenario2_des9_152$all_alerts_2dim,
    Res_alert_fixtime_Scenario2_des9_152$all_alerts_3dim,
    Res_alert_fixtime_Scenario2_des9_90$all_alerts_2dim,
    Res_alert_fixtime_Scenario2_des9_90$all_alerts_3dim,
    Res_alert_fixtime_Scenario2_des9_45$all_alerts_2dim,
    Res_alert_fixtime_Scenario2_des9_45$all_alerts_3dim,
    Res_alert_fixtime_Scenario2_dopt_152$all_alerts_2dim,
    Res_alert_fixtime_Scenario2_dopt_152$all_alerts_3dim,
    Res_alert_fixtime_Scenario2_dopt_90$all_alerts_2dim,
    Res_alert_fixtime_Scenario2_dopt_90$all_alerts_3dim,
    Res_alert_fixtime_Scenario2_dopt_45$all_alerts_2dim,
    Res_alert_fixtime_Scenario2_dopt_45$all_alerts_3dim
  ),
  case = rep(
    c("Des9_N152_2D",
      "Des9_N152_3D",
      "Des9_N90_2D",
      "Des9_N90_3D",
      "Des9_N45_2D",
      "Des9_N45_3D",
      "Dopt_N152_2D",
      "Dopt_N152_3D",
      "Dopt_N90_2D",
      "Dopt_N90_3D",
      "Dopt_N45_2D",
      "Dopt_N45_3D"),
    each = 1000
  )
)



df_median <- tibble(
  median_values = c(
    Res_alert_fixtime_Scenario2_des9_152$median_2dim,
    Res_alert_fixtime_Scenario2_des9_152$median_3dim,
    Res_alert_fixtime_Scenario2_des9_90$median_2dim,
    Res_alert_fixtime_Scenario2_des9_90$median_3dim,
    Res_alert_fixtime_Scenario2_des9_45$median_2dim,
    Res_alert_fixtime_Scenario2_des9_45$median_3dim,
    Res_alert_fixtime_Scenario2_dopt_152$median_2dim,
    Res_alert_fixtime_Scenario2_dopt_152$median_3dim,
    Res_alert_fixtime_Scenario2_dopt_90$median_2dim,
    Res_alert_fixtime_Scenario2_dopt_90$median_3dim,
    Res_alert_fixtime_Scenario2_dopt_45$median_2dim,
    Res_alert_fixtime_Scenario2_dopt_45$median_3dim
  ),
  case = 
    c("Des9_N152_2D",
      "Des9_N152_3D",
      "Des9_N90_2D",
      "Des9_N90_3D",
      "Des9_N45_2D",
      "Des9_N45_3D",
      "Dopt_N152_2D",
      "Dopt_N152_3D",
      "Dopt_N90_2D",
      "Dopt_N90_3D",
      "Dopt_N45_2D",
      "Dopt_N45_3D")
  
)



df_count <- df_reslist %>%
  dplyr::count(case, value) %>%
  mutate(
    design = factor(ifelse(grepl("Des9_",case), "Factorial 3x3","D-optimal"),levels=c("Factorial 3x3","D-optimal")),
    n_plot   = n ,
    numobsv     = factor(sub(".*_(N[0-9]+)_.*", "\\1", case),levels=c("N152","N90","N45")),              # Simple / Small / Medium / Large
    dim      = factor(ifelse(grepl("_2D", case), "2D", "3D"))
  )




p <- ggplot(df_count,
            aes(x = value, y = n_plot,
                col=numobsv,
                fill = numobsv) ) +
  geom_vline(xintercept=true_alert80,
             col="orangered2")+
  geom_area(
    alpha = 0.3,
    position = "identity"
  ) +
  geom_hline(yintercept = 0) +
  scale_fill_manual(
    values = c(
      N45 ="forestgreen",
      N90 = "goldenrod1",
      N152 = "royalblue"
    )
  ) +
  scale_color_manual(
    values = c(
      N45 ="forestgreen",
      N90 = "goldenrod1",
      N152 = "royalblue"
    )
  )  +
  facet_grid(design~dim)+
  labs(
    title= "",
    x = "Dose 2",
    y = "Counts",
    fill = ""
  ) +
  theme(      axis.title=element_text(size=17),
              legend.text=element_text(size=19),
              plot.title = element_text(size=21),
              strip.text = element_text(size = 15),
              legend.title=element_blank(),
              panel.background = element_rect(fill = "gray96",
                                              colour = "gray96",
                                              size = 0.5, linetype = "solid"),
              panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                              colour = "white"), 
              panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                              colour = "white")) +
  guides(colour = "none") 


df_median_prep <- df_median %>%
  mutate(
    design = factor(ifelse(grepl("Des9_",case), "Factorial 3x3","D-optimal"),levels=c("Factorial 3x3","D-optimal")),
    numobsv     = factor(sub(".*_(N[0-9]+)_.*", "\\1", case),levels=c("N152","N90","N45")),              # Simple / Small / Medium / Large
    dim      = factor(ifelse(grepl("_2D", case), "2D", "3D")),
    y_end     =  Inf
  )


p_2d_counts_per_t <- p +
  geom_segment(
    data = df_median_prep,
    aes(
      x = median_values,
      xend = median_values,
      y = 0,
      yend = y_end,
      colour = numobsv
    ),
    linewidth = 0.5,
    linetype="dashed",
    alpha=1
  ) 


#p_2d_counts_per_t

#'------------------------------------------------------------------------------
#####  3D analysis   ----
#'------------------------------------------------------------------------------

#'------------------------------------------------------------------------------
######  Median error  ----
#'------------------------------------------------------------------------------



#median error plot per time point 
#combine results
df_res <-rbind(   Res_alert_3d_Scenario2_des9_152$errors,
                  Res_alert_3d_Scenario2_des9_90$errors,
                  Res_alert_3d_Scenario2_des9_45$errors,
                  Res_alert_3d_Scenario2_dopt_152$errors,
                  Res_alert_3d_Scenario2_dopt_90$errors,
                  Res_alert_3d_Scenario2_dopt_45$errors)

df_res$nobsv <- factor(df_res$nobsv,levels=c("N152","N90","N45")) 
df_res$design <- factor(df_res$design,levels=c("Factorial 3x3","D - optimal"))

p_alert_3d_errors <-  ggplot(
  df_res     , 
  aes(x = time, y = med_error, fill = nobsv)
) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "grey50") +
  geom_ribbon(aes(ymin = q10, ymax = q90), alpha = 0.3) +
  geom_line(aes(x = time, y = med_error, color = nobsv, fill = nobsv),linewidth = 0.9) +
  scale_fill_manual(
    values = c(
      N45 ="forestgreen",
      N90 = "goldenrod1",
      N152 = "royalblue"
    )
  ) +
  scale_color_manual(
    values = c(
      N45 ="forestgreen",
      N90 = "goldenrod1",
      N152 = "royalblue"
    )
  )  +
  facet_grid(~design
  )+
  labs(
    title= "",
    x = "Dose 1",
    y = "Median Error",
    fill = ""
  ) +
  theme(      axis.title=element_text(size=17),
              legend.text=element_text(size=19),
              plot.title = element_text(size=21),
              strip.text = element_text(size = 15),
              legend.title=element_blank(),
              panel.background = element_rect(fill = "gray96",
                                              colour = "gray96",
                                              size = 0.5, linetype = "solid"),
              panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                              colour = "white"), 
              panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                              colour = "white")) +
  guides(colour = "none",fill="none") 

#p_alert_3d_errors

#ggsave(file="./plots_tables/012_fig_simulation_res_scenario1_3dim_alerterror.pdf",width=12,height=10)



#'------------------------------------------------------------------------------
######  RMSE Boxplots    ----
#'------------------------------------------------------------------------------


cases_df <- rbind(
  Res_alert_3d_Scenario2_des9_152$info,
  Res_alert_3d_Scenario2_des9_90$info,
  Res_alert_3d_Scenario2_des9_45$info,
  Res_alert_3d_Scenario2_dopt_152$info,
  Res_alert_3d_Scenario2_dopt_90$info,
  Res_alert_3d_Scenario2_dopt_45$info
)  %>% as.data.frame()

colnames(cases_df) <- c("Scenario","Design","NumbObserv")

cases_df$case <- 1:6 


rmse_reslist <- list(
  Res_alert_3d_Scenario2_des9_152$rmse_overlap,
  Res_alert_3d_Scenario2_des9_90$rmse_overlap,
  Res_alert_3d_Scenario2_des9_45$rmse_overlap,
  Res_alert_3d_Scenario2_dopt_152$rmse_overlap,
  Res_alert_3d_Scenario2_dopt_90$rmse_overlap,
  Res_alert_3d_Scenario2_dopt_45$rmse_overlap
)


df_rmse <- imap_dfr(
  rmse_reslist,
  function(rmse_vec, case_id) {
    
    tibble(
      case = case_id,
      rmse = rmse_vec
    )
  }
)


df_rmse <- df_rmse %>%
  left_join(cases_df, by = "case")


df_rmse$NumbObserv <- factor(df_rmse$NumbObserv,levels=c("N152","N90","N45")) 
df_rmse$Design <- factor(df_rmse$Design,levels=c("Factorial 3x3","D - optimal"))

p_3d_rmse <- ggplot(
  df_rmse,
  aes(
    x = NumbObserv,
    y = rmse,
    fill = NumbObserv,
    color=NumbObserv
  )
) +
  geom_boxplot(
    outlier.alpha = 0.3,
    width = 0.7,
    alpha=0.5
  ) +
  facet_grid(
     ~ Design
  ) +
  labs(
    x = "Number of total observations",
    y = "RMSE",
    fill = "Algorithm"
  ) +
  scale_fill_manual(
    values = c(
      N45 ="forestgreen",
      N90 = "goldenrod1",
      N152 = "royalblue"
    )
  ) +
  scale_color_manual(
    values = c(
      N45 ="forestgreen",
      N90 = "goldenrod1",
      N152 = "royalblue"
    )
  ) +
  theme( axis.title=element_text(size=17),
         axis.text.x =element_text(size=13),
         legend.text=element_text(size=19),
         plot.title = element_text(size=21),
         strip.text = element_text(size = 15),
         legend.title=element_blank(),
         panel.background = element_rect(fill = "gray96",
                                         colour = "gray96",
                                         size = 0.5, linetype = "solid"),
         panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                         colour = "white"), 
         panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                         colour = "white"),
         legend.position = "bottom"
  ) +
  guides(color="none",fill="none")


#p_3d_rmse

#'------------------------------------------------------------------------------
#####  Combine Plot   ----
#'------------------------------------------------------------------------------

design <- "
AAAB
CCDD
"

p_2d_counts_per_t + guide_area() + 
  p_alert_3d_errors +  p_3d_rmse + 
  plot_layout(design=design,guides="collect")+plot_annotation(tag_levels = 'A',
                                                              title = 'Scenario 2 - Results') & 
  theme(plot.tag = element_text(size = 15),plot.title = element_text(size=23))
ggsave(file="./plots_tables/012_fig_simulation_res_scenario2.pdf",width=15,height=15)


#'------------------------------------------------------------------------------
####  Combine Plots H0 rejected   ----
#'------------------------------------------------------------------------------

p_h0_reject_scen1+p_h0_reject_scen2+guide_area()+
  plot_layout(ncol=3,guides="collect")+  plot_annotation(
    tag_levels = 1,
    tag_prefix = "Scenario ",
    tag_suffix = "",
    tag_sep = ""
  ) &
  theme(plot.tag = element_text(size = 15))
ggsave(file="./plots_tables/013_fig_simulation_res_h0_reject.pdf",width=13,height=4)
