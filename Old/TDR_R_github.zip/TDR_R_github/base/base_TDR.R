#'##############################################################################
#                                                                              #
#                  Corresponding R Code to the Manuscript                      #
#                "Estimating effect thresholds and beyond:                     #
#              A flexible framework for multivariate alert detection"          #
#                                                                              #
#                                 Authors                                      #
#                    L. Ameis, N. Hagemann and K. Moellenhoff                  #
#                                                                              #
#                                Base file                                     #
#                                                                              #
#'##############################################################################


#'==============================================================================
# Model function ====
#'==============================================================================

#'------------------------------------------------------------------------------
#' Sigma formula ---
#'------------------------------------------------------------------------------

#'create a function from the sigma formula, to calculate sigma using the results from
#'fitting the gamlss
#'we include donor,time and dose in the definition to allow for more difficult
#'sigma formulas
sigma_function <- function(sd,time=NA,dose=NA,donor=NA,sig.f=sigma_formula){ 
  data_eval <- data.frame(donor=factor(c(donor),levels=levels(donor_all)),
                          time=c(time),
                          dose=c(dose))
  
  df <- model.matrix(sig.f,data_eval)
  
  est_sigma <- df %*% sd
  
  return(est_sigma)
}



#'==============================================================================
# Model Estimation ====
#'==============================================================================

#'------------------------------------------------------------------------------
## Basic ----
#'------------------------------------------------------------------------------

#modelfit
modelfit_robust <- function(data){
  if(anyNA(data$donor)==T){
    data <- data %>% dplyr::select(time,dose,resp)
  }
  fit <-tryCatch({
    nlgamlss( y= resp,
              mu.fo = mu_formula,                          # mean model
              sigma.fo = sigma_formula,                    # sigma model
              mu.start = mu_start,                         # start values for mean
              sigma.start = sigma_start,                   # start values for sigma
              family = NO(),                               # assume normal errors
              data = data
    )
  }, error=function(e){
    list(mu.coefficients=NA,sigma.coefficients=NA)
  })
  
  coef <- fit$mu.coefficients
  sd <- fit$sigma.coefficients           
  
  return(list("fit_data"=fit,"coef"=coef,"sd"=sd))
}

#'------------------------------------------------------------------------------
## Fast version ----
#'------------------------------------------------------------------------------

modelfit_robust_fast <- function(data){
  fit <- fit_fast(data) 
  if(anyNA(fit)==T){coef <- NA
  sd <-NA}
  else{
  coef <- coef(fit)
  sd <- sqrt(RSS(fit)/df.residual(fit))
  }
  #we use log of sd, since simulation expects exp as linkfunction for
  #standard deviation
  return(list("fit_data"=fit,"coef"=coef,"sd"=log(sd)))
}

#'==============================================================================
# Simulation ====
#'==============================================================================

#simul

simul <- function(sd, par, time, dose, donor=NA){
  #sd is standard deviation
  #par as estimated form the data
  #time vector of data
  #dose vector of data
  #donor vector of data, if used for sigma_formula
  
  if(anyNA(donor)==T){                    #if we do not use the donor, we correct the length
    #for technical reasons
    donor <- rep(NA, times= length(time)) #Here, we assume, that if a donor vector
                                          #is supplied, non of the entries is NA
  }
  
  #calculate response
  resp <- model(t=time, d=dose, theta=par)
  
  #to store noise
  noise <- numeric(length(time))
  
  df <- model.matrix(sigma_formula,data.frame(time=time,
                                              dose=dose,
                                              donor=donor))
  
  #for each data entry
  for(i in 1:length(time)){
    #calculate estimate for sigma depending on the sigma_formula
    est_sigma <- df[i,] %*% sd
    
    #draw noise form normal distribution
    noise[i] <- rnorm(n=1, mean=0, sd=exp(est_sigma))
    
  }
  
  count <- resp+noise
  return(data.frame("time"=time,"dose"=dose,"resp"=count,"donor"=donor))
}


#'==============================================================================
# Bootstrap ====
#'==============================================================================
#bootstrap
bootstrap <- function(sd, par, B, time, dose, 
                      donor=NA, fast=F, 
                      fixtime=F,fixdose=F,
                      centertime=T,centerdose=T){
  #sd is standard deviation
  #par is theta
  #B is number of bootstrap runs
  #time is time vector of original data set
  #dose is dose vector of original data set
  #donor is donor vector of original data set (optional if used for sigma_formula)
  #fast if faster model fit should be used
  #fixtime/dose fix time or dose of interest (define either or not not both)
  #centertime/dose center model fit on model value at centertime/dose 
  #                if fixtime/dose is chosen, the value is automatically set
  #                as centertime/dose even if specified otherwise
  #                if no numeric value is chosen, the smallest time/dose is
  #                chosen as default
  
  fits <- list() #store ests 
  boot<-matrix(NA, nrow=B, ncol=nrow(grid_full)) #store results from run
  fail_runs <- numeric(B)   #number of runs, that don't converge
  for(i in 1:B){
    data_boot <- simul(sd=sd, par=par, time=time, dose=dose, donor=donor)
    if(fast==T){
      fit_boot <- modelfit_robust_fast(data_boot)  
    } else{
      fit_boot <- modelfit_robust(data_boot)
    }
    fits[[i]] <- fit_boot
    if(sum(is.na(fit_boot$coef))>0){
      fail_runs[[i]]<-1
    }
    
    if(centerdose==T){            #If no centerdose is chosen
      centerdose <- min(grid_full$dose)     #we set it to minimal dose
    }
    if(centertime==T){            #If no centertime is chosen
      centertime <- min(grid_full$time)     #we set it to minimal time
    }
    
    if(is.numeric(fixtime)==T){   #If a numeric fixtime is specified 
      centertime <- fixtime       #we overwrite centertime to fixtime
    }                             #regardless of specified value
    
    if(is.numeric(fixdose)==T){   #If a numeric fixdose is specified 
      centerdose <- fixtdose     #we overwrite centerdose to fixdose
    }  
    
    boot[i,] <- abs(model(t=grid_full$time,
                      d=grid_full$dose,
                      theta=fit_boot$coef)-model(t=rep(centertime,times=nrow(grid_full)),
                                                 d=rep(centerdose,times=nrow(grid_full)),
                                                 theta=fit_boot$coef))
  }
  return(list("fit"=fits, "boot"=boot,"failed_runs"=sum(fail_runs)))
}


#Of note, on our server, the td2pLL package could not be installed. Therefore
#it had to be temporarily removed from line 264, see scenario1_run_simulation for details
#on how this problem is handled
#bootstrap crit value
critval_boot <- function(outerboot, B_in, B_out, 
                         sd, par, time, dose,
                         fixtime=F,fixdose=F,
                         centertime=T,centerdose=T,
                         donor=NA,seeds,fast_in=F){
  #sd is standard deviation
  #par is theta
  #B_in is number of inner bootstrap runs
  #B_out is number of outer bootstrap runs
  #time is time vector of original data set
  #dose is dose vector of original data set
  #donor is donor vector of original data set (optional if used for sigma_formula)
  #seed vector for inner boostrap
  
  if(centerdose==T){            #If no centerdose is chosen
    centerdose <- min(grid_full$dose)     #we set it to minimal dose
  }
  if(centertime==T){            #If no centertime is chosen
    centertime <- min(grid_full$time)     #we set it to minimal time
  }
  
  if(is.numeric(fixtime)==T){   #If a numeric fixtime is specified 
    centertime <- fixtime       #we overwrite centertime to fixtime
  }                             #regardless of specified value
  
  if(is.numeric(fixdose)==T){   #If a numeric fixdose is specified 
    centerdose <- fixtdose     #we overwrite centerdose to fixdose
  }  
  
  
  if(fixtime==F&fixdose==F){
    #store
    D <- numeric(nrow(grid_full))
    
  } else{
    if(is.numeric(fixtime)==T){
    grid_fix <- grid_full %>%
      filter(time==fixtime)
    
    indices_fix <- which(grid_full$time==fixtime)
    #store
    D <- numeric(nrow(grid_full)+nrow(grid_fix))
    } 
    if(is.numeric(fixdose)==T){
        grid_fix <- grid_full %>%
          filter(dose==fixdose)
        
        indices_fix <- which(grid_full$dose==fixdose)
        #store
        D <- numeric(nrow(grid_full)+nrow(grid_fix))  
      
      }
    
  }
  all_failed_runs <- numeric(1)
  
  #inner boostrap using parallelization
  doParallel::registerDoParallel(cl=my.cluster)
  res <- foreach (m=1:B_out,
                  .combine ="rbind",
                  .export=c("mu_formula","sigma_formula","mu_start","sigma_start","model",
                            "fit_fast","bootstrap","simul","grid_full",
                            "td2pLL","modelfit_robust","modelfit_robust_fast",
                            "schuettler","schuettler_fast",
                            "schuettler_formula"),
                  .packages = c("minpack.lm","td2pLL","qpcR","gamlss","gamlss.nl","dplyr","stats4")) %dopar% {
                   set.seed(seeds[m])
                    
                    if(anyNA(outerboot$fit[[m]]$coef)==T){
                      all_failed_runs <- B_in
                      D <-  rep(NA,length(D))
                    } else{
                    #inner boostrap
                    inner_boot <- bootstrap(par=outerboot$fit[[m]]$coef,
                                                sd=outerboot$fit[[m]]$sd,
                                                B=B_in,
                                                time=time,
                                                dose=dose,
                                                donor=donor,
                                                fast=fast_in) # inner bootstrap for estimating the SE*
                    all_failed_runs <- inner_boot$failed_runs
                    inner_boot <- inner_boot$boot
                    
                    if(fixtime==F&fixdose==F){
                      for(l in 1:(nrow(grid_full))){
                        #calculate difference 
                        D[l] <-(outerboot$boot[m,l]-abs(model(t=grid_full$time[l],
                                                              d=grid_full$dose[l],
                                                              theta=par)-model(t=rep(centertime,times=nrow(grid_full)),
                                                                               d=rep(centerdose,times=nrow(grid_full)),
                                                                               theta=par)))/sd(inner_boot[,l],na.rm=T)
                      }
                    } else{
                      for(l in 1:(nrow(grid_full))){
                        #calculate difference 
                        D[l] <-(outerboot$boot[m,l]-abs(model(t=grid_full$time[l],
                                                              d=grid_full$dose[l],
                                                              theta=par)-model(t=rep(centertime,times=nrow(grid_full)),
                                                                               d=rep(centerdose,times=nrow(grid_full)),
                                                                               theta=par)))/sd(inner_boot[,l],na.rm=T)
                      }
                      for(l in 1:(nrow(grid_fix))){
                        #calculate difference
                        indice <- indices_fix[l]
                        D[nrow(grid_full)+l] <-(outerboot$boot[m,indice]-abs(model(t=grid_fix$time[l],
                                                                                   d=grid_fix$dose[l],
                                                                                   theta=par)-model(t=rep(centertime,times=nrow(grid_fix)),
                                                                                                    d=rep(centerdose,times=nrow(grid_fix)),
                                                                                                    theta=par)))/sd(inner_boot[,indice],na.rm=T)
                      }
                    }
                    D <- as.numeric(D)
                    }
                    D_add <- c(D,all_failed_runs)
                    D_add
                  }
  stopImplicitCluster()
  #return results
  res_boot <- res[,1:(ncol(res)-1)]
  all_failed_runs <- res[,ncol(res)]
  
  return(list("res"=res_boot,"all_failed_runs"=all_failed_runs))
}

#'==============================================================================
# Evaluation ====
#'==============================================================================

#estimate crit val
crit.val <- function(crit.val.boot, alpha,fixtime=F,fixdose=F){
  #crit.val.boot output from function above
  #alpha alpha level of test
  
  if(fixtime==F&fixdose==F){
    #exclude nans
    nancol <- numeric(ncol(crit.val.boot))
    for(i in 1:ncol(crit.val.boot)){
      if(any(is.nan(crit.val.boot[,i])==T)){
        nancol[i] <- 1
      } else{
        nancol[i] <- 0
      }
    }
    
    if(sum(nancol)>0){ 
      crit.val.boot_nna <- crit.val.boot[,-which(nancol==1)]
      #crit.val.boot results of function crit.val.boot
      #calculate max of difference over time for each run
    } else{
      crit.val.boot_nna <- crit.val.boot
    }
    
    narow <- numeric(nrow(crit.val.boot_nna))
    for(j in 1:nrow(crit.val.boot_nna)){
      if(sum(is.na(crit.val.boot_nna[j,])==T)==ncol(crit.val.boot_nna)){
      narow[j] <- 1  
      } else{
        narow[j] <- 0
      }
    }
    
    
    if(sum(narow)>0){ 
      crit.val.boot_nna <- crit.val.boot[-which(narow==1),]
      #crit.val.boot results of function crit.val.boot
      #calculate max of difference over time for each run
    } else{
      crit.val.boot_nna <- crit.val.boot_nna
    }
    
    
    Dmax <- rowMax(crit.val.boot_nna) 
    crit <- as.numeric(Dmax)
    
    #calculate quantile
    c <- quantile(crit,1-alpha,na.rm=TRUE)
    
  } else{
    crit.val.boot_full <- crit.val.boot[,1:nrow(grid_full)]
    crit.val.boot_fix <- crit.val.boot[,(nrow(grid_full)+1):ncol(crit.val.boot)]
    
    #exclude nans
    nancol <- numeric(ncol(crit.val.boot_full))
    for(i in 1:ncol(crit.val.boot_full)){
      if(any(is.nan(crit.val.boot_full[,i])==T)){
        nancol[i] <- 1
      } else{
        nancol[i] <- 0
      }
    }
    
    if(sum(nancol)>0){ 
      crit.val.boot_full_nna <- crit.val.boot_full[,-which(nancol==1)]
      #crit.val.boot results of function crit.val.boot
      #calculate max of difference over time for each run
    } else{
      crit.val.boot_full_nna <- crit.val.boot_full
    }
    
    
    narow <- numeric(nrow(crit.val.boot_full_nna))
    for(j in 1:nrow(crit.val.boot_full_nna)){
      if(sum(is.na(crit.val.boot_full_nna[j,])==T)==ncol(crit.val.boot_full_nna)){
        narow[j] <- 1  
      } else{
        narow[j] <- 0
      }
    }
    
    
    if(sum(narow)>0){ 
      crit.val.boot_full_nna <- crit.val.boot_full_nna[-which(narow==1),]
      #crit.val.boot results of function crit.val.boot
      #calculate max of difference over time for each run
    } else{
      crit.val.boot_full_nna <- crit.val.boot_full_nna
    }
    
    
    #exclude nans
    nancol <- numeric(ncol(crit.val.boot_fix))
    for(i in 1:ncol(crit.val.boot_fix)){
      if(any(is.nan(crit.val.boot_fix[,i])==T)){
        nancol[i] <- 1
      } else{
        nancol[i] <- 0
      }
    }
    
    if(sum(nancol)>0){ 
      crit.val.boot_fix_nna <- crit.val.boot_fix[,-which(nancol==1)]
      #crit.val.boot results of function crit.val.boot
      #calculate max of difference over time for each run
    } else{
      crit.val.boot_fix_nna <- crit.val.boot_fix
    }
    
    
    narow <- numeric(nrow(crit.val.boot_fix_nna))
    for(j in 1:nrow(crit.val.boot_fix_nna)){
      if(sum(is.na(crit.val.boot_fix_nna[j,])==T)==ncol(crit.val.boot_fix_nna)){
        narow[j] <- 1  
      } else{
        narow[j] <- 0
      }
    }
    
    
    if(sum(narow)>0){ 
      crit.val.boot_fix_nna <- crit.val.boot_fix_nna[-which(narow==1),]
      #crit.val.boot results of function crit.val.boot
      #calculate max of difference over time for each run
    } else{
      crit.val.boot_fix_nna <- crit.val.boot_fix_nna
    }
    
    
    Dmax_full <- rowMax(crit.val.boot_full_nna) 
    crit_full <- as.numeric(Dmax_full)
    
    #calculate quantile
    c_full <- quantile(crit_full,1-alpha,na.rm=TRUE)
    
    Dmax_fix <- rowMax(crit.val.boot_fix_nna) 
    crit_fix <- as.numeric(Dmax_fix)
    
    #calculate quantile
    c_fix <- quantile(crit_fix,1-alpha,na.rm=TRUE)
    
    c <- list("full"=c_full,"fix"=c_fix)
  }
  return(c)
}

#estimate confidence band
conf.bands <- function(par, c, outerboot, fixtime=F,fixdose=F,
                       centertime=T,centerdose=T){
  #par theta
  #c result from function crit.val (quantile of difference)
  #outerboot results outer bootstrap
  
  if(centerdose==T){            #If no centerdose is chosen
    centerdose <- min(grid_full$dose)     #we set it to minimal dose
  }
  if(centertime==T){            #If no centertime is chosen
    centertime <- min(grid_full$time)     #we set it to minimal time
  }
  
  if(is.numeric(fixtime)==T){   #If a numeric fixtime is specified 
    centertime <- fixtime       #we overwrite centertime to fixtime
  }                             #regardless of specified value
  
  if(is.numeric(fixdose)==T){   #If a numeric fixdose is specified 
    centerdose <- fixtdose     #we overwrite centerdose to fixdose
  }  
  
  
  if(fixtime==F&fixdose==F){
    #store confidence band
    low.cf_full<-numeric(nrow(grid_full))
    
  } else{
    c_full <- c$full
    c_fix <- c$fix
    
    if(is.numeric(fixtime)==T){
    grid_fix <- grid_full %>%
      filter(time==fixtime)
    
    indices_fix <- which(grid_full$time==fixtime)
    
    }
    
    if(is.numeric(fixdose)==T){
      grid_fix <- grid_full %>%
        filter(dose==fixdose)
      
      indices_fix <- which(grid_full$dose==fixdose)
      
    }
    #store confidence band
    low.cf_full<-numeric(nrow(grid_full))
    low.cf_fix<-numeric(nrow(grid_fix))
    
    
  }
  
  
  if(fixtime==F&fixdose==F){
    #calculate confidence band for grid
    for(l in 1:(nrow(grid_full))){
      tx <- abs(model(t=grid_full$time[l],
                  d=grid_full$dose[l],
                  theta=par)-model(t=rep(centertime,times=nrow(grid_full)),
                                   d=rep(centerdose,times=nrow(grid_full)),
                                   theta=par) )
      #pointwise estimated variance (each l is one point of the grid)
      var.FC <- var(outerboot$boot[,l],na.rm = T)
      corfac <- c*sqrt(var.FC)
      low.cf_full[l] <- tx - corfac
      
    }
    return(low.cf=low.cf_full)
  } else{
    #calculate confidence band for grid
    for(l in 1:(nrow(grid_full))){
      tx <- abs(model(t=grid_full$time[l],
                  d=grid_full$dose[l],
                  theta=par)-model(t=rep(centertime,times=nrow(grid_full)),
                                  d=rep(centerdose,times=nrow(grid_full)),
                                  theta=par))
      #pointwise estimated variance (each l is one point of the grid)
      var.FC <- var(outerboot$boot[,l],na.rm=T)
      corfac <- c_full*sqrt(var.FC)
      low.cf_full[l] <- tx - corfac
      
    }
    
    for(l in 1:nrow(grid_fix)){
      tx <- abs(model(t=grid_fix$time[l],
                  d=grid_fix$dose[l],
                  theta=par)-model(t=rep(centertime,times=nrow(grid_fix)),
                                  d=rep(centerdose,times=nrow(grid_fix)),
                                  theta=par)) 
      #pointwise estimated variance (each l is one point of the grid)
      var.FC <- var(outerboot$boot[,indices_fix[l]],na.rm=T)
      corfac <- c_fix*sqrt(var.FC)
      low.cf_fix[l] <- tx - corfac
    }
    low.cf <- list("full"=low.cf_full,"fix"=low.cf_fix)
  }
}

