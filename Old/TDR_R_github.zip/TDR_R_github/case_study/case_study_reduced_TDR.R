#'##############################################################################
#                                                                              #
#                  Corresponding R Code to the Manuscript                      #
#                "Estimating effect thresholds and beyond:                     #
#              A flexible framework for multivariate alert detection"          #
#                                                                              #
#                                 Authors                                      #
#                    L. Ameis, N. Hagemann and K. Moellenhoff                  #
#                                                                              #
#                         Case study - Reduced                                 #
#                                                                              #
#'##############################################################################

#'==============================================================================
#'Analysis with td2pLL ====
#'==============================================================================

model <- td2pLL

fit_fast <- td2pLL_fast

mu_formula <- td2pLL_formula


#'------------------------------------------------------------------------------
# Basic mean model fit ----
#'------------------------------------------------------------------------------

#Investigate fitting start parameters
fit_jcd <- fit_td2pLL(data = data_subset_reduced[,c(1,2,4)]) #Use modelfit from td2pLL package
summary(fit_jcd)                                #Start parameters for mean

mu_start <- list(h = 3, Delta = 6, gamma = 2, C0 = 5)


#'------------------------------------------------------------------------------
# Basic sd model fit  ----
#'------------------------------------------------------------------------------

#Prepare data set
data_subset_reduced_sd <- data_subset_reduced          %>%      #combine data via sd
  group_by(time,dose)            %>%
  summarize(resp_sd=sd(resp))

#CASE 1: Constant
sigma_formula_case1 <- ~1
#identify starting values for constant case
error_model <- glm(                             #estimate error model with glm 
  resp_sd ~ 1,
  family = gaussian(link = "log"),              #Log-Link 
  data = data_subset_reduced_sd
)
summary(error_model)                            #start parameters for sd 

sigma_start_case1 <- coef(error_model)

#Fit gamlss
td2pLL_fit_gamlss_nl_donor_reduced_case1<-nlgamlss( y= resp,
                                            mu.fo = mu_formula, 
                                            sigma.fo = sigma_formula_case1,
                                            mu.start = mu_start,                         
                                            sigma.start = sigma_start_case1,                                                 # Startwerte für sigma
                                            family = NO(),                                                                  # Normalverteilung
                                            data = data_subset_reduced
)

td2pLL_fit_gamlss_nl_donor_reduced_case1$aic
#440.0188


#CASE 2: From Duda et al
sigma_formula_case2 <- ~ dose+I(dose^2)+time+I(dose^2):time
#identify starting values for constant case
error_model <- glm(                             #estimate error model with glm 
  resp_sd ~ dose+I(dose^2)+time+I(dose^2):time,
  family = gaussian(link = "log"),              #Log-Link 
  data = data_subset_reduced_sd
)
summary(error_model)                            #start parameters for sd 

sigma_start_case2 <- coef(error_model)

#Fit gamlss
td2pLL_fit_gamlss_nl_donor_reduced_case2<-nlgamlss( y= resp,
                                            mu.fo = mu_formula, 
                                            sigma.fo = sigma_formula_case2,
                                            mu.start = mu_start,                         
                                            sigma.start = sigma_start_case2,                                                 # Startwerte für sigma
                                            family = NO(),                                                                  # Normalverteilung
                                            data = data_subset_reduced
)

td2pLL_fit_gamlss_nl_donor_reduced_case2$aic
#447.8604

#'------------------------------------------------------------------------------
# Analysis (Fixtime 4) ----
#'------------------------------------------------------------------------------

#CASE 1

sigma_formula <- sigma_formula_case1
sigma_start <- sigma_start_case1
td2pLL_fit_gamlss_nl_donor<-td2pLL_fit_gamlss_nl_donor_reduced_case1



#Est conf band
if(file.exists("./case_study/td2pLL_analysis_gamlssnl_donor_reduced_CASE1.RData")){
  load("./case_study/td2pLL_analysis_gamlssnl_donor_reduced_CASE1.RData")
} else{
  set.seed(5211)
  seeds_gamlssnl_donor <- runif(B_out, min = 0, max=1000000)
  outerbootstrap_gamlssnl_donor <- bootstrap(sd=td2pLL_fit_gamlss_nl_donor$sigma.coefficients,
                                             par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                             B=B_out,
                                             time=data_subset_reduced$time,
                                             dose=data_subset_reduced$dose,
                                             donor=data_subset_reduced$donor)
  # system.time()
  # user     system elapsed 
  # 25.25    0.44   25.80 
  crit.val_boot_gamlssnl_donor <- critval_boot(outerboot=outerbootstrap_gamlssnl_donor,
                                               B_in=B_in,
                                               B_out=B_out,
                                               sd=td2pLL_fit_gamlss_nl_donor$sigma.coefficients,
                                               par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                               time=data_subset_reduced$time,
                                               dose=data_subset_reduced$dose,
                                               donor=data_subset_reduced$donor,
                                               seeds=seeds_gamlssnl_donor,
                                               fixtime = 4)
  # system.time()
  # user  system elapsed 
  # 5.36    1.30   87.50 
  crit.val_gamlssnl_donor <- crit.val(crit.val.boot=crit.val_boot_gamlssnl_donor$res,
                                      alpha=0.05,
                                      fixtime=4)
  conf.band_gamlssnl_donor <- conf.bands(par=td2pLL_fit_gamlss_nl_donor$mu.coefficients, 
                                         c=crit.val_gamlssnl_donor, 
                                         outerboot = outerbootstrap_gamlssnl_donor,
                                         fixtime=4)
  
  td2pLL_analysis_gamlssnl_donor_reduced_CASE1 <- list("boot"=outerbootstrap_gamlssnl_donor,
                                               "crit_boot"=crit.val_boot_gamlssnl_donor,
                                               "crit_val"=crit.val_gamlssnl_donor,
                                               "conf"=conf.band_gamlssnl_donor)
  save(td2pLL_analysis_gamlssnl_donor_reduced_CASE1,
       file="./case_study/td2pLL_analysis_gamlssnl_donor_reduced_CASE1.RData")
  
}

min(which(td2pLL_analysis_gamlssnl_donor_reduced_CASE1$conf$fixtime<50))
#72
dose_seq[72]
#7.1

conf_band_mat_gamlssnl_donor <- td2pLL_analysis_gamlssnl_donor_reduced_CASE1$conf$full   %>%
  cbind(grid_full, "cf"=. )                %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

min(which(conf_band_mat_gamlssnl_donor[31,]<50))
#79
dose_seq[79]
#7.8

res_td2pLL_CASE1_reduced <- c("td2pLL","Case 1","normal",dose_seq[72],dose_seq[79])


#CASE 2

sigma_formula <- sigma_formula_case2
sigma_start <- sigma_start_case2
td2pLL_fit_gamlss_nl_donor<-td2pLL_fit_gamlss_nl_donor_reduced_case2



#Est conf band
if(file.exists("./case_study/td2pLL_analysis_gamlssnl_donor_reduced_CASE2.RData")){
  load("./case_study/td2pLL_analysis_gamlssnl_donor_reduced_CASE2.RData")
} else{
  set.seed(55733)
  seeds_gamlssnl_donor <- runif(B_out, min = 0, max=1000000)
  outerbootstrap_gamlssnl_donor <- bootstrap(sd=td2pLL_fit_gamlss_nl_donor$sigma.coefficients,
                                             par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                             B=B_out,
                                             time=data_subset_reduced$time,
                                             dose=data_subset_reduced$dose,
                                             donor=data_subset_reduced$donor)
  # system.time()
  # user     system elapsed 
  # 56.45    0.94   57.7 
  crit.val_boot_gamlssnl_donor <- critval_boot(outerboot=outerbootstrap_gamlssnl_donor,
                                               B_in=B_in,
                                               B_out=B_out,
                                               sd=td2pLL_fit_gamlss_nl_donor$sigma.coefficients,
                                               par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                               time=data_subset_reduced$time,
                                               dose=data_subset_reduced$dose,
                                               donor=data_subset_reduced$donor,
                                               seeds=seeds_gamlssnl_donor,
                                               fixtime = 4)
  # system.time()
  # user  system elapsed 
  # 5.75    1.03  159.34 
  crit.val_gamlssnl_donor <- crit.val(crit.val.boot=crit.val_boot_gamlssnl_donor$res,
                                      alpha=0.05,
                                      fixtime=4)
  conf.band_gamlssnl_donor <- conf.bands(par=td2pLL_fit_gamlss_nl_donor$mu.coefficients, 
                                         c=crit.val_gamlssnl_donor, 
                                         outerboot = outerbootstrap_gamlssnl_donor,
                                         fixtime=4)
  
  td2pLL_analysis_gamlssnl_donor_reduced_CASE2 <- list("boot"=outerbootstrap_gamlssnl_donor,
                                               "crit_boot"=crit.val_boot_gamlssnl_donor,
                                               "crit_val"=crit.val_gamlssnl_donor,
                                               "conf"=conf.band_gamlssnl_donor)
  save(td2pLL_analysis_gamlssnl_donor_reduced_CASE2,
       file="./case_study/td2pLL_analysis_gamlssnl_donor_reduced_CASE2.RData")
  
}

min(which(td2pLL_analysis_gamlssnl_donor_reduced_CASE2$conf$fixtime<50))
#67
dose_seq[67]
#6.6

conf_band_mat_gamlssnl_donor <- td2pLL_analysis_gamlssnl_donor_reduced_CASE2$conf$full   %>%
  cbind(grid_full, "cf"=. )                %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

min(which(conf_band_mat_gamlssnl_donor[31,]<50))
#69
dose_seq[69]
#6.8

res_td2pLL_CASE2_reduced <- c("td2pLL","Case 2","normal",dose_seq[67],dose_seq[69])



#'------------------------------------------------------------------------------
# Analysis (Fixtime 4/Fast) ----
#'------------------------------------------------------------------------------

#CASE 1

sigma_formula <- sigma_formula_case1
sigma_start <- sigma_start_case1
td2pLL_fit_gamlss_nl_donor<-td2pLL_fit_gamlss_nl_donor_reduced_case1



#Est conf band
if(file.exists("./case_study/tdpLL_analysis_gamlssnl_donor_fast_reduced_CASE1.RData")){
  load("./case_study/tdpLL_analysis_gamlssnl_donor_fast_reduced_CASE1.RData")
} else{
  set.seed(447)
  seeds_gamlssnl_donor_fast <- runif(B_out, min = 0, max=1000000)
  outerbootstrap_gamlssnl_donor_fast <- bootstrap(sd=td2pLL_fit_gamlss_nl_donor$sigma.coefficients,
                                                  par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                                  B=B_out,
                                                  time=data_subset_reduced$time,
                                                  dose=data_subset_reduced$dose,
                                                  donor=data_subset_reduced$donor)
  # system.time()
  # user  system elapsed 
  # 25.12    0.28   25.49
  crit.val_boot_gamlssnl_donor_fast <- critval_boot(outerboot=outerbootstrap_gamlssnl_donor_fast,
                                                    B_in=B_in,
                                                    B_out=B_out,
                                                    sd=td2pLL_fit_gamlss_nl_donor$sigma.coefficients,
                                                    par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                                    time=data_subset_reduced$time,
                                                    dose=data_subset_reduced$dose,
                                                    donor=data_subset_reduced$donor,
                                                    seeds=seeds_gamlssnl_donor_fast,
                                                    fixtime = 4,
                                                    fast_in=T)
  # system.time()
  # user  system elapsed 
  # 5.31    1.11   53.94 
  crit.val_gamlssnl_donor_fast <- crit.val(crit.val.boot=crit.val_boot_gamlssnl_donor_fast$res,
                                           alpha=0.05,
                                           fixtime=4)
  conf.band_gamlssnl_donor_fast <- conf.bands(par=td2pLL_fit_gamlss_nl_donor$mu.coefficients, 
                                              c=crit.val_gamlssnl_donor_fast, 
                                              outerboot = outerbootstrap_gamlssnl_donor_fast,
                                              fixtime=4)
  
  td2pLL_analysis_gamlssnl_donor_fast_reduced_CASE1 <- list("boot"=outerbootstrap_gamlssnl_donor_fast,
                                                    "crit_boot"=crit.val_boot_gamlssnl_donor_fast,
                                                    "crit_val"=crit.val_gamlssnl_donor_fast,
                                                    "conf"=conf.band_gamlssnl_donor_fast)
  save(td2pLL_analysis_gamlssnl_donor_fast_reduced_CASE1,
       file="./case_study/tdpLL_analysis_gamlssnl_donor_fast_reduced_CASE1.RData")
  
}


min(which(td2pLL_analysis_gamlssnl_donor_fast_reduced_CASE1$conf$fixtime<50))
#70
dose_seq[70]
#6.9

conf_band_mat_gamlssnl_donor_fast <- td2pLL_analysis_gamlssnl_donor_fast_reduced_CASE1$conf$full   %>%
  cbind(grid_full, "cf"=. )                %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

min(which(conf_band_mat_gamlssnl_donor_fast[31,]<50))
#80
dose_seq[80]
#7.9

res_td2pLL_CASE1_fast_reduced <- c("td2pLL","Case 1","fast",dose_seq[70],dose_seq[80])


#CASE 2

sigma_formula <- sigma_formula_case2
sigma_start <- sigma_start_case2
td2pLL_fit_gamlss_nl_donor<-td2pLL_fit_gamlss_nl_donor_reduced_case2



#Est conf band
if(file.exists("./case_study/tdpLL_analysis_gamlssnl_donor_fast_reduced_CASE2.RData")){
  load("./case_study/tdpLL_analysis_gamlssnl_donor_fast_reduced_CASE2.RData")
} else{
  set.seed(76777)
  seeds_gamlssnl_donor_fast <- runif(B_out, min = 0, max=1000000)
  outerbootstrap_gamlssnl_donor_fast <- bootstrap(sd=td2pLL_fit_gamlss_nl_donor$sigma.coefficients,
                                                  par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                                  B=B_out,
                                                  time=data_subset_reduced$time,
                                                  dose=data_subset_reduced$dose,
                                                  donor=data_subset_reduced$donor)
  # system.time()
  # user  system elapsed 
  # 53.75    1.36   55.45
  crit.val_boot_gamlssnl_donor_fast <- critval_boot(outerboot=outerbootstrap_gamlssnl_donor_fast,
                                                    B_in=B_in,
                                                    B_out=B_out,
                                                    sd=td2pLL_fit_gamlss_nl_donor$sigma.coefficients,
                                                    par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                                    time=data_subset_reduced$time,
                                                    dose=data_subset_reduced$dose,
                                                    donor=data_subset_reduced$donor,
                                                    seeds=seeds_gamlssnl_donor_fast,
                                                    fixtime = 4,
                                                    fast_in=T)
  # system.time()
  # user  system elapsed 
  # 5.17    1.07   53.98 
  crit.val_gamlssnl_donor_fast <- crit.val(crit.val.boot=crit.val_boot_gamlssnl_donor_fast$res,
                                           alpha=0.05,
                                           fixtime=4)
  conf.band_gamlssnl_donor_fast <- conf.bands(par=td2pLL_fit_gamlss_nl_donor$mu.coefficients, 
                                              c=crit.val_gamlssnl_donor_fast, 
                                              outerboot = outerbootstrap_gamlssnl_donor_fast,
                                              fixtime=4)
  
  td2pLL_analysis_gamlssnl_donor_fast_reduced_CASE2 <- list("boot"=outerbootstrap_gamlssnl_donor_fast,
                                                    "crit_boot"=crit.val_boot_gamlssnl_donor_fast,
                                                    "crit_val"=crit.val_gamlssnl_donor_fast,
                                                    "conf"=conf.band_gamlssnl_donor_fast)
  save(td2pLL_analysis_gamlssnl_donor_fast_reduced_CASE2,
       file="./case_study/tdpLL_analysis_gamlssnl_donor_fast_reduced_CASE2.RData")
  
}


min(which(td2pLL_analysis_gamlssnl_donor_fast_reduced_CASE2$conf$fixtime<50))
#63
dose_seq[63]
#6.2

conf_band_mat_gamlssnl_donor_fast <- td2pLL_analysis_gamlssnl_donor_fast_reduced_CASE2$conf$full   %>%
  cbind(grid_full, "cf"=. )                %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

min(which(conf_band_mat_gamlssnl_donor_fast[31,]<50))
#68
dose_seq[68]
#6.7


res_td2pLL_CASE2_fast_reduced <- c("td2pLL","Case 2","fast",dose_seq[63],dose_seq[68])


#'==============================================================================
#'Analysis with schuettler formula ====
#'==============================================================================

model <- schuettler

fit_fast <- schuettler_fast

mu_formula <- schuettler_formula

#'------------------------------------------------------------------------------
# Basic model fit ----
#'------------------------------------------------------------------------------

#Investigate fitting start parameters
fit_schuettler <- nlsLM(resp ~ log2FC_max/(                         #Use basic model fit
  1+exp(
    -slope*(
      log(dose)-log(
        1/(
          S_max*exp(
            -0.5*(
              (log(time)-log(t_max))/S_dur
            )^2
          )
        )
      )
    )
  )
),
data = data_subset_reduced,
start = list(log2FC_max=100,slope = -3, S_max = 0.2, t_max = 5.5, S_dur = 1.4) )
summary(fit_schuettler)                                       

mu_start <- list(log2FC_max=100,slope = -3, S_max=0.2,t_max=7, S_dur=1.5)


#'------------------------------------------------------------------------------
# Basic sd model fit  ----
#'------------------------------------------------------------------------------

#Prepare data set
data_subset_reduced_sd <- data_subset_reduced          %>%      #combine data via sd
  group_by(time,dose)            %>%
  summarize(resp_sd=sd(resp))

#CASE 1: Constant
sigma_formula_case1 <- ~1
#identify starting values for constant case
error_model <- glm(                             #estimate error model with glm 
  resp_sd ~ 1,
  family = gaussian(link = "log"),              #Log-Link 
  data = data_subset_reduced_sd
)
summary(error_model)                            #start parameters for sd 

sigma_start_case1 <- coef(error_model)

#Fit gamlss
schuettler_fit_gamlss_nl_donor_reduced_case1 <-nlgamlss( y= resp,
                                                 mu.fo = mu_formula, 
                                                 sigma.fo = sigma_formula_case1,
                                                 mu.start = mu_start,                         
                                                 sigma.start = sigma_start_case1,                                                 # Startwerte für sigma
                                                 family = NO(),                                                                  # Normalverteilung
                                                 data = data_subset_reduced
)

schuettler_fit_gamlss_nl_donor_reduced_case1$aic
#441.9928



#CASE 2: From Duda et al
sigma_formula_case2 <- ~ dose+I(dose^2)+time+I(dose^2):time
#identify starting values for constant case
error_model <- glm(                             #estimate error model with glm 
  resp_sd ~ dose+I(dose^2)+time+I(dose^2):time,
  family = gaussian(link = "log"),              #Log-Link 
  data = data_subset_reduced_sd
)
summary(error_model)                            #start parameters for sd 

sigma_start_case2 <- coef(error_model)

#Fit gamlss
schuettler_fit_gamlss_nl_donor_reduced_case2 <-nlgamlss( y= resp,
                                                 mu.fo = mu_formula, 
                                                 sigma.fo = sigma_formula_case2,
                                                 mu.start = mu_start,                         
                                                 sigma.start = sigma_start_case2,                                                 # Startwerte für sigma
                                                 family = NO(),                                                                  # Normalverteilung
                                                 data = data_subset_reduced
)

schuettler_fit_gamlss_nl_donor_reduced_case2$aic
#448.8963




#'------------------------------------------------------------------------------
# Analysis (Fixtime 4) ----
#'------------------------------------------------------------------------------

#CASE 1

sigma_formula <- sigma_formula_case1
sigma_start <- sigma_start_case1
schuettler_fit_gamlss_nl_donor<-schuettler_fit_gamlss_nl_donor_reduced_case1


#Est conf band
if(file.exists("./case_study/schuettler_analysis_gamlssnl_donor_reduced_CASE1.RData")){
  load("./case_study/schuettler_analysis_gamlssnl_donor_reduced_CASE1.RData")
} else{
  set.seed(1111)
  seeds_gamlssnl_donor <- runif(B_out, min = 0, max=1000000)
  outerbootstrap_gamlssnl_donor <- bootstrap(sd=schuettler_fit_gamlss_nl_donor$sigma.coefficients,
                                             par=schuettler_fit_gamlss_nl_donor$mu.coefficients,
                                             B=B_out,
                                             time=data_subset_reduced$time,
                                             dose=data_subset_reduced$dose,
                                             donor=data_subset_reduced$donor)
  # system.time()
  # user  system elapsed 
  # 45.49    1.16   49.00 
  crit.val_boot_gamlssnl_donor <- critval_boot(outerboot=outerbootstrap_gamlssnl_donor,
                                               B_in=B_in,
                                               B_out=B_out,
                                               sd=schuettler_fit_gamlss_nl_donor$sigma.coefficients,
                                               par=schuettler_fit_gamlss_nl_donor$mu.coefficients,
                                               time=data_subset_reduced$time,
                                               dose=data_subset_reduced$dose,
                                               donor=data_subset_reduced$donor,
                                               seeds=seeds_gamlssnl_donor,
                                               fixtime = 4)
  # system.time()
  # user  system elapsed 
  # 5.87    1.36  126.41 
  crit.val_gamlssnl_donor <- crit.val(crit.val.boot=crit.val_boot_gamlssnl_donor$res,
                                      alpha=0.05,
                                      fixtime=4)
  conf.band_gamlssnl_donor <- conf.bands(par=schuettler_fit_gamlss_nl_donor$mu.coefficients, 
                                         c=crit.val_gamlssnl_donor, 
                                         outerboot = outerbootstrap_gamlssnl_donor,
                                         fixtime=4)
  
  schuettler_analysis_gamlssnl_donor_reduced_CASE1 <- list("boot"=outerbootstrap_gamlssnl_donor,
                                                   "crit_boot"=crit.val_boot_gamlssnl_donor,
                                                   "crit_val"=crit.val_gamlssnl_donor,
                                                   "conf"=conf.band_gamlssnl_donor)
  save(schuettler_analysis_gamlssnl_donor_reduced_CASE1,
       file="./case_study/schuettler_analysis_gamlssnl_donor_reduced_CASE1.RData")
  
}


min(which(schuettler_analysis_gamlssnl_donor_reduced_CASE1$conf$fixtime<50))
#79
dose_seq[79]
#7.8

conf_band_mat_gamlssnl_donor <- schuettler_analysis_gamlssnl_donor_reduced_CASE1$conf$full   %>%
  cbind(grid_full, "cf"=. )                %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

min(which(conf_band_mat_gamlssnl_donor[31,]<50))
#84
dose_seq[84]
#8.3


res_schuettler_CASE1_reduced <- c("schuettler","Case 1","normal",dose_seq[79],dose_seq[84])

#CASE 2

sigma_formula <- sigma_formula_case2
sigma_start <- sigma_start_case2
schuettler_fit_gamlss_nl_donor<-schuettler_fit_gamlss_nl_donor_reduced_case2


#Est conf band
if(file.exists("./case_study/schuettler_analysis_gamlssnl_donor_reduced_CASE2.RData")){
  load("./case_study/schuettler_analysis_gamlssnl_donor_reduced_CASE2.RData")
} else{
  set.seed(3111111)
  seeds_gamlssnl_donor <- runif(B_out, min = 0, max=1000000)
  outerbootstrap_gamlssnl_donor <- bootstrap(sd=schuettler_fit_gamlss_nl_donor$sigma.coefficients,
                                             par=schuettler_fit_gamlss_nl_donor$mu.coefficients,
                                             B=B_out,
                                             time=data_subset_reduced$time,
                                             dose=data_subset_reduced$dose,
                                             donor=data_subset_reduced$donor)
  # system.time()
  # user  system elapsed 
  # 115.70    2.86  120.07  
  crit.val_boot_gamlssnl_donor <- critval_boot(outerboot=outerbootstrap_gamlssnl_donor,
                                               B_in=B_in,
                                               B_out=B_out,
                                               sd=schuettler_fit_gamlss_nl_donor$sigma.coefficients,
                                               par=schuettler_fit_gamlss_nl_donor$mu.coefficients,
                                               time=data_subset_reduced$time,
                                               dose=data_subset_reduced$dose,
                                               donor=data_subset_reduced$donor,
                                               seeds=seeds_gamlssnl_donor,
                                               fixtime = 4)
  # system.time()
  # user  system elapsed 
  # 7.13    2.39  255.28 
  crit.val_gamlssnl_donor <- crit.val(crit.val.boot=crit.val_boot_gamlssnl_donor$res,
                                      alpha=0.05,
                                      fixtime=4)
  conf.band_gamlssnl_donor <- conf.bands(par=schuettler_fit_gamlss_nl_donor$mu.coefficients, 
                                         c=crit.val_gamlssnl_donor, 
                                         outerboot = outerbootstrap_gamlssnl_donor,
                                         fixtime=4)
  
  schuettler_analysis_gamlssnl_donor_reduced_CASE2 <- list("boot"=outerbootstrap_gamlssnl_donor,
                                                   "crit_boot"=crit.val_boot_gamlssnl_donor,
                                                   "crit_val"=crit.val_gamlssnl_donor,
                                                   "conf"=conf.band_gamlssnl_donor)
  save(schuettler_analysis_gamlssnl_donor_reduced_CASE2,
       file="./case_study/schuettler_analysis_gamlssnl_donor_reduced_CASE2.RData")
  
}


min(which(schuettler_analysis_gamlssnl_donor_reduced_CASE2$conf$fixtime<50))
#75
dose_seq[75]
#7.4

conf_band_mat_gamlssnl_donor <- schuettler_analysis_gamlssnl_donor_reduced_CASE2$conf$full   %>%
  cbind(grid_full, "cf"=. )                %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

min(which(conf_band_mat_gamlssnl_donor[31,]<50))
#80
dose_seq[80]
#7.9

res_schuettler_CASE2_reduced <- c("schuettler","Case 2","normal",dose_seq[75],dose_seq[80])


#'------------------------------------------------------------------------------
# Analysis (Fixtime 4/Fast)  ----
#'------------------------------------------------------------------------------


#CASE 1

sigma_formula <- sigma_formula_case1
sigma_start <- sigma_start_case1
schuettler_fit_gamlss_nl_donor<-schuettler_fit_gamlss_nl_donor_reduced_case1


#Est conf band
if(file.exists("./case_study/schuettler_analysis_gamlssnl_donor_fast_reduced_CASE1.RData")){
  load("./case_study/schuettler_analysis_gamlssnl_donor_fast_reduced_CASE1.RData")
} else{
  set.seed(413)
  seeds_gamlssnl_donor_fast <- runif(B_out, min = 0, max=1000000)
  outerbootstrap_gamlssnl_donor_fast <- bootstrap(sd=schuettler_fit_gamlss_nl_donor$sigma.coefficients,
                                                  par=schuettler_fit_gamlss_nl_donor$mu.coefficients,
                                                  B=B_out,
                                                  time=data_subset_reduced$time,
                                                  dose=data_subset_reduced$dose,
                                                  donor=data_subset_reduced$donor)
  # system.time()
  # user  system elapsed 
  # 64.67    1.42   66.72 
  crit.val_boot_gamlssnl_donor_fast <- critval_boot(outerboot=outerbootstrap_gamlssnl_donor_fast,
                                                    B_in=B_in,
                                                    B_out=B_out,
                                                    sd=schuettler_fit_gamlss_nl_donor$sigma.coefficients,
                                                    par=schuettler_fit_gamlss_nl_donor$mu.coefficients,
                                                    time=data_subset_reduced$time,
                                                    dose=data_subset_reduced$dose,
                                                    donor=data_subset_reduced$donor,
                                                    seeds=seeds_gamlssnl_donor_fast,
                                                    fixtime = 4,
                                                    fast_in=T)
  # system.time()
  # user  system elapsed 
  # 6.93    1.74   36.28
  crit.val_gamlssnl_donor_fast <- crit.val(crit.val.boot=crit.val_boot_gamlssnl_donor_fast$res,
                                           alpha=0.05,
                                           fixtime=4)
  conf.band_gamlssnl_donor_fast <- conf.bands(par=schuettler_fit_gamlss_nl_donor$mu.coefficients, 
                                              c=crit.val_gamlssnl_donor_fast, 
                                              outerboot = outerbootstrap_gamlssnl_donor_fast,
                                              fixtime=4)
  
  schuettler_analysis_gamlssnl_donor_fast_reduced_CASE1 <- list("boot"=outerbootstrap_gamlssnl_donor_fast,
                                                        "crit_boot"=crit.val_boot_gamlssnl_donor_fast,
                                                        "crit_val"=crit.val_gamlssnl_donor_fast,
                                                        "conf"=conf.band_gamlssnl_donor_fast)
  save(schuettler_analysis_gamlssnl_donor_fast_reduced_CASE1,
       file="./case_study/schuettler_analysis_gamlssnl_donor_fast_reduced_CASE1.RData")
  
}


min(which(schuettler_analysis_gamlssnl_donor_fast_reduced_CASE1$conf$fixtime<50))
#78
dose_seq[78]
#7.7

conf_band_mat_gamlssnl_donor_fast <- schuettler_analysis_gamlssnl_donor_fast_reduced_CASE1$conf$full   %>%
  cbind(grid_full, "cf"=. )                %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

min(which(conf_band_mat_gamlssnl_donor_fast[31,]<50))
#84
dose_seq[84]
#8.3

res_schuettler_CASE1_fast_reduced <- c("schuettler","Case 1","fast",dose_seq[78],dose_seq[84])



#CASE 2

sigma_formula <- sigma_formula_case2
sigma_start <- sigma_start_case2
schuettler_fit_gamlss_nl_donor<-schuettler_fit_gamlss_nl_donor_reduced_case2


#Est conf band
if(file.exists("./case_study/schuettler_analysis_gamlssnl_donor_fast_reduced_CASE2.RData")){
  load("./case_study/schuettler_analysis_gamlssnl_donor_fast_reduced_CASE2.RData")
} else{
  set.seed(6131313)
  seeds_gamlssnl_donor_fast <- runif(B_out, min = 0, max=1000000)
  outerbootstrap_gamlssnl_donor_fast <- bootstrap(sd=schuettler_fit_gamlss_nl_donor$sigma.coefficients,
                                                  par=schuettler_fit_gamlss_nl_donor$mu.coefficients,
                                                  B=B_out,
                                                  time=data_subset_reduced$time,
                                                  dose=data_subset_reduced$dose,
                                                  donor=data_subset_reduced$donor)
  # system.time()
  # user  system elapsed 
  # 102.70    2.35  106.03 
  crit.val_boot_gamlssnl_donor_fast <- critval_boot(outerboot=outerbootstrap_gamlssnl_donor_fast,
                                                    B_in=B_in,
                                                    B_out=B_out,
                                                    sd=schuettler_fit_gamlss_nl_donor$sigma.coefficients,
                                                    par=schuettler_fit_gamlss_nl_donor$mu.coefficients,
                                                    time=data_subset_reduced$time,
                                                    dose=data_subset_reduced$dose,
                                                    donor=data_subset_reduced$donor,
                                                    seeds=seeds_gamlssnl_donor_fast,
                                                    fixtime = 4,
                                                    fast_in=T)
  # system.time()
  # user  system elapsed 
  # 6.77    1.85   35.99 
  crit.val_gamlssnl_donor_fast <- crit.val(crit.val.boot=crit.val_boot_gamlssnl_donor_fast$res,
                                           alpha=0.05,
                                           fixtime=4)
  conf.band_gamlssnl_donor_fast <- conf.bands(par=schuettler_fit_gamlss_nl_donor$mu.coefficients, 
                                              c=crit.val_gamlssnl_donor_fast, 
                                              outerboot = outerbootstrap_gamlssnl_donor_fast,
                                              fixtime=4)
  
  schuettler_analysis_gamlssnl_donor_fast_reduced_CASE2 <- list("boot"=outerbootstrap_gamlssnl_donor_fast,
                                                        "crit_boot"=crit.val_boot_gamlssnl_donor_fast,
                                                        "crit_val"=crit.val_gamlssnl_donor_fast,
                                                        "conf"=conf.band_gamlssnl_donor_fast)
  save(schuettler_analysis_gamlssnl_donor_fast_reduced_CASE2,
       file="./case_study/schuettler_analysis_gamlssnl_donor_fast_reduced_CASE2.RData")
  
}


min(which(schuettler_analysis_gamlssnl_donor_fast_reduced_CASE2$conf$fixtime<50))
#68
dose_seq[68]
#6.7

conf_band_mat_gamlssnl_donor_fast <- schuettler_analysis_gamlssnl_donor_fast_reduced_CASE2$conf$full   %>%
  cbind(grid_full, "cf"=. )                %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

min(which(conf_band_mat_gamlssnl_donor_fast[31,]<50))
#74
dose_seq[74]
#7.3


res_schuettler_CASE2_fast_reduced <- c("schuettler","Case 2","fast",dose_seq[68],dose_seq[74])


#'==============================================================================
# Combine results in table ====
#'==============================================================================

#Note, that case 1 assumes constant standard deviation and therefore the normal
#and fast assumptions are identical
#Both were run to control the algorithm
#In the paper, only the fast results are presented, as there is a general
#focus on the fast approach

res_case_study_reduced <- rbind(#res_td2pLL_CASE1_reduced,
                                res_td2pLL_CASE1_fast_reduced,
                                res_td2pLL_CASE2_reduced,
                                res_td2pLL_CASE2_fast_reduced,
                                #res_schuettler_CASE1_reduced,
                                res_schuettler_CASE1_fast_reduced,
                                res_schuettler_CASE2_reduced,
                                res_schuettler_CASE2_fast_reduced)

colnames(res_case_study_reduced) <- c("Model","Case","Algorithm","2D alert","3D alert")
rownames(res_case_study_reduced) <- NULL
write.xlsx(res_case_study_reduced,"./plots_tables/002_res_case_study_reduced.xlsx", rowNames = FALSE)
