#'##############################################################################
#                                                                              #
#                  Corresponding R Code to the Manuscript                      #
#                "Estimating effect thresholds and beyond:                     #
#              A flexible framework for multivariate alert detection"          #
#                                                                              #
#                                 Authors                                      #
#                    L. Ameis, N. Hagemann and K. Moellenhoff                  #
#                                                                              #
#                        Case study  - Centered                                #
#                                                                              #
#'##############################################################################

#'==============================================================================
#'Analysis with td2pLL ====
#'==============================================================================

model <- td2pLL

fit_fast <- td2pLL_fast

mu_formula <- td2pLL_formula


#'------------------------------------------------------------------------------
# Basic mean model fit ----
#'------------------------------------------------------------------------------

#Investigate fitting start parameters
fit_jcd <- fit_td2pLL(data = data_subset[,2:4]) #Use modelfit from td2pLL package
summary(fit_jcd)                                #Start parameters for mean

mu_start <- list(h = 3, Delta = 6, gamma = 2, C0 = 5)


#'------------------------------------------------------------------------------
# Basic sd model fit  ----
#'------------------------------------------------------------------------------

#Prepare data set
data_subset_sd <- data_subset          %>%      #combine data via sd
  group_by(time,dose,donor)            %>%
  summarize(resp_sd=sd(resp))

#CASE 1: Constant
sigma_formula_case1 <- ~1
#identify starting values for constant case
error_model <- glm(                             #estimate error model with glm 
  resp_sd ~ 1,
  family = gaussian(link = "log"),              #Log-Link 
  data = data_subset_sd
)
summary(error_model)                            #start parameters for sd 

sigma_start_case1 <- coef(error_model)

#Fit gamlss
td2pLL_fit_gamlss_nl_donor_case1<-nlgamlss( y= resp,
                                            mu.fo = mu_formula, 
                                            sigma.fo = sigma_formula_case1,
                                            mu.start = mu_start,                         
                                            sigma.start = sigma_start_case1,                                                 # Startwerte für sigma
                                            family = NO(),                                                                  # Normalverteilung
                                            data = data_subset
)

td2pLL_fit_gamlss_nl_donor_case1$aic
#2137.09



#CASE 2: From Duda et al
sigma_formula_case2 <- ~ dose+I(dose^2)+time+I(dose^2):time
#identify starting values for constant case
error_model <- glm(                             #estimate error model with glm 
  resp_sd ~ dose+I(dose^2)+time+I(dose^2):time,
  family = gaussian(link = "log"),              #Log-Link 
  data = data_subset_sd
)
summary(error_model)                            #start parameters for sd 

sigma_start_case2 <- coef(error_model)

#Fit gamlss
td2pLL_fit_gamlss_nl_donor_case2<-nlgamlss( y= resp,
                                            mu.fo = mu_formula, 
                                            sigma.fo = sigma_formula_case2,
                                            mu.start = mu_start,                         
                                            sigma.start = sigma_start_case2,                                                 # Startwerte für sigma
                                            family = NO(),                                                                  # Normalverteilung
                                            data = data_subset
)

td2pLL_fit_gamlss_nl_donor_case2$aic
#2127.866

#'------------------------------------------------------------------------------
# Analysis (Fixtime 4) ----
#'------------------------------------------------------------------------------

#CASE 1

sigma_formula <- sigma_formula_case1
sigma_start <- sigma_start_case1
td2pLL_fit_gamlss_nl_donor<-td2pLL_fit_gamlss_nl_donor_case1

#Est conf band
if(file.exists("./case_study/centered_td2pLL_analysis_gamlssnl_donor_CASE1.RData")){
  load("./case_study/centered_td2pLL_analysis_gamlssnl_donor_CASE1.RData")
} else{
  set.seed(25)
  seeds_gamlssnl_donor <- runif(B_out, min = 0, max=1000000)
  outerbootstrap_gamlssnl_donor <- bootstrap(sd=td2pLL_fit_gamlss_nl_donor$sigma.coefficients,
                                             par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                             B=B_out,
                                             time=data_subset$time,
                                             dose=data_subset$dose,
                                             donor=data_subset$donor,
                                             fixtime=4)
  # system.time()
  # user     system elapsed 
  # 42.42    0.42   42.96
  crit.val_boot_gamlssnl_donor <- critval_boot(outerboot=outerbootstrap_gamlssnl_donor,
                                               B_in=B_in,
                                               B_out=B_out,
                                               sd=td2pLL_fit_gamlss_nl_donor$sigma.coefficients,
                                               par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                               time=data_subset$time,
                                               dose=data_subset$dose,
                                               donor=data_subset$donor,
                                               seeds=seeds_gamlssnl_donor,
                                               fixtime = 4)
  # system.time()
  # user  system elapsed 
  # 7.11    2.50  971.06 
  crit.val_gamlssnl_donor <- crit.val(crit.val.boot=crit.val_boot_gamlssnl_donor$res,
                                      alpha=0.05,
                                      fixtime=4)
  conf.band_gamlssnl_donor <- conf.bands(par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                         c=crit.val_gamlssnl_donor, 
                                         outerboot = outerbootstrap_gamlssnl_donor,
                                         fixtime=4)
  
  centered_td2pLL_analysis_gamlssnl_donor_CASE1 <- list("boot"=outerbootstrap_gamlssnl_donor,
                                         "crit_boot"=crit.val_boot_gamlssnl_donor,
                                         "crit_val"=crit.val_gamlssnl_donor,
                                         "conf"=conf.band_gamlssnl_donor)
  save(centered_td2pLL_analysis_gamlssnl_donor_CASE1,
       file="./case_study/centered_td2pLL_analysis_gamlssnl_donor_CASE1.RData")
  
}

min(which(centered_td2pLL_analysis_gamlssnl_donor_CASE1$conf$fix>50))
#63
dose_seq[63]
#6.2

conf_band_mat_gamlssnl_donor <- centered_td2pLL_analysis_gamlssnl_donor_CASE1$conf$full   %>%
  cbind(grid_full, "cf"=. )                %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

min(which(conf_band_mat_gamlssnl_donor[31,]>50))
#67
dose_seq[67]
#6.6

res_td2pLL_CASE1_centered <- c("td2pLL","Case 1","normal",dose_seq[63],dose_seq[67])


#CASE 2

sigma_formula <- sigma_formula_case2
sigma_start <- sigma_start_case2
td2pLL_fit_gamlss_nl_donor<-td2pLL_fit_gamlss_nl_donor_case2

#Est conf band
if(file.exists("./case_study/centered_td2pLL_analysis_gamlssnl_donor_CASE2.RData")){
  load("./case_study/centered_td2pLL_analysis_gamlssnl_donor_CASE2.RData")
} else{
  set.seed(252525)
  seeds_gamlssnl_donor <- runif(B_out, min = 0, max=1000000)
  outerbootstrap_gamlssnl_donor <- bootstrap(sd=td2pLL_fit_gamlss_nl_donor$sigma.coefficients,
                                                          par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                                          B=B_out,
                                                          time=data_subset$time,
                                                          dose=data_subset$dose,
                                                          donor=data_subset$donor,
                                                          fixtime=4)
  # system.time()
  # user     system elapsed 
  # 111.51    1.63  113.65 
  crit.val_boot_gamlssnl_donor <- critval_boot(outerboot=outerbootstrap_gamlssnl_donor,
                                                           B_in=B_in,
                                                           B_out=B_out,
                                                           sd=td2pLL_fit_gamlss_nl_donor$sigma.coefficients,
                                                           par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                                           time=data_subset$time,
                                                           dose=data_subset$dose,
                                                           donor=data_subset$donor,
                                                           seeds=seeds_gamlssnl_donor,
                                                           fixtime = 4)
  # system.time()
  # user  system elapsed 
  # 6.42    1.79 1014.68 
  crit.val_gamlssnl_donor <- crit.val(crit.val.boot=crit.val_boot_gamlssnl_donor$res                                               ,
                                      alpha=0.05,
                                      fixtime=4)
  conf.band_gamlssnl_donor <- conf.bands(par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                         c=crit.val_gamlssnl_donor, 
                                         outerboot = outerbootstrap_gamlssnl_donor,
                                         fixtime=4)
  
  centered_td2pLL_analysis_gamlssnl_donor_CASE2 <- list("boot"=outerbootstrap_gamlssnl_donor,
                                                        "crit_boot"=crit.val_boot_gamlssnl_donor,
                                                        "crit_val"=crit.val_gamlssnl_donor,
                                                        "conf"=conf.band_gamlssnl_donor)
  save(centered_td2pLL_analysis_gamlssnl_donor_CASE2,
       file="./case_study/centered_td2pLL_analysis_gamlssnl_donor_CASE2.RData")
  
}

min(which(centered_td2pLL_analysis_gamlssnl_donor_CASE2$conf$fix>50))
#57
dose_seq[57]
#5.6

conf_band_mat_gamlssnl_donor <- centered_td2pLL_analysis_gamlssnl_donor_CASE2$conf$full   %>%
  cbind(grid_full, "cf"=. )                %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

min(which(conf_band_mat_gamlssnl_donor[31,]>50))
#57
dose_seq[57]
#5.6

res_td2pLL_CASE2_centered <- c("td2pLL","Case 2","normal",dose_seq[57],dose_seq[57])


#'------------------------------------------------------------------------------
# Analysis (Fixtime 4/Fast) ----
#'------------------------------------------------------------------------------


#CASE 1

sigma_formula <- sigma_formula_case1
sigma_start <- sigma_start_case1
td2pLL_fit_gamlss_nl_donor<-td2pLL_fit_gamlss_nl_donor_case1


#Est conf band
if(file.exists("./case_study/centered_tdpLL_analysis_gamlssnl_donor_fast_CASE1.RData")){
  load("./case_study/centered_tdpLL_analysis_gamlssnl_donor_fast_CASE1.RData")
} else{
  set.seed(27)
  seeds_gamlssnl_donor_fast <- runif(B_out, min = 0, max=1000000)
  outerbootstrap_gamlssnl_donor_fast <- bootstrap(sd=td2pLL_fit_gamlss_nl_donor$sigma.coefficients,
                                                  par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                                  B=B_out,
                                                  time=data_subset$time,
                                                  dose=data_subset$dose,
                                                  donor=data_subset$donor,
                                                  fixtime=4)
  # system.time()
  # user  system elapsed 
  # 69.13    1.23   72.39
  crit.val_boot_gamlssnl_donor_fast <- critval_boot(outerboot=outerbootstrap_gamlssnl_donor_fast,
                                                    B_in=B_in,
                                                    B_out=B_out,
                                                    sd=td2pLL_fit_gamlss_nl_donor$sigma.coefficients,
                                                    par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                                    time=data_subset$time,
                                                    dose=data_subset$dose,
                                                    donor=data_subset$donor,
                                                    seeds=seeds_gamlssnl_donor_fast,
                                                    fixtime = 4,
                                                    fast_in=T)
  # system.time()
  # user  system elapsed 
  # 6.85    2.86  815.22 
  crit.val_gamlssnl_donor_fast <- crit.val(crit.val.boot=crit.val_boot_gamlssnl_donor_fast$res,
                                           alpha=0.05,
                                           fixtime=4)
  conf.band_gamlssnl_donor_fast <- conf.bands(par=td2pLL_fit_gamlss_nl_donor$mu.coefficients, 
                                              c=crit.val_gamlssnl_donor_fast, 
                                              outerboot = outerbootstrap_gamlssnl_donor_fast,
                                              fixtime=4)
  
  centered_td2pLL_analysis_gamlssnl_donor_fast_CASE1  <- list("boot"=outerbootstrap_gamlssnl_donor_fast,
                                              "crit_boot"=crit.val_boot_gamlssnl_donor_fast,
                                              "crit_val"=crit.val_gamlssnl_donor_fast,
                                              "conf"=conf.band_gamlssnl_donor_fast)
  save(centered_td2pLL_analysis_gamlssnl_donor_fast_CASE1 ,
       file="./case_study/centered_tdpLL_analysis_gamlssnl_donor_fast_CASE1.RData")
  
}


min(which(centered_td2pLL_analysis_gamlssnl_donor_fast_CASE1$conf$fix>50))
#63
dose_seq[63]
#6.2

conf_band_mat_gamlssnl_donor <- centered_td2pLL_analysis_gamlssnl_donor_fast_CASE1$conf$full   %>%
  cbind(grid_full, "cf"=. )                %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

min(which(conf_band_mat_gamlssnl_donor[31,]>50))
#67
dose_seq[67]
#6.6

res_td2pLL_CASE1_centered_fast <- c("td2pLL","Case 1","fast",dose_seq[63],dose_seq[67])





#CASE 2

sigma_formula <- sigma_formula_case2
sigma_start <- sigma_start_case2
td2pLL_fit_gamlss_nl_donor<-td2pLL_fit_gamlss_nl_donor_case2


#Est conf band
if(file.exists("./case_study/centered_tdpLL_analysis_gamlssnl_donor_fast_CASE2.RData")){
  load("./case_study/centered_tdpLL_analysis_gamlssnl_donor_fast_CASE2.RData")
} else{
  set.seed(272727)
  seeds_gamlssnl_donor_fast <- runif(B_out, min = 0, max=1000000)
  outerbootstrap_gamlssnl_donor_fast <- bootstrap(sd=td2pLL_fit_gamlss_nl_donor$sigma.coefficients,
                                                              par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                                              B=B_out,
                                                              time=data_subset$time,
                                                              dose=data_subset$dose,
                                                              donor=data_subset$donor,
                                                              fixtime=4)
  # system.time()
  # user  system elapsed 
  # 159.55    1.84  162.17  
  crit.val_boot_gamlssnl_donor_fast <- critval_boot(outerboot=outerbootstrap_gamlssnl_donor_fast,
                                                                B_in=B_in,
                                                                B_out=B_out,
                                                                sd=td2pLL_fit_gamlss_nl_donor$sigma.coefficients,
                                                                par=td2pLL_fit_gamlss_nl_donor$mu.coefficients,
                                                                time=data_subset$time,
                                                                dose=data_subset$dose,
                                                                donor=data_subset$donor,
                                                                seeds=seeds_gamlssnl_donor_fast,
                                                                fixtime = 4,
                                                                fast_in=T)
  # system.time()
  # user  system elapsed 
  #  7.20    3.24 1002.44  
  crit.val_gamlssnl_donor_fast <- crit.val(crit.val.boot=crit.val_boot_gamlssnl_donor_fast$res,
                                           alpha=0.05,
                                           fixtime=4)
  conf.band_gamlssnl_donor_fast <- conf.bands(par=td2pLL_fit_gamlss_nl_donor$mu.coefficients, 
                                              c=crit.val_gamlssnl_donor_fast, 
                                              outerboot = outerbootstrap_gamlssnl_donor_fast,
                                              fixtime=4)
  
  centered_td2pLL_analysis_gamlssnl_donor_fast_CASE2 <- list("boot"=outerbootstrap_gamlssnl_donor_fast,
                                                             "crit_boot"=crit.val_boot_gamlssnl_donor_fast,
                                                             "crit_val"=crit.val_gamlssnl_donor_fast,
                                                             "conf"=conf.band_gamlssnl_donor_fast)
  save(centered_td2pLL_analysis_gamlssnl_donor_fast_CASE2,
       file="./case_study/centered_tdpLL_analysis_gamlssnl_donor_fast_CASE2.RData")
  
}


min(which(centered_td2pLL_analysis_gamlssnl_donor_fast_CASE2$conf$fix>50))
#55
dose_seq[55]
#5.4

conf_band_mat_gamlssnl_donor <- centered_td2pLL_analysis_gamlssnl_donor_fast_CASE2$conf$full   %>%
  cbind(grid_full, "cf"=. )                %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

min(which(conf_band_mat_gamlssnl_donor[31,]>50))
#56
dose_seq[56]
#5.5


res_td2pLL_CASE2_centered_fast <- c("td2pLL","Case 2","fast",dose_seq[55],dose_seq[56])


#'==============================================================================
#'Analysis with schuettler formula ====
#'==============================================================================

model <- schuettler

fit_fast <- schuettler_fast

mu_formula <- schuettler_formula

#'------------------------------------------------------------------------------
# Basic model fit ----
#'------------------------------------------------------------------------------

#Investigate fitting start parameters
fit_schuettler <- nlsLM(resp ~ log2FC_max/(                         #Use basic model fit
  1+exp(
    -slope*(
      log(dose)-log(
        1/(
          S_max*exp(
            -0.5*(
              (log(time)-log(t_max))/S_dur
            )^2
          )
        )
      )
    )
  )
),
data = data_subset,
start = list(log2FC_max=100,slope = -3, S_max = 0.2, t_max = 5.5, S_dur = 1.4) )
summary(fit_schuettler)                                       

mu_start <- list(log2FC_max=100,slope = -3, S_max=0.2,t_max=7, S_dur=1.5)


#'------------------------------------------------------------------------------
# Basic sd model fit  ----
#'------------------------------------------------------------------------------

#Prepare data set
data_subset_sd <- data_subset          %>%      #combine data via sd
  group_by(time,dose,donor)            %>%
  summarize(resp_sd=sd(resp))

#CASE 1: Constant
sigma_formula_case1 <- ~1
#identify starting values for constant case
error_model <- glm(                             #estimate error model with glm 
  resp_sd ~ 1,
  family = gaussian(link = "log"),              #Log-Link 
  data = data_subset_sd
)
summary(error_model)                            #start parameters for sd 

sigma_start_case1 <- coef(error_model)

#Fit gamlss
schuettler_fit_gamlss_nl_donor_case1 <-nlgamlss( y= resp,
                                                 mu.fo = mu_formula, 
                                                 sigma.fo = sigma_formula_case1,
                                                 mu.start = mu_start,                         
                                                 sigma.start = sigma_start_case1,                                                 # Startwerte für sigma
                                                 family = NO(),                                                                  # Normalverteilung
                                                 data = data_subset
)

schuettler_fit_gamlss_nl_donor_case1$aic
#2137.68


#CASE 2: From Duda et al
sigma_formula_case2 <- ~ dose+I(dose^2)+time+I(dose^2):time
#identify starting values for constant case
error_model <- glm(                             #estimate error model with glm 
  resp_sd ~ dose+I(dose^2)+time+I(dose^2):time,
  family = gaussian(link = "log"),              #Log-Link 
  data = data_subset_sd
)
summary(error_model)                            #start parameters for sd 

sigma_start_case2 <- coef(error_model)

#Fit gamlss
schuettler_fit_gamlss_nl_donor_case2 <-nlgamlss( y= resp,
                                                 mu.fo = mu_formula, 
                                                 sigma.fo = sigma_formula_case2,
                                                 mu.start = mu_start,                         
                                                 sigma.start = sigma_start_case2,                                                 # Startwerte für sigma
                                                 family = NO(),                                                                  # Normalverteilung
                                                 data = data_subset
)

schuettler_fit_gamlss_nl_donor_case2$aic
#2125.422




#'------------------------------------------------------------------------------
# Analysis (Fixtime 4) ----
#'------------------------------------------------------------------------------

#CASE 1

sigma_formula <- sigma_formula_case1
sigma_start <- sigma_start_case1
schuettler_fit_gamlss_nl_donor<-schuettler_fit_gamlss_nl_donor_case1


#Est conf band
if(file.exists("./case_study/centered_schuettler_analysis_gamlssnl_donor_CASE1.RData")){
  load("./case_study/centered_schuettler_analysis_gamlssnl_donor_CASE1.RData")
} else{
  set.seed(211)
  seeds_gamlssnl_donor <- runif(B_out, min = 0, max=1000000)
  outerbootstrap_gamlssnl_donor <- bootstrap(sd=schuettler_fit_gamlss_nl_donor$sigma.coefficients,
                                             par=schuettler_fit_gamlss_nl_donor$mu.coefficients,
                                             B=B_out,
                                             time=data_subset$time,
                                             dose=data_subset$dose,
                                             donor=data_subset$donor,
                                             fixtime=4)
  # system.time()
  # user  system elapsed 
  # 102.71    0.59  103.95  
  crit.val_boot_gamlssnl_donor <- critval_boot(outerboot=outerbootstrap_gamlssnl_donor,
                                               B_in=B_in,
                                               B_out=B_out,
                                               sd=schuettler_fit_gamlss_nl_donor$sigma.coefficients,
                                               par=schuettler_fit_gamlss_nl_donor$mu.coefficients,
                                               time=data_subset$time,
                                               dose=data_subset$dose,
                                               donor=data_subset$donor,
                                               seeds=seeds_gamlssnl_donor,
                                               fixtime = 4)
  # system.time()
  # user  system elapsed 
  # 5.99    1.84  585.30  
  crit.val_gamlssnl_donor <- crit.val(crit.val.boot=crit.val_boot_gamlssnl_donor$res,
                                      alpha=0.05,
                                      fixtime=4)
  conf.band_gamlssnl_donor <- conf.bands(par=schuettler_fit_gamlss_nl_donor$mu.coefficients, 
                                         c=crit.val_gamlssnl_donor, 
                                         outerboot = outerbootstrap_gamlssnl_donor,
                                         fixtime=4)
  
  centered_schuettler_analysis_gamlssnl_donor_CASE1 <- list("boot"=outerbootstrap_gamlssnl_donor,
                                           "crit_boot"=crit.val_boot_gamlssnl_donor,
                                           "crit_val"=crit.val_gamlssnl_donor,
                                           "conf"=conf.band_gamlssnl_donor)
  save(centered_schuettler_analysis_gamlssnl_donor_CASE1,
       file="./case_study/centered_schuettler_analysis_gamlssnl_donor_CASE1.RData")
  
}


min(which(centered_schuettler_analysis_gamlssnl_donor_CASE1$conf$fix>50))
#67
dose_seq[67]
#6.6

conf_band_mat_gamlssnl_donor <- centered_schuettler_analysis_gamlssnl_donor_CASE1$conf$full   %>%
  cbind(grid_full, "cf"=. )                %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

min(which(conf_band_mat_gamlssnl_donor[31,]>50))
#70
dose_seq[70]
#6.9

res_schuettler_CASE1_centered <- c("schuettler","Case 1","normal",dose_seq[67],dose_seq[70])


#CASE 2

sigma_formula <- sigma_formula_case2
sigma_start <- sigma_start_case2
schuettler_fit_gamlss_nl_donor<-schuettler_fit_gamlss_nl_donor_case2


#Est conf band
if(file.exists("./case_study/centered_schuettler_analysis_gamlssnl_donor_CASE2.RData")){
  load("./case_study/centered_schuettler_analysis_gamlssnl_donor_CASE2.RData")
} else{
  set.seed(211211211)
  seeds_gamlssnl_donor <- runif(B_out, min = 0, max=1000000)
  outerbootstrap_gamlssnl_donor <- bootstrap(sd=schuettler_fit_gamlss_nl_donor$sigma.coefficients,
                                                         par=schuettler_fit_gamlss_nl_donor$mu.coefficients,
                                                         B=B_out,
                                                         time=data_subset$time,
                                                         dose=data_subset$dose,
                                                         donor=data_subset$donor,
                                                         fixtime=4)
  # system.time()
  # user  system elapsed 
  # 89.70    1.23   91.28  
  crit.val_boot_gamlssnl_donor <- critval_boot(outerboot=outerbootstrap_gamlssnl_donor,
                                                           B_in=B_in,
                                                           B_out=B_out,
                                                           sd=schuettler_fit_gamlss_nl_donor$sigma.coefficients,
                                                           par=schuettler_fit_gamlss_nl_donor$mu.coefficients,
                                                           time=data_subset$time,
                                                           dose=data_subset$dose,
                                                           donor=data_subset$donor,
                                                           seeds=seeds_gamlssnl_donor,
                                                           fixtime = 4)
  # system.time()
  # user  system elapsed 
  # .49    1.74  729.04 
  crit.val_gamlssnl_donor <- crit.val(crit.val.boot=crit.val_boot_gamlssnl_donor$res,
                                      alpha=0.05,
                                      fixtime=4)
  conf.band_gamlssnl_donor <- conf.bands(par=schuettler_fit_gamlss_nl_donor$mu.coefficients, 
                                         c=crit.val_gamlssnl_donor, 
                                         outerboot = outerbootstrap_gamlssnl_donor,
                                         fixtime=4)
  
  centered_schuettler_analysis_gamlssnl_donor_CASE2 <- list("boot"=outerbootstrap_gamlssnl_donor,
                                                            "crit_boot"=crit.val_boot_gamlssnl_donor,
                                                            "crit_val"=crit.val_gamlssnl_donor,
                                                            "conf"=conf.band_gamlssnl_donor)
  save(centered_schuettler_analysis_gamlssnl_donor_CASE2,
       file="./case_study/centered_schuettler_analysis_gamlssnl_donor_CASE2.RData")
  
}


min(which(centered_schuettler_analysis_gamlssnl_donor_CASE2$conf$fix>50))
#55
dose_seq[55]
#5.4

conf_band_mat_gamlssnl_donor <- centered_schuettler_analysis_gamlssnl_donor_CASE2$conf$full   %>%
  cbind(grid_full, "cf"=. )                %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

min(which(conf_band_mat_gamlssnl_donor[31,]>50))
#56
dose_seq[56]
#5.5

res_schuettler_CASE2_centered <- c("schuettler","Case 2","normal",dose_seq[55],dose_seq[56])


#'------------------------------------------------------------------------------
# Analysis (Fixtime 4/Fast)  ----
#'------------------------------------------------------------------------------


#CASE 1

sigma_formula <- sigma_formula_case1
sigma_start <- sigma_start_case1
schuettler_fit_gamlss_nl_donor<-schuettler_fit_gamlss_nl_donor_case1


#Est conf band
if(file.exists("./case_study/centered_schuettler_analysis_gamlssnl_donor_fast_CASE1.RData")){
  load("./case_study/centered_schuettler_analysis_gamlssnl_donor_fast_CASE1.RData")
} else{
  set.seed(213)
  seeds_gamlssnl_donor_fast <- runif(B_out, min = 0, max=1000000)
  outerbootstrap_gamlssnl_donor_fast <- bootstrap(sd=schuettler_fit_gamlss_nl_donor$sigma.coefficients,
                                                  par=schuettler_fit_gamlss_nl_donor$mu.coefficients,
                                                  B=B_out,
                                                  time=data_subset$time,
                                                  dose=data_subset$dose,
                                                  donor=data_subset$donor,
                                                  fixtime=4)
  # system.time()
  # user  system elapsed 
  #  53.33    0.83   54.56  
  crit.val_boot_gamlssnl_donor_fast <- critval_boot(outerboot=outerbootstrap_gamlssnl_donor_fast,
                                                    B_in=B_in,
                                                    B_out=B_out,
                                                    sd=schuettler_fit_gamlss_nl_donor$sigma.coefficients,
                                                    par=schuettler_fit_gamlss_nl_donor$mu.coefficients,
                                                    time=data_subset$time,
                                                    dose=data_subset$dose,
                                                    donor=data_subset$donor,
                                                    seeds=seeds_gamlssnl_donor_fast,
                                                    fixtime = 4,
                                                    fast_in=T)
  # system.time()
  # user  system elapsed 
  # 5.64    1.47  460.09 
  crit.val_gamlssnl_donor_fast <- crit.val(crit.val.boot=crit.val_boot_gamlssnl_donor_fast$res,
                                           alpha=0.05,
                                           fixtime=4)
  conf.band_gamlssnl_donor_fast <- conf.bands(par=schuettler_fit_gamlss_nl_donor$mu.coefficients, 
                                              c=crit.val_gamlssnl_donor_fast, 
                                              outerboot = outerbootstrap_gamlssnl_donor_fast,
                                              fixtime=4)
  
  centered_schuettler_analysis_gamlssnl_donor_fast_CASE1 <- list("boot"=outerbootstrap_gamlssnl_donor_fast,
                                                "crit_boot"=crit.val_boot_gamlssnl_donor_fast,
                                                "crit_val"=crit.val_gamlssnl_donor_fast,
                                                "conf"=conf.band_gamlssnl_donor_fast)
  save(centered_schuettler_analysis_gamlssnl_donor_fast_CASE1,
       file="./case_study/centered_schuettler_analysis_gamlssnl_donor_fast_CASE1.RData")
  
}


min(which(centered_schuettler_analysis_gamlssnl_donor_fast_CASE1$conf$fix>50))
#66
dose_seq[66]
#6.5

conf_band_mat_gamlssnl_donor <- centered_schuettler_analysis_gamlssnl_donor_fast_CASE1$conf$full   %>%
  cbind(grid_full, "cf"=. )                %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

min(which(conf_band_mat_gamlssnl_donor[31,]>50))
#69
dose_seq[69]
#6.8

res_schuettler_CASE1_centered_fast <- c("schuettler","Case 1","fast",dose_seq[66],dose_seq[69])




#CASE 2

sigma_formula <- sigma_formula_case2
sigma_start <- sigma_start_case2
schuettler_fit_gamlss_nl_donor<-schuettler_fit_gamlss_nl_donor_case2


#Est conf band
if(file.exists("./case_study/centered_schuettler_analysis_gamlssnl_donor_fast_CASE2.RData")){
  load("./case_study/centered_schuettler_analysis_gamlssnl_donor_fast_CASE2.RData")
} else{
  set.seed(213213213)
  seeds_gamlssnl_donor_fast <- runif(B_out, min = 0, max=1000000)
  outerbootstrap_gamlssnl_donor_fast <- bootstrap(sd=schuettler_fit_gamlss_nl_donor$sigma.coefficients,
                                                              par=schuettler_fit_gamlss_nl_donor$mu.coefficients,
                                                              B=B_out,
                                                              time=data_subset$time,
                                                              dose=data_subset$dose,
                                                              donor=data_subset$donor,
                                                              fixtime=4)
  # system.time()
  # user  system elapsed 
  # 88.43    1.41   90.43 
  crit.val_boot_gamlssnl_donor_fast <- critval_boot(outerboot=outerbootstrap_gamlssnl_donor_fast,
                                                                B_in=B_in,
                                                                B_out=B_out,
                                                                sd=schuettler_fit_gamlss_nl_donor$sigma.coefficients,
                                                                par=schuettler_fit_gamlss_nl_donor$mu.coefficients,
                                                                time=data_subset$time,
                                                                dose=data_subset$dose,
                                                                donor=data_subset$donor,
                                                                seeds=seeds_gamlssnl_donor_fast,
                                                                fixtime = 4,
                                                                fast_in=T)
  # system.time()
  # user  system elapsed 
  # 5.65    1.66  417.33  
  crit.val_gamlssnl_donor_fast <- crit.val(crit.val.boot=crit.val_boot_gamlssnl_donor_fast$res,
                                           alpha=0.05,
                                           fixtime=4)
  conf.band_gamlssnl_donor_fast <- conf.bands(par=schuettler_fit_gamlss_nl_donor$mu.coefficients, 
                                              c=crit.val_gamlssnl_donor_fast, 
                                              outerboot = outerbootstrap_gamlssnl_donor_fast,
                                              fixtime=4)
  
  centered_schuettler_analysis_gamlssnl_donor_fast_CASE2 <- list("boot"=outerbootstrap_gamlssnl_donor_fast,
                                                                 "crit_boot"=crit.val_boot_gamlssnl_donor_fast,
                                                                 "crit_val"=crit.val_gamlssnl_donor_fast,
                                                                 "conf"=conf.band_gamlssnl_donor_fast)
  save(centered_schuettler_analysis_gamlssnl_donor_fast_CASE2,
       file="./case_study/centered_schuettler_analysis_gamlssnl_donor_fast_CASE2.RData")
  
}


min(which(centered_schuettler_analysis_gamlssnl_donor_fast_CASE2$conf$fix>50))
#53
dose_seq[53]
#5.2

conf_band_mat_gamlssnl_donor <- centered_schuettler_analysis_gamlssnl_donor_fast_CASE2$conf$full   %>%
  cbind(grid_full, "cf"=. )                %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="cf")

min(which(conf_band_mat_gamlssnl_donor[31,]>50))
#54
dose_seq[54]
#5.3


res_schuettler_CASE2_centered_fast <- c("schuettler","Case 2","fast",dose_seq[53],dose_seq[54])


#'==============================================================================
# Combine results in table ====
#'==============================================================================
#Note, that case 1 assumes constant standard deviation and therefore the normal
#and fast assumptions are identical
#Both were run to control the algorithm
#In the paper, these results are not presented, but used for the example plot

res_case_study_centered <- rbind(res_td2pLL_CASE1_centered,
                                 res_td2pLL_CASE1_centered_fast,
                                 res_td2pLL_CASE2_centered,
                                 res_td2pLL_CASE2_centered_fast,
                                res_schuettler_CASE1_centered,
                                res_schuettler_CASE1_centered_fast,
                                res_schuettler_CASE2_centered,
                                res_schuettler_CASE2_centered_fast)

colnames(res_case_study_centered) <- c("Model","Case","Algorithm","2D alert","3D alert")
rownames(res_case_study_centered) <- NULL
write.xlsx(res_case_study_centered,"./plots_tables/101_res_case_study_centered.xlsx", rowNames = FALSE)

