#'##############################################################################
#                                                                              #
#                  Corresponding R Code to the Manuscript                      #
#                "Estimating effect thresholds and beyond:                     #
#              A flexible framework for multivariate alert detection"          #
#                                                                              #
#                                 Authors                                      #
#                    L. Ameis, N. Hagemann and K. Moellenhoff                  #
#                                                                              #
#                               Data Preparation                               #
#                                                                              #
#'##############################################################################

#'==============================================================================
# Load data set and specific compound ====
#'==============================================================================
data(cytotox)                             #load data

data_subset <- cytotox    %>%             #From all data 
  filter(compound=="ASP") %>%             #Select compound
  dplyr::select(donor,time=expo,dose,resp)#Select only columns of interest 


donor_all <- data_subset$donor            #vector with information regarding
                                          #donors

#generate data set with donor means

data_subset_reduced <- data_subset %>%
                       group_by(time,dose,donor) %>%
                       summarize(resp=mean(resp))

#'------------------------------------------------------------------------------
## Save examples as templates ----
#'------------------------------------------------------------------------------
#we export the example data sets as templates for the simulation analysis
#as we run them on a server
Scenario1_designtemplates <- list("full"=data_subset,
                                  "reduced"=data_subset_reduced)
# save(Scenario1_designtemplates,file="./simulation/simulated_data/Scenario1_designtemplates.RData")
#'==============================================================================
# Store data specific information ====
#'==============================================================================
#store study dependent data for later use
#time
min_time <- 1
max_time <- 7

#dose
min_dose <- 0
max_dose <- 10

#fineness of the grid
epsilon <- 0.1



#create the grid
time_seq <- seq(min_time, max_time, by=epsilon)   #time
dose_seq <- seq(min_dose, max_dose, by=epsilon)   #dose

grid_full      <- data.frame("time"=rep(time_seq, times=length(dose_seq)))
grid_dose <- numeric(length=length(time_seq)*length(dose_seq))
for(i in 1:length(dose_seq)){
  grid_dose[((i-1)*length(time_seq)+1):(i*length(time_seq))] <- rep(dose_seq[i],  times=length(time_seq))
}
grid_full$dose <- grid_dose


#'==============================================================================
# Store analysis specific information ====
#'==============================================================================
B_out<-500
B_in<-25

Threshold <-  grid_full                                    %>%
  cbind(.,"th"=rep(50,times=nrow(grid_full)))  %>%
  reshape2::acast(., 
                  time~dose, 
                  value.var="th")
                


#'==============================================================================
# Checking the influence of the donor on the sd ====
#'==============================================================================

#Prepare data set
data_subset_sd <- data_subset          %>%      #combine data via sd
  group_by(time,dose,donor)            %>%
  summarize(resp_sd=sd(resp))



#Preparation: Checking the effect of the donors
sigma_formula_donor <- ~donor
#identify starting values for constant case
error_model <- glm(                             #estimate error model with glm 
  resp_sd ~ donor,
  family = gaussian(link = "log"),              #Log-Link 
  data = data_subset_sd
)
summary(error_model)                            #start parameters for sd 
#There is no significant influence beyond the Intercept
#We therefore assume, that we can ignore the repeated measurements
